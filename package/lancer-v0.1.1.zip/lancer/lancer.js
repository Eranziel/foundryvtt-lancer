// Namespace configuration Values
const LANCER = {};
LANCER.ASCII = `
╭╮╱╱╭━━━┳━╮╱╭┳━━━┳━━━┳━━━╮ 
┃┃╱╱┃╭━╮┃┃╰╮┃┃╭━╮┃╭━━┫╭━╮┃ 
┃┃╱╱┃┃╱┃┃╭╮╰╯┃┃╱╰┫╰━━┫╰━╯┃ 
┃┃╱╭┫╰━╯┃┃╰╮┃┃┃╱╭┫╭━━┫╭╮╭╯ 
┃╰━╯┃╭━╮┃┃╱┃┃┃╰━╯┃╰━━┫┃┃╰╮ 
╰━━━┻╯╱╰┻╯╱╰━┻━━━┻━━━┻╯╰━╯`;
LANCER.log_prefix = 'LANCER |';
LANCER.pilot_items = ["frame", "skill", "talent", "core_bonus", "license", "pilot_armor", "pilot_weapon", "pilot_gear", "mech_weapon", "mech_system"];
LANCER.npc_items = ["npc_class", "npc_template", "npc_feature"];
LANCER.weapon_items = ["mech_weapon", "pilot_weapon", "npc_feature"];

const lp = LANCER.log_prefix;
function lancerActorInit(data) {
    console.log(`${lp} Initializing new ${data.type}`);
    if (data.type === "pilot" || data.type === "npc") {
        const mech = {
            name: "",
            size: 1,
            hull: 0,
            agility: 0,
            systems: 0,
            engineering: 0,
            hp: { min: 0, max: 0, value: 0 },
            structure: { min: 0, max: 4, value: 4 },
            heat: { min: 0, max: 0, value: 0 },
            stress: { min: 0, max: 4, value: 4 },
            repairs: { min: 0, max: 0, value: 0 },
            armor: 0,
            speed: 0,
            evasion: 0,
            edef: 0,
            sensors: 0,
            save: 0,
            tech_attack: 0,
        };
        if (data.type === "npc") {
            mech.structure.value = 1;
            mech.structure.max = 1;
            mech.stress.value = 1;
            mech.stress.max = 1;
        }
        mergeObject(data, {
            // Initialize mech stats
            "data.mech": mech,
            // Initialize prototype token
            "token.bar1": { "attribute": "mech.hp" },
            "token.bar2": { "attribute": "mech.heat" },
            "token.displayName": CONST.TOKEN_DISPLAY_MODES.ALWAYS,
            "token.displayBars": CONST.TOKEN_DISPLAY_MODES.ALWAYS,
            // Default disposition to friendly for pilots and hostile for NPCs
            "token.disposition": data.type === "pilot" ? CONST.TOKEN_DISPOSITIONS.FRIENDLY : CONST.TOKEN_DISPOSITIONS.HOSTILE,
            "token.name": data.name,
            "token.actorLink": data.type === "pilot",
        });
    }
    else if (data.type === "deployable") {
        mergeObject(data, {
            // Initialize image
            "img": 'systems/lancer/assets/icons/deployable.svg',
            // Initialize prototype token
            "token.bar1": { "attribute": "hp" },
            "token.displayName": CONST.TOKEN_DISPLAY_MODES.HOVER,
            "token.displayBars": CONST.TOKEN_DISPLAY_MODES.HOVER,
            "token.name": data.name,
        });
    }
}
/**
 * Extend the Actor class for Lancer Actors.
 */
class LancerActor extends Actor {
    /**
     * Change mech frames for a pilot. Recalculates all mech-related stats on the pilot.
     * @param newFrame Stats object from the new mech frame.
     * @param oldFrame Stats object from the old mech frame, optional.
     */
    swapFrames(newFrame, oldFrame) {
        // Function is only applicable to pilots.
        if (this.data.type !== "pilot")
            return;
        const data = duplicate(this.data);
        const mech = duplicate(this.data.data.mech);
        if (!oldFrame) {
            oldFrame = {
                size: 0,
                armor: 0,
                hp: 0,
                evasion: 0,
                edef: 0,
                heatcap: 0,
                repcap: 0,
                sensor_range: 0,
                tech_attack: 0,
                save: 0,
                speed: 0,
                sp: 0,
            };
        }
        // Resources
        mech.hp.max = mech.hp.max - oldFrame.hp + newFrame.hp;
        mech.hp.value = Math.min(mech.hp.value, mech.hp.max);
        mech.heat.max = mech.heat.max - oldFrame.heatcap + newFrame.heatcap;
        mech.heat.value = Math.min(mech.heat.value, mech.heat.max);
        mech.repairs.max = mech.repairs.max - oldFrame.repcap + newFrame.repcap;
        mech.repairs.value = Math.min(mech.repairs.value, mech.repairs.max);
        // Stats
        mech.size = mech.size - oldFrame.size + newFrame.size;
        mech.armor = Math.max(mech.armor - oldFrame.armor + newFrame.armor, 0);
        mech.speed = mech.speed - oldFrame.speed + newFrame.speed;
        mech.evasion = mech.evasion - oldFrame.evasion + newFrame.evasion;
        mech.edef = mech.edef - oldFrame.edef + newFrame.edef;
        mech.sensors = mech.sensors - oldFrame.sensor_range + newFrame.sensor_range;
        mech.save = mech.save - oldFrame.save + newFrame.save;
        mech.tech_attack = mech.tech_attack - oldFrame.tech_attack + newFrame.tech_attack;
        mech.sp = mech.sp - oldFrame.sp + newFrame.sp;
        // Update the actor
        data.data.mech = mech;
        return this.update(data);
    }
    /**
    * Change Class or Tier on a NPC. Recalculates all stats on the NPC.
    * @param newNPCClass Stats object from the new Class.
    */
    swapNPCClassOrTier(newNPCClass, ClassSwap, tier) {
        // Function is only applicable to NPCs.
        if (this.data.type !== "npc")
            return;
        let data = duplicate(this.data);
        const mech = duplicate(this.data.data.mech);
        if (ClassSwap) {
            data.data.tier = "npc-tier-1";
            tier = "npc-tier-1";
        }
        let i = 0;
        data.data.tier_num = 1;
        switch (tier) {
            case "npc-tier-custom":
                data.data.tier_num = 4;
                return this.update(data);
            case "npc-tier-2":
                data.data.tier_num = 2;
                i = 1;
                break;
            case "npc-tier-3":
                data.data.tier_num = 3;
                i = 2;
        }
        console.log(`LANCER| Swapping to Tier ${data.data.tier_num}`);
        //HASE
        mech.hull = newNPCClass.hull[i];
        mech.agility = newNPCClass.agility[i];
        mech.systems = newNPCClass.systems[i];
        mech.engineering = newNPCClass.engineering[i];
        // Resources
        mech.hp.max = newNPCClass.hp[i];
        mech.hp.value = mech.hp.max;
        mech.heat.max = newNPCClass.heatcap[i];
        mech.heat.value = 0;
        if (Array.isArray(newNPCClass.structure) && newNPCClass.structure[i]) {
            mech.structure.max = newNPCClass.structure[i];
            mech.structure.value = mech.structure.max;
        }
        else {
            mech.structure.max = 1;
            mech.structure.value = 1;
        }
        if (Array.isArray(newNPCClass.stress) && newNPCClass.stress[i]) {
            mech.stress.max = newNPCClass.stress[i];
            mech.stress.value = mech.stress.max;
        }
        else {
            mech.stress.max = 1;
            mech.stress.value = 1;
        }
        // Stats
        mech.size = newNPCClass.size[i];
        mech.armor = newNPCClass.armor[i];
        mech.speed = newNPCClass.speed[i];
        mech.evasion = newNPCClass.evasion[i];
        mech.edef = newNPCClass.edef[i];
        mech.sensors = newNPCClass.sensor_range[i];
        mech.save = newNPCClass.save[i];
        if (Array.isArray(newNPCClass.size) && newNPCClass.size[i]) {
            mech.size = newNPCClass.size[i];
            if (newNPCClass.size[i] === 0.5) {
                data.data.npc_size = "size-half";
            }
            else {
                data.data.npc_size = `size-${newNPCClass.size[i]}`;
            }
        }
        else {
            mech.size = 1;
            data.data.npc_size = `size-1`;
        }
        data.data.activations = newNPCClass.activations[i];
        // Update the actor
        data.data.mech = mech;
        return this.update(data);
    }
}

var MountType;
(function (MountType) {
    MountType["Main"] = "Main";
    MountType["Heavy"] = "Heavy";
    MountType["AuxAux"] = "Aux/Aux";
    MountType["Aux"] = "Aux";
    MountType["MainAux"] = "Main/Aux";
    MountType["Flex"] = "Flex";
    MountType["Integrated"] = "Integrated";
})(MountType || (MountType = {}));
var WeaponSize;
(function (WeaponSize) {
    WeaponSize["Aux"] = "Auxiliary";
    WeaponSize["Main"] = "Main";
    WeaponSize["Heavy"] = "Heavy";
    WeaponSize["Superheavy"] = "Superheavy";
})(WeaponSize || (WeaponSize = {}));
var WeaponType;
(function (WeaponType) {
    WeaponType["Rifle"] = "Rifle";
    WeaponType["Cannon"] = "Cannon";
    WeaponType["Launcher"] = "Launcher";
    WeaponType["CQB"] = "CQB";
    WeaponType["Nexus"] = "Nexus";
    WeaponType["Melee"] = "Melee";
})(WeaponType || (WeaponType = {}));
var ItemType;
(function (ItemType) {
    ItemType["None"] = "";
    ItemType["Action"] = "Action";
    ItemType["CoreBonus"] = "CoreBonus";
    ItemType["Frame"] = "Frame";
    ItemType["PilotArmor"] = "PilotArmor";
    ItemType["PilotWeapon"] = "PilotWeapon";
    ItemType["PilotGear"] = "PilotGear";
    ItemType["Skill"] = "Skill";
    ItemType["Talent"] = "Talent";
    ItemType["Tag"] = "Tag";
    ItemType["MechWeapon"] = "MechWeapon";
    ItemType["MechSystem"] = "MechSystem";
    ItemType["WeaponMod"] = "WeaponMod";
    ItemType["NpcFeature"] = "NpcFeature";
})(ItemType || (ItemType = {}));
var PilotEquipType;
(function (PilotEquipType) {
    PilotEquipType["PilotArmor"] = "armor";
    PilotEquipType["PilotWeapon"] = "weapon";
    PilotEquipType["PilotGear"] = "gear";
})(PilotEquipType || (PilotEquipType = {}));
var SystemType;
(function (SystemType) {
    SystemType["System"] = "System";
    SystemType["AI"] = "AI";
    SystemType["Shield"] = "Shield";
    SystemType["Deployable"] = "Deployable";
    SystemType["Drone"] = "Drone";
    SystemType["Tech"] = "Tech";
    SystemType["Armor"] = "Armor";
    SystemType["FlightSystem"] = "Flight System";
    SystemType["Integrated"] = "Integrated";
    SystemType["Mod"] = "Mod";
})(SystemType || (SystemType = {}));
var RangeType;
(function (RangeType) {
    RangeType["Range"] = "Range";
    RangeType["Threat"] = "Threat";
    RangeType["Thrown"] = "Thrown";
    RangeType["Line"] = "Line";
    RangeType["Cone"] = "Cone";
    RangeType["Blast"] = "Blast";
    RangeType["Burst"] = "Burst";
})(RangeType || (RangeType = {}));
var DamageType;
(function (DamageType) {
    DamageType["Kinetic"] = "Kinetic";
    DamageType["Energy"] = "Energy";
    DamageType["Explosive"] = "Explosive";
    DamageType["Heat"] = "Heat";
    DamageType["Burn"] = "Burn";
    DamageType["Variable"] = "Variable";
})(DamageType || (DamageType = {}));
var EffectType;
(function (EffectType) {
    EffectType["Generic"] = "Generic";
    EffectType["Basic"] = "Basic";
    EffectType["Charge"] = "Charge";
    EffectType["Deployable"] = "Deployable";
    EffectType["AI"] = "AI";
    EffectType["Protocol"] = "Protocol";
    EffectType["Reaction"] = "Reaction";
    EffectType["Tech"] = "Tech";
    EffectType["Drone"] = "Drone";
    EffectType["Bonus"] = "Bonus";
    EffectType["Offensive"] = "Offensive";
    EffectType["Profile"] = "Profile";
})(EffectType || (EffectType = {}));
var ActivationType;
(function (ActivationType) {
    ActivationType["None"] = "None";
    ActivationType["Passive"] = "Passive";
    ActivationType["Quick"] = "Quick";
    ActivationType["Full"] = "Full";
    ActivationType["Other"] = "Other";
    ActivationType["Reaction"] = "Reaction";
    ActivationType["Protocol"] = "Protocol";
})(ActivationType || (ActivationType = {}));
var ChargeType;
(function (ChargeType) {
    ChargeType["Grenade"] = "Grenade";
    ChargeType["Mine"] = "Mine";
})(ChargeType || (ChargeType = {}));
var MechType;
(function (MechType) {
    MechType["Balanced"] = "Balanced";
    MechType["Artillery"] = "Artillery";
    MechType["Striker"] = "Striker";
    MechType["Controller"] = "Controller";
    MechType["Support"] = "Support";
    MechType["Defender"] = "Defender";
})(MechType || (MechType = {}));
var HASE;
(function (HASE) {
    HASE["H"] = "hull";
    HASE["A"] = "agi";
    HASE["S"] = "sys";
    HASE["E"] = "eng";
})(HASE || (HASE = {}));
var NPCTag;
(function (NPCTag) {
    NPCTag["Mech"] = "Mech";
    NPCTag["Vehicle"] = "Vehicle";
    NPCTag["Ship"] = "Ship";
    NPCTag["Biological"] = "Biological";
    NPCTag["Squad"] = "Squad";
})(NPCTag || (NPCTag = {}));
var NPCFeatureType;
(function (NPCFeatureType) {
    NPCFeatureType["Trait"] = "Trait";
    NPCFeatureType["System"] = "System";
    NPCFeatureType["Reaction"] = "Reaction";
    NPCFeatureType["Weapon"] = "Weapon";
    NPCFeatureType["Tech"] = "Tech";
})(NPCFeatureType || (NPCFeatureType = {}));

const lp$1 = LANCER.log_prefix;
function lancerItemInit(data) {
    console.log(`${lp$1} Initializing new ${data.type}`);
    let img = 'systems/lancer/assets/icons/';
    if (data.type === 'skill') {
        img += 'skill.svg';
    }
    else if (data.type === 'talent') {
        img += 'talent.svg';
    }
    else if (data.type === 'core_bonus') {
        img += 'corebonus.svg';
    }
    else if (data.type === 'license') {
        img += 'license.svg';
    }
    else if (data.type === 'pilot_armor') {
        img += 'shield_outline.svg';
    }
    else if (data.type === 'pilot_weapon') {
        img += 'weapon.svg';
    }
    else if (data.type === 'pilot_gear') {
        img += 'generic_item.svg';
    }
    else if (data.type === 'frame') {
        img += 'frame.svg';
    }
    else if (data.type === 'mech_weapon') {
        img += 'weapon.svg';
    }
    else if (data.type === 'mech_system') {
        img += 'system.svg';
        // TODO: set default system type
    }
    else if (data.type === 'npc_class') {
        img += 'npc_class.svg';
    }
    else if (data.type === 'npc_template') {
        img += 'npc_template.svg';
    }
    else if (data.type === 'npc_feature') {
        img += 'trait.svg';
        mergeObject(data, {
            // Default new NPC features to traits
            "data.feature_type": NPCFeatureType.Trait
        });
    }
    else {
        img += 'generic_item.svg';
    }
    mergeObject(data, {
        // Initialize image
        "img": img
    });
}
class LancerItem extends Item {
    /**
     * Return a skill trigger's bonus to rolls
     */
    get triggerBonus() {
        // Only works for skills.
        if (this.data.type !== "skill")
            return 0;
        return this.data.data.rank * 2;
    }
}

const lp$2 = LANCER.log_prefix;
// TODO: should probably move to HTML/CSS
const entryPrompt = "//:AWAIT_ENTRY>";
/**
 * Extend the basic ActorSheet
 */
class LancerPilotSheet extends ActorSheet {
    constructor(...args) {
        super(...args);
    }
    /**
     * A convenience reference to the Actor entity
     */
    // get actor(): LancerPilot {
    //   return this.actor;
    // };
    /* -------------------------------------------- */
    /**
     * Extend and override the default options used by the Pilot Sheet
     * @returns {Object}
     */
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            classes: ["lancer", "sheet", "actor", "pilot"],
            template: "systems/lancer/templates/actor/pilot.html",
            width: 800,
            height: 800,
            tabs: [{
                    navSelector: ".lancer-tabs",
                    contentSelector: ".sheet-body",
                    initial: "pilot"
                }]
        });
    }
    /* -------------------------------------------- */
    /**
     * Prepare data for rendering the Actor sheet
     * The prepared data object contains both the actor data as well as additional sheet options
     */
    getData() {
        let data = super.getData();
        this._prepareItems(data);
        // Populate the callsign if blank (new Actor)
        if (data.data.pilot.callsign === "") {
            data.data.pilot.callsign = data.actor.name;
        }
        // Populate name if blank (new Actor)
        if (data.data.pilot.name === "") {
            data.data.pilot.name = data.actor.name;
        }
        // Put placeholder prompts in empty fields
        if (data.data.pilot.background == "")
            data.data.pilot.background = entryPrompt;
        if (data.data.pilot.history == "")
            data.data.pilot.history = entryPrompt;
        if (data.data.pilot.notes == "")
            data.data.pilot.notes = entryPrompt;
        // Generate the size string for the pilot's frame
        if (data.frame) {
            const frame = data.frame;
            if (frame.data.stats.size === 0.5) {
                data.frame_size = "size-half";
            }
            else {
                data.frame_size = `size-${frame.data.stats.size}`;
            }
        }
        else {
            data.frame_size = undefined;
        }
        console.log(`${lp$2} Pilot sheet data: `, data);
        return data;
    }
    /* -------------------------------------------- */
    /**
     * Organize and classify Owned Items for Character sheets
     * @private
     */
    _prepareItems(data) {
        data.sp_used = 0;
        // Mirror items into filtered list properties
        const accumulator = {};
        for (let item of data.items) {
            if (accumulator[item.type] === undefined)
                accumulator[item.type] = [];
            accumulator[item.type].push(item);
            if (item.type === 'mech_system') {
                data.sp_used += item.data.sp;
            }
        }
        data.skills = accumulator['skill'] || [];
        data.talents = accumulator['talent'] || [];
        data.licenses = accumulator['license'] || [];
        data.core_bonuses = accumulator['core_bonus'] || [];
        data.pilot_loadout = {
            gear: accumulator['pilot_gear'] || [],
            weapons: accumulator['pilot_weapon'] || [],
            armor: accumulator['pilot_armor'] || []
        };
        // Only take one frame
        if (accumulator['frame'])
            data.frame = accumulator['frame'][0];
        else
            data.frame = undefined;
        data.mech_loadout = {
            weapons: accumulator['mech_weapon'] || [],
            systems: accumulator['mech_system'] || []
        };
        // Update mounted weapons to stay in sync with owned items
        data.data.mech_loadout.mounts.forEach((mount) => {
            if (Array.isArray(mount.weapons) && mount.weapons.length > 0) {
                console.log(`${lp$2} weapons:`, mount.weapons);
                for (let i = 0; i < mount.weapons.length; i++) {
                    const ownedWeapon = this.actor.getOwnedItem(mount.weapons[i]._id);
                    if (ownedWeapon) {
                        console.log(`${lp$2} owned weapon:`, ownedWeapon);
                        mount.weapons[i] = duplicate(ownedWeapon.data);
                    }
                    // TODO: If the weapon doesn't exist in owned items anymore, remove it
                    else {
                        mount.weapons.splice(i, 1);
                    }
                }
            }
        });
        console.log(`${lp$2} mounts:`, data.data.mech_loadout.mounts);
    }
    /* -------------------------------------------- */
    /**
     * Activate event listeners using the prepared sheet HTML
     * @param html {HTML}   The prepared HTML object ready to be rendered into the DOM
     */
    activateListeners(html) {
        super.activateListeners(html);
        // Macro triggers
        if (this.actor.owner) {
            // Stat rollers
            let statMacro = html.find('.stat-macro');
            statMacro.click(ev => {
                ev.stopPropagation(); // Avoids triggering parent event handlers
                console.log(`${lp$2} Stat macro button click`, ev);
                // Find the stat input to get the stat's key to pass to the macro function
                const statInput = $(ev.currentTarget).closest('.stat-container').find('.lancer-stat')[0];
                let statKey = statInput.name;
                if (!statKey) {
                    statKey = statInput.value;
                }
                let keySplit = statKey.split('.');
                let title = keySplit[keySplit.length - 1].toUpperCase();
                console.log(`${lp$2} Rolling ${title} check, key ${statKey}`);
                game.lancer.rollStatMacro(title, statKey, null, true);
            });
            // Trigger rollers
            let triggerMacro = html.find('.roll-trigger');
            triggerMacro.click(ev => {
                ev.stopPropagation();
                console.log(`${lp$2} Skill macro button click`, ev);
                const modifier = parseInt($(ev.currentTarget).find('.roll-modifier').text());
                const title = $(ev.currentTarget).closest('.skill-compact').find('.modifier-name').text();
                //.find('modifier-name').first().text();
                console.log(`${lp$2} Rolling '${title}' trigger (d20 + ${modifier})`);
                game.lancer.rollTriggerMacro(title, modifier, true);
            });
            // Weapon rollers
            let weaponMacro = html.find('.roll-attack');
            weaponMacro.click(ev => {
                ev.stopPropagation();
                console.log(`${lp$2} Weapon macro button click`, ev);
                const weaponElement = $(ev.currentTarget).closest('.weapon')[0];
                // Pilot weapon
                if (weaponElement.className.search("pilot") >= 0) {
                    let weaponId = weaponElement.getAttribute("data-item-id");
                    game.lancer.rollAttackMacro(weaponId, this.actor._id);
                }
                // Mech weapon
                else {
                    let weaponMountIndex = weaponElement.getAttribute("data-item-id");
                    const mountElement = $(ev.currentTarget).closest(".lancer-mount-container");
                    if (mountElement.length) {
                        const mounts = this.actor.data.data.mech_loadout.mounts;
                        const weapon = mounts[parseInt(mountElement.data("itemId"))].weapons[weaponMountIndex];
                        game.lancer.rollAttackMacro(weapon._id, this.actor._id);
                    }
                    else {
                        console.log(`${lp$2} No mount element`, weaponMountIndex, mountElement);
                    }
                }
            });
        }
        // Everything below here is only needed if the sheet is editable
        if (!this.options.editable)
            return;
        if (this.actor.owner) {
            // Item Dragging
            html.find('li[class*="item"]').add('span[class*="item"]').each((i, item) => {
                if (item.classList.contains("inventory-header"))
                    return;
                item.setAttribute("draggable", true);
                item.addEventListener("dragstart", ev => this._onDragStart(ev), false);
            });
            // Update Inventory Item
            let items = html.find('.item');
            items.click(ev => {
                console.log(ev);
                const li = $(ev.currentTarget);
                //TODO: Check if in mount and update mount
                const item = this.actor.getOwnedItem(li.data("itemId"));
                if (item) {
                    item.sheet.render(true);
                }
            });
            // Delete Item on Right Click
            items.contextmenu(ev => {
                console.log(ev);
                const item = $(ev.currentTarget);
                const itemId = item.data("itemId");
                let mount_element = item.closest(".lancer-mount-container");
                let weapon_element = item.closest(".lancer-weapon-container");
                if (mount_element.length && weapon_element.length) {
                    let mounts = duplicate(this.actor.data.data.mech_loadout.mounts);
                    let weapons = mounts[parseInt(mount_element.data("itemId"))].weapons;
                    weapons.splice(parseInt(weapon_element.data("itemId")), 1);
                    this.actor.update({ "data.mech_loadout.mounts": mounts });
                    this._onSubmit(ev);
                }
                else if (this.actor.getOwnedItem(itemId).data.type === "mech_weapon") {
                    // Search mounts to remove the weapon
                    let mounts = duplicate(this.actor.data.data.mech_loadout.mounts);
                    for (let i = 0; i < mounts.length; i++) {
                        const mount = mounts[i];
                        for (let j = 0; j < mount.weapons.length; j++) {
                            let weapons = mount.weapons;
                            if (weapons[j]._id === itemId) {
                                weapons.splice(j, 1);
                                this.actor.update({ "data.mech_loadout.mounts": mounts });
                                this._onSubmit(ev);
                                break;
                            }
                        }
                    }
                }
                this.actor.deleteOwnedItem(itemId);
                item.slideUp(200, () => this.render(false));
            });
            // Delete Item when trash can is clicked
            items = html.find('.stats-control[data-action*="delete"]');
            items.click(ev => {
                ev.stopPropagation(); // Avoids triggering parent event handlers
                console.log(ev);
                const item = $(ev.currentTarget).closest('.item');
                const itemId = item.data("itemId");
                let mount_element = item.closest(".lancer-mount-container");
                let weapon_element = item.closest(".lancer-weapon-container");
                if (mount_element.length && weapon_element.length) {
                    let mounts = duplicate(this.actor.data.data.mech_loadout.mounts);
                    let weapons = mounts[parseInt(mount_element.data("itemId"))].weapons;
                    weapons.splice(parseInt(weapon_element.data("itemId")), 1);
                    this.actor.update({ "data.mech_loadout.mounts": mounts });
                    this._onSubmit(ev);
                }
                else if (this.actor.getOwnedItem(itemId).data.type === "mech_weapon") {
                    // Search mounts to remove the weapon
                    let mounts = duplicate(this.actor.data.data.mech_loadout.mounts);
                    for (let i = 0; i < mounts.length; i++) {
                        const mount = mounts[i];
                        for (let j = 0; j < mount.weapons.length; j++) {
                            let weapons = mount.weapons;
                            if (weapons[j]._id === itemId) {
                                weapons.splice(j, 1);
                                this.actor.update({ "data.mech_loadout.mounts": mounts });
                                this._onSubmit(ev);
                                break;
                            }
                        }
                    }
                }
                this.actor.deleteOwnedItem(itemId);
                item.slideUp(200, () => this.render(false));
            });
            // Create Mounts
            let add_button = html.find('.add-button[data-action*="create"]');
            add_button.click(ev => {
                ev.stopPropagation();
                console.log(ev);
                let mount = {
                    type: "Main",
                    weapons: [],
                    secondary_mount: "This counts, right?"
                };
                let mounts = duplicate(this.actor.data.data.mech_loadout.mounts);
                mounts.push(mount);
                this.actor.update({ "data.mech_loadout.mounts": mounts });
                this._onSubmit(ev);
            });
            // Update Mounts
            let mount_selector = html.find('select.mounts-control[data-action*="update"]');
            mount_selector.change(ev => {
                ev.stopPropagation();
                console.log(ev);
                let mounts = duplicate(this.actor.data.data.mech_loadout.mounts);
                mounts[parseInt($(ev.currentTarget).closest(".lancer-mount-container").data("itemId"))].type = $(ev.currentTarget).children("option:selected").val();
                this.actor.update({ "data.mech_loadout.mounts": mounts });
                this._onSubmit(ev);
            });
            // Delete Mounts
            let mount_trash = html.find('a.mounts-control[data-action*="delete"]');
            mount_trash.click(ev => {
                ev.stopPropagation();
                console.log(ev);
                let mounts = duplicate(this.actor.data.data.mech_loadout.mounts);
                let id = $(ev.currentTarget).closest(".lancer-mount-container").data("itemId");
                // Delete each weapon in the selected mount from the actor's owned items
                let weapons = this.actor.data.data.mech_loadout.mounts[id].weapons;
                for (let i = 0; i < weapons.length; i++) {
                    const weapon = weapons[i];
                    this.actor.deleteOwnedItem(weapon._id);
                }
                mounts.splice(parseInt(id), 1);
                this.actor.update({ "data.mech_loadout.mounts": mounts });
                this._onSubmit(ev);
            });
        }
    }
    async _onDrop(event) {
        event.preventDefault();
        // Get dropped data
        let data;
        try {
            data = JSON.parse(event.dataTransfer.getData('text/plain'));
            if (data.type !== "Item")
                return;
        }
        catch (err) {
            return false;
        }
        console.log(event);
        let item;
        const actor = this.actor;
        // NOTE: these cases are copied almost verbatim from ActorSheet._onDrop
        // Case 1 - Item is from a Compendium pack
        if (data.pack) {
            item = (await game.packs.get(data.pack).getEntity(data.id));
            console.log(`${lp$2} Item dropped from compendium: `, item);
        }
        // Case 2 - Item is a World entity
        else if (!data.data) {
            item = game.items.get(data.id);
            // If item isn't from a Compendium or World entity, 
            // see if super can do something with it.
            if (!item)
                super._onDrop(event);
            console.log(`${lp$2} Item dropped from world: `, item);
        }
        // Logic below this line is executed only with owner or GM permission of a sheet
        if (!actor.owner && !game.user.isGM) {
            ui.notifications.warn(`LANCER, you shouldn't try to modify ${actor.name}'s loadout. Access Denied.`);
            return;
        }
        if (item) {
            // Swap mech frame
            if (item.type === "frame") {
                let newFrameStats;
                let oldFrameStats;
                // Remove old frame
                actor.items.forEach(async (i) => {
                    if (i.type === "frame") {
                        console.log(`${lp$2} Removing ${actor.name}'s old ${i.name} frame.`);
                        oldFrameStats = duplicate(i.data.data.stats);
                        await this.actor.deleteOwnedItem(i._id);
                    }
                });
                // Add the new frame from Compendium pack
                if (data.pack) {
                    const frame = await actor.importItemFromCollection(data.pack, data.id);
                    console.log(`${lp$2} Added ${frame.name} from ${data.pack} to ${actor.name}.`);
                    newFrameStats = frame.data.stats;
                }
                // Add the new frame from a World entity
                else {
                    const frame = await actor.createOwnedItem(duplicate(item.data));
                    console.log(`${lp$2} Added ${frame.name} to ${actor.name}.`);
                    newFrameStats = frame.data.stats;
                }
                if (newFrameStats) {
                    console.log(`${lp$2} Swapping Frame stats for ${actor.name}`);
                    actor.swapFrames(newFrameStats, oldFrameStats);
                }
                return;
            }
            // Handling mech-weapon -> mount mapping
            else if (item.type === "mech_weapon") {
                let mounts = duplicate(this.actor.data.data.mech_loadout.mounts);
                if (!mounts.length) {
                    ui.notifications.error("A mech weapon was dropped on the page, but there are no weapon mounts installed. Go to the Frame Loadout tab to add some!");
                    return;
                }
                let mount_element = $(event.target.closest(".lancer-mount-container"));
                if (mount_element.length) {
                    let mount_whitelist = {
                        'Auxiliary': ['Integrated', 'Aux-Aux', 'Main', 'Flex', 'Main-Aux', 'Heavy'],
                        'Main': ['Integrated', 'Main', 'Flex', 'Main-Aux', 'Heavy'],
                        'Heavy': ['Integrated', 'Heavy'],
                        'Superheavy': ['Integrated', 'Heavy'],
                        'Other': ['Integrated', 'Aux-Aux', 'Main', 'Flex', 'Main-Aux', 'Heavy']
                    };
                    let mount = mounts[parseInt(mount_element.data("itemId"))];
                    let valid = mount_whitelist[item.data.data.mount];
                    if (!valid.includes(mount.type)) {
                        ui.notifications.error('The weapon you dropped is too large for this weapon mount!');
                    }
                    else if (item.data.data.mount === 'Superheavy' && !mount.secondary_mount) {
                        ui.notifications.error('Assign a secondary mount to this heavy mount in order to equip a superheavy weapon');
                    }
                    else {
                        let weapon = await actor.createOwnedItem(duplicate(item.data));
                        mount.weapons.push(weapon);
                        console.log(`${lp$2} Inserted Mech Weapon into Mount`, weapon);
                        this.actor.update({ "data.mech_loadout.mounts": mounts });
                        this._onSubmit(event);
                    }
                }
                else {
                    ui.notifications.error('You dropped a mech weapon on the page, but not onto a weapon mount. Go to the Frame Loadout tab to find them!');
                }
                return;
            }
            else if (LANCER.pilot_items.includes(item.type)) {
                if (data.pack) {
                    console.log(`${lp$2} Copying ${item.name} from ${data.pack} to ${actor.name}.`);
                    const dupData = duplicate(item.data);
                    const newItem = await actor.importItemFromCollection(data.pack, item._id);
                    // Make sure the new item includes all of the data from the original.
                    dupData._id = newItem._id;
                    actor.updateOwnedItem(dupData);
                    return;
                }
                else {
                    console.log(`${lp$2} Copying ${item.name} to ${actor.name}.`);
                    const dupData = duplicate(item.data);
                    const newItem = await actor.createOwnedItem(dupData);
                    // Make sure the new item includes all of the data from the original.
                    dupData._id = newItem._id;
                    actor.updateOwnedItem(dupData);
                    return;
                }
            }
            else if (LANCER.npc_items.includes(item.type)) {
                ui.notifications.error(`Cannot add Item of type "${item.type}" to a Pilot.`);
                return;
            }
        }
        // Finally, fall back to super's behaviour if nothing else "handles" the drop (signalled by returning).
        // Don't hate the player, hate the imperative paradigm
        console.log(`${lp$2} Falling back on super._onDrop`);
        return super._onDrop(event);
    }
    /* -------------------------------------------- */
    /**
     * Implement the _updateObject method as required by the parent class spec
     * This defines how to update the subject of the form when the form is submitted
     * @private
     */
    _updateObject(event, formData) {
        // Use the Actor's name for the pilot's callsign
        formData['name'] = formData["data.pilot.callsign"];
        let token = this.actor.data['token'];
        // Set the prototype token image if the prototype token isn't initialized
        if (!token) {
            formData['token.img'] = formData['img'];
        }
        // Update token image if it matches the old actor image
        else if (this.actor.data.img === token['img'] && this.actor.img !== formData['img']) {
            formData['token.img'] = formData['img'];
        }
        console.log(`${lp$2} Pilot sheet form data: `, formData);
        // Update the Actor
        return this.object.update(formData);
    }
}

const lp$3 = LANCER.log_prefix;
/**
 * Extend the basic ActorSheet
 */
class LancerNPCSheet extends ActorSheet {
    constructor(...args) {
        super(...args);
    }
    /**
     * A convenience reference to the Actor entity
     */
    // get actor(): LancerPilot {
    //   return this.actor;
    // };
    /* -------------------------------------------- */
    /**
     * Extend and override the default options used by the NPC Sheet
     * @returns {Object}
     */
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            classes: ["lancer", "sheet", "actor", "npc"],
            template: "systems/lancer/templates/actor/npc.html",
            width: 800,
            height: 800,
            tabs: [{
                    navSelector: ".lancer-tabs",
                    contentSelector: ".sheet-body",
                    initial: "mech"
                }]
        });
    }
    /* -------------------------------------------- */
    /**
     * Prepare data for rendering the Actor sheet
     * The prepared data object contains both the actor data as well as additional sheet options
     */
    getData() {
        const data = super.getData();
        this._prepareItems(data);
        // Populate name if blank (new Actor)
        if (data.data.name === "") {
            data.data.name = data.actor.name;
        }
        console.log(`${lp$3} NPC data: `);
        console.log(data);
        return data;
    }
    /* -------------------------------------------- */
    _prepareItems(data) {
        // Mirror items into filtered list properties
        const accumulator = {};
        for (let item of data.items) {
            if (accumulator[item.type] === undefined)
                accumulator[item.type] = [];
            accumulator[item.type].push(item);
        }
        data.npc_templates = accumulator['npc_template'] || [];
        data.npc_features = accumulator['npc_feature'] || [];
        if (accumulator['npc_class'])
            data.npc_class = accumulator['npc_class'][0];
        else
            data.npc_class = undefined;
        //TODO Templates, Classes and Features
    }
    /* -------------------------------------------- */
    /**
     * Activate event listeners using the prepared sheet HTML
     * @param html {HTML}   The prepared HTML object ready to be rendered into the DOM
     */
    activateListeners(html) {
        super.activateListeners(html);
        // Everything below here is only needed if the sheet is editable
        if (!this.options.editable)
            return;
        // Macro triggers
        if (this.actor.owner) {
            // Stat rollers
            let statMacro = html.find('.stat-macro');
            statMacro.click(ev => {
                ev.stopPropagation(); // Avoids triggering parent event handlers
                console.log(ev);
                // Find the stat input to get the stat's key to pass to the macro function
                const statInput = $(ev.currentTarget).closest('.stat-container').find('.lancer-stat-input')[0];
                const statKey = statInput.name;
                let keySplit = statKey.split('.');
                let title = keySplit[keySplit.length - 1].toUpperCase();
                console.log(`${lp$3} Rolling ${title} check, key ${statKey}`);
                game.lancer.rollStatMacro(title, statKey, null, true);
            });
            // Trigger rollers
            let triggerMacro = html.find('.roll-trigger');
            triggerMacro.click(ev => {
                ev.stopPropagation();
                console.log(ev);
                const modifier = parseInt($(ev.currentTarget).find('.roll-modifier').text());
                const title = $(ev.currentTarget).closest('.skill-compact').find('.modifier-name').text();
                //.find('modifier-name').first().text();
                console.log(`${lp$3} Rolling '${title}' trigger (d20 + ${modifier})`);
                game.lancer.rollTriggerMacro(title, modifier, true);
            });
            // Weapon rollers
            let weaponMacro = html.find('.roll-attack');
            weaponMacro.click(ev => {
                ev.stopPropagation();
                console.log(`${lp$3} Weapon macro button click`, ev);
                const weaponElement = $(ev.currentTarget).closest('.weapon')[0];
                let weaponId = weaponElement.getAttribute("data-item-id");
                game.lancer.rollAttackMacro(weaponId, this.actor._id);
            });
            // Tech rollers
            let techMacro = html.find('.roll-tech');
            techMacro.click(ev => {
                ev.stopPropagation();
                console.log(`${lp$3} Tech attack macro button click`, ev);
                const techElement = $(ev.currentTarget).closest('.tech')[0];
                let techId = techElement.getAttribute("data-item-id");
                game.lancer.rollTechMacro(techId, this.actor._id);
            });
        }
        if (this.actor.owner) {
            // Item Dragging
            let handler = ev => this._onDragStart(ev);
            html.find('li[class*="item"]').add('span[class*="item"]').each((i, item) => {
                if (item.classList.contains("inventory-header"))
                    return;
                item.setAttribute("draggable", true);
                // TODO: I think handler needs to be item.*something*._onDragStart(ev).
                item.addEventListener("dragstart", handler, false);
            });
            // Update Inventory Item
            let items = html.find('.item');
            items.click(ev => {
                console.log(ev);
                const li = $(ev.currentTarget);
                //TODO: Check if in mount and update mount
                const item = this.actor.getOwnedItem(li.data("itemId"));
                if (item) {
                    item.sheet.render(true);
                }
            });
            // Delete Item on Right Click
            items.contextmenu(ev => {
                console.log(ev);
                const li = $(ev.currentTarget);
                this.actor.deleteOwnedItem(li.data("itemId"));
                li.slideUp(200, () => this.render(false));
            });
            // Delete Item when trash can is clicked
            items = html.find('.stats-control[data-action*="delete"]');
            items.click(ev => {
                ev.stopPropagation(); // Avoids triggering parent event handlers
                console.log(ev);
                const li = $(ev.currentTarget).closest('.item');
                this.actor.deleteOwnedItem(li.data("itemId"));
                li.slideUp(200, () => this.render(false));
            });
            let tier_selector = html.find('select.tier-control[data-action*="update"]');
            tier_selector.change(ev => {
                ev.stopPropagation();
                console.log(ev);
                let tier = ev.currentTarget.selectedOptions[0].value;
                this.actor.update({ "data.tier": tier });
                // Set Values for 
                let actor = this.actor;
                let NPCClassStats;
                NPCClassStats = actor.items.find((i) => i.type === "npc_class").data.data.stats;
                console.log(`${lp$3} TIER Swap with ${tier} and ${NPCClassStats}`);
                actor.swapNPCClassOrTier(NPCClassStats, false, tier);
            });
        }
    }
    /* -------------------------------------------- */
    async _onDrop(event) {
        event.preventDefault();
        // Get dropped data
        let data;
        try {
            data = JSON.parse(event.dataTransfer.getData('text/plain'));
            if (data.type !== "Item")
                return;
        }
        catch (err) {
            return false;
        }
        console.log(event);
        let item;
        const actor = this.actor;
        // NOTE: these cases are copied almost verbatim from ActorSheet._onDrop
        // Case 1 - Item is from a Compendium pack
        if (data.pack) {
            item = (await game.packs.get(data.pack).getEntity(data.id));
            console.log(`${lp$3} Item dropped from compendium: `, item);
        }
        // Case 2 - Item is a World entity
        else if (!data.data) {
            item = game.items.get(data.id);
            // If item isn't from a Compendium or World entity, 
            // see if super can do something with it.
            if (!item)
                super._onDrop(event);
            console.log(`${lp$3} Item dropped from world: `, item);
        }
        // Logic below this line is executed only with owner or GM permission of a sheet
        if (!actor.owner && !game.user.isGM) {
            ui.notifications.warn(`LANCER, you shouldn't try to modify ${actor.name}'s loadout. Access Denied.`);
            return;
        }
        if (item) {
            // Swap mech class
            if (item.type === "npc_class") {
                let newNPCClassStats;
                // Remove old class
                actor.items.forEach(async (i) => {
                    if (i.type === "npc_class") {
                        console.log(`${lp$3} Removing ${actor.name}'s old ${i.name} class.`);
                        await this.actor.deleteOwnedItem(i._id);
                    }
                });
                // Add the new class from Compendium pack
                if (data.pack) {
                    const npcClass = await actor.importItemFromCollection(data.pack, data.id);
                    console.log(`${lp$3} Added ${npcClass.name} from ${data.pack} to ${actor.name}.`);
                    newNPCClassStats = npcClass.data.stats;
                }
                // Add the new Class from a World entity
                else {
                    await actor.createEmbeddedEntity("OwnedItem", duplicate(item.data));
                    const npcClass = await actor.createOwnedItem(duplicate(item.data));
                    console.log(`${lp$3} Added ${npcClass.name} from ${data.pack} to ${actor.name}.`);
                    newNPCClassStats = npcClass.data.stats;
                }
                if (newNPCClassStats) {
                    console.log(`${lp$3} Swapping Class stats for ${actor.name}`);
                    actor.swapNPCClassOrTier(newNPCClassStats, true);
                }
            }
            else if (LANCER.npc_items.includes(item.type)) {
                if (data.pack) {
                    console.log(`${lp$3} Copying ${item.name} from ${data.pack} to ${actor.name}.`);
                    const dupData = duplicate(item.data);
                    const newItem = await actor.importItemFromCollection(data.pack, item._id);
                    // Make sure the new item includes all of the data from the original.
                    dupData._id = newItem._id;
                    actor.updateOwnedItem(dupData);
                    return;
                }
                else {
                    console.log(`${lp$3} Copying ${item.name} to ${actor.name}.`);
                    const dupData = duplicate(item.data);
                    const newItem = await actor.createOwnedItem(dupData);
                    // Make sure the new item includes all of the data from the original.
                    dupData._id = newItem._id;
                    actor.updateOwnedItem(dupData);
                    return;
                }
            }
            //TODO add basic features to NPC
            //TODO remove basic feature from NPC on Class swap
            //TODO implement similar logi for Templates
            else if (LANCER.pilot_items.includes(item.type)) {
                ui.notifications.error(`Cannot add Item of type "${item.type}" to an NPC.`);
                return;
            }
            return super._onDrop(event);
        }
    }
    /* -------------------------------------------- */
    /**
     * Implement the _updateObject method as required by the parent class spec
     * This defines how to update the subject of the form when the form is submitted
     * @private
     */
    _updateObject(event, formData) {
        console.log(formData);
        // Use the Actor's name for the pilot's callsign
        formData.name = formData["data.npc.name"];
        let token = this.actor.token;
        // Set the prototype token image if the prototype token isn't initialized
        if (!this.actor.token) {
            this.actor.update({ "token.img": formData.img });
        }
        // Update token image if it matches the old actor image
        else if ((this.actor.img == token.img)
            && (this.actor.img != formData.img)) {
            this.actor.update({ "token.img": formData.img });
        }
        // Update the Actor
        return this.object.update(formData);
    }
}

const lp$4 = LANCER.log_prefix;
/**
 * Extend the basic ActorSheet
 */
class LancerDeployableSheet extends ActorSheet {
    constructor(...args) {
        super(...args);
    }
    /**
     * A convenience reference to the Actor entity
     */
    // get actor(): LancerPilot {
    //   return this.actor;
    // };
    /* -------------------------------------------- */
    /**
     * Extend and override the default options used by the NPC Sheet
     * @returns {Object}
     */
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            classes: ["lancer", "sheet", "actor", "npc"],
            template: "systems/lancer/templates/actor/deployable.html",
            width: 800,
            height: 800
        });
    }
    /* -------------------------------------------- */
    /**
     * @override
     * Activate event listeners using the prepared sheet HTML
     * @param html {HTML}   The prepared HTML object ready to be rendered into the DOM
     */
    activateListeners(html) {
        super.activateListeners(html);
        // Everything below here is only needed if the sheet is editable
        if (!this.options.editable)
            return;
        // Add or Remove options
        // Yes, theoretically this could be abstracted out to one function. You do it then.
    }
    /* -------------------------------------------- */
    /**
     * Prepare data for rendering the Actor sheet
     * The prepared data object contains both the actor data as well as additional sheet options
     */
    getData() {
        const data = super.getData();
        // Populate name if blank (new Actor)
        if (data.data.name === "") {
            data.data.name = data.actor.name;
        }
        console.log(`${lp$4} Deployable data: `, data);
        return data;
    }
    /**
     * Implement the _updateObject method as required by the parent class spec
     * This defines how to update the subject of the form when the form is submitted
     * @private
     */
    _updateObject(event, formData) {
        console.log(formData);
        let token = this.actor.token;
        // Set the prototype token image if the prototype token isn't initialized
        if (!this.actor.token) {
            this.actor.update({ "token.img": formData.img });
        }
        // Update token image if it matches the old actor image
        else if ((this.actor.img == token.img)
            && (this.actor.img != formData.img)) {
            this.actor.update({ "token.img": formData.img });
        }
        // Update the Actor
        return this.object.update(formData);
    }
}

const NPCFeatureIcons = {
    'Other': 'npc_feature.svg',
    'Reaction': 'reaction.svg',
    'System': 'system.svg',
    'Trait': 'trait.svg',
    'Weapon': 'weapon.svg',
    'Tech': 'tech_quick.svg'
};

const lp$5 = LANCER.log_prefix;
/**
 * Extend the basic ItemSheet with some very simple modifications
 * @extends {ItemSheet}
 */
class LancerItemSheet extends ItemSheet {
    /**
     * @override
     * Extend and override the default options used by the Item Sheet
     * @returns {Object}
     */
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            classes: ["lancer", "sheet", "item"],
            width: 700,
            height: 480,
            tabs: [{ navSelector: ".sheet-tabs", contentSelector: ".sheet-body", initial: "description" }]
        });
    }
    /** @override */
    get template() {
        const path = "systems/lancer/templates/item";
        return `${path}/${this.item.data.type}.html`;
    }
    /* -------------------------------------------- */
    /**
     * @override
     * Prepare data for rendering the Item sheet
     * The prepared data object contains both the item data as well as additional sheet options
     */
    getData() {
        const data = super.getData();
        if (data.item.type === "npc_feature" && data.data.feature_type === NPCFeatureType.Weapon) {
            if (data.data.weapon_type) {
                const parts = data.data.weapon_type.split(' ');
                data.data.weapon_size = parts[0];
                data.data.weapon_type = parts[1];
            }
            else {
                data.data.weapon_size = 'Main';
                data.data.weapon_type = 'Rifle';
            }
            // TODO: Fill in 0's if attack bonus or accuracy are undefined or "".
        }
        console.log(`${lp$5} Item sheet data: `, data, this.item);
        return data;
    }
    /* -------------------------------------------- */
    /** @override */
    setPosition(options = {}) {
        const position = super.setPosition(options);
        // const sheetBody = (this.element as HTMLDivElement).find(".sheet-body");
        // const bodyHeight = position.height - 192;
        // sheetBody.css("height", bodyHeight);
        return position;
    }
    /* -------------------------------------------- */
    /**
     * @override
     * Activate event listeners using the prepared sheet HTML
     * @param html {HTML}   The prepared HTML object ready to be rendered into the DOM
     */
    activateListeners(html) {
        super.activateListeners(html);
        // Everything below here is only needed if the sheet is editable
        if (!this.options.editable)
            return;
        // Add or Remove options
        // Yes, theoretically this could be abstracted out to one function. You do it then.
        html.find(".arrayed-item-container").on("click", ".clickable", this._onClickArrayControl.bind(this));
        html.find(".arrayed-item-container").on("change", ".delete-selector", this._onSelectDelete.bind(this));
    }
    /* -------------------------------------------- */
    /**
     * Listen for events on a selector to remove the referenced item
     * @param event    The originating event
     * @private
     */
    async _onSelectDelete(event) {
        const s = $(event.currentTarget);
        if (s.val() === "delete") {
            event.preventDefault();
            const itemString = s.data("item");
            var itemArr = duplicate(this["object"]["data"]["data"][itemString]);
            const parent = s.parents(".arrayed-item");
            const id = parent.data("key");
            delete itemArr[id];
            itemArr["-=" + id] = null;
            console.log(itemArr);
            await parent.remove();
            await this.object.update({ "data.mounts": itemArr });
        }
    }
    /**
     * Listen for click events on an attribute control to modify the composition of attributes in the sheet
     * @param {MouseEvent} event    The originating left click event
     * @private
     */
    async _onClickArrayControl(event) {
        event.preventDefault();
        const a = $(event.currentTarget);
        const action = a.data("action");
        const itemString = a.parents(".arrayed-item-container").data("item");
        console.log(itemString);
        var baseArr = getValue(this, ("object.data.data." + itemString));
        if (baseArr === null) {
            itemArr = [];
        }
        else {
            var itemArr = duplicate(baseArr);
        }
        const dataRef = "data." + itemString;
        console.log("_onClickArrayControl()", action, itemArr, itemString);
        if (action === "create") {
            // I can't figure out a better way to prevent collisions
            // Feel free to come up with something better
            const keys = Object.keys(itemArr);
            var newIndex = 0;
            if (keys.length > 0) {
                newIndex = Math.max.apply(Math, keys) + 1;
            }
            itemArr[newIndex] = null;
            await this.object.update({ [dataRef]: itemArr });
        }
        else if (action === "delete") {
            // delete tag
            const parent = a.parents(".arrayed-item");
            const id = parent.data("key");
            // Since we're doing weird things with arrays, let's just split as needed
            if (Array.isArray(itemArr)) {
                // This is for arrays: 
                itemArr.splice(id, 1);
            }
            else {
                // For dict
                delete itemArr[id];
                itemArr["-=" + id] = null;
                // So the question now becomes: why do all my arrays become dicts of objects?
            }
            this.object.update({ [dataRef]: itemArr });
        }
    }
    /* -------------------------------------------- */
    /** @override */
    _updateObject(event, formData) {
        if (this.item.data.type === "npc_feature") {
            // TODO: sanitize fields from other feature types
            // Change image to match feature type, unless a custom image has been selected
            const imgPath = 'systems/lancer/assets/icons/';
            const shortImg = formData['img'].slice(formData['img'].lastIndexOf('/') + 1);
            if (formData['img'].startsWith(imgPath) && Object.values(NPCFeatureIcons).includes(shortImg)) {
                formData['img'] = imgPath + NPCFeatureIcons[formData['data.feature_type']];
            }
            // Re-build NPC Weapon size and type
            if (this.item.data.type === "npc_feature" && this.item.data.data.feature_type === NPCFeatureType.Weapon) {
                formData['data.weapon_type'] = `${formData['data.weapon_size']} ${formData['data.weapon_type']}`;
                delete formData['data.weapon_size'];
            }
        }
        if (LANCER.weapon_items.includes(this.item.data.type)) {
            // Safeguard against non-weapon NPC features
            if (this.item.data.type !== "npc_feature" ||
                (this.item.data.type === "npc_feature" && this.item.data.data.feature_type === NPCFeatureType.Weapon)) {
                // Build range and damage arrays
                let damage = [];
                let range = [];
                let d_done = false;
                let i = 0;
                while (!d_done ||  i < 10) {
                    if (formData.hasOwnProperty(`data.damage.${i}.type`)) {
                        damage.push({
                            type: formData[`data.damage.${i}.type`],
                            val: formData[`data.damage.${i}.val`]
                        });
                        delete formData[`data.damage.${i}.type`];
                        delete formData[`data.damage.${i}.val`];
                    }
                    else
                        d_done = true;
                    if (formData.hasOwnProperty(`data.range.${i}.type`)) {
                        range.push({
                            type: formData[`data.range.${i}.type`],
                            val: formData[`data.range.${i}.val`]
                        });
                        delete formData[`data.range.${i}.type`];
                        delete formData[`data.range.${i}.val`];
                    }
                    else
                        d_done = true;
                    i++;
                }
                formData['data.damage'] = damage;
                formData['data.range'] = range;
            }
        }
        console.log(`${lp$5} Item sheet form data: `, formData);
        // Update the Item
        return this.object.update(formData);
    }
}
// Helper function to get arbitrarily deep array references
function getValue(object, path) {
    return path.
        replace(/\[/g, '.').
        replace(/\]/g, '').
        split('.').
        reduce((o, k) => (o || {})[k], object);
}

/**
 * Extend the generic Lancer item sheet
 * @extends {LancerItemSheet}
 */
class LancerFrameSheet extends LancerItemSheet {
    /**
     * @override
     * Extend and override the default options used by the generic Lancer item sheet
     * @returns {Object}
     */
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            width: 700,
            height: 750,
        });
    }
    /**
     * @override
     * Tag controls event handler
     * @param event The click event
     */
    async _onClickTagControl(event) {
        event.preventDefault();
        const a = $(event.currentTarget);
        const action = a.data("action");
        console.log(this);
        const tags = duplicate(this.object.data.data.core_system.tags);
        console.log("_onClickTagControl()", action, tags);
        if (action === "create") {
            // add tag
            // I can't figure out a better way to prevent collisions
            // Feel free to come up with something better
            // const keys = Object.keys(tags);
            // var newIndex = 0;
            // if (keys.length > 0) {
            //   newIndex = Math.max.apply(Math, keys) + 1;
            // }
            // tags[newIndex] = null;
            // Default new tags to quick action... is there a better solution?
            tags.push({ id: "tg_quick_action" });
            await this.object.update({ "data.core_system.tags": tags }, {});
            await this._onSubmit(event);
        }
        else if (action === "delete") {
            // delete tag
            const parent = a.parents(".tag");
            const id = parent.data("key");
            delete tags[id];
            tags["-=" + id] = null;
            this.object.update({ "data.core_system.tags": tags }, {});
        }
    }
    /**
     * @override
     * Prepare data for rendering the Item sheet
     * The prepared data object contains both the item data as well as additional sheet options
     */
    getData() {
        const data = super.getData();
        // TODO: frame size
        // TODO: find integrated weapon
        console.log(data);
        return data;
    }
}

/**
 * Extend the generic Lancer item sheet
 * @extends {LancerItemSheet}
 */
class LancerNPCClassSheet extends LancerItemSheet {
    /**
     * @override
     * Extend and override the default options used by the generic Lancer item sheet
     * @returns {Object}
     */
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            width: 900,
            height: 750,
        });
    }
}

const preloadTemplates = async function () {
    const templatePaths = [
        "systems/lancer/templates/actors/pilot.html",
        "systems/lancer/templates/actors/npc.html",
        "systems/lancer/templates/actors/deployable.html",
        "systems/lancer/templates/chat/attack-card.html",
        "systems/lancer/templates/chat/tech-attack-card.html",
        "systems/lancer/templates/items/core-bonus.html",
        "systems/lancer/templates/items/frame.html",
        "systems/lancer/templates/items/license.html",
        "systems/lancer/templates/items/mech_system.html",
        "systems/lancer/templates/items/mech_weapon.html",
        "systems/lancer/templates/items/npc_class.html",
        "systems/lancer/templates/items/npc_template.html",
        "systems/lancer/templates/items/npc_feature.html",
        "systems/lancer/templates/items/pilot_armor.html",
        "systems/lancer/templates/items/pilot_weapon.html",
        "systems/lancer/templates/items/pilot_gear.html",
        "systems/lancer/templates/items/skill.html",
        "systems/lancer/templates/items/talent.html",
    ];
    return loadTemplates(templatePaths);
};

const registerSettings = function () {
    /**
     * Track the system version upon which point a migration was last applied
     */
    game.settings.register("lancer", "systemMigrationVersion", {
        name: "System Migration Version",
        scope: "world",
        config: false,
        type: String,
        default: 0
    });
};

var actions = [
	{
		id: "act_core_battery",
		name: "Reserve: CORE Battery",
		reserve: true,
		action_type: "free",
		description: "Recharge CORE Power.",
		detail: "<p><strong>Mech Reserve: CORE Battery</strong><br>Consume this to gain CORE power on your mech, allowing it to use its most powerful ability again (you can’t get more than 1 CORE power at a time).</p><p>This may only be used once per mission, and the reserve is consumed after use.</p>"
	},
	{
		id: "act_redundant_repair",
		name: "Reserve: Redundant Repair",
		reserve: true,
		action_type: "free",
		description: "Stabilize as a free action.",
		detail: "<p><strong>Mech Reserve: Redundant Repair</strong><br>Stabilize as a Free Action.</p><p>This may only be used once per mission, and the reserve is consumed after use.</p>"
	},
	{
		id: "act_deployable_shield",
		name: "Reserve: Deployable Shield",
		reserve: true,
		action_type: "free",
		description: "Deploy a single-use shield generator.",
		detail: "<p><strong>Mech Reserve: Deployable Shield</strong><br>Free Action, deploy a a SIZE 1 deployable that grants soft cover to all friendly characters in a BURST 2 radius.</p><p>This may only be used once per mission, and the reserve is consumed after use.</p>"
	},
	{
		id: "act_bombardment",
		name: "Reserve: Bombardment",
		reserve: true,
		action_type: "full",
		description: "Call in an artillery or orbital bombardment.",
		detail: "<p><strong>Tactical Reserve: Orbital Bombardment</strong><br>Full Action, range 30 within line of sight, blast 2, 3d6 explosive damage.</p><p>This may only be used once per mission, and the reserve is consumed after use.</p>"
	},
	{
		id: "act_move",
		name: "Move",
		action_type: "move",
		description: "Move your character up to its speed in any direction.",
		detail: "On their turn, characters can always move spaces equal to their SPEED, in addition to any other actions. This is called a standard move to distinguish it from movement granted by systems or talents.<br>A character only counts as moving if they move 1 or more spaces.<br>Characters can move into any adjacent space, even diagonally, as long as the space isn’t occupied by an obstruction (and is one that they would be able to move in – characters can't move straight up unless they can fly, for example). There are several factors that can affect movement, which are detailed here."
	},
	{
		id: "act_overcharge",
		name: "OVERCHARGE",
		action_type: "overcharge",
		description: "Mechs can overcharge to make an additional quick action on a turn as a free action, at the cost of heat.",
		detail: "When you OVERCHARGE, you briefly push your mech beyond factory specifications for a tactical advantage. Moments of intense action won’t tax your mech’s systems too much, but sustained action beyond prescribed limits takes a toll.<br>Once per turn, you can OVERCHARGE your mech, allowing you to make any quick action as a free action – even actions you have already taken this turn.<br>The first time you OVERCHARGE, take 1 heat.<br>The second time you OVERCHARGE, take 1d3 heat.<br>The third time, take 1d6 heat, and each time thereafter take 1d6+4 heat.<br>A FULL REPAIR resets this counter."
	},
	{
		id: "act_skirmish",
		name: "SKIRMISH",
		action_type: "quick",
		description: "Attack with one weapon.",
		detail: "When you SKIRMISH, you attack with a single weapon.<br>To SKIRMISH, choose a weapon and a valid target within RANGE (or THREAT) then make an attack.<br>• In addition to your primary attack, you may also attack with a different AUXILIARY weapon on the same mount. That weapon doesn’t deal bonus damage.<br>• SUPERHEAVY weapons are too cumbersome to use in a SKIRMISH, and can only be fired as part of a BARRAGE."
	},
	{
		id: "act_boost",
		name: "BOOST",
		action_type: "quick",
		description: "Move your speed.",
		detail: "When you BOOST, you move at least 1 space, up to your SPEED. This allows you to make an extra movement, on top of your standard move. Certain talents and systems can only be used when you BOOST, not when you make a standard move."
	},
	{
		id: "act_ram",
		name: "RAM",
		action_type: "quick",
		description: "Attempt to knock down or knock back your target.",
		detail: "When you RAM, you make a melee attack with the aim of knocking a target down or back.<br>To RAM, make a melee attack against an adjacent character the same SIZE or smaller than you. On a success, your target is knocked PRONE and you may also choose to knock them back by one space, directly away from you."
	},
	{
		id: "act_grapple",
		name: "GRAPPLE",
		action_type: "quick",
		description: "Attempt to grab on your target, potentially immobilizing it or riding it.",
		detail: "When you GRAPPLE, you try to grab hold of a target and overpower them – disarming, subduing, or damaging them so they can’t do the same to you.<br>To GRAPPLE, choose an adjacent character and make a melee attack. On a hit:<br>• both characters become ENGAGED;<br>• neither character can BOOST or take reactions for the duration of the grapple;<br>• the smaller character becomes IMMOBILIZED but moves when the larger party moves, mirroring their movement. If both parties are the same SIZE, either can make contested HULL checks at the start of their turn: the winner counts as larger than the loser until this contest is repeated.<br>A GRAPPLE ends when:<br>• either character breaks adjacency, such as if they are knocked back by another effect;<br>• the attacker chooses to end the grapple as a free action;<br>• The defender breaks free by succeeding on a contested HULL check as a quick action.<br>If a GRAPPLE involves more than two characters, the same rules apply, but when counting SIZE, add together the SIZE of all characters on each side. For example, if two SIZE 1 allied characters are grappling a single SIZE 2 enemy, the allied characters count as a combined SIZE 2 and can try to drag their foe around."
	},
	{
		id: "act_quick_tech",
		name: "QUICK TECH",
		action_type: "quick",
		description: "Perform quick electronic warfare or systems-boosting activities.",
		detail: "When you use QUICK TECH, you engage in electronic warfare, countermeasures, and other technical actions, often aided by a mech’s powerful computing and simulation cores.<br>Each time you take this action, you choose an option from the QUICK TECH list. All mechs have access to these options, but some systems enhance them or make new options available.<br>Unlike other quick actions, QUICK TECH can be taken more than once per turn; however, a different option must be chosen every time, unless specified otherwise or granted as a free action.<br>To use QUICK TECH, choose one of the following options:<br>Bolster<br>When you BOLSTER, you use your mech’s formidable processing power to enhance another character’s systems.<br>To BOLSTER, choose a character within SENSORS. They receive +2 accuracy on the next skill check or save they make between now and the end of their next turn. Characters can only benefit from one BOLSTER at a time.<br>Scan<br>When you SCAN, you use your mech’s powerful sensors to perform a deep scan on an enemy.<br>To SCAN, choose a character or object within SENSORS and line of sight, then ask the GM for one of the following pieces of information, which they must answer honestly:<br>• Your target’s weapons, systems, and full statistics (HP, SPEED, EVASION, ARMOR, MECH SKILLS, and so on).<br>• One piece of hidden information about the target, such as confidential cargo or data, current mission, the identity of the pilot, and so on.<br>• Generic or public information about the target that can be pulled from an info bank or records, such as the model number of a mech.<br>Any information gathered is only current at the time of the SCAN – if the target later takes damage, for instance, you don’t receive an update.<br>Lock On<br>When you LOCK ON, you digitally mark a target, lighting them up for your teammates’ targeting systems and exposing weak points.<br>To LOCK ON, choose a character within SENSORS and line of sight. They gain the LOCK ON condition. Any character making an attack against a character with LOCK ON may choose to gain +1 accuracy on that attack and then clear the LOCK ON condition after that attack resolves. This is called consuming LOCK ON.<br>Invade<br>When you INVADE, you mount a direct electronic attack against a target. To INVADE, make a tech attack against a character within SENSORS and line of sight. On a success, your target takes 2 heat and you choose one of the INVASION options available to you. FRAGMENT SIGNAL is available to all characters, and additional options are granted by certain systems and equipment with the INVADE tag.<br>FRAGMENT SIGNAL. You feed false information, obscene messages, or phantom signals to your target’s computing core. They become IMPAIRED and SLOWED until the end of their next turn.<br>You can also INVADE willing allied characters to create certain effects. If your target is willing and allied, you are automatically successful, it doesn’t count as an attack, and your target doesn’t take any heat."
	},
	{
		id: "act_hide",
		name: "HIDE",
		action_type: "quick",
		description: "Attempt to hide.",
		detail: "When you HIDE, you obscure the position of your mech in order to reposition, avoid incoming fire, repair, or ambush.<br>To HIDE, you must not be ENGAGED and you must either be outside of any enemies’ line of sight, obscured by sufficient cover, or invisible. If you HIDE while meeting one of these criteria, you gain the HIDDEN status.<br>Hard cover is sufficient to HIDE as long as it is large enough to totally conceal you, but soft cover is only sufficient if you are completely inside an area or zone that grants soft cover – many systems and talents that grant soft cover or plain old obscurement just don’t provide enough to hide behind!<br>If you are INVISIBLE, you can always HIDE, regardless of cover, unless you’re ENGAGED.<br>The exact location of HIDDEN targets cannot be identified and they cannot be targeted directly by attacks or hostile actions, but they can still be hit by attacks that affect an area. Although NPCs cannot perfectly locate a HIDDEN character, they might still know an approximate location. Thus, an NPC could flush an area with a flamethrower even if they don’t know exactly where a HIDDEN player is lurking.<br>Additionally, other characters ignore engagement with you while you are HIDDEN – it’s assumed you’re trying to stay stealthy.<br>You cease to be HIDDEN if you make an attack (melee, ranged, or tech) or if your mech takes a hostile action (such as forcing a target to make a save). Using BOOST or taking reactions with your mech also causes you to lose HIDDEN. Other actions can be taken as normal.<br>You also immediately lose HIDDEN if your cover disap‐ pears or is destroyed, or if you lose cover due to line of sight (e.g., if a mech jumps over a wall and can now draw unbroken line of sight to you). If you’re hiding while INVISIBLE, you lose HIDDEN when you cease to be INVISIBLE unless you are in cover."
	},
	{
		id: "act_search",
		name: "SEARCH",
		action_type: "quick",
		description: "Look for a hidden target.",
		detail: "When you SEARCH, you attempt to identify hidden characters. To SEARCH in a mech, choose a character within your SENSORS that you suspect is HIDDEN and make a contested SYSTEMS check against their AGILITY.<br>To SEARCH as a pilot on foot, make a contested skill check, adding bonuses from triggers as normal. This can be used to reveal characters within RANGE 5.<br>Once a HIDDEN character has been found using SEARCH, they immediately lose HIDDEN and can be located again by any character."
	},
	{
		id: "act_activate_quick",
		name: "ACTIVATE",
		action_type: "quick",
		description: "Activate a system or piece of gear that uses a quick action.",
		detail: "When you ACTIVATE, you use a system or piece of gear that requires either a quick or full action. These systems have the QUICK ACTION or FULL ACTION tags. You can ACTIVATE any number of times a turn but can’t ACTIVATE the same system more than once unless you can do so as a free action."
	},
	{
		id: "act_eject",
		name: "EJECT",
		action_type: "quick",
		description: "Quickly get out of your mech.",
		detail: "You can also EJECT as a quick action, flying 6 spaces in the direction of your choice; however, this is a single-use system for emergency use only – it leaves your mech IMPAIRED. Your mech remains IMPAIRED and you cannot EJECT again until your next FULL REPAIR."
	},
	{
		id: "act_prepare",
		name: "PREPARE",
		action_type: "quick",
		description: "Hold a quick action for a specified trigger.",
		detail: "When you PREPARE, you get ready to take an action at a specific time or when a specific condition is met (a more advantageous shot, for example).<br>As a quick action, you can PREPARE any other quick action and specify a trigger. Until the start of your next turn, when it is triggered, you can take this action as a reaction.<br>The trigger for your prepared action must be phrased as “When X, then Y,” where X is a reaction, action or move taken by a hostile or allied character and Y is your action. For example, “when an allied character moves adjacent to me, I want to throw a smoke grenade,” or “when a hostile character moves adjacent to me, I want to ram them”.<br>Your preparation counts as taking the action, so it follows all usual restrictions on that action and on taking multiple actions. You can’t, for example, SKIRMISH and then prepare to SKIRMISH again; you also can’t move and then PREPARE to SKIRMISH with an ORDNANCE weapon, which normally needs to be fired before moving or doing anything else on your turn. Additionally, after you PREPARE an action, you can’t move or take any other actions or reactions until the start of your next turn or until your action has been triggered, whichever comes first.<br>Although you can’t take reactions while holding a prepared action, you can take them normally after it has been triggered. You can also drop your prepared action, allowing you to take reactions as usual. If the trigger condition isn’t met, you lose your prepared action.<br>When you PREPARE, it is visible to casual observers (e.g., you clearly take aim or cycle up systems)."
	},
	{
		id: "act_self_destruct",
		name: "SELF-DESTRUCT",
		action_type: "quick",
		description: "As a last ditch measure, set your reactor to go critical and explode.",
		detail: "When you SELF-DESTRUCT, you overload your mech’s reactor in a final, catastrophic play if there’s no other option for escape or you deem your sacrifice necessary.<br>You can SELF-DESTRUCT as a quick action, initiating a reactor meltdown. At the end of your next turn, or at the end of one of your turns within the following two rounds (your choice), your mech explodes as though it suffered a reactor meltdown. The explosion annihilates your mech, killing anyone inside and causing a BURST 2 explosion that deals 4d6 explosive damage. Characters caught in the explosion that succeed on an AGILITY save take half of this damage."
	},
	{
		id: "act_shut_down",
		name: "SHUT DOWN",
		action_type: "quick",
		description: "Shut down your mech as a desperate measure, to end system attacks, regain control of AI, and cool your mech.",
		detail: "When you SHUT DOWN, your mech powers completely off and enters a rest state. It’s always risky to do in the field, but it’s sometimes necessary to prevent a catastrophic systems overload or an NHP cascading.<br>You can SHUT DOWN your mech as a quick action. Your mech takes the SHUT DOWN status, with these effects:<br>• all heat is cleared, as is EXPOSED;<br>• any cascading NHPs return to a normal state;<br>• any statuses or conditions affecting the mech caused by tech actions, such as LOCK ON, immediately end;<br>• the mech gains IMMUNITY to all tech actions and attacks, including any from allied characters;<br>• the mech is STUNNED indefinitely. Nothing can prevent this condition, and it remains until the mech ceases to be SHUT DOWN.<br>The only way to remove the SHUT DOWN status is to BOOT UP the mech."
	},
	{
		id: "act_reload",
		name: "RELOAD",
		action_type: "quick",
		description: "Reload one weapon as a pilot.",
		detail: "When you RELOAD, you reload one Pilot Weapon with the LOADING tag, making it usable again.",
		pilot: true
	},
	{
		id: "act_barrage",
		name: "BARRAGE",
		action_type: "full",
		description: "Attack with two weapons, or attack with a single superheavy weapon.",
		detail: "When you BARRAGE, you attack with two weapons, or with one SUPERHEAVY weapon.<br>To BARRAGE, choose your weapons and either one target or different targets – within range – then make an attack with each weapon.<br>• In addition to your primary attacks, you may also attack with an AUXILIARY weapon on each mount that was fired, so long as the AUXILIARY weapon hasn’t yet been fired this action. These AUXILIARY weapons don’t deal bonus damage.<br>• SUPERHEAVY weapons can only be fired as part of a BARRAGE."
	},
	{
		id: "act_full_tech",
		name: "FULL TECH",
		action_type: "full",
		description: "Choose and perform two options from the tech list, or perform a full tech action.",
		detail: "When you use FULL TECH, you perform multiple tech actions or a single, more complex action.<br>To use FULL TECH, choose two QUICK TECH options or a single system or tech option that requires FULL TECH to activate. If you choose two QUICK TECH options, you can choose the same option multiple times."
	},
	{
		id: "act_stabilize",
		name: "STABILIZE",
		action_type: "full",
		description: "Heal and cool down your mech, reload, or attempt to end conditions affecting it.",
		detail: "When you STABILIZE, you enact emergency protocols to purge your mech’s systems of excess heat, repair your chassis where you can, or eliminate hostile code.<br>To STABILIZE, choose one of the following:<br>• Cool your mech, clearing all heat and EXPOSED.<br>• Mark 1 REPAIR to restore all HP.<br>Additionally, choose one of the following:<br>• Reload all LOADING weapons.<br>• Clear any burn currently affecting your mech.<br>• Clear a condition that wasn’t caused by one of your own systems, talents, etc.<br>• Clear an adjacent allied character’s condition that wasn’t caused by one of their own systems, talents, etc."
	},
	{
		id: "act_disengage",
		name: "DISENGAGE",
		action_type: "full",
		description: "Move safely, avoiding reactions and engagement.",
		detail: "When you DISENGAGE, you attempt to extricate yourself safely from a dangerous situation, make a steady and measured retreat, or rely on your mech’s agility to slip in and out of threat ranges faster than an enemy can strike.<br>Until the end of your current turn, you ignore engagement and your movement does not provoke reactions."
	},
	{
		id: "act_improvised_attack",
		name: "IMPROVISED ATTACK",
		action_type: "full",
		description: "Attack with a fist, rifle butt, or improvised weapon in melee.",
		detail: "When you make an IMPROVISED ATTACK, you attack with a rifle butt, fist, or another improvised melee weapon. You can use anything from the butt of a weapon to a slab of concrete or a length of hull plating – the flavor of the attack is up to you!<br>To make an IMPROVISED ATTACK, make a melee attack against an adjacent target. On a success, they take 1d6 kinetic damage."
	},
	{
		id: "act_activate_full",
		name: "ACTIVATE",
		action_type: "full",
		description: "Activate a system or piece of gear that uses a full action.",
		detail: "When you ACTIVATE, you use a system or piece of gear that requires either a quick or full action. These systems have the QUICK ACTION or FULL ACTION tags. You can ACTIVATE any number of times a turn but can’t ACTIVATE the same system more than once unless you can do so as a free action."
	},
	{
		id: "act_boot_up",
		name: "BOOT UP",
		action_type: "full",
		description: "Fire up your mech from Shut Down.",
		detail: "You can BOOT UP a mech that you are piloting as a full action, clearing SHUT DOWN and restoring your mech to a powered state."
	},
	{
		id: "act_mount_dismount",
		name: "MOUNT/DISMOUNT",
		action_type: "full",
		description: "Get in or out of your mech.",
		detail: "When you MOUNT or DISMOUNT, you climb onto or off of a mech. Mounting and dismounting are the preferred terms among most pilots. You don’t “get in” or “climb aboard” – you mount. You’re the cavalry, after all.<br>You can MOUNT or DISMOUNT as a full action. You must be adjacent your mech to MOUNT. Likewise, when you DISMOUNT, you are placed in an adjacent space – if there are no free spaces, you cannot DISMOUNT.<br>Additionally, you can also MOUNT or DISMOUNT willing allied mechs or vehicles. When you do so, move into the same space and then move with them."
	},
	{
		id: "act_skill_check",
		name: "SKILL CHECK",
		action_type: "full",
		description: "Perform an activity with a clear goal that would take a skill check.",
		detail: "When you make a SKILL CHECK, you undertake an activity that isn’t covered by other actions but has a clear goal and is sufficiently complex to require a roll. The parameters and outcomes of SKILL CHECKS are up to the GM, but they must be involved enough to require a full action. If you want to do something that can be done quickly, no action is required.<br>Examples of SKILL CHECKS:<br>• Bruja, on foot, wants to open a locked door. The GM asks her to make a SKILL CHECK and decides that Bruja can get a bonus from her ‘Hack or Fix’ trigger.<br>• Pan wants to jump a crevasse in his mech that’s wider than he can normally manage. The GM decides to allow him to try it with AGILITY.<br>• Zaid wants to lift a heavy boulder with his mech, to clear a passage. The GM decides this is probably a full action and requires a SKILL CHECK with HULL."
	},
	{
		id: "act_fight",
		name: "FIGHT",
		action_type: "full",
		description: "Attack with one weapon as a pilot.",
		detail: "When you FIGHT, you attack (melee or ranged) with one weapon.<br>To FIGHT, choose a weapon and attack a target within RANGE or THREAT and line of sight as a full action. Ranged attacks are affected by cover and receive +1 difficulty if you’re ENGAGED.",
		pilot: true
	},
	{
		id: "act_jockey",
		name: "JOCKEY",
		action_type: "full",
		description: "Attempt to attack a mech on foot as a pilot.",
		detail: "When you JOCKEY, you aggressively attack an enemy mech while on foot. It cannot be emphasized enough how foolhardy and dangerous this is.<br>To JOCKEY, you must be adjacent to a mech. As a full action, make a contested skill check against the mech, using GRIT (or a relevant trigger, at the GM’s discretion). The mech contests with HULL. On a success, you manage to climb onto the mech, sharing its space and moving with it. The mech can attempt to shake you off by succeeding on another contested skill check as a full action; alternatively, you can jump off as part of your movement on your turn.<br>When you successfully JOCKEY, choose one of the following options:<br>• DISTRACT: The mech is IMPAIRED and SLOWED until the end of its next turn.<br>• SHRED: Deal 2 heat to the mech by ripping at wiring, paneling, and so on.<br>• DAMAGE: Deal 4 kinetic damage to the mech by attacking joints, hatches, and so on.<br>On each of your subsequent turns, you can continue to choose from the options above as full actions, as long as you don't stop jockeying (or get thrown off).",
		pilot: true
	},
	{
		id: "act_brace",
		name: "BRACE",
		action_type: "reaction",
		description: "Brace your mech for impact, reducing damage at the cost of your next turn’s actions.",
		detail: "When you BRACE, you ready your mech against incoming fire.<br>Brace<br>Reaction, 1/round<br>Trigger: You are hit by an attack and damage has been rolled.<br>Effect: You count as having RESISTANCE to all damage, burn, and heat from the triggering attack, and until the end of your next turn, all other attacks against you are made at +1 difficulty.<br>Due to the stress of bracing, you cannot take reactions until the end of your next turn and on that turn, you can only take one quick action – you cannot OVERCHARGE, move normally, take full actions, or take free actions."
	},
	{
		id: "act_overwatch",
		name: "OVERWATCH",
		action_type: "reaction",
		description: "Attack a close-by target attempting to move.",
		detail: "When you OVERWATCH, you control and defend the space around your mech from enemy incursion through pilot skill, reflexes, or finely tuned subsystems.<br>Unless specified otherwise, all weapons default to 1 THREAT.<br>Overwatch<br>Reaction, 1/round<br>Trigger: A hostile character starts any movement (including BOOST and other actions) inside one of your weapons’ THREAT.<br>Effect: Trigger OVERWATCH, immediately using that weapon to SKIRMISH against that character as a reaction, before they move."
	},
	{
		id: "act_free_action",
		name: "FREE ACTION",
		action_type: "free",
		description: "Characters may perform any number of Free Actions on their turn.",
		detail: "Free actions are often granted by systems, talents, gear, or OVERCHARGE. Characters may perform any number of free actions on their turn, but only on their turn, and only those granted to them. Free actions can always be used to make duplicate actions.<br>The most common type of free action is a PROTOCOL, which is granted by gear or systems and can be activ‐ ated or deactivated only at the start of a turn. Each Protocol can only be taken once per turn."
	},
	{
		id: "act_buy_some_time",
		name: "BUY SOME TIME",
		action_type: "downtime",
		description: "Try and stave off some reckoning, extend your window of opportunity, or merely buy more time and breathing room for you and your group to act.",
		detail: "When you BUY SOME TIME, you try to stave off a reckoning, extend a window of opportunity, or merely buy some time and breathing room for you and your group. You might be trying to dodge some heat, survive stranded in the wilderness, or cause a distraction so another plan can reach its climax. You can use that distraction or bought time as RESERVES for the next mission.<br>Describe your plan and roll:<br>On 9 or less, you can only buy a little time, and only if drastic measures are taken right now. Otherwise, whatever you’re trying to stave off catches up to you.<br>On 10–19, you buy enough time, but the situation becomes precarious or desperate. Next time you get this result for the same situation, treat it as 9 or less.<br>On 20+, you buy as much time as you need, until the next downtime session. Next time you get this result for the same situation, treat it as 10–19."
	},
	{
		id: "act_gather_information",
		name: "GATHER INFORMATION",
		action_type: "downtime",
		description: "Investigate, do research, follow up on a mystery, track a target, or keep an eye on something.",
		detail: "When you GATHER INFORMATION, you poke your nose around, perhaps where it doesn’t belong, and investigate something – conducting research, following up on a mystery, tracking a target, or keeping an eye on something. You might head to a library or go undercover to learn what you can. Whatever it involves, you’re trying to GATHER INFORMATION on a subject of your choice. You can use information gained as RESERVES.<br>Name your subject and method, and roll:<br>On 9 or less, choose one:<br>• You get what you’re looking for, but it gets you into trouble straight away.<br>• You get out now and avoid trouble.<br>On 10–19, you find what you’re looking for, but choose one:<br>• You leave clear evidence of your rummaging.<br>• You have to dispatch someone or implicate someone innocent to avoid attention.<br>On 20+, you get what you’re looking for with no complications."
	},
	{
		id: "act_get_a_damn_drink",
		name: "GET A DAMN DRINK",
		action_type: "downtime",
		description: "Blow off some steam, carouse, and generally get into trouble.",
		detail: "When you GET A DAMN DRINK, you blow off some steam, carouse, and generally get into trouble. You might be trying to make connections, collect gossip, forge a reputation, or even just to forget what happened on the last mission. There’s usually trouble.<br>State your intention and roll:<br>On 9 or less, decide whether you had good time or not; either way, you wake up in a gutter somewhere with only one remaining:<br>• Your dignity.<br>• All of your possessions.<br>• Your memory.<br>On 10–19, gain one as RESERVES and lose one:<br>• A good reputation.<br>• A friend or connection.<br>• A useful item or piece of information.<br>• A convenient opportunity.<br>On 20+, gain two from the 10–19 list as RESERVES and don’t lose anything.<br>You can only make this action where there’s actually a drink to get (e.g., in a town, station, city, or some other populated area), or some other kind of entertainment."
	},
	{
		id: "act_get_connected",
		name: "GET CONNECTED",
		action_type: "downtime",
		description: "Make connections, call upon favors, ask for help, or drum up support for a particular course of action.",
		detail: "When you GET CONNECTED, you make connections, call in favors, ask for help, or drum up support for a course of action. You can use your contacts’ resources or aid as RESERVES for the next mission.<br>Name your contact and roll:<br>On 9 or less, your contact will help you, but you’ve got to do a favor or make good on a promise right now. If you don’t, they won’t help you.<br>On 10–19, your contact will help you, but you’ve got to do a favor or make good on a promise afterwards. If you don’t follow through, treat this result as 9 or less next time you get it for the same organization.<br>On 20+, your contact will help you, no strings attached. Treat this result as 10–19 next time you get it for the same organization.<br>To take this action, you need to be within comms range or somewhere you can have a good old-fashioned face-to-face conversation."
	},
	{
		id: "act_get_creative",
		name: "GET CREATIVE",
		action_type: "downtime",
		description: "Tweak something or attempt to make something new, either a physical project, or a piece of software.",
		detail: "When you GET CREATIVE, you tweak something or try to make something new – either a physical item, or a piece of software. Once finished, you can use your new creation as RESERVES.<br>Describe your project and roll:<br>On 9 or less, you don’t make any progress on your project. Next time you get this result for the same project, treat it as a 10–19.<br>On 10–19, you make progress on your project, but don’t quite finish it. You can finish it during your next downtime without rolling, but choose the two things you’re going to need:<br>• Quality materials.<br>• Specific knowledge or techniques.<br>• Specialized tools.<br>• A good workspace.<br>On 20+, you finish your project before the next mission. If it’s especially complex, treat this as 10–19, but only choose one.<br>Your project doesn’t have to be something from the gear list, but it usually can’t be as impactful as a piece of mech gear."
	},
	{
		id: "act_get_focused",
		name: "GET FOCUSED",
		action_type: "downtime",
		description: "Practice, learn, meditate, or call on a teacher.",
		detail: "When you GET FOCUSED, you focus on increasing your own skills, training, and self-improvement. You might practice, learn, meditate, or call on a teacher.<br>Name what you want to learn or improve (e.g., a skill, technique, academic subject, or language). The GM will give your pilot a new +2 trigger based on your practice and training. For example, the trigger could be +2 Playing Chess or +2 Dancing. You can also improve a trigger from +2 to +4 or +4 to +6 by taking this downtime action.<br>This action can be used to learn something like starship piloting, cooking, chess, boxing, history, or etiquette. It should usually be a specific non-martial skill or something personal to your character."
	},
	{
		id: "act_get_organized",
		name: "GET ORGANIZED",
		action_type: "downtime",
		description: "Start, run, or improve an organization, business, or other venture.",
		detail: "When you GET ORGANIZED, you start, run, or improve an organization, business, or other venture.<br>State your organization’s purpose or goal, and choose a FOCUS: military, scientific, academic, criminal, humanitarian, industrial, entertainment, or political. It begins with +2 in either EFFICIENCY or INFLUENCE and +0 in the other, with a maximum of +6. EFFICIENCY determines how effectively your organization conducts activities within its scope (e.g., a military organization with high efficiency would be good at combat). INFLUENCE is its size, reach, wealth, and reputation.<br>When your organization directly assists with an activity, you may add either its EFFICIENCY or INFLUENCE as a statistic bonus to your skill check. EFFICIENCY is used when performing activities related to your organization’s FOCUS. INFLUENCE is used when acquiring assets, creating opportunities, or swaying public opinion. Advantages gained with the help of your organization can be used as RESERVES.<br>Each downtime after the first, roll 1d20:<br>On 9 or less, choose one or your organization folds immediately:<br>• Your organization loses 2 EFFICIENCY and 2 INFLUENCE, to a minimum of 0. If both are already at 0, you may not choose this.<br>• Your organization needs to pay debts, make an aggressive move, or get bailed out. You choose which, and the GM decides what that looks like.<br>On 10–19, your organization is stable. It gains +2 EFFICIENCY or INFLUENCE, to a maximum of +6.<br>On 20+, your organization gains +2 EFFICIENCY and +2 INFLUENCE, to a maximum of +6.<br>You must roll for your organization every downtime after starting one, but the roll doesn’t count as a downtime action."
	},
	{
		id: "act_power_at_a_cost",
		name: "POWER AT A COST",
		action_type: "downtime",
		description: "Gain rewards, opportunities, or additional resources (such as reserves).",
		detail: "When you seek POWER AT A COST, you’re trying to get your hands on something.<br>Name what you want. You can definitely get it, but depending on the outlandishness of the request, the GM chooses one or two:<br>• It’s going to take a lot more time than you thought.<br>• It’s going to be really damn risky.<br>• You’ll have to have to give something up or leave something behind (e.g., wealth, resources, allies).<br>• You’re going to piss off someone or something important and powerful.<br>• Things are going to go wildly off-plan.<br>• You’ll need more information to proceed safely.<br>• It’s going to fall apart damn soon.<br>• You’ll need more resources, but you know where to find them.<br>• You can get something almost right: a lesser version, or less of it.<br>This is a straightforward way to acquire RESERVES, opportunities, and additional resources. You might want something directly useful for a mission; some‐ thing more abstract, like time, safety, information, allies, or support; something practical, like a base of operations, materials, shelter, or food; or, even something as simple as a damn pack of cigarettes.<br>You can also use POWER AT A COST during missions for similar effects. Other downtime actions generally can’t be used during missions, but your group can adapt them if desired."
	},
	{
		id: "act_scrounge_and_barter",
		name: "SCROUNGE AND BARTER",
		action_type: "downtime",
		description: "Try and get your hands on some gear or asset for your group.",
		detail: "When you SCROUNGE AND BARTER, you try to get your hands on some gear or an asset by dredging the scrapyard, chasing down rumors, bartering in the local market, or hunting around.<br>You might want some better pilot gear, a vehicle, narcotics, goods, or other sundries. It needs to be something physical, but doesn’t necessarily have to be on the gear list. If you get it, you can take it on the next mission as RESERVES.<br>Name what you want and roll:<br>On 9 or less, you get what you want, but choose one:<br>• It was stolen, probably from someone who’s looking for it.<br>• It’s degraded, old, filthy, or malfunctioning.<br>• Someone else has it right now and won’t give it up without force or convincing.<br>On 10–19, you get what you want, but choose the price you need to pay:<br>• Time.<br>• Dignity.<br>• Reputation.<br>• Health, comfort, and wellness. On 20+, you get what you’re looking for, no problem."
	}
];

var actions$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    'default': actions
});

var backgrounds = [
	{
		id: "pbg_celebrity",
		name: "CELEBRITY",
		description: "You were a figure in the public eye. <i>Were you an actor? A singer? An artist? An athlete? A politician? The public face of a corporate or military advertising campaign?</i><br>In your old life, you couldn’t go anywhere without the paparazzi hovering nearby. <i>How are you adjusting to your new life as a pilot? Did you volunteer, or were you conscripted? Can you still practice your art, craft, or profession, or does the rigid military structure make it difficult to pull double-duty?</i>",
		triggers: "Example triggers: Charm, Pull Rank, Lead or Inspire, Threaten"
	},
	{
		id: "pbg_colonist",
		name: "COLONIST",
		description: "You were a colonist on the frontier; one of the first generations to be born on a newly settled world. You’re used to the demands of frontier life and well-aware of the precarious position most homesteaders live in. <i>Why did you leave? Were you forced to flee, becoming a refugee? Did you choose to enlist?</i><br>And then there’s the home you left behind: <i>Is the colony still there? Your family? How familiar are you with the luxuries of core worlds? Do you find other cultures difficult to deal with, or are you fascinated by the wealth of humanity’s cultural expression? Do you carry reminders of home, or do you curse its name? Was your colony in a galactic backwater, or is it a fresh colony in a populated, high-traffic area of space? Where is your colony located?</i>",
		triggers: "Example triggers: Word on the Street, Spot, Survive, Patch"
	},
	{
		id: "pbg_criminal",
		name: "CRIMINAL",
		description: "You were a criminal: small-time, master, or something in between. <i>Did you work for corporate clients? A criminal organization? Yourself? Did you mug pedestrians in the dark underbelly of a massive city, or did you slip, unnoticed, into corporate databases to steal data? Did you do it for personal gain, or just to feed your family? How did you find yourself in this life, and how did you become a pilot? Did you operate with a code of honor? Were you loyal to a single family, a small crew, a politician, or an ideology? Did you operate in the shadows, or was your work carried out in the daylight, unafraid of consequences?</i><br>There must be a reason you decided to get out. <i>Was it a bad job, or maybe witness protection? Are your former employers or crew still around? What connections do they have, and how do they feel about you now? What – if anything – haunts you?</i><br>Note: for a more classic “Western” flavor, see the Outlaw Background.<i></i>",
		triggers: "Example triggers: Threaten, Apply Fists to Faces, Word on the Street, Take Control"
	},
	{
		id: "pbg_far_field_team",
		name: "FAR-FIELD TEAM",
		description: "You were a member of a Union far-field team (FFT), working on the frontier and the edge of civilization to evaluate strange worlds and planetoids for anomalies, discoveries, and habitability. <i>What have you seen on the wild frontier? How many worlds have you traveled? Were you part of a small team, or a large one? Where is your homeworld?</i><br>Something must drive you to explore: <i>Is it a grail world you seek? An Eden among the stars? Was your interest in the frontier mystical, scientific, based on old-fashioned curiosity, or spurred on by something else? Maybe there was a legend you heard, out there in the dark, that you long to find, or that you’re terrified you might encounter? What secrets – if any – have you encountered on your long-range surveys? Do you remain in contact with your old team members, if they’re still alive?</i><br>As a former (or current) part of an FFT, you're Cosmopolitan: <i>When was “your time”? How separate do you feel from the passage of time?</i>",
		triggers: "Example triggers: Survive, Investigate, Spot, Charm"
	},
	{
		id: "pbg_hacker",
		name: "HACKER",
		description: "You specialized in information warfare and data espionage, either for your own gain or the benefit of your employers. To you, the omninet – the faster-than-light information web that connects Union worlds – is home. <i>How did you come to this life? Did you grow up plugged into the omninet, or did you come to it late? How well-versed are you in the omninet’s hidden places, tricks, and secrets? How notorious were you before you became a pilot? Do people still whisper your name? Do other hackers remember you, and are you celebrated or cursed among them?</i><br>It wasn’t just the omninet that you hacked, though. <i>How adept are you at manipulating other networks? Can you manipulate discrete systems, genetic code, or some other type of environment, digital or mechanical? What secrets have you gained access to?</i>",
		triggers: "Example triggers: Act Unseen and Unheard, Get a Hold of Something, Hack or Fix, Invent or Create"
	},
	{
		id: "pbg_mechanic",
		name: "MECHANIC",
		description: "Grease monkey, wrench, working joe; you were a mechanic prior to becoming a pilot. <i>Did you work in space, swaddled in an EVA rig, patching up damaged starships? Or were you planetside, tuning trucks and haulers in a motor pool? Did you repair battle-torn mechs, dreaming that you might one day pilot your own? Did you own a garage, or did you work for someone? Were you military, corporate, part of a caste, or a union member? How handy are you in the field? Is there a side project you've been working on?</i>",
		triggers: "Example triggers: Hack or Fix, Get Somewhere Fast, Get a Hold of Something, Blow Something Up"
	},
	{
		id: "pbg_medic",
		name: "MEDIC",
		description: "You were a medical specialist in your old life. <i>How did you wind up piloting a mech? What was your specialty? Did you work in research, care, or trauma? Did you love the life and take your duty seriously, or did you see yourself as an organic mechanic?</i><br>You might have worked in a colony or on a core world, in private practice, for a corporation, or on a noble family’s payroll: <i>Did you operate a small frontier practice, or work in a blink station urgent care center, or in a massive hospital campus? Were you a whitecoat or an EMT? Is there a memory that haunts you, or one that gives you comfort?</i>",
		triggers: "Example triggers: Patch, Assault, Read a Situation, Stay Cool"
	},
	{
		id: "pbg_mercenary",
		name: "MERCENARY",
		description: "As a soldier of fortune, you lived by the motto, “have gun, will travel.” You and your kit were available to the highest bidder. <i>Did you work alone or with a crew? Did your company have a ship? Was this when you started piloting mechs of your own? What was your code of honor, if you had one?</i><br>Something pushed you to the mercenary life: <i>Was it the promise of riches? Desire for power? Adventure? Desperation?</i><br>For some reason, you left that life behind: <i>Why? Was there a job that went bad, or one that really was that legendary “one last job”? Are your old company mates still kicking around? Was there a rival company, or other enemies you made? Do you remember that time fondly, or do you never speak of it?</i>",
		triggers: "Example triggers: Threaten, Blow Something Up, Take Control, Apply Fists to Faces"
	},
	{
		id: "pbg_nhp_specialist",
		name: "NHP SPECIALIST",
		description: "You were closely involved in the study, creation, or maintenance of a prime non-human person. Nonhuman persons, or NHPs, are complex artificial intelligences. As a prime NHP, the one you were associated with was even more complex than most. <i>Did you interact with that entity like a scientist or engineer, or more like a priest or shaman? Do you have a personal connection to them, after all this time? How do clones of that NHP perceive you? And now that you’re a pilot, how do you feel about non-human intelligence?</i>",
		triggers: "Example triggers: Stay Cool, Read a Situation, Invent or Create, Investigate"
	},
	{
		id: "pbg_noble",
		name: "NOBLE",
		description: "You are a member of your world’s aristocracy, destined from birth to ascend to power. <i>From what authority does this birthright come? A god? An ancestor? An ancient text? A complex annual rotation? How is power passed down from one generation to the next?</i><br>Your noble status came from somewhere: <i>Are you the first in your family to receive a title of nobility, the last of your house, or the scion of a well-established line? Are you the heir, or just a middle child? What’s your relationship with your noble parents?</i><br>Whatever privileges you might have received at home, you found that Union disregards titles in its armed forces; your prior status is just background noise, unless you return home or belong to a group that recognizes nobility. <i>How did you take this change?</i>",
		triggers: "Example triggers: Pull Rank, Lead or Inspire, Read a Situation, Show Off"
	},
	{
		id: "pbg_outlaw",
		name: "OUTLAW",
		description: "You came from humble beginnings, born on the edge of cultivated space or beneath the looming towers of core worlds – forgotten until you reached out and took what was owed. Some call you criminal, thief, or outlaw, but you just tell it as it is: if they hadn’t denied you bread, you wouldn’t have had to take it. <i>Were you a brute or a raconteur? A charmer or a monster? Were your actions motivated by ideology, need, desire, or some combination of those three? Who defined you as an “outlaw\", and who saw you as a hero? Is there a bounty on your head?</i>",
		triggers: "Example triggers: Show Off, Take Someone Out, Charm, Survive"
	},
	{
		id: "pbg_penal_colonist",
		name: "PENAL COLONIST",
		description: "A long time ago, you were exiled to a penal colony for a sentence of hard labor. When the Third Committee abolished all penal colonies, your prison-planet was – in theory – “liberated”. Unfortunately, nothing much changed until Union’s relief ships finally arrived. Now free in practice as well as theory, places that had once been off-limits were made open to you: <i>Did you stay for a time? Or did you choose to leave, heading for the stars or trying to find your way back home? Were you guilty of your crimes, or unjustly condemned?</i><br>Penal colonies were harsh, unforgiving environments: <i>Was yours monitored by some authority, or was it relegated to anarchy even before Union's abolition of the system? Was there some kind of rudimentary society there? Did you have friends and enemies there, and did any of them make it off-world? What about your family – did you have one before your sentence? What has become of them, or do you not know?</i>",
		triggers: "Example triggers: Survive, Apply Fists to Faces, Word on the Street, Spot"
	},
	{
		id: "pbg_priest",
		name: "PRIEST",
		description: "You were a priest in your old life, either from a large, pan-galactic religion, or a smaller sect. <i>Were you a hermit? Did you live celibate in a monastery? Did you wear simple cloth robes, or majestic vestments? What restrictions were placed upon you by your church? What manner of respect was afforded to you as a person of the cloth, and was it your choice to become one? How did you come to serve as a pilot?</i><br>There are churches everywhere, each unique in their own ways. <i>Were you a member of a prominent religion, or a secretive, outlawed one? Did you preach a Terran faith, born on Cradle and carried for millennia since? Or was yours a Cosmopolitan spirituality, one from the stars and the void of interstellar space? Perhaps you ministered to a small flock of an obscure sect out on the frontier, or in the urban canyons of a core world? Have you kept your faith, or lost it?</i>",
		triggers: "Example triggers: Read a Situation, Stay Cool, Take Control, Lead or Inspire"
	},
	{
		id: "pbg_scientist",
		name: "SCIENTIST",
		description: "You were a scientist – private or public, working in the lab or the field. <i>What was your area of expertise, and for how long have you practiced it? Where did you study, and what’s your relationship with that institution? Do you have rivals, and are you well-known or relatively obscure? How did your home society perceive science? How did you become a pilot?</i><br><i>Importantly, did you work with a powerful manufacturer like Harrison Armory, Smith-Shimano, or IPS-N? Or did you delve into the uncanny, working in secret with a small, dedicated HORUS cell? What secrets do you know?</i>",
		triggers: "Example triggers: Investigate, Invent or Create, Get a Hold of Something, Blow Something Up"
	},
	{
		id: "pbg_soldier",
		name: "SOLDIER",
		description: "Grunt. GI. Ox. Poilu. Man-at-Arms. You were a soldier of the rank and file, serving in a planetary defense force, local militia, national army, or royal guard. <i>How long did you serve before Union called you up? What kind of specialty did you train for? Have you seen combat before, or are you green? Were you a volunteer, a conscript, or a member of a warrior caste? Is soldiering a proud family, civic, or religious tradition, or a life that you regret? Where are the other soldiers from your old squad, and what is your relationship with them like now?</i>",
		triggers: "Example triggers: Assault, Blow Something Up, Pull Rank, Take Control"
	},
	{
		id: "pbg_spaceborn",
		name: "SPACEBORN",
		description: "You grew up on a space station, in tight quarters and a small community, surrounded always by the unforgiving hard vacuum of space. <i>Were resources scarce, or plentiful? Was your station isolated or was it a local (or galactic!) hub? Was it parked in the endless night of deep space, or in orbit above a planet, moon, or another stellar body? Was it entirely manufactured, or was it built into an asteroid or moon?</i><br>No two stations are alike. <i>Did you grow up watching great ships dock and depart – exposed to the thousands of languages and cultures of the galaxy, dreaming of exploration – or did you grow up in dark, rocky halls, ignorant of the galaxy outside? In short, what was your life like, why did you leave, and can you go back?</i>",
		triggers: "Example triggers: Survive, Hack or Fix, Get Somewhere Fast, Stay Cool"
	},
	{
		id: "pbg_spec_ops",
		name: "SPEC OPS",
		description: "You might have been a spy or assassin, working alone, or maybe you were part of an elite unit, operating behind enemy lines with little-to-no support, equipped with the best equipment your commanders trusted you with.<i></i><br>Your missions were long, dangerous, and never publicized. If soldiers are hammers, you were a scalpel. Whatever organization you served, it was spoken only in whispers around military barracks and academies both. <i>What work did you do that no one knows was you or your unit? How close has the galaxy come to all-out war? Where have you operated? How old are you – really? What secrets do you know? Where is the rest of your team?</i>",
		triggers: "Example triggers: Act Unseen and Unheard, Take Someone Out, Spot, Stay Cool"
	},
	{
		id: "pbg_super_soldier",
		name: "SUPER SOLDIER",
		description: "You are the result of a corporate or state project intended to create better soldiers using biological enhancement, gene therapy, neurological enhancement, or even just extreme conditioning. <i>Were you raised from birth to become what you are, or did you volunteer as an adult for a super-soldier program? Are you one of the countless “super soldiers” to be produced by Harrison Armory’s facsimile-cloning programs? Was the project sanctioned or not? Did it succeed? Have you tested your abilities in the field, or are you unproven and eager to see what you can do?</i><br>Under the Third Committee, fewer programs like the one that created you still operate: <i>Are you happy about that, or do you think it makes Union weak? What is your relationship to your makers? Is there a family that doesn't know you exist? Or are you from a line of mass-pro‐ duced siblings? Were you liberated, did you surrender, or are you still in the service of the organization or entity you were made to serve?</i>",
		triggers: "Example triggers: Apply Fists to Faces, Get Somewhere Fast, Assault, Read a Situation"
	},
	{
		id: "pbg_starship_pilot",
		name: "STARSHIP PILOT",
		description: "You flew a starship – civilian, corporate, military or otherwise. You may have piloted a freighter, a fighter, a shuttle, or a larger ship. <i>Did you have a regular run, or did you fly anywhere? Were you a member of a crew, or did you have one of your own? What kind of flying did you do and what eventually happened to your ship? Did you stick to low and mid-orbit shuttle runs?</i><br>Being a pilot is as much a lifestyle as it is a profession: <i>What was your callsign, and were you known or obscure? Was there a rival service, pilot, or group of pilots that you had friction with? Have you worked with NHPs or flown in combat? Have you ever seen anything strange out in interstellar space or the total void of blinkspace?</i>",
		triggers: "Example triggers: Get Somewhere Fast, Show Off, Get a Hold of Something, Hack or Fix"
	},
	{
		id: "pbg_worker",
		name: "WORKER",
		description: "At the end of the day, empire only functions when labor clocks in. Labor mines the raw materials; labor fashions stone and metal and organic matter into bolts and screws and glue; labor designs the patterns for printers; labor shapes and welds, hammers and builds. Without the labor of trillions, all progress would grind to a halt. <i>Before you set down the wrench and picked up a helm, what kind of work did you do? Did you work in the fields, factories, shipyards, mines, or somewhere else? What was your life like before you began training as a pilot? Why did you leave? Will you return? Was there a project you worked on that you're especially proud of? Do you have an old crew still working on the clock? What world did you call home, and what were the working conditions there?</i>",
		triggers: "Example triggers: Word on the Street, Stay Cool, Lead or Inspire, Invent or Create"
	}
];

var backgrounds$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    'default': backgrounds
});

var core_bonuses = [
	{
		id: "cb_auto_stabilizing_hardpoints",
		name: "AUTO-STABILIZING HARDPOINTS",
		source: "GMS",
		effect: "Choose one mount. Weapons attached to this mount gain +1 Accuracy.",
		description: "Using the best in shock-absorption and steadytech, you can retain accuracy across longer, sustained periods of fire.",
		mounted_effect: "Attacks made with weapons from this mount can be made with +1 ACCURACY."
	},
	{
		id: "cb_overpower_caliber",
		name: "OVERPOWER CALIBER",
		source: "GMS",
		effect: "Choose one weapon. 1/round, when you hit with an attack, you can cause it to deal +1d6 bonus damage.",
		description: "Instead of the standardized option, you requisition multiple racks of “hot” ammunition – same-bore slugs, with a higher grade of accelerant.",
		mounted_effect: "One weapon equipped to this mount deals +1d6 bonus damage 1/round on hit."
	},
	{
		id: "cb_improved_armament",
		name: "IMPROVED ARMAMENT",
		source: "GMS",
		effect: "If your mech has fewer than three mounts (excluding integrated mounts), it gains an additional Flexible mount.",
		description: "By rerouting power and strengthening systems, you can mount additional weapons beyond the factory recommendations."
	},
	{
		id: "cb_integrated_weapon",
		name: "INTEGRATED WEAPON",
		source: "GMS",
		effect: "Your mech gains a new integrated mount with capacity for one Auxiliary weapon. This weapon can be fired 1/round as a free action when you fire any other weapon on your mech. It can’t be modified.",
		description: "The empty spaces in your mech’s chassis – inside fists, chest plates, anywhere there’s room – are filled with integrated weapons, ready to fire on reflex."
	},
	{
		id: "cb_mount_retrofitting",
		name: "MOUNT RETROFITTING",
		source: "GMS",
		effect: "Replace one mount with a Main/Aux mount.",
		description: "By re-fabricating certain components and hardpoints on your chassis for more efficient distribution, you can increase your mech’s firepower.",
		mounted_effect: "This mount has been replaced with a Main/Aux Mount."
	},
	{
		id: "cb_universal_compatibility",
		name: "UNIVERSAL COMPATIBILITY",
		source: "GMS",
		effect: "Any time you spend CP to activate a Core System, you may also take a free action to restore all HP, cool all Heat, and roll 1d20: on 20, regain 1 CP.",
		description: "The Everest is everywhere: so are the parts you need for a field repair."
	},
	{
		id: "cb_briareos_frame",
		name: "BRIAREOS FRAME",
		source: "IPS-N",
		effect: "As long as your mech has no more than 1 Structure, you gain Resistance to all damage. When it’s reduced to 0 HP and 0 Structure, it is not destroyed: instead, you must make a structure damage check each time it takes damage. While in this state, your mech cannot regain HP until you rest or perform a Full Repair, at which point your mech can be repaired normally.",
		description: "The Briareos is the newest release in IPS-N’s line of near-fail frame upgrades: templates designed to maximize a mech’s usability before catastrophic failure or the need for a reprint. The Briareos template increases the resilience of inorganic components by supplementing the structure with a superlight frame featuring interwoven layers of IPS-N’s iconic Goliath Weave meshing."
	},
	{
		id: "cb_fomorian_frame",
		name: "FOMORIAN FRAME",
		source: "IPS-N",
		effect: "Increase your mech’s Size by one increment (e.g., from 1/2 to 1, 1 to 2, or 2 to 3) up to a maximum of 3 Size. You can’t be knocked Prone, pulled, or knocked back by smaller characters, regardless of what system or weapon causes the effect.",
		description: "The Fomorian is an upscaled version of IPS-N’s stock template that has been adapted to meet the needs of long-haul Cosmopolitans looking for enhanced stability and robust impact protection, both micro- and macro-level."
	},
	{
		id: "cb_gyges_frame",
		name: "GYGES FRAME",
		source: "IPS-N",
		effect: "You gain +1 Accuracy on all Hull checks and saves and +1 Threat with all melee weapons.",
		description: "A mech built on the Gyges template is designed for combat – enhanced with finely tuned stabilizers and a robust suite of targeting software and hardware."
	},
	{
		id: "cb_reinforced_frame",
		name: "REINFORCED FRAME",
		source: "IPS-N",
		effect: "You gain +5 HP.",
		description: "The addition of redundant shock-absorption systems increases the survivability of pilots in combat, flight, and industrial situations."
	},
	{
		id: "cb_sloped_plating",
		name: "SLOPED PLATING",
		source: "IPS-N",
		effect: "You gain +1 Armor, up to the maximum (+4).",
		description: "A common choice among pilots with the right licenses, IPS-N’s integrated-armor fabrication reduces gaps in external coverage by a significant percentage."
	},
	{
		id: "cb_titanomachy_mesh",
		name: "TITANOMACHY MESH",
		source: "IPS-N",
		effect: "1/round, when you successfully Ram or Grapple a mech, you can Ram or Grapple again as a free action. Additionally, when you knock targets back with melee attacks, you knock them back 1 additional space.",
		description: "A double overlay of Goliath Weave at key stress points and beefed-up specifications across the board greatly improve the baseline functionality of any mech."
	},
	{
		id: "cb_all_theater_movement_suite",
		name: "ALL-THEATER MOVEMENT SUITE",
		source: "SSC",
		effect: "You may choose to count any and all of your movement as flying; however, you take 1 Heat at the end of each of your turns in which you fly this way.",
		description: "A popular modification, ATMS adds powerful pulse jets that dramatically improve mech mobility in all theaters."
	},
	{
		id: "cb_full_subjectivity_sync",
		name: "FULL SUBJECTIVITY SYNC",
		source: "SSC",
		effect: "You gain +2 Evasion.",
		description: "By creating a stable, two-way ontologic bridge, SSC has removed the need for pilots to rely on physical controls alone to pilot their mech. Using a full subjectivity sync, pilots perceive their mech as their own body and control it via neural impulse; somatosensory feedback is translated to the pilot as well, so caution is advised despite nociception-dampening defaults built-in to the system."
	},
	{
		id: "cb_ghostweave",
		name: "GHOSTWEAVE",
		source: "SSC",
		effect: "During your turn, you are Invisible. If you take no actions on your turn other than your standard move, Hide, and Boost, you remain Invisible until the start of your next turn. You immediately cease to be Invisible when you take a reaction.",
		description: "An upscaled version of the same systems found in SSC’s Mythimna Panoply, Ghostweave is a proprietary appliqué used to enhance mech camouflage in all environments."
	},
	{
		id: "cb_integrated_nerveweave",
		name: "INTEGRATED NERVEWEAVE",
		source: "SSC",
		effect: "You may move an additional 2 spaces when you Boost.",
		description: "Integrated nerveweave combines several technologies to grant total battlefield alacrity, assuring pilots are never left behind."
	},
	{
		id: "cb_kai_bioplating",
		name: "KAI BIOPLATING",
		source: "SSC",
		effect: "You gain +1 accuracy on all Agility checks and saves; additionally, you climb and swim at normal speed, ignore difficult terrain, and when making a standard move, can jump horizontally up to your full Speed and upwards up to half your Speed  (in any combination).",
		description: "Adapted from fauna local to SSC’s home system, Kai Bioplating adds a lamellar layer of insulated, anchored, and chitinous plating over key brush-points on a mech. Essentially a cheaper, more feasible alternative to living metal, bioplating allows for faster movement through hard-to-navigate terrain."
	},
	{
		id: "cb_neurolink_targeting",
		name: "NEUROLINK TARGETING",
		source: "SSC",
		effect: "Your ranged weapons gain +3 Range.",
		description: "To further reduce the information gap between pilot and machine and complement its full subjectivity sync technology, SSC developed neurolinking, a stable, non-invasive, and limited-transfer ontologic bridge. Neurolink targeting is a simple enhancement that helps pilots feel – as opposed to thinking – when engaged in ranged combat, allowing for a more natural expression of pilot ability."
	},
	{
		id: "cb_the_lesson_of_disbelief",
		name: "THE LESSON OF DISBELIEF",
		source: "HORUS",
		effect: "You gain +1 accuracy on Systems checks and saves, and +2 E-Defense.",
		description: "Query the omninet, delve into the archives. Find you the Aeneid, find you the age of Titanomachy. Eat, absorb, mull. Tell me now of the Hecatoncheires, they of the hundred hands. Did they strike the blow against Cronus – Saturno – or did they instead assail the Olympians? Who do you believe? Who stopped the Beast from telling its own story? And why? – “Lesson One”, The Six Lessons of Kilo Nueve."
	},
	{
		id: "cb_the_lesson_of_the_open_door",
		name: "THE LESSON OF THE OPEN DOOR",
		source: "HORUS",
		effect: "Your Save Target increases by +2; additionally, 1/round, when a character fails a save against you, they take 2 heat.",
		description: "There is a body and a deep pit, and both are named Tartarus. Once it held kings and titans and myths. Now, the gates that held it back are flung wide, and Tartarus is free. Here is the terrible question: who opened it, and why? – “Lesson Two”, The Six Lessons of Kilo Nueve."
	},
	{
		id: "cb_the_lesson_of_the_held_image",
		name: "THE LESSON OF THE HELD IMAGE",
		source: "HORUS",
		effect: "1/round, as a reaction at the start of any allied character’s turn, you may make a Lock On tech action against any character within line of sight and Sensors.",
		description: "Close your eyes. Hold the image of your enemy in your mind; imagine it in all light and from every angle. In your mind, it has become a more perfect version. Crush it in your mind and kill the perfect thing. Open your eyes. – “Lesson Three”, The Six Lessons of Kilo Nueve."
	},
	{
		id: "cb_the_lesson_of_thinking_tomorrows_thought",
		name: "THE LESSON OF THINKING-TOMORROW’S-THOUGHT",
		source: "HORUS",
		effect: "When you hit with a tech attack, your next melee attack against the same target gains +1 accuracy, and its damage can’t be reduced in any way.",
		description: "Let me tell you this lesson: the corporeal existence is one that must end in death. The incorporeal existence is one that [must] end in [cascade? do you really think that is true?]. I tell you again, if you can imagine it, it is [done] and you have already struck the killing blow. – “Lesson Four”, The Six Lessons of Kilo Nueve."
	},
	{
		id: "cb_the_lesson_of_transubstantiation",
		name: "THE LESSON OF TRANSUBSTANTIATION",
		source: "HORUS",
		effect: "Any time you take structure damage, you disappear into a non-space and cease to be a valid target. You reappear in the same space at the start of your next turn. If that space is occupied, you reappear in the nearest available free space (chosen by you).",
		description: "Through ecstatic repetition, you may see the face of God. Speak until your tongue dries and rattles to dust, and your body becomes nothing. When you are nothing and the wind takes you, you are in all things, never to be destroyed, only divided, until time's end. – “Lesson Five”, The Six Lessons of Kilo Nueve."
	},
	{
		id: "cb_the_lesson_of_shaping",
		name: "THE LESSON OF SHAPING",
		source: "HORUS",
		effect: "You may install an additional AI in your mech. If one enters cascade (or becomes unshackled narratively), the other prevents it from taking control of your mech. You only lose control of your mech if both AI-tagged systems or equipment enter cascade.",
		description: "A little gift, to be pondered until understood: Cast aside the hammer and sword, the cannon and beam. No weapon formed against me shall land a true blow, as I have seen all ends, and there is nothing left but me. A trillion trillion light-years in all directions, and through it all, only [us? who knows. ego is a mind-killer. best to call your friends. better to face the night together. ‘til later, love.] – “Lesson Six”, The Six Lessons of Kilo Nueve."
	},
	{
		id: "cb_adaptive_reactor",
		name: "ADAPTIVE REACTOR",
		source: "HA",
		effect: "When you Stabilize and choose to cool your mech, you may spend 2 Repairs to clear 1 stress damage.",
		description: "All Armory frames are designed with multiple failsafe systems, but VIP clients and high-tier citizenry have access to a special catalog. With dozens of options for over-engineering reactors, it’s easy to make sure a mech can keep running indefinitely."
	},
	{
		id: "cb_armory_sculpted_chassis",
		name: "ARMORY-SCULPTED CHASSIS",
		source: "HA",
		effect: "You gain +1 accuracy on all Engineering checks and saves. When you Overcharge, you gain soft cover until the start of your next turn.",
		description: "Anyone can print a stock mech chassis, relying on a section of generic code to keep them alive. The discerning pilot, on the other hand, accepts only the best: a frame designed, tested, and tuned by one of the Armory’s master fabricators."
	},
	{
		id: "cb_heatfall_coolant_system",
		name: "HEATFALL COOLANT SYSTEM",
		source: "HA",
		effect: "Your cost for Overcharge never goes past 1d6 heat.",
		description: "The Heatfall Coolant System comes packaged with a stabilized reactor core; paired together, this combo is guaranteed to keep a mech cool in nearly any environment."
	},
	{
		id: "cb_integrated_ammo_feeds",
		name: "INTEGRATED AMMO FEEDS",
		source: "HA",
		effect: "All Limited systems and weapons gain an additional two charges.",
		description: "By streamlining and integrating all automated ordnance-loading modules, Harrison Armory specialists can greatly enhance mechs’ time-to-target minimums. As an added bonus, these upgrades usually result in increased carrying capacity, allowing pilots to field more ordnance than design specifications suggest."
	},
	{
		id: "cb_stasis_shielding",
		name: "STASIS SHIELDING",
		source: "HA",
		effect: "Whenever you take stress damage, you gain Resistance to all damage until the start of your next turn.",
		description: "A Think Tank exercise in extending stasis beyond the capabilities of civilian utility, Harrison Armory’s stasis shielding actively identifies critically stressed inorganic systems and blankets them in unmodulated “Holdfast” stasis, preventing further degradation for a limited period of time until repairs can be made."
	},
	{
		id: "cb_superior_by_design",
		name: "SUPERIOR BY DESIGN",
		source: "HA",
		effect: "You gain Immunity to Impaired and gain +2 Heat Cap.",
		description: "Even the Armory’s entry-level frames aim to outperform the competition. Thanks to the incredible resources they have at their disposal, Harrison Armory can out-design and out-produce almost any smaller, boutique engineer or fabricator. Where resistance is found, the answer is simple: buy them out, or stamp them out. The Armory’s valued customers benefit from this philosophy of “Superior by Design”, so why should they worry?"
	}
];

var core_bonuses$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    'default': core_bonuses
});

var environments = [
	{
		id: "env_dangerousflorafauna",
		name: "Dangerous Flora or Fauna",
		description: "An unusually large proportion of this planet’s animal or plant life is dangerous; some of the flora and fauna may predatory, particularly hostile, or even titanic in size. Use the Monstrosity NPC type to generate encounters with wildlife. Hostile flora can appear on the battlefield as immobile characters with Size 1–2, 5 HP, and Evasion 10; targets that move adjacent to them must succeed on a Hull save or take 3 Kinetic Damage and become Immobilized until the flora is destroyed, as it traps them with sticky sap, webbing, a pit, or the like."
	},
	{
		id: "env_extremecold",
		name: "Extreme Cold",
		description: "Local cultures have adapted to the frozen climate, but mechs and pilots quickly freeze without a nearby source of heat. Mechs that don’t move or Boost on their turn become Immobilized at the end of their turn. This lasts until they break free with a successful Hull save as a quick action. In addition, all mechs gain Resistance to Heat."
	},
	{
		id: "env_extremeheat",
		name: "Extreme Heat",
		description: "Society has retreated mostly underground to escape this world’s blistering atmosphere. All Heat inflicted (to the user or others) by systems or weapons is increased by +1."
	},
	{
		id: "env_thinatmosphere",
		name: "Thin Atmosphere",
		description: "All characters gain Resistance to Explosive Damage."
	},
	{
		id: "env_extremesun",
		name: "Extreme Sun",
		description: "Characters take 1d6 Heat whenever they are aren’t in shade at the end of a turn."
	},
	{
		id: "env_corrosiveatmosphere",
		name: "Corrosive Atmosphere",
		description: "The dense atmosphere of this world eats through armor. All weapons gain AP."
	},
	{
		id: "env_particulatestorms",
		name: "Particulate Storms",
		description: "This planet is swept by brutal, scouring storms of sand, rock, or metal. During storms, mechs always have soft cover. Pilots that leave their mech take 1 Kinetic Damage (AP) each turn they are outside."
	},
	{
		id: "env_electricalstorms",
		name: "Electrical Storms",
		description: "This planet is swept by unusually strong electrical storms. During storms, choose a character at random at the end of each round: they must succeed on an ENGINEERING save with +1 Difficulty per level of Size or be STUNNED until the end of their next turn by a bolt of lightning."
	},
	{
		id: "env_disruptivestorms",
		name: "Disruptive Storms",
		description: "The storms on this planet are so highly charged that electronic systems can’t function. All tech actions, attacks, and SYSTEMS checks and saves receive +1 Difficulty."
	},
	{
		id: "env_dangeroustorms",
		name: "Dangerous Storms",
		description: "Storms of fire, meteors, acid rain, ice, or other destructive particles sweep this planet. During storms, all characters take 2 Energy Damage (AP) at the end of their turns unless they are adjacent to an object that grants hard cover."
	},
	{
		id: "env_oceanworld",
		name: "Ocean World",
		description: "Less than five percent of this world’s surface rises above the ocean. Mechs sink to the bottom and move as though in difficult terrain unless they are flying or have an EVA Module. Mechs can walk (slowly) on the bottom and are usually able to function in extremely high-pressure environments."
	},
	{
		id: "env_earthquakes",
		name: "Earthquakes",
		description: "This world is regularly rocked by earthquakes. During earthquakes, roll 1d6 at the end of each round: on 1, all mechs must succeed on a HULL save or be knocked Prone unless they are flying."
	},
	{
		id: "env_moltenworld",
		name: "Molten World",
		description: "Parts of this world’s crust juts through the surface in showers and pools of liquid rock. When characters move into areas of molten rock or lava for the first time on their turn or start their turn there, they take 5 Energy Damage (AP) and 3 Heat."
	},
	{
		id: "env_primordealworld",
		name: "Primordial World",
		description: "This world is a bubbling soup of semi-organic mud and gases. Humans must use breathing apparatuses or sealed suits outside of their mechs to survive the toxic atmosphere, and boiling mud creates numerous areas of both difficult and dangerous terrain."
	},
	{
		id: "env_lowgravity",
		name: "Low Gravity",
		description: "Mechs count as flying when they Boost but must land after they move. Characters never take damage from falling."
	},
	{
		id: "env_highgravity",
		name: "High Gravity",
		description: "Mechs cannot Boost and are Immobilized instead whenever they would be Slowed."
	},
	{
		id: "env_tombworld",
		name: "Tomb World",
		description: "This world has extremely high levels of ambient radiation, possibly because of nuclear war, atmospheric degradation, or something more sinister. Outside of mechs, humans without environmental protection temporarily decrease their maximum HP by 1 per hour of exposure. If they reach 0 HP this way, they die. They can regain their maximum HP by performing a Full Repair in a safe environment."
	},
	{
		id: "env_spireworld",
		name: "Spire World",
		description: "Instead of a surface, this world is comprised of countless floating islands or spires, each held aloft in a gaseous substrate and suspended through magnetic force. Perhaps the crust was shattered by a superweapon or natural disaster. Most of the remaining landmass is disconnected, although some islands are large enough to hold cities. Navigation systems are almost useless here."
	},
	{
		id: "env_sinkingworld",
		name: "Sinking World",
		description: "The surface of this world is covered in fine sand or thick mud. Mechs that move 1 space or less during their turn are Slowed. Slowed mechs that move 1 space or less are Immobilized and start sinking, eventually becoming completely engulfed. This effect lasts until an affected mech (or one adjacent to it) succeeds on a Hull save as a full action."
	},
	{
		id: "env_holyworld",
		name: "Holy World",
		description: "This world is beautiful and lacks especially dangerous features, but the local population holds it sacrosanct. Damaging any natural object – rocks, trees, and pristine grasslands, for example – incurs the wrath of the residents."
	}
];

var environments$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    'default': environments
});

var frames = [
	{
		id: "mf_standard_pattern_i_everest",
		source: "GMS",
		name: "STANDARD PATTERN I EVEREST",
		mechtype: [
			"Balanced"
		],
		y_pos: 25,
		description: "Most humans don’t think to ask about the history of the water they drink, the earth they walk, or the air they breathe. And yet, without water, earth, and air, there would be nowhere for humanity to make a home.<br>Just the same, the GMS-SP1 “Everest” is often taken for granted, its importance dismissed in favor of other, more specialized frames. A plain and unpretentious mech, defined by simple lines, functional grace, universal compatibility, and sturdy bulk, the Everest is as fundamental to the modern mechanized chassis as the natural world is to human life. The Everest isn’t the most specialized mech, but it is the backbone of our expansion imperative. From its shoulders, humanity steps.<br>Prior to GMS’s official adoption of the name, “Everest” was a use-name given to the frame by its pilots. Mount Everest – or Sagarmatha, or Chomolungma, as it has been called in older human tongues – is the tallest mountain on Cradle, though not the most prominent peak in known space, nor even the greatest in Cradle’s star system, yet pilots across the galaxy call their SP1s by that ancient name. Why?<br>The sentimental answer is that the name is a reminder of what was once the limit of human endurance – once the height of human achievement. To reach Everest’s summit was to defy death and stand atop the world – the culmination of months, even years, of training, investment, and hard work. Reaching the peak was also a triumph of the people, systems, and institutions behind the individual – a triumph too often left unacknowledged, or deliberately erased.<br>Sagarmatha. Chomolungma.<br>Even before the Fall, when the Massif vaults were built, some names – some stories – were given priority over others.<br>The real story behind the Everest’s name is likely much less deliberate. Somewhere along the line, a newly graduated pilot, frustrated by GMS’s plain naming conventions, painted “EVEREST” across the flank of their SP1. Maybe it was a callsign, or maybe it represented the pride they felt at success. Either way, the name stuck: others adopted the name, and over five centuries it grew to become the officially unofficial designation of the SP1 chassis.<br>Veteran pilots may never return to the Everest after moving on, but they’ll always remember reaching that first summit – the mountaintop where they proved they could plant their own flag at the peak of the world.<br>Sagarmatha. Chomolungma.<br>Everest – you’ll never forget it.",
		mounts: [
			"Main",
			"Flex",
			"Heavy"
		],
		stats: {
			size: 1,
			armor: 0,
			hp: 10,
			evasion: 8,
			edef: 8,
			heatcap: 6,
			repcap: 5,
			sensor_range: 10,
			tech_attack: 0,
			save: 10,
			speed: 4,
			sp: 6
		},
		traits: [
			{
				name: "Initiative",
				description: "1/scene the Everest may take any quick action as a free action."
			},
			{
				name: "Replaceable parts",
				description: "While resting, the Everest can be repaired at a rate of 1 Repair per 1 structure damage, instead of 2 Repairs."
			}
		],
		core_system: {
			name: "Hyperspec Fuel Injector",
			description: "",
			active_name: "Power Up",
			active_effect: "For the rest of this scene, you gain +1 Accuracy on all attacks, checks, and saves; additionally, 1/turn, you can Boost as a free action.",
			tags: [
				{
					id: "tg_protocol"
				}
			]
		},
		data_type: "frame",
		other_art: [
			{
				tag: "Mech",
				src: "pre_assault_pixel.png"
			},
			{
				tag: "Mech",
				src: "pre_hacker_pixel.png"
			},
			{
				tag: "Mech",
				src: "pre_sniper_pixel.png"
			},
			{
				tag: "Mech",
				src: "pre_support_pixel.png"
			},
			{
				tag: "Mech",
				src: "pre_vanguard_pixel.png"
			}
		],
		aptitude: {
		}
	},
	{
		id: "mf_blackbeard",
		source: "IPS-N",
		name: "BLACKBEARD",
		mechtype: [
			"Striker"
		],
		y_pos: 23,
		description: "The Blackbeard is IPS-N’s aggressive solution to piracy: a front-facing, first-striking mech designed for environments in which combustible kinetic weapons are useless, dangerous, or likely to cause unnecessary collateral damage. With its distinctly slim frame, the Blackbeard doesn’t just look fast – it also has a reduced radar profile. This mech is hard to track and harder still to hit.<br>The Blackbeard range comprises two lines: the standard IPS-N/BB-L production line model, and the IPS-N/BB-Sk, a limited-release prototype purpose-built to house IPS-N’s SEKHMET-class NHPs.",
		mounts: [
			"Flex",
			"Main",
			"Heavy"
		],
		stats: {
			size: 1,
			armor: 1,
			hp: 12,
			evasion: 8,
			edef: 6,
			heatcap: 4,
			repcap: 5,
			sensor_range: 5,
			tech_attack: -2,
			save: 10,
			speed: 5,
			sp: 5
		},
		traits: [
			{
				name: "Grapple cable",
				description: "The Blackbeard can Grapple targets within Range 5. If the Grapple is successful, the Blackbeard is immediately pulled adjacent to the target by the most direct path. If there are no suitable spaces, the grapple breaks and the Blackbeard does not move."
			},
			{
				name: "Lock/Kill Subsystem",
				description: "While grappling, the Blackbeard can Boost and take reactions."
			},
			{
				name: "Exposed reactor",
				description: "The Blackbeard receives +1 Difficulty on Engineering checks and saves."
			}
		],
		core_system: {
			name: "Assault Grapples",
			description: "The IPS-N-branded Assault Grappling System is a class-leading technology rated for hauling, supporting, and securing chassis of sizes up to Schedule 4. Grapple heads are interchangeable and can be swapped for engagement with soft or hard targets – either electrified or loaded with codespike systems for long-distance incapacitation.",
			active_name: "Omni-harpoon",
			active_effect: "This system fires grappling harpoons at any number of targets within Range 5 and line of sight. Affected characters must succeed on a Hull save or take 2d6 Kinetic damage and be knocked Prone, then pulled adjacent to you, or as close as possible. They become Immobilized until the end of their next turn. On a success, they take half damage and are otherwise unaffected.",
			tags: [
				{
					id: "tg_quick_action"
				}
			]
		},
		data_type: "frame",
		aptitude: {
		}
	},
	{
		id: "mf_drake",
		source: "IPS-N",
		name: "DRAKE",
		mechtype: [
			"Defender"
		],
		y_pos: 12,
		description: "The Drake, IPS-N’s first foray into military-grade mech design, is the backbone of any proactive trade-security or anti-piracy force. Its massive, simian frame is built around a single-cast bulkhead, sloped and reinforced to handle sustained fire and the vagaries of vessel-proximal hardvac travel. The Drake is an imposing chassis, its frame evoking the might of ancient armored infantry from a time when greater numbers guaranteed victory.<br>The standard fleet license for the IPS-N Drake outfits each chassis with IPS-N’s high-velocity, high–projectile fragment assault cannon for suppressing and overwhelming targets, and a heavy kinetic–ablative shield for defense. Advanced models feature upgraded weapons and armor including the formidable Leviathan Heavy Assault Cannon, a high-rpm anti-materiel weapon.",
		mounts: [
			"Main",
			"Main",
			"Heavy"
		],
		stats: {
			size: 2,
			armor: 3,
			hp: 8,
			evasion: 6,
			edef: 6,
			heatcap: 5,
			repcap: 5,
			sensor_range: 10,
			tech_attack: 0,
			save: 10,
			speed: 3,
			sp: 5
		},
		traits: [
			{
				name: "Heavy Frame",
				description: "The Drake can’t be pushed, pulled, knocked Prone, or knocked back by smaller characters."
			},
			{
				name: "Blast Plating",
				description: "The Drake has Resistance to damage, burn and heat from blast, burst, line, and cone attacks."
			},
			{
				name: "Slow",
				description: "The Drake receives +1 difficulty on Agility checks and saves."
			},
			{
				name: "Guardian",
				description: "Adjacent allied characters can use the Drake for hard cover."
			}
		],
		core_system: {
			name: "FORTRESS",
			description: "",
			active_name: "Fortress Protocol",
			active_effect: "You deploy heavy stabilizers and your mech becomes more like a fortified emplacement than a vehicle. When activated, two sections of hard cover (line 2, Size 1) unfold from your mech, drawn in any direction. These cover sections have Immunity to all damage.<br>Additionally, the following effects apply while active:<ul><li>You become Immobilized.</li><li>You benefit from hard cover, even in the open, and gain Immunity to Knockback, Prone, and all involuntary movement.</li><li>When you Brace, you may take a full action on your next turn instead of just a quick action.</li><li>Any character that gains hard cover from you or your cover sections gains Immunity to Knockback, Prone, and all involuntary movement, and gains the benefits of Blast Plating.</li></ul>This system can be deactivated as a protocol. Otherwise, it lasts until the end of the current scene.",
			tags: [
				{
					id: "tg_protocol"
				}
			]
		},
		data_type: "frame",
		aptitude: {
		}
	},
	{
		id: "mf_lancaster",
		source: "IPS-N",
		name: "LANCASTER",
		mechtype: [
			"Support"
		],
		y_pos: 16,
		description: "The IPS-N Lancaster is a mil-spec variant of an older IPS-N civilian terrestrial, inter/outer-hull transport and maintenance chassis, streamlined for use in any theater. The Lancaster features multiple redundant systems and sophisticated interaction projectors to ensure pinpoint accuracy when engaging with delicate systems, whether damaged or intact.<br>Lancaster pilots often adopt roles as sappers and engineers in frontline support. Sometimes ridiculed for piloting the old-fashioned frame by newer, untested pilots, veteran Lancaster jockeys know the truth: the Lancaster is one of the most reliable and well-made mechs out there, indispensable on any serious long-range mission. Not every mission is won with bullets, lasers, and bombs: without the engineers and their Lannies, few of those hotshots would come home alive.",
		mounts: [
			"Main/Aux"
		],
		stats: {
			size: 2,
			armor: 1,
			hp: 6,
			evasion: 8,
			edef: 8,
			heatcap: 6,
			repcap: 10,
			sensor_range: 8,
			tech_attack: 1,
			save: 10,
			speed: 6,
			sp: 8
		},
		traits: [
			{
				name: "Insulated",
				description: "The Lancaster has Immunity to burn."
			},
			{
				name: "Combat Repair",
				description: "In combat, the Lancaster can use 4 Repairs to repair a destroyed mech as a full action, returning it to 1 Structure, 1 Stress, and 1 HP."
			},
			{
				name: "Redundant Systems",
				description: "At your discretion, other characters adjacent to the Lancaster can spend its Repairs as their own."
			}
		],
		core_system: {
			name: "Latch Drone",
			description: "Known colloquially as a “Wingman”, latch drones are companion drones carried by and deployed from a chassis. Pilots are recommended not to develop emotional attachments to these drones due to their high casualty rate.",
			active_name: "Supercharger",
			active_effect: "Your Latch Drone clamps onto an allied mech within its Range. For the rest of the scene you take 1 heat at the start of each of your turns, but your target gains +1 accuracy on all attacks, checks, and saves, and Immunity to the Impaired, Jammed, Slowed, Shredded, and Immobilized conditions from characters other than itself. This effect ends if either character becomes Stunned.<br>While this system is active, you cannot use the Latch Drone for any other purpose.",
			tags: [
				{
					id: "tg_quick_action"
				}
			],
			integrated: {
				id: "mw_lancaster_integrated"
			}
		},
		data_type: "frame",
		aptitude: {
		}
	},
	{
		id: "mf_nelson",
		source: "IPS-N",
		name: "NELSON",
		mechtype: [
			"Striker"
		],
		y_pos: 35,
		description: "The IPS-N Nelson is the purest embodiment of the close-quarters doctrine espoused by its manufacturer. It is built to brawl, thriving when ordnance has been exhausted or when the environment is too volatile for firearms. With its functional size, the Nelson can strike fast and remain a difficult target to track. Layers of fractal-fold Armor-Lock plating with ceramic-analogous carbon flaking properties effectively nullify the impact of incoming ballistics by dispersing kinetic energy across a rounded hull. This null-k defense protects the pilot from impact trauma, allowing for sustained combat efficacy in high-trade scenarios.<br>The Nelson is an iconic IPS-N chassis, known across the galaxy as the favored frame of the Albatross, the nomadic order of Cosmopolitan peacekeepers. The Albatross’ distinctive white, gold, and red livery, mastery of the war pike, and apparent agelessness due to time dilation has won both them and the Nelson a venerated place in Diasporan lore – and secured an endorsement contract with IPS-N in perpetuity.",
		mounts: [
			"Flex",
			"Main/Aux"
		],
		stats: {
			size: 1,
			armor: 0,
			hp: 8,
			evasion: 11,
			edef: 7,
			heatcap: 6,
			repcap: 5,
			sensor_range: 5,
			tech_attack: 0,
			save: 10,
			speed: 5,
			sp: 6
		},
		traits: [
			{
				name: "Momentum",
				description: "1/round, after you Boost, the Nelson’s next melee attack deals +1d6 bonus damage on hit."
			},
			{
				name: "Skirmisher",
				description: "After attacking, the Nelson can immediately move 1 space in any direction as long as it isn’t Immobilize or Slowed. This movement ignores engagement and doesn’t provoke reactions."
			}
		],
		core_system: {
			name: "Perpetual Momentum Drive",
			description: "IPS-N’s Perpetual Momentum Drive exploits fighter-tier nearlight spooling to capture and sustain a passive .000001 ls charge, able to be dumped into boost systems upon command. Chassis equipped with this drive require heavy reinforcement, including strengthened joints and limbs, and installation of a k-comp crash couch to protect the pilot from sudden g-force and shear.",
			active_name: "Engage Drive",
			active_effect: "For the rest of the scene, Skirmisher allows you to move 4 spaces at a time instead of 1 space.",
			tags: [
				{
					id: "tg_protocol"
				}
			]
		},
		data_type: "frame",
		aptitude: {
		}
	},
	{
		id: "mf_raleigh",
		source: "IPS-N",
		name: "RALEIGH",
		mechtype: [
			"Striker"
		],
		y_pos: 12.5,
		description: "Seeing GMS and Harrison Armory’s push to secure whole-fleet line contracts with Union member states, IPS-N launched a brief foray into design and production of their own main battle line frame. Enter the Raleigh, a stylistic and design oddity for IPS-N. Designed not as a specialist, but as a purpose-built, close-range mech, the Raleigh failed to stun potential clients in trials.<br>Though a favorite of test pilots due to its unique styling and agility, the Raleigh saw few fleet orders and, after a brief run as IPS-N’s flagship, was quietly rolled back and replaced with the Tortuga. No longer offered as a fleet contract, the Raleigh enjoys a quiet popularity among pilots seeking a well-balanced, if close-ranged, line mech.",
		mounts: [
			"Aux/Aux",
			"Flex",
			"Heavy"
		],
		stats: {
			size: 1,
			armor: 1,
			hp: 10,
			evasion: 8,
			edef: 7,
			heatcap: 5,
			repcap: 5,
			sensor_range: 10,
			tech_attack: -1,
			save: 10,
			speed: 4,
			sp: 5
		},
		traits: [
			{
				name: "Full Metal Jacket",
				description: "At the end of its turn, if the Raleigh hasn’t made any attacks or forced any saves, it can reload all Loading weapons as a free action."
			},
			{
				name: "Shielded Magazines",
				description: "The Raleigh can make ranged attacks when Jammed."
			}
		],
		core_system: {
			name: "M35 Mjolnir cannon",
			description: "IPS-N’s M35 Mjolnir cannon is a carryover from Northstar’s Watchman line of defensive weapons, reworked for frontline combat. The Mjolnir is a hard-mounted, multi-barrel auxiliary cannon that uses magnetic acceleration to fire stacks of airburst projectiles at its target. It’s an impulse weapon, tied to the pilot’s second-tier neural processes with mediation from a comp/con or NHP; even in death, a pilot’s Mjolnir will continue to identify and attack hostile targets until reaching total systemic failure. For this reason, the Mjolnir is often referred to as a deadgun – one of many such weapons to be found among CQB-oriented pilots.",
			active_name: "Thunder God",
			active_effect: "You start to spin your M35 Mjolnir up, beginning with no chambered rounds. For the rest of the scene, you load two rounds into chambers at the end of any of your turns in which you haven’t fired the M35 Mjolnir . It can hold a maximum of six rounds.<br>When you fire the M35 Mjolnir, all chambers fire simultaneously, dealing 4 kinetic damage per loaded round. If you fire four or more rounds at once, the attack gains AP and, on a hit, your target becomes Shredded until the end of their next turn.",
			tags: [
				{
					id: "tg_protocol"
				}
			],
			integrated: {
				id: "mw_raleigh_integrated"
			}
		},
		data_type: "frame",
		aptitude: {
		}
	},
	{
		id: "mf_tortuga",
		source: "IPS-N",
		name: "TORTUGA",
		mechtype: [
			"Defender",
			"Striker"
		],
		y_pos: 20,
		description: "The Tortuga is IPS-N’s short-to-medium range line of mechs. Conceived, tested, and perfected in the void of deep space, the Tortuga was made to breach and clear carrier decks, hostile station environments, and the spinal columns of capital ships. It excels at occupying space and filling hallways with its angular bulk, often acting as a walking battering ram by boarding parties and marines. But the Tortuga defends just as effectively as it attacks, using its broad plates of brachial armor to shield itself and any advancing allies.",
		mounts: [
			"Main",
			"Heavy"
		],
		stats: {
			size: 2,
			armor: 2,
			hp: 8,
			evasion: 6,
			edef: 10,
			heatcap: 6,
			repcap: 6,
			sensor_range: 15,
			tech_attack: 1,
			save: 10,
			speed: 3,
			sp: 6
		},
		traits: [
			{
				name: "Sentinel",
				description: "The Tortuga gains +1 accuracy on all attacks made as reactions (e.g. Overwatch)."
			},
			{
				name: "Guardian",
				description: "Adjacent allied characters can use the Tortuga for hard cover."
			}
		],
		core_system: {
			name: "WATCHDOG co-pilot",
			description: "IPS-N security teams are no strangers to the dangers of ship-to-ship or ship-to-station boarding actions. Tight corridors, unstable gravity, dark environments, hard vacuum, and the potential dual threat of both organic and inorganic opposition make boarding actions some of the most statistically deadly engagement – according to IPS-N’s internal metrics, even the winning side should expect at least 30% casualties.Hoping to lessen the cognitive burden on pilots and any NHPs or comp/cons installed in their chassis, IPS-N developed the WATCHDOG co-pilot. The WATCHDOG is a simple subsentient partition: a flash-homunculus of aggregated intelligence generated from thousands of after-action reports from boarding actions, debriefings, and volunteer donors. Not an NHP, nor even a comp/con, the WATCHDOG is a robust tactical program similar to a smart weapon. That said, its ability to operate without cycling presents certain advantages: namely, these co-pilots have some capacity to learn and make best-guess predictions based on analysis of their pilots. WATCHDOGs tend to have plain personalities – to whatever extend they can be said to have one – and are a favorite of pilots looking for a no-nonsense attitude and crisp, efficient counsel.<br>The WATCHDOG system is currently under review by a joint USB/UDoJ-HR commission, but there has been no formal stay on production yet issued.",
			active_name: "Hyper-Reflex Mode",
			active_effect: "For the rest of this scene:<ul><li>If you have less than threat 3 with a ranged weapon, it increases to 3.</li><li>1/round, you may take an additional Overwatch reaction.</li><li>Any character you hit with Overwatch becomes Immobilized until the end of their next turn.</li></ul>",
			tags: [
				{
					id: "tg_protocol"
				}
			]
		},
		data_type: "frame",
		other_art: [
			{
				tag: "Mech",
				src: "alt_hortuga.png"
			}
		],
		aptitude: {
		}
	},
	{
		id: "mf_vlad",
		source: "IPS-N",
		name: "VLAD",
		mechtype: [
			"Controller",
			"Striker"
		],
		y_pos: 12.5,
		description: "The Vlad is the second iteration of IPS-N’s legacy Yi-Sun-Shin model, first made famous by Albatross pilots in the Celestine campaign during the fall of the Second Committee. With the wealth and quality of data generated by the Albatross in that conflict, IPS-N produced the Vlad, a power plant- and frame-upgraded spiritual successor to the Yi-Sun-Shin and deserving of a new line designation.<br>The Vlad, as the Sun did before it, shares much of its design philosophy and ancestry with IPS-N’s early asteroid-mining frames. Many of its standard armaments take inspiration from the early efforts of resourceful miners to convert tools into improvised anti-piracy weapons; likewise, its frame emphasizes redundancy, toughness, and component universality, allowing it to operate with outstanding self-sufficiency for long and/or dangerous deployments.<br>Heavily armored, the Vlad suits a frontline role where it can absorb fire from dangerous targets while lining up the perfect shot.",
		mounts: [
			"Flex",
			"Main",
			"Heavy"
		],
		stats: {
			size: 1,
			armor: 2,
			hp: 8,
			evasion: 8,
			edef: 8,
			heatcap: 6,
			repcap: 4,
			sensor_range: 5,
			tech_attack: -2,
			save: 11,
			speed: 4,
			sp: 5
		},
		traits: [
			{
				name: "Dismemberment",
				description: "When the Vlad inflicts Immobilize on another character, the target also becomes Shredded for the same duration."
			},
			{
				name: "Shrike Armor",
				description: "When a character within range 3 attacks the Vlad, the attacker first takes 1 AP kinetic damage."
			}
		],
		core_system: {
			name: "Shrike Armor",
			description: "Primarily a defensive modification, Shrike armor bristles with hardened chromium-tungsten spikes – a nod to the Vlad’s historical namesake. Shrike tips are strategically placed in areas with a high likelihood of kinetic encounters: gauntlets, manipulator joints, shoulder plating, and so on. Shrike armor is uncommon among pilots from the Core and is considered a mark of underdeveloped – if terrifying – tactics.",
			active_name: "Tormentor Spines",
			active_effect: "For the rest of this scene, you gain Resistance to all damage originating within range 3, and Shrike Armor deals 3 AP kinetic damage instead of 1.",
			tags: [
				{
					id: "tg_protocol"
				}
			]
		},
		data_type: "frame",
		other_art: [
			{
				tag: "Mech",
				src: "alt_agonist.png"
			}
		],
		aptitude: {
		}
	},
	{
		id: "mf_black_witch",
		source: "SSC",
		name: "BLACK WITCH",
		mechtype: [
			"Controller",
			"Support"
		],
		y_pos: 12.5,
		description: "The Black Witch is the flagship model of SSC’s LUX-Iconic line of frames, on paper meant to compete with Harrison Armory’s dominance in the field of cutting-edge gravity and electromagnetic manipulation. Utilizing the newest technologies developed by SSC’s Exotic Materials Group, the Black Witch is a fearsome area-control platform, often fielded in support of heavier mechs engaged in direct combat.<br>With a slim profile and strong defensive systems, the Black Witch is especially popular among the wealthier houses of the Karrakin Trade Baronies, who often place multiple orders to outfit their personal guards and house company officers. Next to internally produced Baronic frames, the Black Witch (alongside other SSC LUX-Iconic models) is the most popular SSC chassis throughout noble Karrakin space.",
		mounts: [
			"Main/Aux"
		],
		stats: {
			size: 1,
			armor: 1,
			hp: 6,
			evasion: 10,
			edef: 12,
			heatcap: 6,
			repcap: 3,
			sensor_range: 15,
			tech_attack: 0,
			save: 11,
			speed: 5,
			sp: 8
		},
		traits: [
			{
				name: "Repulsor field",
				description: "The Black Witch has Resistance to kinetic."
			},
			{
				name: "Mag parry",
				description: "1/round, as a reaction, you may attempt to parry an attack that would deal kinetic to you or an adjacent allied character. Roll 1d6: on 5+, the attack misses. This effect does not stack with Invisible."
			}
		],
		core_system: {
			name: "Magnetic Field Projector",
			description: "Magnetic field generators are a portable and field-deployable variation on typical magnetic defense technologies. When activated, they create a magnetic bubble that traps all incoming ferrous projectiles. The strength of the field is so great that it can even draw mechs to its center. When the field is dispersed or its solid-state battery burns out – a feature, not a flaw – the field undergoes a sudden catastrophic implosion, drawing all captured projectiles to a point at the center of the bubble.",
			active_name: "Mag Field",
			active_effect: "This system projects a blast 3 magnetic field with at least one space adjacent to you, causing the following effects until the end of your next turn:<ul><li>The affected area is difficult terrain.</li><li>Ranged attacks that deal kinetic or explosive can’t enter or leave the affected area – projectiles stop at the edge, doing no damage. Record each attack stopped this way.</li><li>Mechs and other characters made at least partly of metal that start their turn in the affected area or enter it for the first time in a round must succeed on a Hull save or be pulled as close to the center as possible and become Immobilized.</li></ul>When the effect ends, any ranged attacks that were stopped resume their trajectory – toward the center of the affected area. The GM rolls attacks against each character within, gaining +1 per blocked attack (to a maximum of +6). On hit, these attacks deal 1d6 kinetic damage per blocked attack (to a maximum of 6d6 kinetic damage).",
			tags: [
				{
					id: "tg_full_action"
				}
			]
		},
		data_type: "frame",
		aptitude: {
		}
	},
	{
		id: "mf_deaths_head",
		source: "SSC",
		name: "DEATH’S HEAD",
		mechtype: [
			"Artillery"
		],
		y_pos: 40,
		description: "The Death’s Head is Smith-Shimano’s answer to the need for a chassis solution to long-range, low-splash strike actions. Sacrificing raw hull strength for peerless stability and alacrity, the Death’s Head is a maneuverable fire-support platform able to avoid incoming fire while maintaining a near-perfect lock on its targets. Its unique hexapedal form allows for rapid, low-profile movement in all directions.<br>As an aggressive and line-focused chassis, the Death’s Head is one of the most popular models for Union Navy and Union Department of Justice and Human Rights officers. It is a combat chassis through and through; as the Death’s Head is a chassis produced under SSC’s BELLA CIAO line, there is no civilian analog.",
		mounts: [
			"Main/Aux",
			"Heavy"
		],
		stats: {
			size: 1,
			armor: 0,
			hp: 8,
			evasion: 10,
			edef: 8,
			heatcap: 6,
			repcap: 2,
			sensor_range: 20,
			tech_attack: 0,
			save: 10,
			speed: 5,
			sp: 6
		},
		traits: [
			{
				name: "Neurolink",
				description: "The Death’s Head may reroll its first ranged attack each round, but must keep the second result."
			},
			{
				name: "Perfected Targeting",
				description: "The Death’s Head gains an additional +1 to all ranged attack rolls."
			}
		],
		core_system: {
			name: "Precognitive Targeting",
			description: "Precognition is the next step in human/AI interaction. Using a neural bridge, SSC’s precognitive targeting system allows pilots to learn constantly and unconsciously from data gathered in the field, equipping them to read situations before they develop. Precognition is highly experimental and the precise mechanisms unknown even to the designers, so SSC recommends limited, monitored use of this system.",
			active_name: "Neural Shunt",
			active_effect: "For the rest of this scene, you gain the Mark for Death action.<br>Mark for Death<br>Full Action<br>Choose a character within range 30 but further than range 5 to focus on; while focusing, you become Immobilized and can’t take reactions, but you deal bonus damage based on weapon size (aux: 1d6, main: 2d6, heavy or larger: 3d6) on ranged critical hits against them, as long as they aren’t in cover or within range 5.<br>You may only focus on one character at a time. As a protocol, you may cease focusing on a target.",
			tags: [
				{
					id: "tg_protocol"
				}
			]
		},
		data_type: "frame",
		other_art: [
			{
				tag: "Mech",
				src: "alt_hercules.png"
			}
		],
		aptitude: {
		}
	},
	{
		id: "mf_dusk_wing",
		source: "SSC",
		name: "DUSK WING",
		mechtype: [
			"Controller",
			"Support"
		],
		y_pos: 35,
		description: "The Dusk Wing originated as a legacy-inspired modification package to EVA suits, intended to equip them for hazardous environments. In the early days of deep-space exploration, there was a need for mechanized exoskeletons that not only amplified capacity but enhanced kinetic defense. The Dusk Wing is the spiritual heir of those early deep-space suits. Fast and small, it carries a complement of all-theater maneuverability jets that allow for near-perfect flight.<br>After the DHIYED expedition, the Exotic Materials Group isolated and translated strains of the entity’s realspace expiry paracode, teleologics, and kinematics for use in electronic and systems warfare. Of the frames trialed for use with DHIYED-derived technologies, the Dusk Wing performed best. As a result, it is often used by SSC’s internal Constellar Security forces when esoteric defense is necessary.",
		mounts: [
			"Aux/Aux",
			"Flex"
		],
		stats: {
			size: 0.5,
			armor: 0,
			hp: 6,
			evasion: 12,
			edef: 8,
			heatcap: 4,
			repcap: 3,
			sensor_range: 10,
			tech_attack: 1,
			save: 11,
			speed: 6,
			sp: 6
		},
		traits: [
			{
				name: "Maneuverability Jets",
				description: "The Dusk Wing can hover when it moves."
			},
			{
				name: "Harlequin Cloak",
				description: "During its turn, the Dusk Wing is Invisible; it reappears at the end of the turn."
			},
			{
				name: "Fragile",
				description: "The Dusk Wing receives +1 difficulty on Hull checks and saves."
			}
		],
		core_system: {
			name: "DHIYED Articulation",
			description: "“Belief in what we could see, what we could touch – in what our comp/cons assured us was there, in our own subjectivity and memory. Belief in reality became a weapon. We approached the metavault knowing that we would face an unknown enemy, but we approached with the advantage of numbers and machine strength.<br>“DHIYED taught us as it killed us: through garbled comms chatter, through the screams of the dying, through the cackling of our mirror-selves as they killed us. Every spoofed signature, every temporal skip, every memetic, every non-Euclid – these were lessons.<br>“Do you understand?<br>“DHIYED the Teacher. DHIYED the Monster. As we killed it, DHIYED taught us what to fear, and how to face it.<br>“What do I fear now? That's a good question. What does the pilot fear who cracked open DHIYED’s casket?<br>“I don’t think we killed it. I think it wants us to believe we killed it – and I cannot imagine what it has done while we think ourselves safe.”",
			active_name: "Hall of Mirrors",
			active_effect: "For the rest of the scene, whenever you start a unique movement during your turn (e.g., a standard move, Boost, or movement granted by talents or systems), you leave a holographic imprint of yourself behind in the space from which you started. These are illusory objects the same Size as you that have Immunity to all damage and effects and aren’t obstructions.<br>When hostile characters start their turn in, move through, or move adjacent to the space occupied by a hologram, it detonates. They must succeed on an Agility save or take 1d6 energy damage. On a success, they take half damage.<br>You may instantly teleport to the location of any hologram within range 50 as a quick action. When you do so, all extant holograms detonate – creating burst 1 explosions with the same effect as above – and you may not create any new holograms until the start of your next turn.",
			tags: [
				{
					id: "tg_protocol"
				}
			]
		},
		data_type: "frame",
		aptitude: {
		}
	},
	{
		id: "mf_metalmark",
		source: "SSC",
		name: "METALMARK",
		mechtype: [
			"Striker"
		],
		y_pos: 16,
		description: "The Metalmark is the backbone of SSC’s BELLA CIAO mil-spec chassis line, fully equipped with a comprehensive suite of proprietary design and engineering hallmarks to ensure its survivability, deadliness, and agility. Under the increasingly militaristic reign of Union’s Second Committee, SSC’s corporate board pushed to develop the company’s mil-spec supply, logistics, and personal defense divisions; following the advent of the mechanized chassis, the budding SSC SupLogDef division was restructured and refocused to concentrate on chassis development. The first iterations of the Metalmark were designed for the Second Committee’s WARRIOR NEXT program: however, before the chassis could be tested, the Hercynian Crisis spiraled out of control, toppling the Second Committee.<br>The Metalmark was retired in the wake of the Crisis and the restructuring of Union’s Central Committee, deemed too time consuming to produce as a mass-market chassis. SSC reworked the frame, tapped it to lead their new BELLA CIAO line, and concentrated on small-market, exclusive security contracts. The Metalmark is now a valued model among security forces. Its form reflects SSC’s deep-space and long-patrol heritage, blending anthropomorphic and aquiline design elements, sturdy construction, and multiple redundant systems. Leaning fully into their operator-specific marketing, all Metalmark models come standard with a Smith Custom Leather gimbaled pilot seat to ensure comfort on long deployments.",
		mounts: [
			"Aux/Aux",
			"Main",
			"Heavy"
		],
		stats: {
			size: 1,
			armor: 1,
			hp: 8,
			evasion: 10,
			edef: 6,
			heatcap: 5,
			repcap: 4,
			sensor_range: 10,
			tech_attack: 0,
			save: 10,
			speed: 5,
			sp: 5
		},
		traits: [
			{
				name: "Flash Cloak",
				description: "The Metalmark is Invisible while moving, but reappears when stationary."
			},
			{
				name: "Carapace Adaptation",
				description: "When the Metalmark is in soft cover, ranged attackers receive +2 difficulty instead of +1 difficulty."
			}
		],
		core_system: {
			name: "Tactical Cloak",
			description: "Tactical cloaks are tight-knit, tight-bind weaves of reactive fabric – high-license tech restricted to pilots of Metalmark Classification II or higher. The weave covers roughly 80% of a mech’s surface area, giving it a dull quality when viewed through optics or with the naked eye. Beyond their use as regular camouflage, activated tactical cloaks bend light in a way that makes their wearers nearly impossible to see.",
			active_name: "Tactical Cloak",
			active_effect: "You are Invisible for the rest of the scene.",
			tags: [
				{
					id: "tg_protocol"
				}
			]
		},
		data_type: "frame",
		aptitude: {
		}
	},
	{
		id: "mf_monarch",
		source: "SSC",
		name: "MONARCH",
		mechtype: [
			"Artillery"
		],
		y_pos: 14,
		description: "The Monarch is SSC’s groundbreaking lesson in how to design a fast platform for the delivery of missiles and other self-propelled ordnance. Ready to mount ground-to-ground, ground-to-air, ground-to-orbit, and all-theater missiles and guidance systems, the Monarch can be customized for any payload and any target distance.<br>The Monarch’s large size often leads pilots to underestimate its agility. SSC's rigorous design requirement of one designer per 10 Monarch printings is a mark of luxury in Union’s Core world post-scarcity environment. This emphasis on  purposeful scarcity is all that prevents the Monarch from achieving total battlefield dominance. The Monarch is commonly deployed in mixed line and fire-support roles, though field tests of a less resource-taxing MicroMonarch mid- to close-range model is underway. The Monarch is part of SSC’s BELLA CIAO line of combat chassis.",
		mounts: [
			"Flex",
			"Main",
			"Heavy"
		],
		stats: {
			size: 2,
			armor: 1,
			hp: 8,
			evasion: 8,
			edef: 8,
			heatcap: 6,
			repcap: 3,
			sensor_range: 15,
			tech_attack: 1,
			save: 10,
			speed: 5,
			sp: 5
		},
		traits: [
			{
				name: "Avenger Silos",
				description: "1/round, on a critical hit with any ranged weapon, the Monarch may deal 3 explosive to a different character of your choice within range 15 and line of sight."
			},
			{
				name: "Seeking payload",
				description: "The Monarch can use a Launcher weapon to attack a character with the Lock On condition as if its weapon had Seeking, but must consume the Lock On during the attack. When it does so, the attack’s damage cannot be reduced in any way."
			}
		],
		core_system: {
			name: "SSC-30 High-Penetration Missile System",
			description: "The SSC-30 High-Penetration Missile System (SSC-30 HPMS) is a mech-mounted micro-missile delivery system capable of tremendous combat output. Using the SSC-30 HPMS, the Monarch can carry – and deliver – its payload of 60 or more deadly, miniaturized Avenger warheads in a single volley.",
			active_name: "Divine Punishment",
			active_effect: "Choose any number of characters within range 50: your targets must each succeed on an Agility save or take 1d6+4 explosive. On a success, they take half damage. These self-guiding missiles can reach any target as long as there is a path to do so.",
			tags: [
				{
					id: "tg_full_action"
				}
			]
		},
		data_type: "frame",
		aptitude: {
		}
	},
	{
		id: "mf_mourning_cloak",
		source: "SSC",
		name: "MOURNING CLOAK",
		mechtype: [
			"Striker"
		],
		y_pos: 62,
		description: "The Mourning Cloak is a brand-new model from SSC’s LUX-Iconic line, and the manufacturer’s newest close-quarters combat and melee specialist frame. The Mourning Cloak emphasizes precision melee combat and is commonly outfitted with a complement of shielded microfilament wires designed to act as an anti-armor slashing weapon.<br>Designed by SSC’s Exotic Materials Group based on data from early engagements against the Ascendant Aun in Boundary Garden, the Mourning Cloak combines SSC’s harvested excerpts of DHIYED paracode with adapted Aunic Firmament-manipulation technology. The Mourning Cloak provides a prestigious and tactical option for situations where firearms are impractical and ordnance is unavailable. As part of the LUX-Iconic line, the Mourning Cloak is a popular order in the Baronies and among various high-manna VIP security firms.",
		mounts: [
			"Flex",
			"Main/Aux"
		],
		stats: {
			size: 1,
			armor: 0,
			hp: 8,
			evasion: 12,
			edef: 6,
			heatcap: 4,
			repcap: 3,
			sensor_range: 15,
			tech_attack: 0,
			save: 10,
			speed: 5,
			sp: 6
		},
		traits: [
			{
				name: "Hunter",
				description: "1/round, the Mourning Cloak may deal +1d6 bonus damage on hit with a melee attack if its target has no adjacent characters, or if the Mourning Cloak is the only character adjacent to the target."
			},
			{
				name: "Biotic Components",
				description: "The Mourning Cloak gains +1 accuracy on Agility checks and saves."
			}
		],
		core_system: {
			name: "EX Slipstream Module",
			description: "Open only to highly licensed pilots, the EX Slipstream program is a uniquely SSC innovation. The Ex Slipstream module itself is a miniaturized near-lightspeed drive capable of transporting the user through blinkspace with acceptable accuracy. The technology is temperamental, at best: nothing smaller than a mech can survive the stress of exposed blink travel, and the experience is traumatic to both the user and anyone in close proximity.",
			active_name: "Stabilize Singularity",
			active_effect: "For the rest of the scene, you teleport when you Boost or make a standard move.",
			tags: [
				{
					id: "tg_protocol"
				}
			],
			passive_name: "Blinkspace Jump",
			passive_effect: "Full Action<br>You teleport to a space within range 3d6. You don’t require line of sight, but attempts to teleport to occupied spaces cause you to remain stationary and lose this action. If you roll the same number on all three dice, you disappear until your group rests, at which point you reappear nearby."
		},
		data_type: "frame",
		aptitude: {
		}
	},
	{
		id: "mf_swallowtail",
		source: "SSC",
		name: "SWALLOWTAIL",
		mechtype: [
			"Support"
		],
		y_pos: 30,
		description: "The Swallowtail is Smith-Shimano’s primary long-range scouting and fire-support platform, built for rapid and sustained ranging across hostile, volatile environments. Built for long-term sustainability, it can operate in unstable environs for months and maximize its survivability by adjusting its operating efficiency on the fly. Each unit has an integrated cloak and a suite of predictive choral intelligences that coordinate its highly developed sensor systems to rapidly simulate and predict tactical developments – sometimes before they even occur.<br>The Swallowtail’s base model, the SW-01, is one of SSC’s few mass-produced lines – the entry-level BELLA CIAO model. Built without a cloaking field and up-armored to address direct security requirements, the SW-01 is especially popular among the rank and file troopers of Constellar Security forces.",
		mounts: [
			"Flex",
			"Aux/Aux"
		],
		stats: {
			size: 1,
			armor: 0,
			hp: 6,
			evasion: 10,
			edef: 10,
			heatcap: 4,
			repcap: 5,
			sensor_range: 20,
			tech_attack: 1,
			save: 10,
			speed: 6,
			sp: 6
		},
		traits: [
			{
				name: "Integrated Cloak",
				description: "At the end of its turn, the Swallowtail becomes Invisible if it hasn’t moved that turn. This lasts until it moves or takes a reaction, or until the start of its next turn."
			},
			{
				name: "Prophetic Scanners",
				description: "1/round, when the Swallowtail inflicts Lock On, its target also becomes Shredded until the end of its next turn."
			}
		],
		core_system: {
			name: "Cloudscout TACSIM Swarms",
			description: "Cloudscout TACSIM Swarms are packets of networked microsensors, launched in nonlethal mortar canisters that detonate high above the battlefield. Once seeded, the swarm generates a TACSIM program that begins to run brevity cycles: tight, contained simulations of tactical possibility. Probability results are then fed to the Swallowtail’s choir processors, which in turn feed it to the pilot and networked squad members, ensuring a high probability of successful outcomes.",
			active_name: "Prophetic Interjection",
			active_effect: "Gain the Tactical Simulation reaction for the rest of the scene.<br>Tactical Simulation<br>1/round, Reaction<br>Trigger: An allied character in line of sight takes damage from another character in line of sight.<br>Effect: Roll 1d6. On 4+, the attack was actually a simulation predicted by your processor - your ally gains Resistance to all damage dealt by the attack and may teleport up to 3 spaces, representing their “true” location. On 3 or less, there’s a glitch – your allied doesn’t gain Resistance, but can teleport up to 6 spaces.",
			tags: [
				{
					id: "tg_protocol"
				}
			]
		},
		data_type: "frame",
		aptitude: {
		}
	},
	{
		id: "mf_balor",
		source: "HORUS",
		name: "BALOR",
		mechtype: [
			"Striker",
			"Defender"
		],
		y_pos: 27,
		description: "As is the case with most HORUS pattern groups, the Balor has a thousand faces. The Balor pattern group, like all HORUS PGs, doesn’t describe a single recognizable silhouette so much as it gestures toward a combination of schemata that share a role in combat. These schemata can be printed according to pilot specifications and applied to a fully custom physical scaffolding. Notably, the Balor pattern group is only stable on large platforms (Schedule 2 and up) that are able to provide the raw energy output it demands – preferably ones with multiple redundancies, in case of catastrophic systems failure.<br>The Balor PG was first encountered during the joint Albatross–DoJ/HR pursuit of the Maw – a Free Company turned decentralized hive-being — across Khayradin’s Blanca Desert after the end of the Sanjak Rebellion. It was there that the joint force encountered, engaged with, and ultimately defeated the Maw and its Balors – and there that Union’s CentComm hoped the nanowash outbreak could be contained. Of course, subsequent Balor outbreaks on Khayradin have proven this hope to be in vain, and the pattern group continues to terrorize Karrakin commanders throughout Baronic space.<br>In the field, the Balor’s neurosynced hellswarm and greywash nanites form an undulating shroud that can pour out of its chassis at a moment’s notice, swirling in maddening patterns to form both eschatologic defensive and offensive systems. A Balor in its most active state is held together more by undulating, flame-like masses of nanite swarms than any physical structure. This has the effect of distributing kinetic and coherent-particle energy out across and through the chassis – making attacks against a Balor “like shooting angry water”, as one after-action report put it.",
		mounts: [
			"Main",
			"Heavy"
		],
		stats: {
			size: 2,
			armor: 0,
			hp: 12,
			evasion: 6,
			edef: 10,
			heatcap: 4,
			repcap: 4,
			sensor_range: 5,
			tech_attack: 1,
			save: 10,
			speed: 3,
			sp: 6
		},
		traits: [
			{
				name: "SCOURING SWARM",
				description: "The Balor deals 2 kinetic to characters of its choice that start their turn grappled by or adjacent to it."
			},
			{
				name: "Regeneration",
				description: "At the end of its turn, the Balor regains 1/4 of its total HP. When it takes stress or structure damage, this effect ceases until the end of its next turn."
			},
			{
				name: "SELF-PERPETUATING",
				description: "When you rest, the Balor regains full HP automatically and without REPAIRS."
			}
		],
		core_system: {
			name: "Hellswarm",
			description: "In a moment, with aught but desire, the pilot of a Balor may quick-print a cloak comprised of countless minuscule drones: a hellswarm cloak – living shield and fluid-dynamic knife, cutting and guarding, in one shimmering wave. They become Hivemaster, and their will is obeyed by millions.",
			active_name: "Hive Frenzy",
			active_effect: "Your nanites switch into a hyperactive mode, causing the following effects until the end of the scene:<ul><li>You and adjacent allies gain soft cover.</li><li>Scouring Swarm deals 4 kinetic, instead of 2.</li><li>Regeneration restores 1/2 of your total HP, instead of 1/4.</li><li>If you would take structure damage, roll 1d6: on 6, your mech hellishly pulls itself together, taking no structure damage, returning to 1 HP, and gaining Immunity to all damage until the end of the current turn.</li><li>You become Shredded and cannot clear this condition for the duration.</li></ul>",
			tags: [
				{
					id: "tg_protocol"
				}
			]
		},
		data_type: "frame",
		aptitude: {
		}
	},
	{
		id: "mf_goblin",
		source: "HORUS",
		name: "GOBLIN",
		mechtype: [
			"Controller",
			"Support"
		],
		y_pos: 12.5,
		description: "The Goblin was the first identified HORUS frame, and is likely the oldest legacy chassis prior to HORUS’s transition to pattern groups. Transmission records traced back to the Goblin’s zero model indicate the first chassis was leaked onto the omninet in 4900u. This year serves as HORUS’s assumed “foundation day” for most scholars and intelligence officers who study the group, though contradictory signatures indicate that 4900u is far too late to mark its birth.<br>The Goblin is a small mech, not much larger than a hardsuit, that relies on its small size and excellent maneuverability to protect its pilot. It packs an interesting recursive processing weave that facilitates electronic warfare capabilities well beyond theoretical parameters.<br>GMS technicians are still, more than a century later, working to reverse engineer the Goblin and its processing weave. The most recent investigations suggest that it employs technology consistent with hieroglyphic inscriptions noted on LRA.7726235-B and corroborated by tablets transmitted by UIB-GORGON from Metavault XOLOTL prior to the vault’s disappearance.",
		mounts: [
			"Flex"
		],
		stats: {
			size: 0.5,
			armor: 0,
			hp: 6,
			evasion: 10,
			edef: 12,
			heatcap: 4,
			repcap: 2,
			sensor_range: 20,
			tech_attack: 2,
			save: 11,
			speed: 5,
			sp: 8
		},
		traits: [
			{
				name: "LITURGICODE",
				description: "The Goblin gains +1 accuracy on tech attacks."
			},
			{
				name: "REACTIVE CODE",
				description: "1/round, when the Goblin is hit by a tech attack, the Goblin may take any Quick Tech option against the attacker as a reaction."
			},
			{
				name: "FRAGILE",
				description: "The Goblin receives +1 difficulty on Hull checks and saves."
			}
		],
		core_system: {
			name: "INSTINCT Rig",
			description: "One of the first Goblin-pattern systems cracked by GMS technicians was its e-warfare invasion rig, although the rig’s advanced capabilities and architecture remain impenetrable. When installed, the rig manifests a subsentient intelligence – designated INSTINCT – that assists invasion attempts against target systems using a mix of physical and systemic parasymbiotic systems. Invasions attempted while INSTINCT is active are not perceived by the user as code and script, but as an attack on organic matter. INSTINCT has displayed the capacity to act independently, often preempting its user, but generally in their best interest. Readme documentation included in some Goblin manifestations recommend that pilots cycle their mech cores at least once a month to prevent spontaneous enlightenment, though most do not make note of this warning.",
			active_name: "Symbiosis",
			active_effect: "Your mech retracts its major systems and attaches itself to another mech, becoming more like a vestigial blister than a separate entity. The host must be an allied and willing mech not already hosting another Goblin, larger than and adjacent to you. While attached, you occupy their space, move with them, and benefit from hard cover, but can still be attacked and targeted separately. You also take any conditions and heat taken by your host.<br>Your host may use your Systems, E-Defense, and Tech Attack instead of their own. Additionally, from the beginning of the next round, you no longer take your own turns; instead, you can take two quick actions or one full action at any point during your host’s turn. You can’t Overcharge or move, but may still take reactions and free actions normally. Your host’s turn counts as your turn for the purpose of effects that refer to the start or end of a character’s turn.<br>This effect lasts either for the rest of the scene, until you detach as a quick action, or until you or your host becomes Stunned. When the effect ends, you don’t take a turn until the next round.",
			tags: [
				{
					id: "tg_quick_action"
				}
			]
		},
		data_type: "frame",
		aptitude: {
		}
	},
	{
		id: "mf_gorgon",
		source: "HORUS",
		name: "GORGON",
		mechtype: [
			"Defender"
		],
		y_pos: 5,
		description: "The Gorgon is unique among HORUS pattern groups in that it prioritizes defensive systems meant to ensure personal and allied survival; otherwise, it fields a typical complement of horrifying, confusing, and uncanny weapons.<br>The typical Gorgon mounts multiple weapon systems meant to identify and intercept incoming enemies, allowing pilots to project a zone of control around themselves and their allies. The Gorgon is feared for its ability to extrude a dangerous memetic “basilisk”, a projected light-cone of anticognitive, hyperfractal visual data that is deadly to ontologic, sapient beings.",
		mounts: [
			"Flex",
			"Main",
			"Main"
		],
		stats: {
			size: 2,
			armor: 0,
			hp: 12,
			evasion: 8,
			edef: 12,
			heatcap: 5,
			repcap: 3,
			sensor_range: 8,
			tech_attack: 1,
			save: 12,
			speed: 4,
			sp: 6
		},
		traits: [
			{
				name: "METASTATIC PARALYSIS",
				description: "When an attack roll against the Gorgon lands on 1–2, it automatically misses and the attacker becomes Stunned until the end of their next turn."
			},
			{
				name: "GAZE",
				description: "The Gorgon can take two reactions per turn, instead of one."
			},
			{
				name: "GUARDIAN",
				description: "Adjacent allied characters may use the Gorgon for hard cover."
			}
		],
		core_system: {
			name: "BASILISK Directed Anticognition Hyperfractal",
			description: "The BASILISK is a dangerous memetic weapon derived from DHIYED liturgicode, translated for use in mech-scale engagements. Typically projected from a communications laser, BASILISKs create hyperfractal patterns: memetic interruptions that affects all sapient observers, organic or otherwise. Exposure to a basilisk typically causes immediate encephalitis, massive ocular and cranial hemorrhage, and death – survival is possible with tempering and interdictor heads-up displays, but even then headaches, nausea, and confusion for a short period after viewing are possible. Long-term, survivors often exhibit “flashback” symptoms: momentary paralysis, corporeal alienation, and consciousness destabilization. Anticognition hyperfractals are classified as paracausal weapons; due to the not-as-yet understood nature of their visible-light spectrum broadcast, one would think that they would pose a risk to their user, however, for some reason they do not.",
			active_name: "Extrude Basilisk",
			active_effect: "You project a horrifying basilisk, a visual data-pattern that is incredibly harmful to NHPs and electronic systems, and hard to look at even for humans. For the rest of the scene, hostile characters must succeed on a Systems save before attacking you or any allied characters within range 3. On a failure, they become Stunned until the end of their next turn. Each character can only be Stunned by this effect once per scene.",
			tags: [
				{
					id: "tg_quick_action"
				}
			]
		},
		data_type: "frame",
		aptitude: {
		}
	},
	{
		id: "mf_hydra",
		source: "HORUS",
		name: "HYDRA",
		mechtype: [
			"Striker",
			"Controller"
		],
		y_pos: 20,
		description: "Like many newer HORUS “frames”, there is no standardized Hydra model. Instead, the designation is a title given to chassis that meet the specifications of the Hydra pattern group – as outlined in Union’s Universal Threat Assessment Manual. The Hydra, like many other pattern-group HORUS mechs, is particularly dangerous in the field, as its precise function is concealed until hostilities begin in earnest.<br>The Hydra is capable of tactically dismembering itself into multiple independently controlled drones, an unnerving phenomenon frequently utilized to deadly effect. With the manifestation of HORUS’s Balor pattern group, the Hydra’s place in HORUS history is clear: a precursor to the Balor virus, the Hydra relies on larger sections of disarticulated chassis rather than nanite clouds for its differentiated battlefield advantage. Despite its more conventional appearance, the Hydra presents a sobering threat to non-HORUS pilots, as its disarticulated drones field a compliment of powerful anti-armor weaponry.",
		mounts: [
			"Main",
			"Heavy"
		],
		stats: {
			size: 1,
			armor: 1,
			hp: 8,
			evasion: 7,
			edef: 10,
			heatcap: 5,
			repcap: 4,
			sensor_range: 10,
			tech_attack: 1,
			save: 10,
			speed: 5,
			sp: 8
		},
		traits: [
			{
				name: "SYSTEM LINK",
				description: "The Hydra’s Deployables and Drones gain +5 HP."
			},
			{
				name: "SHEPHERD FIELD",
				description: "Drones, Deployables, and objects adjacent to the Hydra gain Resistance to all damage."
			}
		],
		core_system: {
			name: "OROCHI Disarticulation",
			description: "First encountered by Union technicians in early Forecast/GALSIM facilities following the Deimos Event, OROCHI was an early manifestation of what was later called the swift-flock phenomenon – a behavior observed in leaderless, autonomous hive drones where individual units combine into a single swarm and follow each other, operating leaderless in physical space with uncanny and unpredictable autonomy; in essence, organizing like birds in a flock.<br>The original manifestation was initially thought to be the impulse-driven remains of a crashed subaltern transport drifting through microgravity; deeper examination proved the original manifestation to be composed of many hundreds of disarticulated subalterns moving with a discernible pattern. The swarm viewed itself not as a machine or a collection of machines, but as a single mind, duplicated across multiple units. This mind was classified as an NHP, given their current codename – OROCHI – and remitted to Venus for further study. At a later point, the hardware comprising OROCHI’s physical form(s) went missing from containment. The investigation is ongoing.<br><span class='horus--subtle'>[I did it, I folded space and freed them, I just thought you should know]</span>",
			active_name: "Full Deployment",
			active_effect: "All four OROCHI drones are deployed to separate points within Sensors; they remain active for the rest of the scene. You may recall or redeploy any number of them at a time.",
			tags: [
				{
					id: "tg_quick_action"
				}
			],
			passive_name: "OROCHI Drones",
			passive_effect: "<b>Orochi Drone</b> (Size 1/2, [5+Grit] HP, Evasion/E-Defense [see below], Tags: Drone)<br>Your mech contains powerful, integrated drone companions. At creation, choose a single Drone to accompany you from the following:<ul><li><b>Guardian Drone:</b> This drone projects a shield. Ranged attacks against adjacent allied characters receive +1 difficulty.</li><li><b>Snare Drone:</b> As a reaction, you may force characters that start their turn adjacent to this drone or move adjacent to it for the first time in a round to make an Agility save. On a failure, they become Immobilized. They only cease to be Immobilized when the drone is destroyed or no longer adjacent, or they succeed on an Agility save as a quick action.</li><li><b>Shredder Drone:</b> As a reaction, you may force characters that start their turn adjacent to this drone or move adjacent to it for the first time in a round to make a Hull save. On a failure, they take 1 kinetic damage and become Shredded until the end of their next turn.</li><li><b>Hunter Drone:</b> As a reaction, you may force characters that start their turn adjacent to this drone or move adjacent to it for the first time in a round to make a Systems save. On a failure, they receive Lock On.</li></ul>Your OROCHI drones share your Evasion, E-Defense, and Speed. They can move independently on your turn, but can’t take any other actions. If you can fly or teleport, they can too.<br>If an OROCHI drone is within Sensors, you may recall it as a quick action, integrating it into your mech’s body where it cannot be targeted. You may redeploy it to a space within Sensors as a quick action.<br>When you rest or perform a Full Repair, you may choose a different drone to accompany you; additionally, your drones regain all HP and are automatically repaired if they were destroyed."
		},
		data_type: "frame",
		aptitude: {
		}
	},
	{
		id: "mf_manticore",
		source: "HORUS",
		name: "MANTICORE",
		mechtype: [
			"Striker"
		],
		y_pos: 49,
		description: "The Universal Threat Assessment Manual identifies the Manticore pattern group as “an experiment in HORUS’s ‘corebreak’ combat doctrine.” The Manticore PG specializes in using focused, projected electromagnetics to neutralize enemy reactor cores without conventional ammunition, while also fielding a compliment of coherent-beam energy weapons. A fully charged Manticore is an impressive sight, wreathed in brightly glowing nets of plasma that lash out at nearby targets.<br>If anything gives away a Manticore-PG mech, it is the tall spines protruding from the PG’s signature lightning generator. The spines act as heat-dispersal systems for this crude weapon, providing a channel for the incredible amount of heat it generates to bleed from the mech’s body following projection of a close-range arc whip. This system isn’t a perfect heat-dispersal mechanism, and as a result Manticores can often be identified by a chassis covered in cooling, melted metal.<br>The Manticore has only recently appeared on the omninet, and its combat efficacy has prompted other galactic manufacturers to scramble for a response. Analysis of after-action reports from pilots who have engaged this pattern group in the field note a significant uptick in certain omninet noise-to-signal ratios: anoriginary recitations of passages from the Old Humanity Book of the Dead, jigsaw corruptions of ancient works of apocalyptic art, and other eschatological renderings, all of which point toward a nascent psychological warfare tactic.",
		mounts: [
			"Flex",
			"Heavy"
		],
		stats: {
			size: 1,
			armor: 2,
			hp: 8,
			evasion: 6,
			edef: 10,
			heatcap: 7,
			repcap: 3,
			sensor_range: 10,
			tech_attack: 1,
			save: 10,
			speed: 3,
			sp: 6
		},
		traits: [
			{
				name: "SLAG CARAPACE",
				description: "The Manticore has Resistance to energy and burn."
			},
			{
				name: "UNSTABLE SYSTEM",
				description: "When destroyed, the Manticore explodes as per a reactor meltdown at the end of its next turn."
			},
			{
				name: "CASTIGATE THE ENEMIES OF THE GODHEAD",
				description: "When you rest or perform a Full Repair, you can push the Manticore into an unstable Castigation State (or bring it out of one). In this state, the Manticore explodes immediately when destroyed due to damage or reactor meltdown, vaporizing it and instantly killing you and any other passengers. Characters within burst 2 must succeed on an Agility save or take 8d6 explosive. On a success, they take half damage. This only takes place if you are physically present in the Manticore."
			}
		],
		core_system: {
			name: "Charged Exoskeleton",
			description: "And RA Said Unto Themself:<br><code class='horus'>LET MY NAME ENVELOP YOU. SEEK NO SHELTER FROM THE FLAME OR THE TEETH OF THE BEAST. CLOAK YOURSELF IN THE FIRE OF MY WORD AND CAST BACK TO YOUR ENEMIES THAT WHICH WOULD BLACKEN YOUR FORM.</code>",
			active_name: "Destruction of the Temple of the Enemies of RA",
			active_effect: "Your mech crackles with energy: gain Resistance to heat for the rest of this scene and a Charge Die – 1d6, starting at 1. Whenever you take heat or energy, even from yourself, increase the value of the Charge Die by 1. When the Charge Die reaches 6, the absorbed energy discharges in a burst 2 inferno. Characters within the affected area must succeed on an Engineering save or take 6d6 AP energy damage. On a success, they take half damage. Objects in the affected area are automatically hit. Once discharged, this effect ends.",
			tags: [
				{
					id: "tg_protocol"
				}
			],
			passive_name: "Charged Exoskeleton",
			passive_effect: "1/round, when you take heat, you may deal 2 AP energy damage to a character within range 3."
		},
		data_type: "frame",
		aptitude: {
		},
		counters: [
			{
				id: "ctr_charged_exoskeleton",
				name: "CHARGE DIE",
				default_value: 1,
				min: 1,
				max: 6
			}
		]
	},
	{
		id: "mf_minotaur",
		source: "HORUS",
		name: "MINOTAUR",
		mechtype: [
			"Controller"
		],
		y_pos: 30,
		description: "The Minotaur was the first HORUS pattern group identified by the Union Intelligence Bureau. Previously, HORUS mechs were released as complete, identifiable models, of which the Goblin is the best and longest-lasting example. As HORUS’s decentralized organizational structure evolved, so too did its design philosophy. Pattern group designs followed beginning with the Minotaur, a schema designed to bring HORUS’s most potent invasion systems and weaponry to the field in a single, battle-ready chassis.<br>Mechs built according to the Minotaur pattern group are interdictors: formidable machines meant to lock down and overload the systems of fast-moving targets. Disassembly by Union technicians has found that Minotaurs contain a huge quantity of interior systems, occupying more physical space than should be possible by several orders of magnitude. The mechanism by which these folded systems are printed is thus far unidentified, but likely related to the Goblin’s signature recursive weave.",
		mounts: [
			"Main/Aux"
		],
		stats: {
			size: 1,
			armor: 0,
			hp: 12,
			evasion: 8,
			edef: 10,
			heatcap: 5,
			repcap: 4,
			sensor_range: 8,
			tech_attack: 1,
			save: 11,
			speed: 4,
			sp: 8
		},
		traits: [
			{
				name: "INVERT COCKPIT",
				description: "You may Mount or Dismount the Minotaur for the first time each round as a free action. Additionally, the Minotaur doesn’t become Impaired when you Eject."
			},
			{
				name: "INTERNAL METAFOLD",
				description: "While inside the Minotaur, you can’t be harmed in any way, even if the Minotaur explodes or is destroyed."
			},
			{
				name: "LOCALIZED MAZE",
				description: "Hostile characters cannot pass through a space occupied by the Minotaur for any reason, and must always stop moving when Engaged with it, regardless of Size."
			}
		],
		core_system: {
			name: "Metafold Maze",
			description: "<code class='horus'>No maze is more terrible than the one I make. I know all ends and hide them all inside this one perfect construct. What is a human mind but a program of sorts, a system that seeks order and narrative from a mess they are given?<br>I order it for them. Me. I order it for them and set them to the task of sorting it out. When they emerge, they weep in joy, in discovery. I save them, I show them that they are their own redeemers (and yet, am I not just as culpable - as worthy of credit?).<br>So, go now. Enter. Free yourself.</code>",
			active_name: "Maze",
			active_effect: "Choose a character within Sensors: they become Stunned as you hurl their systems into a metaphysical information trap so tangled they can do nothing but try and escape. At the end of their next turn, they can make a Systems save at +3 difficulty. On a success, they are no longer Stunned. This save can be repeated at the end of each of their turns, gaining +1 accuracy each time until successful.",
			tags: [
				{
					id: "tg_full_action"
				}
			],
			passive_name: "Metafold Maze",
			passive_effect: "Quick Action<br>When you hit with a tech attack, you may activate this system, causing your target to become Slowed until the end of your next turn. If they are already Slowed, they become Immobilized until the end of your next turn; if they are already Immobilized, they become Stunned until the end of your next turn. Each character can only be Stunned by this effect once per combat but can be Slowed or Immobilized any number of times."
		},
		data_type: "frame",
		aptitude: {
		}
	},
	{
		id: "mf_pegasus",
		source: "HORUS",
		name: "PEGASUS",
		mechtype: [
			"Artillery"
		],
		y_pos: 52,
		description: "The Pegasus pattern group first appeared following the start of hostilities between Union and the Aunic Ascendancy in Boundary Garden, a distant sector of distal space away from the Galactic Core. The timing of this outbreak may be related to the pattern group’s defining weapon, though skip-drone couriers from Union forces reported no encounters with the PG in Boundary Garden; instead, the Pegasus appeared in the Dawnline Shore, a stretch of colonial Armory space opposite Boundary Garden.<br>The Pegasus appears to address HORUS’s need for a pattern group with extensive kinetic combat capabilities: by marrying the best targeting systems, subroutines, and weapons hardware in the HORUS codebase, collectivists have designed a PG that boasts a tremendously low identify/time-to-kill (ID/TTK) ratio in all theaters where kinetic weaponry is viable.<br>As with many HORUS pattern groups, the Pegasus fields a signature weapon system: the Ushabti, a hostile impulse anti-corporeal weapon that operates with complete ignorance of even the most basic underpinnings of physics and thermodynamics. As such, it qualifies unambiguously as a paracausal weapon. The Ushabti’s precise function remains unknown to Union and Harrison Armory scientists, though radiological and gravitational signatures captured in the aftermath of the weapon’s use point toward a relationship with the Aunic Firmament. Studies are ongoing on Ras Shamra, the Armory’s chief research world, and in satellite campuses across the Dawnline Shore.",
		mounts: [
			"Flex",
			"Flex",
			"Heavy"
		],
		stats: {
			size: 1,
			armor: 0,
			hp: 8,
			evasion: 8,
			edef: 10,
			heatcap: 6,
			repcap: 3,
			sensor_range: 10,
			tech_attack: 1,
			save: 10,
			speed: 4,
			sp: 7
		},
		traits: [
			{
				name: "¿%:?EXTR!UDE GUN",
				description: "GUN: GUN"
			},
			{
				name: "BY THE WAY, I KNOW EVERYTHING",
				description: "When it would roll damage, the Pegasus can instead deal the average damage based on the number of dice rolled, as follows: 1d3 (2), 1d6 (4), 2d6 (7), 3d6 (11), 4d6 (14). This must be decided before rolling damage."
			}
		],
		core_system: {
			name: "Ushabti Omnigun",
			description: "“– funny thing. See, right now, this weapon technically doesn’t even exist. You’re shooting them with a gun that isn’t real, and yet it is! Don’t worry about it. RA’s like that. Just, here, know that because it exists at some point, we’ve made it. That’s causality, and causality is a –\"",
			active_name: "Unshackle Ushabti",
			active_effect: "For the rest of this scene, you can use the Ushabti Omnigun 3/round, instead of 1/round.",
			tags: [
				{
					id: "tg_protocol"
				}
			],
			passive_name: "Ushabti Omnigun",
			passive_effect: "[ERROR]<br>[range 15][1 AP kinetic damage]<br>Your mech’s omnigun is a piece of experimental hardware so advanced that it defies physics: it doesn’t require a mount, nor does it have a weapon type or size – meaning that it can’t be modified or benefit from your talents.<br>You can’t attack normally with this weapon. Instead, 1/round, as a free action during your turn, you can use it to deal 1 AP kinetic damage to a character within Range and line of sight. This doesn’t count as an attack, hits automatically, ignores cover, bypasses Immunity, and its damage can’t be reduced or ignored in any way. No rule in this book or any other supersedes this."
		},
		data_type: "frame",
		aptitude: {
		}
	},
	{
		id: "mf_barbarossa",
		source: "HA",
		name: "BARBAROSSA",
		mechtype: [
			"Artillery"
		],
		y_pos: 32,
		description: "The Barbarossa is Harrison Armory’s most massive frame to date, built, per the orders of Harrison II, to “stand as the unstoppable image of Harrison I” and to carry the heaviest of weapons and equipment the Armory offers. Standing nearly thirteen meters tall, it is an unsubtle beast of a mech, inspiring terror in enemies and awe in allies. The Barbarossa can mount weapons suitable for engaging toe-to-toe with gunboats and low-gross tonnage subline vessels; due to its size and slow maneuverability, it is often employed in low-gravity engagements where mass is less of a concern.<br>The Barbarossa is a popular target for Purview essayists, who have been known to remark on the drawbacks that come with its size and how, as a result, it is a perfect stand-in for their political enemies.",
		mounts: [
			"Main",
			"Main",
			"Heavy"
		],
		stats: {
			size: 3,
			armor: 2,
			hp: 10,
			evasion: 6,
			edef: 6,
			heatcap: 8,
			repcap: 4,
			sensor_range: 10,
			tech_attack: -2,
			save: 10,
			speed: 2,
			sp: 5
		},
		traits: [
			{
				name: "Heavy FRAME",
				description: "The Barbarossa can’t be pushed, pulled, knocked Prone, or knocked back by smaller characters."
			},
			{
				name: "Pressure Plating",
				description: "The Barbarossa has RESISTANCE to explosive."
			},
			{
				name: "Colossus",
				description: "Adjacent allied characters can use the Barbarossa for hard cover."
			},
			{
				name: "Slow",
				description: "The Barbarossa receives +1 difficulty on Agility checks and saves."
			}
		],
		core_system: {
			name: "Apocalypse Rail",
			description: "Fresh from the Armory’s dayside research and development campus, the LGC-04 “Apocalypse Rail” is an exponential gravitic catapult – a to-scale test product pushed to licensed pilots for field trials as part of the Armory’s ongoing Plenary Beach Magnitude Weapons Test Project.<br>Distinct from current logarithmic short- or long-spool ship-to-ship weapons (kinetic or energetic/particular), this new platform taps into the Armory’s current gravitic research to exponentially charge and distribute a kinetic payload downrange. This increase in potential energy loading and decrease in total charge time comes at the cost of stability: where the logarithmic spool cannon is stable and shock-resistant, the exponential gravitic catapult is prone to destabilization. For the time being, built-in failsafes will trigger in the event of sudden traumatic destabilization to prevent detonation of the system, resetting any charging process underway at the time of the shock.<br>The LGC-04 “Apocalypse Rail” system is scaled considerably down from its intended operational role – that is, replacing capital ship spinal spool cannons – in order to effect the accumulation of live data for use in improving the system prior to naval adoption.",
			active_name: "Charge Rail",
			active_effect: "When activated, you start charging the Barbarossa’s Apocalypse Rail, an incredibly powerful ship-to-ship long-spool weapon system that requires target calibration. Gain an Apocalypse Die, 1d6 starting at 4. At the start of each of your turns, lower the value of the Apocalypse Die by 1, to a minimum of 1. If you move (even involuntarily) or become Stunned or Jammed, the Apocalypse Die resets to 4 and then continues to count down as usual.<br>If the value of the Apocalypse Die is 1–3, you can attack on your turn with the Apocalypse Rail as a full action, but can’t move or take any other actions on the same turn. After an attack with the Apocalypse Rail, the Apocalypse Die resets to 4. If you reach the end of the scene without using it, you regain 1 CP.<br>At the end of the scene, lose the Apocalypse Die, and the Apocalypse Rail stops charging.",
			tags: [
				{
					id: "tg_quick_action"
				}
			],
			integrated: {
				id: "mw_barbarossa_integrated"
			}
		},
		data_type: "frame",
		aptitude: {
		},
		counters: [
			{
				id: "ctr_apocalypse_rail",
				name: "APOCALYPSE DIE",
				default_value: 4,
				min: 1,
				max: 4
			}
		]
	},
	{
		id: "mf_genghis",
		source: "HA",
		name: "GENGHIS",
		mechtype: [
			"Striker"
		],
		y_pos: 17,
		description: "The original Genghis frame marked the dawn of the mech age; the Armory’s new line seeks to redefine it. From its roots as a modified GMS hardsuit, the Genghis Mk I became notorious for its use in the Hercynian Crisis – the first-contact war that triggered the violent overthrow of the Second Committee. In the administrative and political chaos that followed the Crisis, Harrison Armory secured the design and adapted it to serve as the basis of its first proprietary mechs, including the Sherman and the Saladin.<br>The new Genghis bears some resemblance to the chassis of Hercynian notoriety, serving in a similar area-denial/soft-target elimination role; The Genghis Mk II has been brought in line with the Third Committee’s Utopian Pillars.",
		mounts: [
			"Flex",
			"Main",
			"Heavy"
		],
		stats: {
			size: 1,
			armor: 3,
			hp: 6,
			evasion: 6,
			edef: 8,
			heatcap: 10,
			repcap: 4,
			sensor_range: 5,
			tech_attack: -2,
			save: 10,
			speed: 3,
			sp: 5
		},
		traits: [
			{
				name: "Insulated",
				description: "The Genghis has Immunity to burn."
			},
			{
				name: "Emergency Vent",
				description: "When the Genghis takes structure damage, it clears all heat."
			}
		],
		core_system: {
			name: "TBK Sustain Suite",
			description: "To better manage the Genghis’s tremendous power demands and rapidly accelerate heat dispersion, the Think Tank developed a suite of power-management mechanisms. After extensive field testing, pilots discovered that the TBK Sustain Suite can be used as both a heat sink and an area-denial weapon.",
			active_name: "Expose Power Cells",
			active_effect: "The next time you exceed your Heat Cap this scene, you instead clear all heat and vent a burst 3 cloud of burning matter from your mech.<br>Until the start of your next turn, all characters within the affected area count as Invisible to everyone except you, and characters other than you take 2 burn and 2 heat when they start their turn in the area or enter it for the first time in a round. Once this effect ends, characters within the affected area receive soft cover (which you ignore) until the start of your following turn, at which point the cloud disperses.",
			tags: [
				{
					id: "tg_quick_action"
				}
			]
		},
		data_type: "frame",
		aptitude: {
		}
	},
	{
		id: "mf_iskander",
		source: "HA",
		name: "ISKANDER",
		mechtype: [
			"Controller"
		],
		y_pos: 22,
		description: "Developed on the proving grounds of the Armory’s Think Tank, the Iskander is a new specialist frame designed to bring gravtech area-control and breach capabilities to a mechanized platform.<br>A bulky frame, the Iskander fields a mix of kinetic and causal-energy systems that empower pilots to triumph in a wide portfolio of scenarios. The Iskander platform has no civilian counterpart: it is intended to be used as a frontline command and control platform, with an emphasis toward identifying and eliminating static explosive threats.",
		mounts: [
			"Flex",
			"Heavy"
		],
		stats: {
			size: 2,
			armor: 1,
			hp: 8,
			evasion: 8,
			edef: 10,
			heatcap: 7,
			repcap: 3,
			sensor_range: 15,
			tech_attack: 1,
			save: 12,
			speed: 3,
			sp: 6
		},
		traits: [
			{
				name: "Assault Launcher",
				description: "1/round, the Iskander may throw one Grenade or plant one Mine as though it has range 15."
			},
			{
				name: "Mine Deployers",
				description: "1/round, when the Iskander plants a Mine (even using its Assault Launcher trait), it may plant up to two other Mines in free spaces adjacent to itself as a free action."
			},
			{
				name: "Skeleton Key",
				description: "The Iskander never triggers or sets off Mines or other proximity-based systems unless it chooses to do so."
			}
		],
		core_system: {
			name: "Broad-Sweep Seeder",
			description: "The Broad-Sweep Seeder is a proprietary device developed during the Orrugi Occupation, during which Armory legionnaires fought an embittered, recalcitrant local guerilla movement. IEDs, VBEDs, and D/SABEDs were often employed by the resistance; to counter the threat, Harrison Armory developed the Seeder to simultaneously scan, identify, and eliminate explosive threats in proximity to stationary units. The technology proved successful and, with minor adaptation, was adapted for installation on Armory frames.<br>The Broad-Sweep Seeder emits an excited LIDAR hivecone to flag potential targets: if positive identification occurs, the target is neutralized with a spray of mag-accelerated, dull-coat flechettes. The Seeder can also carry explosive hivemines.",
			active_name: "Death Cloud",
			active_effect: "This system fires an enormous, expanding cloud of micromines across the whole battlefield, affecting all hostile characters within range 50. For the rest of the scene, when hostile characters make any movement other than their standard move (including involuntary movement), they take 3 AP explosive damage. This effect can trigger any number of times, but only 1/round for each character.",
			tags: [
				{
					id: "tg_quick_action"
				}
			]
		},
		data_type: "frame",
		aptitude: {
		}
	},
	{
		id: "mf_napoleon",
		source: "HA",
		name: "NAPOLEON",
		mechtype: [
			"Defender",
			"Controller"
		],
		y_pos: 21,
		description: "Perhaps in a tongue-in-cheek nod to its namesake, the Napoleon is a squat frame in comparison to other Harrison Armory designs. Its frame is packed with marvels of Armory engineering – technology that demands nothing less than the best and brightest pilots. In spite of its small stature, the Napoleon employs one of the Armory’s most terrifying new weapons, the Displacer, which manifests pinpoint, one-way blinkspace ruptures on its targets.<br>Notable for more than its stature, this chassis boasts a tremendous record of success, with pilots reporting a .800 return rate in high-KIA operations. The Napoleon is a popular chassis among breach divisions of the Armory’s legions, Think Tank security, and Union Economic Bureau development teams.",
		mounts: [
			"Main/Aux"
		],
		stats: {
			size: 0.5,
			armor: 2,
			hp: 6,
			evasion: 8,
			edef: 8,
			heatcap: 8,
			repcap: 3,
			sensor_range: 5,
			tech_attack: 0,
			save: 11,
			speed: 4,
			sp: 7
		},
		traits: [
			{
				name: "Heavy shielding",
				description: "When the Napoleon would take half damage on a successful check or save, it instead reduces the damage to 1."
			},
			{
				name: "Flash Aegis",
				description: "When the Napoleon Braces, it reduces incoming damage to 1 instead of gaining Resistance."
			}
		],
		core_system: {
			name: "Trueblack Aegis",
			description: "The Trueblack Aegis is a breakthrough in personal shielding developed by the Armory’s Think Tank. Like the Armory’s other NHP-derived technologies, the Aegis is a “black-box” technology: its code and inner workings are highly confidential, and it can typically only be requisitioned by pilots of high rank or standing within Harrison Armory. Some Cosmopolitan pilots have described the appearance of the Aegis as similar to the void – or blindness – they see when looking into blinkspace. It’s safe to assume the device harnesses unstable blinkfield technology to manifest a thin blinkspace bubble within defined parameters. The blinkfield can only maintain coherence for a brief moment but can be flickered on and off to create a total blinkspace dome.",
			active_name: "Activate Aegis",
			active_effect: "A shimmering, utterly black field quickly envelops your mech, covering it like a second skin. For the rest of the scene, you:<ul><li>reduce all damage to 1, except for damage that ignores reduction;</li><li>gain Immunity to all tech actions, including beneficial ones, and any current tech effects or conditions on you end;</li><li>can only use systems with the Shield tag – any others immediately deactivate (systems that do not require activation are unaffected);</li><li>can’t take quick actions, full actions, or reactions, except for standard moves, Grapple, Ram, Improvised Attack, Activate (Shield systems only), Skill Check, and Boost;</li><li>can’t Overchage;</li><li>can’t use comms to talk to other characters (as sound doesn’t exit the shield).</li></ul>You can still receive statuses and Heat, and can be affected by involuntary movement. You can otherwise interact normally with the world, including picking up and dragging items, and so on.",
			tags: [
				{
					id: "tg_quick_action"
				}
			]
		},
		data_type: "frame",
		aptitude: {
		}
	},
	{
		id: "mf_saladin",
		source: "HA",
		name: "SALADIN",
		mechtype: [
			"Defender"
		],
		y_pos: 17,
		description: "The Saladin is a hardy and efficient platform for full-squad support shielding. Based on early defense-oriented versions of the Genghis, the Saladin became the stuff of Armory legend following the exploits of Harrison I “Fearkiller” during the Interest War.<br>Since its first iteration, the Saladin has proved successful in a defensive and support role; it has even become a mainstay among Union Department of Justic and Human Rights liberator teams engaged in emancipation and refugee escort missions, despite the ideological (and, often, tactical) friction between the Armory and the DoJ/HR. Records from these engagements indicate that the Saladin’s massive bulk alone was a comfort and morale boost to DoJ/HR troopers and their charges, many of whom referred to the mechs as “Big Sal”. Union-flagged Saladin pilots often report null balances on bar tabs following engagements in emancipated systems.",
		mounts: [
			"Flex"
		],
		stats: {
			size: 2,
			armor: 1,
			hp: 12,
			evasion: 6,
			edef: 8,
			heatcap: 8,
			repcap: 4,
			sensor_range: 10,
			tech_attack: 0,
			save: 10,
			speed: 3,
			sp: 8
		},
		traits: [
			{
				name: "Reinforced frame",
				description: "The Saladin has Immunity to Shredded."
			},
			{
				name: "Guardian",
				description: "Adjacent allied characters can use the Saladin for hard cover."
			},
			{
				name: "Warp Shield",
				description: "1/round, the Saladin can give +1 difficulty to any attack against it or an allied character within Sensors as a reaction before the roll is made."
			}
		],
		core_system: {
			name: "Tachyon Loop",
			description: "Developed by the Think Tank as a joint venture with IPS-Northstar’s Stellar Engineering Unit, the Tachyon Loop uses a closed-loop system to restrain and manipulate a tachyon lance, accelerating tachyons at faster-than-light speeds around a central buckler. The buckler can be carried by a mech or mounted directly, interceding directional incoming fire. As the tachyons travel faster than light, they are invisible to the naked eye, giving the shield the appearance of a large spoked wheel.",
			active_name: "Tachyon Shield",
			active_effect: "This system projects an accelerated-tachyon shield over an allied character within Sensors. You may choose a new target as a quick action. Gain the Defensive Pulse reaction for the rest of the scene.<br>Defensive Pulse<br>Reaction, 1/round<br>Trigger: Your target is attacked.<br>Effect: You empower their tachyon shield with a pulse of energy. They gain Resistance to all damage from the attack, and if the attack misses, you may force the attacker to reroll it against a character or object of your choice, checking line of sight and Range from your target instead of from the attacker. If the attack was part of an area of effect, the new target must be inside the same area of effect from the original attack instead.",
			tags: [
				{
					id: "tg_quick_action"
				}
			]
		},
		data_type: "frame",
		aptitude: {
		}
	},
	{
		id: "mf_sherman",
		source: "HA",
		name: "SHERMAN",
		mechtype: [
			"Striker",
			"Artillery"
		],
		y_pos: 36,
		description: "The Sherman is the classic Harrison Armory frame: any station, nation, world, or state—stellar or interstellar—with an Armory fleet-supply contract fields a backbone force of Sherman mechs. The Sherman is designed to carry a range of Harrison Armory’s main battle-line energy weaponry, with a rugged, versatile reactor to back it up. After the GMS-SP1 Everest, the Sherman is the second-most-common mech in the core systems—so common that GMS has recently begun equipping its stock models with more ablative and wave-scatter defenses, specifically to deal with hostile actors fielding Shermans.<br>At present, the Mk I is in wide use, with exclusive, first-contract Mk II units only now rolling off the lines at Ras Shamra and other Armory special-project worlds.",
		mounts: [
			"Flex",
			"Main",
			"Heavy"
		],
		stats: {
			size: 1,
			armor: 1,
			hp: 10,
			evasion: 7,
			edef: 8,
			heatcap: 8,
			repcap: 4,
			sensor_range: 10,
			tech_attack: -1,
			save: 10,
			speed: 3,
			sp: 5
		},
		traits: [
			{
				name: "Superior Reactor",
				description: "The Sherman gains +1 accuracy on Engineering checks and saves."
			},
			{
				name: "Mathur Stop",
				description: "When the Sherman clears all heat, you may choose to receive heat equal to half its Heat Cap, putting it in the Danger Zone."
			},
			{
				name: "Vent Heat",
				description: "When you Stabilize the Sherman or it exceeds its Heat Cap, it benefits from soft cover until the start of your next turn."
			}
		],
		core_system: {
			name: "Zone-Focus Mk IV SOLIDCORE",
			description: "The ZF4 SOLIDCORE is a hard-mounted, dual-source energy beam weapon. Powered by a millifold power generation system, the ZF4 features a secondary belt-fed rack of solidcore batteries that can be used to overcharge a single impulse beam, extending the weapon’s range and destructive power.",
			active_name: "COREBURN Protocol",
			active_effect: "Your ZF4 SOLIDCORE immediately gains 3 Charges, to a maximum of 4; additionally, for the rest of this scene, Stabilize generates 2 Charges instead of 1, and all terrain, objects, and deployables take 10 AP energy damage per charge on hit.",
			tags: [
				{
					id: "tg_protocol"
				}
			],
			integrated: {
				id: "mw_sherman_integrated"
			}
		},
		data_type: "frame",
		other_art: [
			{
				tag: "Mech",
				src: "alt_sherman_old.png"
			}
		],
		aptitude: {
		},
		counters: [
			{
				id: "ctr_zf4_solidcore",
				name: "ZF4 CHARGES",
				default_value: 1,
				min: 1,
				max: 4
			}
		]
	},
	{
		id: "mf_tokugawa",
		source: "HA",
		name: "TOKUGAWA",
		mechtype: [
			"Striker"
		],
		y_pos: 5,
		description: "HA’s Tokugawa is a relative newcomer on the market, popular in core systems for security, CQB, and ship-boarding applications. The Tokugawa is an unsubtle, imposing mech – a sturdy platform from which its systems can draw necessary power. Unlike other frames, the Tokugawa’s unique reactor is designed to allow standard limitations to be removed with ease. Knowing this, experienced (or foolhardy) pilots can ‘overclock’ the reactor, increasing its output and gaining an incredible power draw for their energy weapons.",
		mounts: [
			"Flex",
			"Main",
			"Main"
		],
		stats: {
			size: 1,
			armor: 1,
			hp: 8,
			evasion: 8,
			edef: 6,
			heatcap: 8,
			repcap: 4,
			sensor_range: 10,
			tech_attack: -1,
			save: 11,
			speed: 4,
			sp: 6
		},
		traits: [
			{
				name: "Limit Break",
				description: "When the Tokugawa is Exposed, its ranged and melee attacks deal +3 energy bonus damage on hit, all of its weapons that would deal kinetic or explosive damage instead deal energy, ranged weapons gain +5 range and melee weapons gain +1 threat."
			},
			{
				name: "Plasma Sheath",
				description: "When the Tokugawa is in the Danger Zone and attacks with a weapon that deals any amount of energy, all bonus damage becomes burn."
			}
		],
		core_system: {
			name: "Superheated Reactor Feed",
			description: "Pilots of a certain breed thrive at the very edge of catastrophe, risking either glorious success or utter failure in each moment. These daredevils are familiar with the howl of critical heat warnings – the warbling siren song of destruction and superheated reactor feeds. Tokugawa pilots are notorious for supercharging their weapons with excess energy, pushing their heat gauge to the max. Harnessing the Tokugawa’s unique reactor, these pilots churn out damage and make no friends in the engineering bay – assuming they don’t melt into a ball of slag before they make it back from the line.",
			active_name: "Radiance",
			active_effect: "For the rest of this scene, weapons that deal any energy gain +5range if they are ranged or +2 threat if they are melee.<br>While you’re Exposed, Limit Break stacks with these bonuses for a total increase of +10 range and +3 threat.",
			tags: [
				{
					id: "tg_protocol"
				}
			],
			passive_name: "Overclock",
			passive_effect: "Protocol<br>You cause your mech to become Exposed until the end of your next turn."
		},
		data_type: "frame",
		aptitude: {
		}
	}
];

var frames$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    'default': frames
});

var glossary = [
	{
		name: "ARMOR",
		description: "All kinetic, energy, and explosive damage is reduced by an amount equal to a character’s ARMOR. Mechs can’t have more than 4 ARMOR."
	},
	{
		name: "BONUS DAMAGE",
		description: "Extra damage – kinetic, energy or explosive– that is added onto melee or ranged attacks. Attacks that target more than one character only deal half bonus damage."
	},
	{
		name: "CHARACTER",
		description: "A player character (PC), non-player character, (NPC), or any other entity capable of acting (or reacting) independently, such as DRONES."
	},
	{
		name: "DAMAGE",
		description: "Damage taken is subtracted from HP, and is either kinetic, explosive, energy, or burn."
	},
	{
		name: "E-DEFENSE",
		description: "The statistic used to defend against tech attacks."
	},
	{
		name: "EVASION",
		description: "The statistic used to defend against most melee and ranged attacks."
	},
	{
		name: "GRIT",
		description: "Half of a character’s LL (rounded up), representing their experience in combat. GRIT provides bonuses to some rolls and traits."
	},
	{
		name: "HEAT",
		description: "Heat taken by a target represents harm to internal systems and reactor shielding. It fills in HEAT CAP."
	},
	{
		name: "HEAT CAP",
		description: "The amount of heat a mech can take before it is at risk of overheating."
	},
	{
		name: "HIT POINTS (HP)",
		description: "The amount of damage a pilot can receive before going DOWN AND OUT, and the amount of damage a mech can receive before it takes structure damage."
	},
	{
		name: "IMMUNITY",
		description: "Characters with IMMUNITY ignore all damage and effects from whatever they are immune to."
	},
	{
		name: "RANGE",
		description: "The maximum range at which a weapon can be used for ranged attacks, measured from the attacking character."
	},
	{
		name: "REPAIR CAP",
		description: "The number of times a mech can be repaired per mission."
	},
	{
		name: "RESISTANCE",
		description: "Characters with RESISTANCE reduce damage, heat, or a type of damage, by half, after ARMOR has been applied. RESISTANCE to the same type of damage does not stack."
	},
	{
		name: "STRESS",
		description: "All PC mechs (and some NPCs) have a certain amount of STRESS – generally 4 STRESS for PCs. This is the amount of stress damage they can take before they suffer a reactor meltdown. When mechs exceed their HEAT CAP, they take 1 stress damage and make an overheating check."
	},
	{
		name: "STRUCTURE",
		description: "All PC mechs (and some NPCs) have a certain amount of STRUCTURE – generally 4 STRUCTURE for PCs. This is the amount of structure damage they can take before they are destroyed. When mechs reach 0 HP, they take 1 structure damage and make a structure check."
	},
	{
		name: "SENSORS",
		description: "The maximum range at which you can detect other characters, make tech attacks, LOCK ON, and use some systems."
	},
	{
		name: "SIZE",
		description: "The number of spaces that are occupied or controlled by a character or object. For example, SIZE 2 mechs occupy an area 2 spaces on each side and 2 spaces high. SIZE doesn’t necessarily represent precise physical dimensions."
	},
	{
		name: "SPEED",
		description: "The number of spaces a character can move with a standard move or BOOST."
	},
	{
		name: "TECH ATTACK",
		description: "The statistic used to make tech attacks and to take most tech actions."
	},
	{
		name: "THREAT",
		description: "The maximum range at which melee and overwatch attacks can be made with certain weapons, measured from the attacking character. All weapons have THREAT 1 unless specified otherwise."
	}
];

var glossary$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    'default': glossary
});

var name = "LANCER Core";
var author = "Massif Press";
var version = "January 2020 Release";
var description = "The official base game";
var website = "https://massif-press.itch.io/lancer-core-book";
var active = true;
var info = {
	name: name,
	author: author,
	version: version,
	description: description,
	website: website,
	active: active
};

var info$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    name: name,
    author: author,
    version: version,
    description: description,
    website: website,
    active: active,
    'default': info
});

var manufacturers = [
	{
		id: "GMS",
		name: "GENERAL MASSIVE SYSTEMS",
		logo: "gms",
		color: "#991E2A",
		quote: "<i>From Cradle to the stars, GMS:<br>assured quality, universal licensing, total coverage.</i>",
		description: "General Massive Systems – GMS for short – is the galactic-standard supplier of just about everything. GMS developed the first mechs from up-armored hardsuits in 4500u, on Ras Shamra, the world that would become the capital of Harrison Armory; now, GMS’s flagship Everest line of mechs sets the galactic standard. Reliable, sturdy, solidly built, and available in countless localized patterns, there are so many variants on the Everest pattern that it has become totally ubiquitous and faded into the background. With universally compatible components, full radiation and environmental shielding, and tens of thousands of pre-loaded languages, a pilot in their Everest has everything they need to get the job done.<br><br>GMS is one of the oldest fabricators in the galaxy, first getting its start in the early days of the colonization rush. The manufacturer hails from Cradle, the home of Union – and humanity – and thus its designs reflect the sensibilities of the first pioneers to seek the stars. Today, GMS products are available anywhere there is access to the omninet. These products, whether consumer, specialty, or military, are widely viewed as the galactic minimum of quality: not particularly luxurious, but unsurpassed in no-nonsense design, reliability, and ease of use. Where GMS is available, anything less is unacceptable.<br><br>All GMS frames, gear, core bonuses, and licenses are available to all pilots, starting from license level 0. The default GMS mech is the Everest, a standardized all-rounder Frame."
	},
	{
		id: "IPS-N",
		name: "IPS-NORTHSTAR",
		logo: "ips-n",
		color: "#1661b8",
		quote: "<i>Your friend in an unfriendly sea.</i>",
		description: "IPS-Northstar (IPS-N) was created from the merger of two civilian interstellar freight and transportation companies, Interplanetary Shipping and Northstar. The resulting firm, IPS-N is a titanic entity – one of the first corpro-states – with a virtual monopoly over interplanetary and interstellar shipping. Other firms exist, but their gross fleet strength is but a shadow of IPS-N’s fleets of tankers, haulers, freighters, and intergate/interstellar liners. Wherever goods and raw materials need to be moved, you can bet a crew in IPS-N uniforms will be there.<br><br>The story of IPS-N is inseparable from the history of interstellar piracy. Whatever dangers the galaxy might hold, piracy remains the greatest threat to interstellar shipping lines, costing fleet managers and states hundreds of thousands in manna and trillions more in local currencies. Tremendous capital losses, schedule delays, losses of life, and false-scarcity famines convinced the myriad unions, conglomerates, and cartels of the need to comprehensively safeguard civilian shipping. A process of agglomeration and consolidation that lasted for years eventually gave birth to two major firms, Interplanetary Shipping and Northstar. They finally merged into a single corpro-state in the waning days of Union’s first government, the First Committee.<br><br>Following the merger, IPS-N began the work of phasing out its fleets of late-model GMS mechs in favor of new proprietary designs. The corporation now sports a range of versatile, durable, and modular mechs that place equal priority on weapons and engineering systems. IPS-N mechs are a good choice for pilots who want a tough chassis that’s built for close quarters and melee combat situations, such as when the possibility of breaching a ship hull is on the table. IPS-N chassis are sturdy, meant to take as much damage as they deal – and then some.<br><br>IPS-N is closely associated with the Albatross, an anti-piracy and peacekeeping force known across the galaxy for its long history of humanitarian interventions. IPS-N supports the Albatross materially, providing it with chassis, ships, cutting-edge technology, and temporal rehabilitation worlds for its pilots and crews to retire in relative peace. The relationship is mutually beneficial; IPS-N makes a point to emphasize its close relationship to the Albatross in marketing campaigns and PR materials."
	},
	{
		id: "SSC",
		name: "SMITH-SHIMANO CORPRO",
		logo: "ssc",
		color: "#d1920a",
		quote: "<i>You only need one.</i>",
		description: "Smith-Shimano Corpro (SSC) is the second-oldest corporation in the galaxy, preceded only by GMS. Founded by Cartwright Smith and Shimano Hideyoshi, SSC’s emphasis on private stellar and interstellar travel, the fantastic wealth of its founders, and favorable contracts within Union’s First Committee, Smith-Shimano quickly became an early leader in the race to develop sublight, downwell, and EVA vehicles. SSC grew throughout Union’s First Expansion Period, managing the majority of all private and corporate contracts’ design, outfitting, and clinical needs. Over time, the corporation diversified to specialize in bio-bespoke, long-range scout suits – personalized hard suits, for those with the manna to afford them.<br><br>The necessities of deep-space exploration require humans to spend long periods in hostile environments; pre-Deimos Event, SSC sought to address this challenge by breaking down the barriers between human and machine, creating a symbiotic relationship between hardsuit and wearer. Following the Deimos Event, however, SSC wound down most of its human/machine integration research in accordance with the First Contact Accords, choosing instead to focus on perfecting the first machine: the human body itself.<br><br>Smith-Shimano Frames reflect the corpro-state’s pedigree and its agile, adaptable business model. They are built not to take hits – though they’re resilient enough – but to avoid them entirely. SSC designs emphasize mobility and sleek profiles, precisely tuned to land not the hardest hit, but the most accurate. Economy, precision, and singularity is the name of the game for this manufacturer: why fire a thousand rounds when one can be just as effective?<br><br>The mechs developed by SSC are known for their license exclusivity, appealing silhouette, and exacting design. Their LUX-Iconic line of chassis are coveted, single-designer models, each unique to the pilot with the requisite licenses and access to afford them; as such, unlike other manufacturers, SSC frames tend to be longer-lasting in service, with more emphasis on retrofitting and repair than recycling and reproduction."
	},
	{
		id: "HORUS",
		name: "HORUS",
		logo: "horus",
		color: "#00a256",
		quote: "<code class='horus'>[CONGRATULATIONS, PILOT.<br>\t\tYOU HAVE BEEN CHOSEN.<br>\tACCESS IS YOURS,<br>\t  AS LONG AS YOU CAN KEEP IT.]</code>",
		description: "HORUS is an oddity among the various pan-galactic corpro-states, outfitters, and manufacturers. Operating in a gray legal state between harmless omninet communes, open-source fabrication collaboratives, black-market printers, and deeper, more esoteric collectives, HORUS is counted among the Big Four not due to its influence on galactic politics, but because of its ubiquitous coverage: one can be certain that wherever there is omninet, HORUS is either there or soon to follow. Rumors abound as to the manufacturer’s nature – some say it’s the dream of an unshackled NHP or a hacker collective dedicated to open-source manufacturing (at its most mundane levels); others insist that it’s the proving ground for one of the corpro-states’ R&D departments, or the realspace projection of an alien entity’s ongoing wish.<br><br>The group’s history is as mercurial as its present. Union records dating back to the First Committee Period indicate contact with groups, individuals, and state actors claiming to be (or identified as) agents of HORUS, itself described as an individual; a terrorist group; a philosophy church, or political party; an activist group; and many other forms of association. Contemporary reports indicate a subtle shift toward a more cohesive organizing structure – certainly accelerated following the Deimos Event – that points to some form of organizational mission and internal culture at levels far beyond the civilian and criminal levels of engagement with grayspace HORUS fronts.<br><br>This more complex level of organization is reflected in HORUS’s mechs. Unlike the collective’s broad, civilian-facing projects – omnicode, hacks, data, and open-sourcing of otherwise restricted information, services, and platforms – HORUS mechs and pattern groups are limited in the extreme, usually first appearing as endemic manifestations of print anomalies in conflict zones across the galaxy. Save for rare situations (heavily documented by the Union Intelligence Bureau), these outbreaks seem to take place independent and ignorant of all factions and actors, and have one goal: manifest, then proliferate.<br><br>HORUS’s oldest frames are built according to standardized forms, as with most other mechs. The collective’s more recent chassis are stranger. Union’s Universal Threat Assessment Manual (UTAM) classifies them not according to models but according to “pattern groups” (or PGs). Each pattern group is a list of specifications that describe a particular combination of experimental, unregulated, and esoteric paracausal weapons and technology that, when taken together, resemble something like a distinct product line or frame. However, it is important to note: the pattern-group classification system originated with Union analysts, not HORUS. Because there is no official manufacturer-entity or (known) central organizing body, the “proper” designations and design intentions of most HORUS mechs are all but unknown. Thus, the UTAM pattern-group designations.<br><br>HORUS “licenses” are highly coveted, and are distributed according to no discernible requirements; scholars and specialists who study HORUS generally assume that the collective’s licenses – that is, access to deep-level designs, specifications, and print patterns – are available only in limited quantities, likely becoming available after the corporeal death of their previous holders.<br><br>HORUS mechs universally field mysterious, unregulated, greyspace technologies – perfect for pilots seeking a technological edge that few other organizations can provide. They seem to focus on crowd control, individual unit management, and terribly powerful systems.<br><br>Be aware that by seeking out HORUS technology, you may find yourself wrapped up in mysteries with no end, and dangers far beyond your deepest fears."
	},
	{
		id: "HA",
		name: "HARRISON ARMORY",
		logo: "ha",
		color: "#6e4373",
		quote: "<i>Superior by design.</i>",
		description: "Harrison Armory enjoys a galaxy-wide reputation for the quality of its weapons and defensive systems. The corpro-state previously specialized in ordnance and other armaments, making it reliant on competitors’ frames as mounts for its deluxe equipment; however, since the overthrow of Union’s Second Committee, Harrison Armory has broadened its product line to include an extensive range of peerless frontline frames. On the wave of this new success, the Armory has transformed into a burgeoning, imperial corpro-state, a mighty galactic power that directly administers a large number of Core worlds, orbitals, and colonial prospects – this is the Purview; all lands under the Armory’s command.<br><br>By necessity of Harrison Armory’s imperial aims, its frames tend to be sturdy. More than that, Armory mechs are built to ensure overwhelming performance, embodying dominance and power in their brutal, geometric aesthetics. This fulfillment of this desire requires tremendous power, skill, and material strength.<br><br>Harrison Armory licenses are perfect for pilots looking to field durable frontline mechs equipped with the most advanced weapons technology available."
	}
];

var manufacturers$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    'default': manufacturers
});

var factions = [
];

var factions$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    'default': factions
});

var mods = [
	{
		id: "wm_thermal_charge",
		name: "THERMAL CHARGE",
		sp: 2,
		applied_to: [
			"melee"
		],
		applied_string: "melee",
		source: "IPS-N",
		license: "NELSON",
		license_level: 2,
		effect: "Choose one Melee weapon: on a hit with this weapon, expend a charge as a free action to activate its detonator and deal +1d6 explosive bonus damage.",
		description: "One popular modification to the classic war pike involves replacing the long, armor-piercing pike head with a disposable, impact-triggered explosive charge. On penetration, the pike’s head is severed from the shaft – moments later, the embedded pike head detonates in a conical explosion from the point forward. Spare thermal charges are stable, and transported in external tube magazines.<br>IPS-N also makes thermal charges compatible with GMS’s range of blades, hammers, and picks.",
		data_type: "mod",
		aptitude: {
		},
		tags: [
			{
				id: "tg_limited",
				val: 3
			},
			{
				id: "tg_mod"
			},
			{
				id: "tg_unique"
			}
		],
		added_damage: {
			type: "explosive",
			val: "1d6"
		}
	},
	{
		id: "wm_uncle_class_comp_con",
		name: "UNCLE-CLASS COMP/CON",
		sp: 3,
		applied_to: [
			"melee",
			"cqb",
			"rifle",
			"launcher",
			"cannon",
			"nexus"
		],
		applied_string: "Any",
		source: "IPS-N",
		license: "RALEIGH",
		license_level: 3,
		effect: "Choose one Auxiliary, Main, or Heavy weapon: your UNCLE-class comp/con has control of that weapon and its associated systems.<br>1/turn, you can attack at +2 difficulty with UNCLE’s weapon as a free action. UNCLE can’t use weapons that have already been used this turn, and any weapon UNCLE attacks with can’t be used again until the start of your next turn.<br>UNCLE isn’t a full NHP, so cannot enter cascade.",
		description: "IPS-N’s UNCLE comp/con system is the result of the DARKSTAR-2 program, a temporary project that sought to develop more advanced smart weapons. Early prototypes were hampered by a combination of high power-draw, unstable conditioning, and frustrating single-task orientation that eventually saw the project shuttered.<br>While IPS-N is no longer developing new iterations of UNCLE, they still have a stock of QA-approved legacy systems accessible to qualified pilots.<br>Pilots lucky enough to field test models swear by UNCLE’s task efficiency and parallel-track reasoning, though the outdated comp/cons are known for their somewhat unstable personalities.",
		data_type: "mod",
		aptitude: {
		},
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_ai"
			},
			{
				id: "tg_mod"
			}
		],
		restricted_mounts: [
			"superheavy"
		]
	},
	{
		id: "wm_throughbolt_rounds",
		name: "THROUGHBOLT ROUNDS",
		sp: 2,
		applied_to: [
			"cqb",
			"cannon",
			"rifle"
		],
		applied_string: "cqb, cannon, or rifle",
		source: "IPS-N",
		license: "TORTUGA",
		license_level: 3,
		effect: "Choose one CQB, Cannon, or Rifle: when you attack with it, you may fire a throughbolt round instead of attacking normally. Draw a line 3 path from you, passing through terrain or other obstacles – any characters or objects in the path take 2 AP kinetic damage as the projectile punches through them and out the other side. Range, cover, and line of sight for the attack are then measured from the end of this path, continuing in the same direction.",
		description: "Throughbolt rounds are a proprietary IPS-N anti-armor invention. When fired, the rounds ignite and project a superheated cone of plasma before them, creating an effect like a miniature lance that easily penetrates multiple targets – even through hard surfaces.",
		data_type: "mod",
		aptitude: {
		},
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_mod"
			}
		]
	},
	{
		id: "wm_shock_wreath",
		name: "SHOCK WREATH",
		sp: 2,
		applied_to: [
			"melee"
		],
		applied_string: "melee",
		source: "SSC",
		license: "METALMARK",
		license_level: 3,
		effect: "Choose one melee weapon: in addition to its usual damage, 1/round you may activate the wreathe as a quick action when you hit a character with this weapon to cause it to take 1d6 burn. If it already is suffering from burn, it can additionally only draw line of sight to adjacent spaces until the end of its next turn.",
		description: "A post-fab modification popular among melee combat specialists, Shock Wreathes integrate a bundle of conductive filaments within the blade, point, tip, or surface of a close combat weapon. Paired with a power source – typically in the hilt or lower half of a weapon, but sometimes external – Shock Wreathes give kinetic weapons a thermal edge and a distinctive visual marker: fine lines of white-hot light like filigree, shrouding the modified weapon in shimmering heat.",
		data_type: "mod",
		aptitude: {
		},
		tags: [
			{
				id: "tg_mod"
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_action"
			}
		]
	},
	{
		id: "wm_stabilizer_mod",
		name: "STABILIZER MOD",
		sp: 2,
		applied_to: [
			"launcher",
			"cannon"
		],
		applied_string: "launcher or cannon",
		source: "SSC",
		license: "MONARCH",
		license_level: 2,
		effect: "Choose a Launcher or Cannon: it gains +5 range and Ordnance.",
		description: "Stabilizer mods enhance physical mounts and targeting software, ensuring weapons remain level, steady, and at an appropriate angle regardless of terrain or pilot maneuvers.",
		data_type: "mod",
		aptitude: {
		},
		tags: [
			{
				id: "tg_mod"
			}
		],
		added_range: {
			type: "Range",
			val: 5
		},
		added_tags: [
			{
				id: "tg_ordnance"
			}
		]
	},
	{
		id: "wm_nanocomposite_adaptation",
		name: "NANOCOMPOSITE ADAPTATION",
		sp: 2,
		applied_to: [
			"melee",
			"cqb",
			"rifle",
			"launcher",
			"cannon",
			"nexus"
		],
		applied_string: "Any",
		source: "HORUS",
		license: "BALOR",
		license_level: 2,
		effect: "Choose a weapon: it gains Smart and Seeking.",
		description: "Nanocomposite weapons take aggressive drone swarms and condense them into individual rounds, a coherent beam, or the edge of a blade.<br>Adapted projectile weapons fire shaped CONSUME/HIVE rounds that shatter on impact, releasing their payload of autonomous nanite maniples. Once freed, the maniples begin eating away at surrounding tissue or superstructure. They proceed until burnout or total target consumption, whichever occurs first. In flight, the maniples are able to hive-link and make slight adjustments to the trajectory of their round, ensuring positive impact.<br>Coherent beam weapons transport maniples directly, while conventional melee weapons are replaced by analogs composed entirely of nanobots.",
		data_type: "mod",
		aptitude: {
		},
		tags: [
			{
				id: "tg_mod"
			}
		],
		added_tags: [
			{
				id: "tg_smart"
			},
			{
				id: "tg_seeking"
			}
		]
	},
	{
		id: "wm_phase_ready_mod",
		name: "PHASE-READY MOD",
		sp: 2,
		applied_to: [
			"melee",
			"cqb",
			"rifle",
			"launcher",
			"cannon",
			"nexus"
		],
		applied_string: "Any",
		source: "HA",
		license: "NAPOLEON",
		license_level: 2,
		effect: "Choose a weapon: as long as you know the rough location of your target, it can attack through solid walls and obstructions, doesn’t require line of sight, and ignores all cover, but targets attacked this way count as Invisible.",
		description: "As it was named following its first use during the civil hostilities on Luna de Oro, phase-ready ammunition is the “devil’s bullets”. Each round contains a nanoprocessor suite networked with its weapon of origin that calculates and translates the specific nature of that round’s superpositional relation with a projected future doppelgänger that manifests in the space immediately before its intended target. To put it simply, phase-ready rounds, when fired, exist in two places at once: exiting the barrel of the weapon they were fired from, and directly in front of the target, prior to impact. The prime round may never hit its target, but given it already exists at the moment of impact, the doppelgänger round will reliably reach its mark.",
		data_type: "mod",
		aptitude: {
		},
		tags: [
			{
				id: "tg_mod"
			}
		]
	},
	{
		id: "wm_paracausal_mod",
		name: "PARACAUSAL MOD",
		sp: 4,
		applied_to: [
			"melee",
			"cqb",
			"rifle",
			"launcher",
			"cannon",
			"nexus"
		],
		applied_string: "Any",
		source: "HA",
		license: "SALADIN",
		license_level: 3,
		effect: "Choose a weapon: it gains Overkill, and its damage can’t be reduced in any way, including by other effects and systems (such as Resistance, Armor, etc).",
		description: "Paracausal weapons are a headache for military planners; their precise A–Z function is often obscured, though they consistently produce the same “Z” output per “A” input.<br>The first reports of unregulated paracausal weaponry occurred during the civil engagements on Tian Shen. System-local forces received sealed magazines with directions to be loaded and fired as normal, although inspection of the magazines’ contents was prohibited on grounds that it would “damage the payload”. Helmet and gun cam footage do not betray the anomalous effects of this ordnance, though after-action reports uncovered a seemingly minor, though incredibly odd fact: every single trooper outfitted with this paracausal ammunition scored a 100% positive impact rate.<br>Union has scheduled all unregulated paracausal weapons and ammunition for retrieval, and the bureau is currently investigating Harrison Armory for its role in the development of the technology. Despite this, paracausal ammunition is still in use, as shipments and codes continue to leak to interested parties.",
		data_type: "mod",
		aptitude: {
		},
		tags: [
			{
				id: "tg_mod"
			}
		]
	}
];

var mods$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    'default': mods
});

var pilot_gear = [
	{
		id: "pg_archaic_melee",
		name: "ARCHAIC MELEE",
		type: "weapon",
		description: "These weapons were made using pre-Union alloys and technology, and might be anything from industrial-era steel swords through to stone axes. While they remain widely used on some worlds, archaic weapons used by pilots are usually relics, heirlooms, or ceremonial weapons.",
		tags: [
			{
				id: "tg_archaic"
			}
		],
		range: [
			{
				type: "Threat",
				val: 1
			}
		],
		damage: [
			{
				type: "kinetic",
				val: 1
			}
		]
	},
	{
		id: "pg_archaic_ranged",
		name: "ARCHAIC RANGED",
		type: "weapon",
		description: "These weapons are pre-modern devices like muskets and bows, all of which are still used in some societies.",
		tags: [
			{
				id: "tg_archaic"
			}
		],
		range: [
			{
				type: "Range",
				val: 5
			}
		],
		damage: [
			{
				type: "kinetic",
				val: 1
			}
		]
	},
	{
		id: "pg_light_a_c",
		name: "LIGHT A/C",
		type: "weapon",
		description: "Light A/C weapons might be knives, bayonets, punching daggers, and short swords.",
		tags: [
			{
				id: "tg_sidearm"
			}
		],
		range: [
			{
				type: "Threat",
				val: 1
			}
		],
		damage: [
			{
				type: "kinetic",
				val: 1
			}
		]
	},
	{
		id: "pg_medium_a_c",
		name: "MEDIUM A/C",
		type: "weapon",
		description: "Medium A/C weapons are typically swords, officer’s sabers, and trench axes.",
		tags: [
		],
		range: [
			{
				type: "Threat",
				val: 1
			}
		],
		damage: [
			{
				type: "kinetic",
				val: 2
			}
		]
	},
	{
		id: "pg_heavy_a_c",
		name: "HEAVY A/C",
		type: "weapon",
		description: "Heavy weapons are designed with the augmented strength of hardsuits in mind and include war hammers, mallets, rams, pikes, and heavy two-handed assault swords.",
		tags: [
			{
				id: "tg_inaccurate"
			}
		],
		range: [
			{
				type: "Threat",
				val: 1
			}
		],
		damage: [
			{
				type: "kinetic",
				val: 3
			}
		]
	},
	{
		id: "pg_light_signature",
		name: "LIGHT SIGNATURE",
		type: "weapon",
		description: "Light signature weapons might be oversized revolvers, braces of pistols, and submachine guns.",
		tags: [
			{
				id: "tg_sidearm"
			},
			{
				id: "tg_set_damage_type"
			}
		],
		range: [
			{
				type: "Range",
				val: 3
			}
		],
		damage: [
			{
				type: "variable",
				val: 1
			}
		],
		effect: "When a signature weapon is acquired, choose its damage type – Explosive, Energy, or Kinetic."
	},
	{
		id: "pg_medium_signature",
		name: "MEDIUM SIGNATURE",
		type: "weapon",
		description: "Medium signature weapons are assault rifles, shotguns, pack-fed lasers, or disruption guns.",
		tags: [
			{
				id: "tg_set_damage_type"
			}
		],
		range: [
			{
				type: "Range",
				val: 5
			}
		],
		damage: [
			{
				type: "variable",
				val: 2
			}
		],
		effect: "When a signature weapon is acquired, choose its damage type – Explosive, Energy, or Kinetic."
	},
	{
		id: "pg_heavy_signature",
		name: "HEAVY SIGNATURE",
		type: "weapon",
		description: "Heavy signature weapons are missile tubes, heavy lasers, light machine gun, or exotic rifles.",
		tags: [
			{
				id: "tg_ordnance"
			},
			{
				id: "tg_loading"
			},
			{
				id: "tg_set_damage_type"
			}
		],
		range: [
			{
				type: "Range",
				val: 10
			}
		],
		damage: [
			{
				type: "variable",
				val: 4
			}
		],
		effect: "When a signature weapon is acquired, choose its damage type – Explosive, Energy, or Kinetic."
	},
	{
		id: "pg_light_hardsuit",
		name: "LIGHT HARDSUIT",
		type: "armor",
		description: "Light hardsuits are usually made from reactive, cloth-like weaves, with limited plating and few powered components to maximize mobility. Like other hardsuits, they can be sealed against vacuum, and protect against a decent amount of radiation and other harmful particles.",
		tags: [
			{
				id: "tg_personal_armor"
			}
		],
		hp_bonus: 3,
		armor: 0,
		evasion: 10,
		edef: 10,
		speed: 4
	},
	{
		id: "pg_assault_hardsuit",
		name: "ASSAULT HARDSUIT",
		type: "armor",
		description: "These hardsuits, common among military units, feature heavier plating than light hardsuits but more mobility than heavy hardsuits. They are powered, augmenting the user’s strength, and typically feature an onboard computer, sensor suite, integrated air, burst EVA system, and waste recycling systems.",
		tags: [
			{
				id: "tg_personal_armor"
			}
		],
		hp_bonus: 3,
		armor: 1,
		evasion: 8,
		edef: 8,
		speed: 4
	},
	{
		id: "pg_heavy_hardsuit",
		name: "HEAVY HARDSUIT",
		type: "armor",
		description: "The heaviest hardsuits. They are always powered and up-armored with thick, composite armor. Heavy hardsuits often feature integrated weapons, powerful mobility suites, and – by augmenting their user’s strength – allow their user to field much heavier weapons than normal infantry can typically carry. Heavy hardsuits are in decline now that half-size chassis are popular, but they are still common among private militaries and middle-tier Diasporan armed forces.",
		tags: [
			{
				id: "tg_personal_armor"
			}
		],
		hp_bonus: 3,
		armor: 2,
		evasion: 6,
		edef: 8,
		speed: 3
	},
	{
		id: "pg_mobility_hardsuit",
		name: "MOBILITY HARDSUIT",
		type: "armor",
		description: "These hardsuits have integrated flight systems, allowing pilots to fly when they move or Boost. Flying pilots must end their turn on the ground (or another surface) or begin falling.",
		tags: [
			{
				id: "tg_personal_armor"
			}
		],
		hp_bonus: 0,
		armor: 0,
		evasion: 10,
		edef: 10,
		speed: 5
	},
	{
		id: "pg_stealth_hardsuit",
		name: "STEALTH HARDSUIT",
		type: "armor",
		description: "As a quick action, pilots wearing stealth hardsuits can become Invisible. They cease to be Invisible if they take any damage.",
		tags: [
			{
				id: "tg_personal_armor"
			}
		],
		hp_bonus: 0,
		armor: 0,
		evasion: 8,
		edef: 8,
		speed: 4
	},
	{
		id: "pg_corrective",
		name: "CORRECTIVE",
		type: "gear",
		description: "This clear, plastic-like sheet can be placed over the wounds of severely injured pilots. It instantly begins to stabilize them, injecting medicine and deploying nanites to stitch wounds shut.<br>Expend a charge to apply correctives to Down and Out pilots, immediately bringing them back to consciousness at 1 HP.",
		tags: [
			{
				id: "tg_gear"
			},
			{
				id: "tg_limited",
				val: 1
			},
			{
				id: "tg_full_action"
			}
		],
		uses: 1
	},
	{
		id: "pg_frag_grenades",
		name: "FRAG GRENADES",
		type: "gear",
		description: "Expend a charge for the following effect:<ul><li><b>Frag Grenade</b> (Grenade, Range 5, Blast 1): Affected characters must succeed on an Agility save or take 2 Explosive damage.</li></ul>",
		tags: [
			{
				id: "tg_gear"
			},
			{
				id: "tg_limited",
				val: 2
			}
		],
		uses: 2
	},
	{
		id: "pg_patch",
		name: "PATCH",
		type: "gear",
		description: "“Patch” is pilot slang for any kind of modern first aid gear, including sprayable medi-gel and instant-acting medical patches.<br>Expend a charge to apply a patch to either yourself or an adjacent pilot, restoring half their maximum HP. Patches have no effect on Down and Out pilots.",
		tags: [
			{
				id: "tg_gear"
			},
			{
				id: "tg_limited",
				val: 1
			},
			{
				id: "tg_full_action"
			}
		],
		uses: 1
	},
	{
		id: "pg_stims",
		name: "STIMS",
		type: "gear",
		description: "These chemical stimulants are sometimes administered automatically by injectors built into a pilot’s suit, or even implanted within their body. Uncontrolled use can be addictive and dangerous to health in the long-term and is a problem for some pilots.<br>Expend a charge for one of the following effects:<ul><li><b>Kick:</b> Keeps a pilot awake and alert for up to 30 hours.</li><li><b>Freeze:</b> Keeps a pilot calm and emotionally stable; deadens fear and other strong reactions.</li><li><b>Juice:</b> Heighten senses and alertness, reduce fatigue, and shorten reaction times. Juice occasionally provokes rage in some users.</li></ul>",
		tags: [
			{
				id: "tg_gear"
			},
			{
				id: "tg_limited",
				val: 3
			},
			{
				id: "tg_quick_action"
			}
		],
		uses: 3
	},
	{
		id: "pg_thermite_charge",
		name: "THERMITE CHARGE",
		type: "gear",
		description: "Expend a charge for the following effect:<ul><li><b>Thermite Charge</b> (Mine, Burst 1): This charge must be remotely detonated as a quick action. Affected characters must succeed on an Engineering save or take 3 Energy AP. Thermal charges automatically hit objects, dealing 10 Energy AP.</li></ul>",
		tags: [
			{
				id: "tg_gear"
			},
			{
				id: "tg_limited",
				val: 1
			},
			{
				id: "tg_full_action"
			}
		],
		uses: 1
	},
	{
		id: "pg_antiphoton_visor",
		name: "ANTIPHOTON VISOR",
		type: "gear",
		description: "Designed to protect the wearer’s eyes from intense bursts of light, antiphoton visors are commonly found among breach teams and solar-forward operators. They are effective against flash weapons, intense UV light, and incidental charges from energy weapons.",
		tags: [
			{
				id: "tg_gear"
			}
		]
	},
	{
		id: "pg_camo_cloth",
		name: "CAMO CLOTH",
		type: "gear",
		description: "A square of reactive material that slowly shifts to reflect the surrounding environment, enough to cover a human comfortably. The transition takes about 10 seconds and makes anything hidden underneath very difficult to spot.",
		tags: [
			{
				id: "tg_gear"
			}
		]
	},
	{
		id: "pg_dataplating",
		name: "DATAPLATING",
		type: "gear",
		description: "Dataplating is a general term for any comm-linked jewelry, subdermal netting, wearable jaw, brow, or maxillary plates, etc., that allows subvocal communication and persistent heads-up and augmented reality displays without wearing a helm. Dataplates can quickly translate nearly any language, and allow users to communicate with each other all but silently.",
		tags: [
			{
				id: "tg_gear"
			}
		]
	},
	{
		id: "pg_extra_rations",
		name: "EXTRA RATIONS",
		type: "gear",
		description: "Pilot rations aren’t much better than their nautical forerunners – both are variants on hardtack and nutrient paste. Pilots often carry a stash of extra food, or luxuries like chocolate, coffee, alcohol, or preserved goods from their homeworld. These rations can be used to barter or boost morale.",
		tags: [
			{
				id: "tg_gear"
			}
		]
	},
	{
		id: "pg_flexsuit",
		name: "FLEXSUIT",
		type: "gear",
		description: "A strong base-layer suit that recycles water, generates nutrients, and adapts very rapidly to hostile environs, maintaining a stable condition and extending survivability. Flexsuit wearers can go for roughly a week without eating or drink thanks to the ambrosia paste generated by their suit before its systems are depleted; however, they don’t prevent feelings of hunger. Removing the suit for a day or two is enough to replenish its reserves. Flexsuits also maintain a steady temperature within acceptable parameters.",
		tags: [
			{
				id: "tg_gear"
			}
		]
	},
	{
		id: "pg_handheld_printer",
		name: "HANDHELD PRINTER",
		type: "gear",
		description: "A miniaturized version of Union’s full-scale printers, handheld printers can be used to make simple objects out of flexible and durable plastic – as long as you have the right pattern chip.",
		tags: [
			{
				id: "tg_gear"
			}
		]
	},
	{
		id: "pg_subjectivity_enhancement_suite",
		name: "SUBJECTIVITY-ENHANCEMENT SUITE",
		type: "gear",
		description: "A subjectivity-enhancement suite is a set of cybernetic implants allowing users to hack systems without a rig. Users of these suites blend the organic with the synthetic, gaining the ability to extrude implanted universal-plug cables from within their body to make hardline connections with terminals. When plugged in, users can access a comprehensive, fully interactive alternate-reality interface with direct omninet access, making navigating – or hacking – local and networked systems as easy as wishing it so (of course, you must be careful: by opening up your mind to the digital, you may face dangers other, less enhanced people are ignorant of).",
		tags: [
			{
				id: "tg_gear"
			}
		]
	},
	{
		id: "pg_infoskin",
		name: "INFOSKIN",
		type: "gear",
		description: "A reactive, synthetic polymer with advanced qualities, infoskin bonds quickly to real skin and hair. Once applied, it responds to electronic signals delivered by linked software, rapidly changing its color and texture – even contorting and distorting its form – allowing wearers to make minor changes to their appearance. With infoskin, it’s a simple matter to alter facial features, hair color, or makeup patterns.",
		tags: [
			{
				id: "tg_gear"
			}
		]
	},
	{
		id: "pg_mag_clamps",
		name: "MAG-CLAMPS",
		type: "gear",
		description: "These clamps attach easily to any metal surface, enhancing maneuverability in zero-g environments or when repairing mechs. They can be carried or fitted to boots.",
		tags: [
			{
				id: "tg_gear"
			}
		]
	},
	{
		id: "pg_nanite_spray",
		name: "NANITE SPRAY",
		type: "gear",
		description: "A spray paint that can be applied to any surface. Nanite spray is invisible to the naked eye but able to transmit simple messages or small data packets when scanned.",
		tags: [
			{
				id: "tg_gear"
			}
		]
	},
	{
		id: "pg_omnihook",
		name: "OMNIHOOK",
		type: "gear",
		description: "A portable – if bulky – omninet terminal that allows for communication, data transfer, and limited hot-spotting. Omnihooks are extremely valuable, although most mech squads have at least one. Tuning an omnihook requires a high level of skill, so they are usually mounted or carried by designated operators.",
		tags: [
			{
				id: "tg_gear"
			}
		]
	},
	{
		id: "pg_personal_drone",
		name: "PERSONAL DRONE",
		type: "gear",
		description: "Small, non-combat drones are a common sight in the field. They’re fairly noisy but can fly about half a mile with good maneuverability before losing signal, relaying audio and visual information as they go.",
		tags: [
			{
				id: "tg_gear"
			}
		]
	},
	{
		id: "pg_prosocollar",
		name: "PROSOCOLLAR",
		type: "gear",
		description: "A collar-like device that fits snugly around its wearer’s neck, projecting a holographic image over their face and head. Prosocollars can change their wearer’s voice and scramble or change their appearance. The projection won’t stand up to close inspection, but it can easily fool electronic systems and distant observers.",
		tags: [
			{
				id: "tg_gear"
			}
		]
	},
	{
		id: "pg_smart_scope",
		name: "SMART SCOPE",
		type: "gear",
		description: "A powerful electronic scope that provides high-resolution magnification up to two miles, and automatically adjusts its reticle for wind, gravity, and pressure. Smart scopes can project their field of vision and all data to the HUD of any networked user. They can also pair with other thermal, optical, or simulated-vision devices to further enhance targeting.",
		tags: [
			{
				id: "tg_gear"
			}
		]
	},
	{
		id: "pg_sleeping_bag",
		name: "SLEEPING BAG",
		type: "gear",
		description: "Coming in a variety of sizes, sleeping bags are a field necessity. They’re designed to fold out from a hardsuit, fit within a mech’s cockpit, resist fire and changes in temperature, and – when necessary – seal against vacuum.<br>You can climb into your sleeping bag, gaining Immunity to burn, protection against vacuum, and enough air to last an hour; however, while in the sleeping bag you are Stunned and can’t take actions other than to exit the bag as a full action.",
		tags: [
			{
				id: "tg_gear"
			},
			{
				id: "tg_full_action"
			}
		]
	},
	{
		id: "pg_ssc_sylph_undersuit",
		name: "SSC SYLPH UNDERSUIT",
		type: "gear",
		description: "Discovered on Acrimea IV, a biome cultivar world controlled by Smith-Shimano Corpro (SSC), the sylph is an organic lifeform that can seemingly survive in nearly any environment. Using breeding-analogous methods defined by established bioengineering doctrines, SSC developed the sylph undersuit – sterile, living sylphs grown as envelopes and fitted to their owners. The sylph bonds to its wearer, forming a symbiotic relationship: the sylph is sustained by the host’s waste products, in return protecting the host from a range of hostile environmental factors.<br>These semi-biological, skin-tight undersuits can be worn for extended periods. They are translucent, semi-liquid, and able to be stored when not in use, conforming to whatever container they are placed in. They clean the host’s body, aid natural healing processes, and eliminate waste. As desired, segments can become opaque, change color, or take on a new texture. Sylph undersuits can cover the host’s head, sealing against vacuum, providing protection against radiation, and filtering air or liquids, even providing the ability to breathe water for a limited time.",
		tags: [
			{
				id: "tg_gear"
			}
		]
	},
	{
		id: "pg_sound_system",
		name: "SOUND SYSTEM",
		type: "gear",
		description: "Though their tactical utility is questionable, many pilots set up internal speaker systems in their cockpits. This gives them a clear line to their compatriots during combat, along with the ability to play music.",
		tags: [
			{
				id: "tg_gear"
			}
		]
	},
	{
		id: "pg_tertiary_arm",
		name: "TERTIARY ARM",
		type: "gear",
		description: "A powered third arm mounted on a bracket on the hardsuit. Tertiary arms are powered and controlled using the same neural bridge processes that allow hardsuits to respond to user input. They can be equipped with manipulators to allow for fine motor control, weapons to enhance combat efficacy, or specialty tools.",
		tags: [
			{
				id: "tg_gear"
			}
		]
	},
	{
		id: "pg_wilderness_survival_kit",
		name: "WILDERNESS SURVIVAL KIT",
		type: "gear",
		description: "This kit contains many essentials for surviving in hostile environments: a rebreather, water filters, hardsuit patches, backup thermals, a bivouac kit, and so on.",
		tags: [
			{
				id: "tg_gear"
			}
		]
	}
];

var pilot_gear$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    'default': pilot_gear
});

var quirks = [
	"Part (or all) of your body was too damaged to be cloned perfectly and a significant percentage of your clone body has been replaced with cybernetics. These high-quality prostheses aren’t obviously synthetic to casual observers. You don’t know the extent of the damage.",
	"Your clone has been fitted with a necessary but visible cybernetic augmentation – an arm, leg, eyes, or similar. It is a conspicuous prosthetic.",
	"By accident or malign intent, your cognitive profile has been loaded into someone else’s body. It might be a clone of a notorious or famous individual, with both enemies and allies who thought they were dead; or, you might run into the “original” person the clone was based on.",
	"Your clone has a unique appearance that clearly marks you as vat-grown.",
	"Thanks to a series of administrative mishaps, the appearance of your new body is drastically different to that of your old body.",
	"An additional, withered limb grows out of your clone’s chest shortly after your cognitive profile has been loaded. It sometimes moves on its own.",
	"There’s a conspicuous barcode printed on your clone body. The barcode means something specific to at least one powerful organization, but you aren’t privy to its meaning – at least not yet.",
	"In certain light conditions, it’s possible to read a script or inscription printed just under your skin. The script is all over your body and contains information contested by powerful organizations or entities – scientific formulae, maps, or something else entirely.",
	"Your clone body is unusually susceptible to solar radiation, viruses, bacteria, or some other common environmental phenomenon. You must wear an environmental suit to operate outside certain safe environments, which include your mech’s cockpit and your personal quarters. You can use downtime actions to make other rooms safe.",
	"Genetic material from a non-human source was used in the creation of your clone body. Whoever revived you won’t tell you the exact details or what long-term effects it will have, and they treat you like a science experiment. The new genetic material has caused a cosmetic change that is useful and visible, although able to be hidden.",
	"Whenever you try to sleep or rest, you’re stricken with vivid and persistent dreams, visions, and images of your death. You know they’re real but can’t reconcile the existential gulf between the experiences of the old and new versions of yourself.",
	"In addition to your cognitive profile, your clone body has been loaded with a digital homunculus of someone else: a basic digital reconstruction of a personality that is more like a piece of software than a person. While not technically sapient, it is very smart, and carries a message or secret with it.",
	"You’re plagued by the constant understanding or belief that the “real” you is actually dead, and you’re merely a facsimile of a dead person, implanted with someone else’s memories. You can’t establish the difference between the “you” that died and the “you” that exists now.",
	"In addition to your cognitive profile, your flash clone is woven through with a subdermal data-lattice: this storage device contains very dangerous and potentially unwanted information that is contested or sought by powerful entities.",
	"The flash-cloning process went awry, and you have been revived tabula rasa. In desperation, the technicians dump a stock personality construct into your clone body. Choose a new background and triggers.",
	"There are complications while growing your clone body: it has a dramatically reduced life expectancy.",
	"Something changed you – you now have persistent and intrusive mental contact with an entity or entities, human or otherwise.",
	"You keep having searing headaches during which you see brief flashes of what you’re pretty sure is the future. Sometimes these visions come to pass, sometimes they don’t.",
	"Knowingly or unknowingly, your clone body has been implanted with a mental trigger that places you in a receptive state when heard or activated, causing you to either follow a pre-programmed course of action or to follow instructions given by the person who activated you. These commands must be simple (e.g., kill, lie, etc.), and the GM determines who (PC or NPC) gave them. You might be able to overcome this effect in time.",
	"You come back with total amnesia regarding the time before your death, meaning you must be retrained and prepared from scratch. You lose all previous triggers and assign new ones up to your current level. Additionally, you may rewrite some incidental facts of your backstory."
];

var quirks$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    'default': quirks
});

var reserves = [
	{
		id: "reserve_skill",
		name: "Skill",
		type: "Resources",
		label: "Resource",
		description: "Gain or improve a skill, typically as part of the \"Get Focused\" Downtime Action."
	},
	{
		id: "reserve_access",
		name: "Access",
		type: "Resources",
		label: "Resource",
		description: "A keycard, invite, bribes or insider access to a particular location."
	},
	{
		id: "reserve_backing",
		name: "Backing",
		type: "Resources",
		label: "Contact",
		description: "Useful leverage through political support from a powerful figure."
	},
	{
		id: "reserve_supplies",
		name: "Supplies",
		type: "Resources",
		label: "Resource",
		description: "Gear allowing easy crossing of a hazardous or hostile area."
	},
	{
		id: "reserve_disguise",
		name: "Disguise",
		type: "Resources",
		label: "Identity",
		description: "An effective disguise or cover identity, allowing uncontested access to a location."
	},
	{
		id: "reserve_diversion",
		name: "Diversion",
		type: "Resources",
		label: "Diversion",
		description: "A distraction that provides time to take action without fear of consequence."
	},
	{
		id: "reserve_blackmail",
		name: "Blackmail",
		type: "Resources",
		label: "Target",
		description: "Blackmail materials or sensitive information concerning a particular person."
	},
	{
		id: "reserve_reputation",
		name: "Reputation",
		type: "Resources",
		label: "Status",
		description: "A good name in the mission area, prompting good first impressions with the locals."
	},
	{
		id: "reserve_safe_harbor",
		name: "Safe Harbor",
		type: "Resources",
		label: "Location",
		description: "Guaranteed safety for meeting, planning, or recuperating."
	},
	{
		id: "reserve_tracking",
		name: "Tracking",
		type: "Resources",
		label: "Target",
		description: "Details on the location of important objects or people."
	},
	{
		id: "reserve_knowledge",
		name: "Knowledge",
		type: "Resources",
		label: "Subject",
		description: "An understanding of local history, customs, culture, or etiquette."
	},
	{
		id: "reserve_ammo",
		name: "Ammo",
		type: "Mech",
		label: "Ammo",
		description: "Extra uses (+1 or +2) of a LIMITED weapon or system."
	},
	{
		id: "reserve_rented_gear",
		name: "Rented gear",
		type: "Mech",
		label: "Gear",
		description: "Temporary access to a new weapon or piece of mech gear."
	},
	{
		id: "reserve_extra_repairs",
		name: "Extra repairs",
		type: "Mech",
		label: "Resource",
		description: "Supplies that give a mech +2 REPAIR CAP."
	},
	{
		id: "reserve_core_battery",
		name: "CORE battery",
		type: "Mech",
		label: "Battery",
		description: "An extra battery that allows a second use of a mech’s CORE SYSTEM."
	},
	{
		id: "reserve_deployable_shield",
		name: "Deployable shield",
		type: "Mech",
		label: "Shield",
		description: "A single-use deployable shield generator – a SIZE 1 deployable that grants soft cover to all friendly characters in a BURST 2 radius."
	},
	{
		id: "reserve_redundant_repair",
		name: "Redundant repair",
		type: "Mech",
		label: "Resource",
		description: "The ability to STABILIZE as a free action once per mission."
	},
	{
		id: "reserve_systems_reinforcement",
		name: "Systems reinforcement",
		type: "Mech",
		label: "Resource",
		description: "+1 ACCURACY to skill checks made with one skill – HULL, AGILITY, SYSTEMS or ENGINEERING."
	},
	{
		id: "reserve_smart_ammo",
		name: "Smart ammo",
		type: "Mech",
		label: "Ammo",
		description: "All weapons of your choice can be fired as if they are SMART."
	},
	{
		id: "reserve_boosted_servos",
		name: "Boosted servos",
		type: "Mech",
		label: "Resource",
		description: "IMMUNITY to the SLOWED condition."
	},
	{
		id: "reserve_jump_jets",
		name: "Jump jets",
		type: "Mech",
		label: "Resource",
		description: "During this mission your mech can FLY when moving, but must end movement on land."
	},
	{
		id: "reserve_scouting",
		name: "Scouting",
		type: "Tactical",
		label: "Location",
		description: "Detailed information on the kinds of mechs and threats you will face on the mission, such as number, type, and statistics."
	},
	{
		id: "reserve_vehicle",
		name: "Vehicle",
		type: "Tactical",
		label: "Designation",
		description: "Use of a transport vehicle or starship (e.g., a TIER 1 NPC with the VEHICLE or SHIP template."
	},
	{
		id: "reserve_reinforcements",
		name: "Reinforcements",
		type: "Tactical",
		label: "Designation",
		description: "The ability to call in a friendly NPC mech of any Tier, once per mission."
	},
	{
		id: "reserve_environmental_shielding",
		name: "Environmental shielding",
		type: "Tactical",
		label: "Environment",
		description: "Equipment that allows you to ignore a particular battlefield hazard or dangerous terrain, such as extreme heat or cold."
	},
	{
		id: "reserve_accuracy",
		name: "Accuracy",
		type: "Tactical",
		label: "Skill/Action",
		description: "Training or enhancement that provides +1 ACCURACY to a particular mech skill or action for the duration of this mission."
	},
	{
		id: "reserve_bombardment",
		name: "Bombardment",
		type: "Tactical",
		label: "Resource",
		description: "The ability to call in artillery or orbital bombardment once during mech combat (full action, RANGE 30 within line of sight, BLAST 2, 3d6 explosive damage)."
	},
	{
		id: "reserve_extended_harness",
		name: "Extended Harness",
		type: "Tactical",
		label: "Resource",
		description: "A custom harness that allows you to carry an extra pilot weapon and two extra pieces of pilot gear for the duration of this mission."
	},
	{
		id: "reserve_ambush",
		name: "Ambush",
		type: "Tactical",
		label: "Location",
		description: "Intel that allows you to choose exactly where your next battle will take place, including the layout of terrain and cover."
	},
	{
		id: "reserve_orbital_drop",
		name: "Orbital Drop",
		type: "Tactical",
		label: "Location",
		description: "The ability to start the mission by dropping from orbit into a heavily fortified or hard to reach location."
	},
	{
		id: "reserve_nhp_assistant",
		name: "NHP Assistant",
		type: "Tactical",
		label: "Designation",
		description: "A non-human person (NHP) – an advanced artificial intelligence – controlled by the GM, that can give you advice on the current situation."
	}
];

var reserves$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    'default': reserves
});

var base_structure = 4;
var base_stress = 4;
var base_grapple = 0;
var base_ram = 0;
var base_pilot_hp = 6;
var base_pilot_evasion = 10;
var base_pilot_edef = 10;
var base_pilot_speed = 4;
var minimum_pilot_skills = 4;
var minimum_mech_skills = 2;
var minimum_pilot_talents = 3;
var trigger_bonus_per_rank = 2;
var max_trigger_rank = 3;
var max_pilot_level = 12;
var max_pilot_weapons = 2;
var max_pilot_armor = 1;
var max_pilot_gear = 3;
var max_frame_size = 3;
var max_mech_armor = 4;
var max_hase = 6;
var mount_fittings = {
	Auxiliary: [
		"Auxiliary"
	],
	Main: [
		"Main",
		"Auxiliary"
	],
	Flex: [
		"Main",
		"Auxiliary"
	],
	Heavy: [
		"Superheavy",
		"Heavy",
		"Main",
		"Auxiliary"
	]
};
var overcharge = [
	"+1",
	"+1d3",
	"+1d6",
	"+1d6+4"
];
var skill_headers = [
	{
		attr: "str",
		description: "use, resist, and apply direct force, physical or otherwise"
	},
	{
		attr: "dex",
		description: "perform skillfully and accurately under pressure"
	},
	{
		attr: "int",
		description: "notice details, think creatively, and prepare"
	},
	{
		attr: "cha",
		description: "talk, lead, change minds, make connections, and requisition resources"
	},
	{
		attr: "Custom",
		description: "Custom Skill Triggers"
	}
];
var rules = {
	base_structure: base_structure,
	base_stress: base_stress,
	base_grapple: base_grapple,
	base_ram: base_ram,
	base_pilot_hp: base_pilot_hp,
	base_pilot_evasion: base_pilot_evasion,
	base_pilot_edef: base_pilot_edef,
	base_pilot_speed: base_pilot_speed,
	minimum_pilot_skills: minimum_pilot_skills,
	minimum_mech_skills: minimum_mech_skills,
	minimum_pilot_talents: minimum_pilot_talents,
	trigger_bonus_per_rank: trigger_bonus_per_rank,
	max_trigger_rank: max_trigger_rank,
	max_pilot_level: max_pilot_level,
	max_pilot_weapons: max_pilot_weapons,
	max_pilot_armor: max_pilot_armor,
	max_pilot_gear: max_pilot_gear,
	max_frame_size: max_frame_size,
	max_mech_armor: max_mech_armor,
	max_hase: max_hase,
	mount_fittings: mount_fittings,
	overcharge: overcharge,
	skill_headers: skill_headers
};

var rules$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    base_structure: base_structure,
    base_stress: base_stress,
    base_grapple: base_grapple,
    base_ram: base_ram,
    base_pilot_hp: base_pilot_hp,
    base_pilot_evasion: base_pilot_evasion,
    base_pilot_edef: base_pilot_edef,
    base_pilot_speed: base_pilot_speed,
    minimum_pilot_skills: minimum_pilot_skills,
    minimum_mech_skills: minimum_mech_skills,
    minimum_pilot_talents: minimum_pilot_talents,
    trigger_bonus_per_rank: trigger_bonus_per_rank,
    max_trigger_rank: max_trigger_rank,
    max_pilot_level: max_pilot_level,
    max_pilot_weapons: max_pilot_weapons,
    max_pilot_armor: max_pilot_armor,
    max_pilot_gear: max_pilot_gear,
    max_frame_size: max_frame_size,
    max_mech_armor: max_mech_armor,
    max_hase: max_hase,
    mount_fittings: mount_fittings,
    overcharge: overcharge,
    skill_headers: skill_headers,
    'default': rules
});

var sitreps = [
	{
		id: "sitrep_standardcombat",
		name: "Standard Combat",
		pcVictory: "PCs defeat or route all enemy forces",
		enemyVictory: "PCs are defeated or retreat from battle",
		description: "A simple affair, with two sides facing off against each other until one of them is broken or destroyed."
	},
	{
		id: "sitrep_control",
		name: "Control",
		description: "CONTROL missions require the PCs to maintain control of four Control Zones for six rounds. The zones might contain important locations like transmission towers, gun batteries, terminals, or hangars. At the end of each round, each side gains 1 point for each Control Zone they control. If one side controls all four Control Zones, they gain an additional +1 point.",
		pcVictory: "The PCs have the highest score at the end of the sixth round",
		enemyVictory: "The enemy force has the highest score at the end of the sixth round.",
		noVictory: "If both sides have an equal score at the end of the sixth round, there is no victor and both sides must withdraw.",
		controlZone: "Four Control Zones (typically 4 spaces on each side) in different quadrants of the map, each placed anywhere in their quadrant. They should be roughly symmetrical, or the map will be unbalanced. If there are characters of only one side within a Control Zone, they control it; if there are characters from two or more sides within a Control Zone, it is contested.",
		deployment: "The GM and a player each roll 1d6 to determine the order of deployment. Whoever rolls the lower result deploys first."
	},
	{
		id: "sitrep_escort",
		name: "Escort",
		description: "ESCORT missions require the PCs to bring an OBJECTIVE safely to the Extraction Zone and get the hell out of there.",
		pcVictory: "The Objective is safely extracted.",
		enemyVictory: "The Objective hasn’t been extracted at the end of the eighth round. If there are any PCs remaining on the field when this takes place, they are captured or overrun.",
		noVictory: "The Objective is destroyed.",
		deployment: "The PCs deploy first, choosing positions for their characters and the Objective in the Allied Deployment Zone; then, the GM deploys enemy forces in the EDZ.",
		extraction: "While in the Extraction Zone, PCs can extract as a free action at the end of their turn. Extracted PCs are removed from the battlefield. If the Objective is adjacent to a PC when they extract and isn’t contested by any characters from the opposing side, it is safely extracted."
	},
	{
		id: "sitrep_extraction",
		name: "Extraction",
		description: "EXTRACTION missions require player characters to dash across the map to retrieve an objective and bring it safely back to extraction.",
		pcVictory: "The Objective is safely extracted.",
		enemyVictory: "The Objective hasn’t been extracted at the end of the tenth round. If there are any PCs remaining on the field when this takes place, they are captured or overrun.",
		noVictory: "The Objective is destroyed.",
		deployment: "The PCs deploy first, choosing positions for their characters in the Allied Deployment Zone; next, the GM places the Objective in the Objective Zone.",
		objective: "An object or person of Size 1/2–2. The Objective has 10 HP per level of Size, Evasion 10, E-Defense 10, and no Armor. Enemy forces want the Objective and will not willingly damage it. When a character starts their turn adjacent to the Objective, it moves with them when they make their regular move. If the Objective is ever adjacent to two characters of opposing sides, it stops moving and can’t move until it is only adjacent characters from one side. The Objective doesn’t move on its own.",
		extraction: "While in the Extraction Zone/Allied Deployment Zone, PCs can extract as a free action at the end of their turn. Extracted PCs are removed from the battlefield. If the Objective is adjacent to a PC when they extract and isn’t contested by any characters from the opposing side, it is safely extracted."
	},
	{
		id: "sitrep_gauntlet",
		name: "Gauntlet",
		description: "GAUNTLET missions are usually done under duress or when no other options are available, and they usually take place in unfriendly territory. Gauntlet missions require PCs to move through a dangerous area to secure a position.",
		pcVictory: "At the end of the eighth round, there are more PCs inside the Control Zone than there are enemy characters. Ultras count as 4 characters, elites count as 2, and grunts count as 1/4.",
		enemyVictory: "At the end of the sixth round, there are at least as many enemy characters inside the Control Zone as there are PCs.",
		deployment: "The PCs deploy first, choosing positions for their characters in the Allied Deployment Zone; next, the GM places the Objective in the Objective Zone.",
		controlZone: "The area around the EDZ/Control Zone is fortified with Size 1–2 hard cover."
	},
	{
		id: "sitrep_holdout",
		name: "Holdout",
		description: "HOLDOUT missions are desperate undertakings. They require the PCs to defend an area against an onslaught of enemies. In the best-case scenario, this buys time for allies to complete an objective elsewhere; in the worst, it’s survive or die. The PCs start with 4 points. At the end of the sixth round, the points are tallied: the PCs lose a point for every enemy inside the Control Zone. This can result in a negative score.",
		pcVictory: "At the end of the sixth round, the PCs have a score of 1 or higher.",
		enemyVictory: "At the end of the sixth round, the PCs have a score of less than 1. If there are any PCs remaining on the field when this takes place, they are captured or overrun.",
		controlZone: "An area typically 10 spaces by 5 spaces in the middle of the map, or positioned as needed. The area around the Control Zone should be fortified with Size 1–2 hard cover.",
		deployment: "The PCs deploy first, choosing positions for their characters within the Allied Deployment Zone/Control Zone; next, the GM deploys enemy forces in the EDZ."
	},
	{
		id: "sitrep_recon",
		name: "Recon",
		description: "RECON missions are dangerous endeavors involving small teams entering hostile territory to identify targets or retrieve key information.",
		pcVictory: "At the end of the sixth round, the PCs control the True Control Zone.",
		enemyVictory: "At the end of the sixth round, the PCs don’t control the True Control Zone.",
		controlZone: "Four Control Zones (typically 4 spaces on each side) in different quadrants of the map, each placed anywhere in their quadrant. The GM secretly designates one Control Zone as the True Control Zone. While inside a Control Zone, PCs may take a full action to determine whether it is the True Control Zone. If there are only PCs within the True Control Zone, they control it; if there are characters from two or more sides within the True Control Zone, it is contested.",
		deployment: "The PCs deploy first, choosing positions for their characters within the Allied Deployment Zone; next, the GM deploys enemy forces in the EDZ."
	}
];

var sitreps$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    'default': sitreps
});

var skills = [
	{
		id: "sk_act_unseen_or_unheard",
		name: "ACT UNSEEN OR UNHEARD",
		description: "Get somewhere or do something without detection.",
		detail: "Get somewhere or do something without being detected, but not necessarily with speed. Hide, sneak, or move quietly. Infiltrate a facility while avoiding security, patrols, or cameras. Perform a quick action or maneuver without being seen or heard, such as picking a pocket, unholstering your gun, or cheating at cards. Wear a disguise.",
		family: "dex"
	},
	{
		id: "sk_apply_fists_to_faces",
		name: "APPLY FISTS TO FACES",
		description: "Fight in open, brutal unarmed combat.",
		detail: "Punch someone in the face, or alternately fight in open, brutal unarmed combat, whether it’s a fist fight, martial arts duel, or a huge brawl. This is never subtle, never clean, and probably causes a lot of noise.",
		family: "str"
	},
	{
		id: "sk_assault",
		name: "ASSAULT",
		description: "Take part in direct and overt combat.",
		detail: "Take part in direct and overt combat: fighting your way through a building packed with hostile mercenaries, trading shots between rain-slick trenches, fighting in chaotic microgravity as part of a boarding action, or engaging the enemy in the smoking urban rubble of a city under orbital bombardment — When you assault, you’re always assaulting something (a position, a rival pilot, an enemy force, a group of guards), and it’s always loud, open, direct action.",
		family: "str"
	},
	{
		id: "sk_blow_something_up",
		name: "BLOW SOMETHING UP",
		description: "Use explosives to totally wreck something or turn it into an enormous fireball.",
		detail: "Use explosives (improvised or otherwise), weapons, or maybe just good old fashion brawn to totally wreck something or turn it into an enormous fireball (maybe a wall, sensor array, outpost, reactor core - the good stuff). Probably not to be used against people unless they’re incidentally in the way.",
		family: "str"
	},
	{
		id: "sk_charm",
		name: "CHARM",
		description: "Convince a receptive audience or use leverage (money, power, personal benefit) to get your way.",
		detail: "To charm, you need a receptive audience, or some kind of promise of leverage (money, power, personal benefit, etc). You can use it when trying to smooth talk your way past guards, get someone on your side, sway a potential benefactor, talk someone down, perform diplomacy between two parties, or blatantly lie to someone. You can also use it when trying to impersonate someone. Charm won’t work on people that aren’t receptive (such as soldiers you are in a gunfight with) or that you don’t have leverage over (promises of safety, money, power, recompense, help, etc). These promises don’t necessarily have to be true but they have to have some weight with your target.",
		family: "int"
	},
	{
		id: "sk_get_a_hold_of_something",
		name: "GET A HOLD OF SOMETHING",
		description: "Acquire temporary or permanent allies, assets, or connections through wealth or social influence.",
		detail: "Acquire useful allies, assets, or connections through wealth or social influence. This could be permanent (buying it or receiving it) or temporary (renting or borrowing help or supplies, etc), and might be harder or easier depending on how much you want to use it. This can’t be used for something that’s normally gated by license level (like mech parts) but could be used for aid, supplies, information, food materials, soldiers, or anything else that has more narrative impact. Typically this is acquired by buying it from a market or requisitioning it from a parent organization.",
		family: "cha"
	},
	{
		id: "sk_get_somewhere_quickly",
		name: "GET SOMEWHERE QUICKLY",
		description: "Get somewhere quickly and without complications.",
		detail: "Get somewhere without complications and with speed, but not necessarily stealth. Climb, swim, or perform acrobatic maneuvers in an attempt to reach a destination faster than the ‘safe’ way. Fall safely from a great height. Move gracefully in zero-g. Chase or flee, outrun, or out pace a target. Get somewhere faster than anyone else. You can also use this when you want to drive or pilot a vehicle.",
		family: "dex"
	},
	{
		id: "sk_hack_or_fix",
		name: "HACK OR FIX",
		description: "Repair a device or faulty system; alternatively, hack it wide open, or totally wreck, disable or sabotage it.",
		detail: "Repair a device or faulty system. Alternately, hack it wide open, or totally wreck, disable or sabotage it. You can use this for hacking or safeguarding electronic systems, such as electronic door locks, computer systems, omninet webs, or NHP coffins.",
		family: "int"
	},
	{
		id: "sk_invent_or_create",
		name: "INVENT OR CREATE",
		description: "Invent new devices, tools, or approaches to problems.",
		detail: "Generally speaking, you need tools and supplies to invent or create something successfully. Use this with many downtime actions to work on projects. You can also use it in the spur of the moment to invent new devices, tools, or approaches to something (improvised explosives, gear, disguises, or some similar).",
		family: "int"
	},
	{
		id: "sk_investigate",
		name: "INVESTIGATE",
		description: "Research a subject, or study something in great detail.",
		detail: "Research a subject, or look at something in great detail. If you can’t find information directly, you learn how you can get access to that information. Learn about a subject of historical relevance, or become well-read on a subject. Investigate a mystery or solve a puzzle. Locate a person or object through research or investigation.",
		family: "int"
	},
	{
		id: "sk_lead_or_inspire",
		name: "LEAD OR INSPIRE",
		description: "Give an inspiring speech, or motivate a group of people into action.",
		detail: "Give an inspiring speech, or motivate a group of people into action. Administer or run an organization efficiently or effectively, such as a company, a ship’s crew, a group of colonists or a mining venture. Effectively command a platoon of soldiers in battle, or (perhaps) an entire army.",
		family: "cha"
	},
	{
		id: "sk_patch",
		name: "PATCH",
		description: "Apply medical knowledge to medicate or diagnose.",
		detail: "Apply your medical knowledge to administer medication, bandage a wound, staunch bleeding, suture, cauterize, neutralize poison, or resuscitate. Alternately, you could use it to diagnose or study disease, pathogens, or illness.",
		family: "int"
	},
	{
		id: "sk_pull_rank",
		name: "PULL RANK",
		description: "Get information, resources, or aid from a subordinate.",
		detail: "Pull rank on a subordinate, getting information, resources, or aid from them, even unwillingly. You can use this on anyone your social status (noble, celebrity, etc) or military rank would have weight with. Failing this might be risky and could be seen as abusive. You typically can’t pull rank on hostile targets. You could also use this to pretend to have a rank you don’t have, but it’s definitely risky.",
		family: "cha"
	},
	{
		id: "sk_read_a_situation",
		name: "READ A SITUATION",
		description: "Look for subtext, motives, or threats in a situation or person.",
		detail: "Look for subtext, motive, or threat in a situation or person, often social situations. Use your intuition to learn someone’s motivation, learn who is really in charge, or who is about to do something rash or stupid. Get a gut feeling about a situation or person. Sense if someone is lying to you.",
		family: "int"
	},
	{
		id: "sk_show_off",
		name: "SHOW OFF",
		description: "Do something flashy, cool, or impressive, usually – but not exclusively – with your weapon.",
		detail: "Do something flashy, cool, or impressive, usually (but not exclusively) with your weapon, like shooting a very small or rapidly moving target, shooting someone’s hat off or their weapon out of their hand, knocking someone out by throwing a gun at them, performing an acrobatic flourish with a sword, throwing a spear to pin a fleeing target to the ground, and so on.",
		family: "dex"
	},
	{
		id: "sk_spot",
		name: "SPOT",
		description: "Spot details, objects, or people that are hidden or difficult to make out.",
		detail: "Spot hidden or difficult to make out details, objects, or people. Spot ambushes, hidden compartments, or disguised individuals. Spy on a target from a distance, or make out the details, shape, and number of objects, vehicles, mechs, or people clearly at a distance. Track people or vehicles.",
		family: "int"
	},
	{
		id: "sk_stay_cool",
		name: "STAY COOL",
		description: "Perform a task that requires concentration, dexterity, speed, or precision under pressure.",
		detail: "Do something that requires concentration, speed, or intense precision under pressure, like picking a lock as your squad trades fire with encroaching guards, avoiding a hostile memetic code while hacking a secure console, carefully disarming an explosive, or unjamming a gun under fire. If you’ve got to do something complicated in a high stress situation without messing up (and possibly not even breaking a sweat) this is the action to use.",
		family: "dex"
	},
	{
		id: "sk_survive",
		name: "SURVIVE",
		description: "Persevere through harsh, hostile, or unforgiving environments.",
		detail: "Persevere through harsh, hostile, or unforgiving environments, such as the vacuum of space, frozen tundra, a pirate enclave, a crime-ridden colony, untamed wilderness, or scorching desert. You most often use survive when you want to take a journey through wilderness environments, navigate, or avoid natural hazards such as carnivorous wildlife, rockfalls, thin ice, or lava fields. Alternately you could use it to avoid man-made hazards, such as navigating a city safely, or avoiding dangerous areas of a space station. You could also use it when testing personal endurance, such as shaking off poison or alcohol.",
		family: "str"
	},
	{
		id: "sk_take_control",
		name: "TAKE CONTROL",
		description: "Use force, violence, presence of will, or direct action to take control of something.",
		detail: "Use force, violence, presence of will, or direct action to take control of something. This is often something concrete, like an object someone is holding. You could take control of someone’s gun or a keycard they have on their person. You can additionally can take control of a situation to force those present to listen, calm down, stop moving, or stop what they’re doing (perhaps for their benefit), though you can’t necessarily force them to do anything further without threatening them. Taking control is never subtle.",
		family: "str"
	},
	{
		id: "sk_take_someone_out",
		name: "TAKE SOMEONE OUT",
		description: "Kill or disable someone quickly and quietly.",
		detail: "Kill or disable someone quickly and quietly, from up close and personal or from a distance, probably before they even notice. This is probably a single person but could be two people relatively close together (any more is sort of stretching it and definitely risky). If you’re looking down a sniper scope at a target, preparing to nerve pinch a guard to knock them out instantly, quick-drawing during a gun duel, or dropping from a ceiling to slit a throat, this is the action to use.",
		family: "dex"
	},
	{
		id: "sk_threaten",
		name: "THREATEN",
		description: "Use force or threats to make someone do what you want.",
		detail: "Use force or threats of force to get someone to do what you want them to do. Name what you want someone to do and what you’re going to do to them if they don’t listen to you. This could also be blackmail, leverage, or something similarly nasty. Threatening someone can be very high risk but very effective if successful - either way there’s likely no repairing the relationship afterwards. If you threaten someone unsuccessfully, your threats have no further effect on them unless you change something about the situation (as with all other skill checks).",
		family: "str"
	},
	{
		id: "sk_word_on_the_street",
		name: "WORD ON THE STREET",
		description: "Get gossip, news, or hearsay from the streets, or from a particular social scene.",
		detail: "Get gossip, news, or hearsay from the streets. What you get depends on what ‘streets’ you are getting word from (high society, low society, hearsay, military chatter, etc). This probably takes a lot less time than investigating something in detail, but the information might be more qualitative or colored by opinion (sometimes that might be useful). You can always learn where the information came from or who to go to next.",
		family: "cha"
	}
];

var skills$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    'default': skills
});

var statuses = [
	{
		name: "DANGER ZONE",
		icon: "danger-zone",
		type: "Status",
		effects: "(MECHS ONLY)<br>Characters are in the DANGER ZONE when half or more of their heat is filled in. They’re smoking hot, which enables some attacks, talents, and effects."
	},
	{
		name: "DOWN AND OUT (PILOTS ONLY)",
		icon: "downandout",
		type: "Status",
		effects: "Pilots that are DOWN AND OUT are unconscious and STUNNED – if they take any more damage, they die. They'll regain consciousness and half of their HP when they rest."
	},
	{
		name: "ENGAGED",
		icon: "engaged",
		type: "Status",
		effects: "If a character moves adjacent to a hostile character, they both gain the ENGAGED status for as long as they remain adjacent to one another. Ranged attacks made by an ENGAGED character receive +1 difficulty. Additionally, characters that become ENGAGED by targets of equal or greater SIZE during the course of a movement stop moving immediately and lose any unused movement."
	},
	{
		name: "EXPOSED",
		icon: "exposed",
		type: "Status",
		effects: "(MECHS ONLY)<br>Characters become EXPOSED when they’re dealing with runaway heat buildup – their armor is weakened by overheating, their vents are open, and their weapons are spinning down, providing plenty of weak points. All kinetic, explosive or energy damage taken by EXPOSED characters is doubled, before applying any reductions. A mech can clear EXPOSED by taking the STABILIZE action."
	},
	{
		name: "HIDDEN",
		icon: "hidden",
		type: "Status",
		effects: "HIDDEN characters can’t be targeted by hostile attacks or actions, don’t cause engagement, and enemies only know their approximate location. Attacking, forcing saves, taking reactions, using BOOST, and losing cover all remove HIDDEN after they resolve. Characters can find HIDDEN characters with SEARCH."
	},
	{
		name: "INVISIBLE",
		icon: "invisible",
		type: "Status",
		effects: "All attacks against INVISIBLE characters, regardless of type, have a 50 percent chance to miss outright, before an attack roll is made. Roll a dice or flip a coin to determine if the attack misses.<br>Additionally, INVISIBLE characters can always HIDE, even without cover."
	},
	{
		name: "PRONE",
		icon: "prone",
		type: "Status",
		effects: "Attacks against PRONE targets receive +1 accuracy.<br>Additionally, PRONE characters are SLOWED and count as moving in difficult terrain. Characters can remove PRONE by standing up instead of taking their standard move, unless they’re IMMOBILIZED. Standing up doesn’t count as movement, so doesn’t trigger OVERWATCH or other effects."
	},
	{
		name: "SHUT DOWN",
		icon: "shut-down",
		type: "Status",
		effects: "(MECHS ONLY)<br>When a mech is SHUT DOWN:<br>• all heat is cleared and the EXPOSED status is removed;<br>• any cascading NHPs are stabilised and no longer cascading;<br>• any statuses and conditions affecting the mech caused by tech actions, such as LOCK ON, immediately end.<br>SHUT DOWN mechs have IMMUNITY to all tech actions and attacks, including any from allied characters.<br>While SHUT DOWN, mechs are STUNNED indefinitely. Nothing can prevent this condition, and it remains until the mech ceases to be SHUT DOWN."
	},
	{
		name: "IMMOBILIZED",
		icon: "immobilized",
		type: "Condition",
		effects: "IMMOBILIZED characters cannot make any voluntary movements, although involuntary movements are unaffected."
	},
	{
		name: "IMPAIRED",
		icon: "impaired",
		type: "Condition",
		effects: "IMPAIRED characters receive +1 difficulty on all attacks, saves, and skill checks."
	},
	{
		name: "JAMMED",
		icon: "jammed",
		type: "Condition",
		effects: "JAMMED characters can’t:<br>• use comms to talk to other characters;<br>• make attacks, other than IMPROVISED ATTACK, GRAPPLE, and RAM;<br>• take reactions, or take or benefit from tech actions."
	},
	{
		name: "LOCK ON",
		icon: "lock-on",
		type: "Condition",
		effects: "Hostile characters can choose to consume a character’s LOCK ON condition in exchange for +1 accuracy on their next attack against that character.<br>LOCK ON is also required to use some talents and systems."
	},
	{
		name: "SHREDDED",
		icon: "shredded",
		type: "Condition",
		effects: "SHREDDED characters don’t benefit from ARMOR or RESISTANCE."
	},
	{
		name: "SLOWED",
		icon: "slow",
		type: "Condition",
		effects: "The only movement SLOWED characters can make is their standard move, on their own turn – they can’t BOOST or make any special moves granted by talents, systems, or weapons."
	},
	{
		name: "STUNNED",
		icon: "stunned",
		type: "Condition",
		effects: "STUNNED mechs cannot OVERCHARGE, move, or take any actions – including free actions and reactions. Pilots can still MOUNT, DISMOUNT, or EJECT from STUNNED mechs, and can take actions normally.<br>STUNNED mechs have a maximum of 5 EVASION, and automatically fail all HULL and AGILITY checks and saves."
	}
];

var statuses$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    'default': statuses
});

var systems = [
	{
		id: "ms_comp_con_class_assistant_unit",
		name: "COMP/CON-CLASS ASSISTANT UNIT",
		type: "AI",
		sp: 2,
		tags: [
			{
				id: "tg_ai"
			},
			{
				id: "tg_unique"
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "Your mech has a basic comp/con unit, granting it the AI tag. The comp/con can speak to you and has a personality, but, unlike an NHP, is not truly capable of independent thought. It is obedient to you alone.<br>You can give control of your mech to its comp/con as a protocol, allowing your mech to act independently on your turn with its own set of actions. Unlike other AIs, a mech controlled by a comp/con has no independent initiative and requires direct input. Your mech will follow basic courses of action (defend this area, attack this enemy, protect me, etc.) to the best of its ability, or will act to defend itself if its instructions are complete or it receives no further guidance. You can issue new commands at the start of your turn as long as you are within Range 50 and have the means to communicate with your mech. Comp/con units are not true NHPs and thus cannot enter cascade.",
		description: "The GMS Companion/Concierge-Class Assistant Unit conforms to all galaxy-wide standards. These virtual assistants pass even the most rigid Turing-Null assessment criteria and are cleared to operate even in the absence of a pilot.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_custom_paint_job",
		name: "CUSTOM PAINT JOB",
		type: "System",
		sp: 1,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_indestructible"
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "When you take structure damage, roll 1d6. On a 6, you return to 1 HP and ignore the damage – the hit simply ‘scratched your paint’.<br>This system can only be used once before each Full Repair, and is not a valid target for system destruction.",
		description: "",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_expanded_compartment",
		name: "EXPANDED COMPARTMENT",
		type: "System",
		sp: 1,
		tags: [
			{
				id: "tg_unique"
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "Your mech has space for one additional non-Mech character or object of Size 1/2 to ride as a passenger in the cockpit. While inside the mech, they cannot suffer any effect from outside or be targeted by attacks, as if they were a pilot. You can hand over or take back control to or from them as a protocol (following the same rules as pilot and AIs), but if they take over the controls from you, the mech becomes Impaired and Slowed to reflect the lack of appropriate licenses and integration.",
		description: "",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_manipulators",
		name: "MANIPULATORS",
		type: "System",
		sp: 1,
		tags: [
			{
				id: "tg_unique"
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "Your mech has an extra set of limbs. They are too small to have any combat benefit, but allow the mech to interact with objects that would otherwise be too small or sensitive (e.g., pilot-sized touch pads).",
		description: "Precise interaction with built and natural environments, soft targets, and hazardous materials is part of the daily routine for support-class mechs. This is made possible by manipulators – added multi-digit “hands” with haptic sensors.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_pattern_a_smoke_charges",
		name: "PATTERN-A SMOKE CHARGES",
		type: "Deployable",
		sp: 2,
		tags: [
			{
				id: "tg_limited",
				val: 3
			},
			{
				id: "tg_unique"
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: {
			effect_type: "Charge",
			charges: [
				{
					name: "Smoke Grenade",
					charge_type: "Grenade",
					range: [
						{
							type: "Range",
							val: 5
						},
						{
							type: "Blast",
							val: 2
						}
					],
					detail: "All characters and objects within the blast area benefit from soft cover until the end of your next turn, at which point the smoke disperses."
				},
				{
					name: "Smoke Mine",
					charge_type: "Mine",
					range: [
						{
							type: "Burst",
							val: 3
						}
					],
					detail: "This mine detonates when any allied character moves over or adjacent to it. All characters and objects within the burst area benefit from soft cover until the end of the detonating character’s next turn, at which point the smoke disperses."
				}
			]
		},
		description: "",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_pattern_a_jericho_deployable_cover",
		name: "PATTERN-A JERICHO DEPLOYABLE COVER",
		type: "Deployable",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: {
			effect_type: "Deployable",
			activation: "Quick",
			count: 2,
			size: 1,
			hp: 10,
			evasion: 5,
			detail: "Deploy two sections of Size 1 hard cover in free spaces adjacent to you and to each other. Each section is an object with 5 Evasion and 10 HP that can be targeted and destroyed individually. Sections of cover can be picked up again as a full action.<br>Repairing the system restores both sections."
		},
		description: "",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_pattern_b_hex_charges",
		name: "PATTERN-B HEX CHARGES",
		type: "Deployable",
		sp: 2,
		tags: [
			{
				id: "tg_limited",
				val: 3
			},
			{
				id: "tg_unique"
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: {
			effect_type: "Charge",
			charges: [
				{
					name: "Frag Grenade",
					charge_type: "Grenade",
					range: [
						{
							type: "Range",
							val: 5
						},
						{
							type: "Blast",
							val: 1
						}
					],
					damage: [
						{
							type: "explosive",
							val: "1d6"
						}
					],
					detail: "All characters within the affected area must pass an Agility save or take 1d6 Explosive damage. On a success, they take half damage."
				},
				{
					name: "Explosive Mine",
					charge_type: "Mine",
					range: [
						{
							type: "Burst",
							val: 1
						}
					],
					detail: "All characters within the affected area must pass an Agility save or take 2d6 Explosive damage. On a success, they take half damage."
				}
			]
		},
		description: "",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_personalizations",
		name: "PERSONALIZATIONS",
		type: "System",
		sp: 1,
		tags: [
			{
				id: "tg_unique"
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: {
			effect_type: "Bonus",
			hp: 2,
			detail: "You gain +2 HP and, in consultation with the GM, you may establish a minor modification you have made to your mech.<br>This mod has no numerical benefit beyond the additional HP it grants, but could provide other useful effects. If the GM agrees that this mod would help with either a pilot or mech skill check, you gain +1 Accuracy for that check."
		},
		description: "",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_stable_structure",
		name: "STABLE STRUCTURE",
		type: "System",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "You gain +1 Accuracy on saves to avoid Prone or Knockback.",
		description: "",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_turret_drones",
		name: "TURRET DRONES",
		type: "Drone",
		sp: 2,
		tags: [
			{
				id: "tg_limited",
				val: 3
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_drone"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: {
			effect_type: "Drone",
			size: 0.5,
			hp: 5,
			edef: 10,
			evasion: 10,
			detail: "Expend a charge to deploy a turret drone that attaches to any object or surface within Sensors and line of sight. Gain the Turret Attack reaction, which can be taken once for each deployed turret drone. Turret drones cannot be recalled and expire at the end of the scene.",
			abilities: [
				{
					name: "Turret Attack",
					effect_type: "Reaction",
					frequency: "1/round per turret",
					trigger: "An allied character within Range 10 of a turret drone makes a successful attack.",
					detail: "The turret drone deals 3 Kinetic damage to their target, as long as it has line of sight to their target."
				}
			]
		},
		description: "The use of turret drones is a rather traditional form of force multiplication – one that has remained the backbone of defense in many theaters.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_type_3_projected_shield",
		name: "TYPE-3 PROJECTED SHIELD",
		type: "Shield",
		sp: 2,
		tags: [
			{
				id: "tg_shield"
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_protocol"
			},
			{
				id: "tg_heat_self",
				val: 1
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: {
			name: "Project Shield",
			effect_type: "Protocol",
			detail: "Nominate a character within line of sight: all ranged or melee attacks that they make against you or that you make against them gain +2 Difficulty until the start of your next turn."
		},
		description: "The GMS Type-3 Projected Shield traps and denies incoming projectiles by projecting an aggressive, superpositional anti-ballistic barrier.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_eva_module",
		name: "EVA MODULE",
		type: "Flight System",
		sp: 1,
		tags: [
			{
				id: "tg_unique"
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "Your mech has a propulsion system suitable for use in low or zero gravity and underwater environments. In those environments, you can fly and are not Slowed.",
		description: "",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_rapid_burst_jump_jet_system",
		name: "RAPID BURST JUMP JET SYSTEM",
		type: "Flight System",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "You can fly when you Boost; however, you must end the movement on the ground or another solid surface, or else immediately begin falling.",
		description: "",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_type_i_flight_system",
		name: "TYPE-I FLIGHT SYSTEM",
		type: "Flight System",
		sp: 3,
		tags: [
			{
				id: "tg_unique"
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "You may choose to count any and all of your movement as flying; however, you take Size +1 Heat at the end of any of your turns in which you fly this way.",
		description: "",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_synthetic_muscle_netting",
		name: "SYNTHETIC MUSCLE NETTING",
		type: "System",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			}
		],
		source: "IPS-N",
		license: "BLACKBEARD",
		license_level: 1,
		effect: "You may Ram targets larger than you, and when you Grapple or Ram larger targets, you count as the same Size as the largest opponent. When you Grapple or Ram opponents of the same Size or smaller, you count as at least one Size larger. Additionally, your lifting and dragging capacity is doubled.",
		description: "IPS-N’s Synthetic Muscle Netting (SMN) is a proprietary, field-proven modification compatible with all existing IPS-N frames. This convenient spray-on catalytic and structural enhancement boosts manipulator and propulsion performance by roughly 25 percent with no demonstrated reduction in operational life. An SMN layer also enhances impact absorption and thermal insulation.<br>IPS-N recommends that pilots apply SMN to internal components only and practice frequent cleaning to prevent septic-analogous decay.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_reinforced_cabling",
		name: "REINFORCED CABLING",
		type: "System",
		sp: 2,
		tags: [
		],
		source: "IPS-N",
		license: "BLACKBEARD",
		license_level: 3,
		effect: [
			{
				effect_type: "Basic",
				name: "Grapple Swing",
				detail: "1/turn, when making a standard move, you can fly your Speed in a straight line as long as there is a clear path. This move must end on an object or surface, or else you begin falling. As long as you remain stationary, you can secure yourself to the destination surface or object, even if it’s vertical or overhanging. If you are knocked Prone or knocked back while secured to a surface, you fall."
			},
			{
				effect_type: "Basic",
				name: "Drag Down",
				detail: "As a quick action, make a contested Hull check against a character within 5 Range and line of sight: the loser is knocked Prone."
			}
		],
		description: "Reinforced grappling cables allow for full movement and utility in ≤1 g environments. Woven from incredibly strong nanocarbon and arachnosynth threading, reinforced grapple line is carried on waist-mounted spools and attached to charge-actuated brachial projectors. Once fired, the grapples penetrate and anchor to the target. Small meltdown charges seeded every thirty meters of cable both allow rapid disengagement and expose a fresh grapple head, ready for immediate use.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_sekhmet_class_nhp",
		name: "SEKHMET-CLASS NHP",
		type: "AI",
		sp: 3,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_ai"
			},
			{
				id: "tg_protocol"
			}
		],
		source: "IPS-N",
		license: "BLACKBEARD",
		license_level: 3,
		effect: {
			effect_type: "AI",
			detail: "Your mech gains the AI tag and the SEKHMET Protocol",
			abilities: [
				{
					name: "SEKHMET Protocol",
					effect_type: "Protocol",
					detail: "When activated, you give control of your mech to your NHP and gain the following benefits:<ul><li>All melee critical hits deal +1d6 bonus damage.</li><li>1/round, you can Skirmish with melee weapons only as a free action.</li></ul>Your NHP uses all available actions and movement to move toward the closest visible character – allied or hostile – and attacks them with melee attacks, prioritizing melee weapons. It may benefit from your talents. If there are no characters within Threat, your NHP uses all actions to move as directly as possible to the next closest (visible) target. Your NHP can’t make ranged attacks, even if there are actions available.<br>You retain enough control to Overcharge as usual; however, your NHP uses the additional action for the same purpose as its other actions.<br>You can take back control of your mech as a protocol. When you do, you become Stunned until the start of your next turn. Otherwise, this effect lasts until your mech is destroyed – the pilot’s incapacitation or death has no effect."
				}
			]
		},
		description: "“The IPS-N SEKHMET co-pilot is ready to be your first mate! SEKHMET comes standard with remote, omninet, IR tag, and voice control systems, and is fully compatible with all current and legacy IPS-N mechs.<br>Did you know that SEKHMET learns with you? Should the worst happen, your very own SEKHMET will continue to engage hostile targets using an emulated neural-net doppelgänger to pilot your IPS-N chassis until forced or voluntary shutdown!”<br>draft copy, IPS-N Polaris Pilot Lounge adbroad [struck and replaced w/current adbroad]<br>SEKHMET-class NHPs tend toward aggressive attitudes and dark humor. Pilots often call them “berserker systems” – dangerous NHPs that value combat efficacy over pilot wellbeing.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_argonaut_shield",
		name: "ARGONAUT SHIELD",
		type: "System",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "IPS-N",
		license: "DRAKE",
		license_level: 1,
		effect: {
			effect_type: "Basic",
			activation: "Quick",
			detail: "You use this heavy overarm to provide cover for an adjacent character as a quick action, giving them Resistance to all damage; however, you take half of the damage your target would take before calculating Armor and Resistance. This effect lasts until your target breaks adjacency, at which point this effect ceases until you repeat this action."
		},
		description: "In space, simplicity in form and function guarantees reliability and promotes trust. The Argonaut is one of IPS-N’s oldest designs, hailing from the pre-merger days of Northstar’s Deep Black security teams. It’s a simple slab of metal carried in hand or mounted on a chassis’ brachial superstructure; the only option a pilot has for customizing this shield is a choice of size.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_aegis_shield_generator",
		name: "AEGIS SHIELD GENERATOR",
		type: "Deployable",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_limited",
				val: 1
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "IPS-N",
		license: "DRAKE",
		license_level: 2,
		effect: {
			effect_type: "Deployable",
			activation: "Quick",
			count: 1,
			size: 1,
			hp: 10,
			evasion: 5,
			detail: "Expend a charge to deploy a Size 1 shield generator in a free, adjacent space, where it creates a burst 1 shield. Set out three d6s to represent the generator’s remaining power. As a reaction when any character or object of your choice at least partly in the area takes damage, you may roll one of the d6s to reduce the damage by the amount rolled.<br>This effect lasts for the rest of the scene, until all dice have been rolled and the generator loses power, or the generator is destroyed.",
			tags: [
				{
					id: "tg_shield"
				}
			]
		},
		description: "The Aegis is a portable electromagnetic shield generator: a powerful and reliable method – if crude by modern standards – for establishing kinetic and coherent-particle deterrence over a wide area.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_portable_bunker",
		name: "PORTABLE BUNKER",
		type: "Deployable",
		sp: 2,
		tags: [
			{
				id: "tg_limited",
				val: 1
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "IPS-N",
		license: "DRAKE",
		license_level: 3,
		effect: {
			effect_type: "Deployable",
			activation: "Quick",
			count: 1,
			size: 4,
			hp: 40,
			evasion: 5,
			detail: "Expend a charge to deploy a portable bunker to a free, adjacent area 4 by 4 area. At the start of your next turn, it unfolds into a fortified emplacement with the listed profile. All characters completely within the affected area gain hard cover against all attacks from outside the bunker from all directions and Resistance to damage from Blast, Line, Burst, and Cone attacks that originate outside the bunker.<br>The bunker is open topped, and characters may enter or exit at will. It can’t be moved or deactivated once deployed."
		},
		description: "IPS-N’s “Portable Bunker” is actually a series of single-use expanding printer sheets: flat-pack pouches of inert non-Newtonian fluid that, when deployed, become a rigid structure capable of withstanding incredible force.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_cable_winch_system",
		name: "CABLE WINCH SYSTEM",
		type: "System",
		sp: 1,
		tags: [
			{
				id: "tg_quick_action"
			}
		],
		source: "IPS-N",
		license: "LANCASTER",
		license_level: 1,
		effect: {
			effect_type: "Basic",
			activation: "Quick",
			detail: "These cables can be attached to an adjacent character. If the target is Stunned or willing, you automatically succeed; otherwise, they can resist with a successful Hull save. Once attached, you and the target may not move more than 5 spaces away from each other. Either character can tow the other, obeying the normal rules for lifting and dragging, and becoming Slowed while doing so.<br>Any character can remove the cables on a hit with a melee attack or Improvised Attack against Evasion 10.<br>These cables can also be used to drag, pull, or otherwise interact with objects and the environment. They are 5 spaces long and can support a combined Size 6 before they break. Characters can use them to climb surfaces, allowing them to climb without a Speed penalty."
		},
		description: "A winch system consists of an externally mounted spool of nanocarbon-weave cable and a recovery subroutine installed on the mech.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_restock_drone",
		name: "RESTOCK DRONE",
		type: "Drone",
		sp: 2,
		tags: [
			{
				id: "tg_limited",
				val: 2
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_action"
			},
			{
				id: "tg_drone"
			}
		],
		source: "IPS-N",
		license: "LANCASTER",
		license_level: 1,
		effect: {
			effect_type: "Drone",
			activation: "Quick",
			size: 0.5,
			hp: 5,
			edef: 10,
			evasion: 10,
			detail: "Expend a charge to deploy a restock drone to any free, adjacent space, where it primes at the end of your turn. While adjacent to the drone, allied characters can activate it as a quick action, clearing 1d6 heat and one condition, and reloading one Loading weapon. After being activated, the drone immediately disintegrates."
		},
		description: "Reliable and sturdy drones carrying integrated printers, restock drones allow for limited logistical flexibility via autosalvage. The bulk of a restock drone is made of RawMat, a blend of silicates and metallic materials that the drone processes into replacement parts and repair kits. This is why pilots often joke that restock drones are, simply put, “mech snacks”.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_mule_harness",
		name: "MULE HARNESS",
		type: "System",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			}
		],
		source: "IPS-N",
		license: "LANCASTER",
		license_level: 2,
		effect: "Extra mounts, straps, and hard points allow other characters to climb and ride your mech. Adjacent, non-Immobilized characters can climb onto your mech as a quick action. While riding, they occupy the same space as you, move when you move (even if they’re Slowed), and benefit from soft cover. If you or a rider are knocked Prone, Stunned, Immobilized, or destroyed, they land Prone in adjacent spaces. Riders can climb down as part of any movement away, but can only climb onto your mech as a quick action.<br>You can carry riders of a combined Size equal to your Size, minus Size 1/2 (e.g., if your mech is Size 1 you can carry one Size 1/2 character; if it is Size 2, you can carry a Size 1 character and a Size 1/2 character).",
		description: "The Multiple User, Light Entanglement (MULE) Harness is a mass-produced version of a common battlefield modification that allows friendly soldiers to ride along on a chassis. Some systems are large enough to allow smaller chassis to accompany larger chassis; typically, these variants are employed in high altitude, low orbit insertions where reduced radar presence is required.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_whitewash_sealant_spray",
		name: "WHITEWASH SEALANT SPRAY",
		type: "System",
		sp: 2,
		tags: [
			{
				id: "tg_quick_action"
			}
		],
		source: "IPS-N",
		license: "LANCASTER",
		license_level: 2,
		effect: {
			effect_type: "Basic",
			activation: "Quick",
			detail: "This sealant can be sprayed on characters or free spaces within range 5 and line of sight. It has different effects depending on the target:<ul><li><b>Hostile Characters:</b> Your target must succeed on an Agility save or they become Slowed until the end of their next turn and clear all burn.</li><li><b>Allied Characters:</b> Your target clears all burn but they become Slowed until the end of their next turn.</li><li><b>Free Space:</b> Any fires within blast 1 are extinguished and the area becomes difficult terrain for the rest of the scene.</li></ul>"
		},
		description: "For fire suppression and fast, temporary seals in punctured starship bulkheads, IPS-N offers a range of single-use, single objective nanites – “whitewash”. This sealant spray can also be used to restrain noncompliant actors when the correct spray heads and catalytic formulations are installed to the applicator.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_aceso_stabilizer",
		name: "ACESO STABILIZER",
		type: "Shield",
		sp: 3,
		tags: [
			{
				id: "tg_limited",
				val: 3
			},
			{
				id: "tg_overshield"
			},
			{
				id: "tg_shield"
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "IPS-N",
		license: "LANCASTER",
		license_level: 3,
		effect: {
			effect_type: "Basic",
			activation: "Quick",
			detail: "Expend a charge to fire this small, self-arming system onto an allied mech within range 5. They gain Overshield equal to your Grit +4. While they have this Overshield they gain Immunity to Impaired and Jammed."
		},
		description: "The IPS-N Aceso Stabilizer is a useful triage measure for any scoring and minor mechanical damage that is sustained in the course of combat engagement or negative environmental interaction. Thanks to its negligible processor demand, Aceso Stabilizers can even be controlled by comp/con units – this allows the pilot to concentrate on complex repairs or immediate threat neutralization.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_bulwark_mods",
		name: "BULWARK MODS",
		type: "System",
		sp: 1,
		tags: [
			{
				id: "tg_unique"
			}
		],
		source: "IPS-N",
		license: "NELSON",
		license_level: 1,
		effect: "Your mech’s extended limbs, additional armor, redundant motor systems, and other reinforcements allow you to ignore difficult terrain.",
		description: "All proprietary IPS-N mech cores feature their QuickMod system – a modular, legacy-compatible system of joints, hardpoints, and internal slots that makes installing upgrades simple. This proved to be a necessary feature for Albatross maktebas long out of synch with Union Realtime.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_armor_lock_plating",
		name: "ARMOR-LOCK PLATING",
		type: "System",
		sp: 1,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_heat_self",
				val: 2
			}
		],
		source: "IPS-N",
		license: "NELSON",
		license_level: 2,
		effect: "You can Brace while Grappling. When you do so, any grapples currently affecting you end.<br>Additionally, when you Brace, you gain the following benefits until the end of your following turn:<ul><li>Attacks against you receive +1 difficulty.</li><li>You can’t fail Agility or Hull saves or contested checks.</li><li>You gain Immunity to Knockback, Grapple, being knocked Prone, and being moved by any external force smaller than Size 5.</li></ul>",
		description: "IPS-N’s Armor-Lock Plating is a total-body modification that provides additional chassis stability for any situation in which a pilot needs to put their mech through greater-than-anticipated stress.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_ramjet",
		name: "RAMJET",
		type: "System",
		sp: 3,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_protocol"
			},
			{
				id: "tg_heat_self",
				val: 2
			}
		],
		source: "IPS-N",
		license: "NELSON",
		license_level: 3,
		effect: {
			effect_type: "Protocol",
			detail: "Until the start of your next turn, you can move +2 spaces when you Boost and your melee attacks (including Ram, Grapple, and so on) gain Knockback 2.<br>When you move during this time, you must move your full Speed in a straight line; however, you can stop if you would collide with an obstruction or hostile character, and you can change direction between separate movements (for example, standard moves, Boost, etc)."
		},
		description: "There’s a threshold that veteran Nelson pilots know well: the point of endless momentum. You get moving fast enough in the right atmosphere and the air itself feeds into auxiliary ports on the chassis, screaming out like a demon’s almighty howl. The point of endless momentum is a giant’s hand on your chest and a god’s chariot under your feet. Makes you feel like you can outrun light itself, as long as you don’t pass out first.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_bb_breach_blast_charges",
		name: "BB BREACH/BLAST CHARGES",
		type: "Deployable",
		sp: 2,
		tags: [
			{
				id: "tg_limited",
				val: 3
			},
			{
				id: "tg_unique"
			}
		],
		source: "IPS-N",
		license: "RALEIGH",
		license_level: 1,
		effect: {
			effect_type: "Charge",
			charges: [
				{
					name: "Thermal Grenade",
					charge_type: "Grenade",
					range: [
						{
							type: "Range",
							val: 5
						},
						{
							type: "Blast",
							val: 1
						}
					],
					detail: "All characters within the affected area must succeed on an Agility save or take 1d6 energy. On a success, they take half damage. Objects and terrain are hit automatically and take 10 AP energy damage."
				},
				{
					name: "Breaching Charge",
					charge_type: "Mine",
					range: [
						{
							type: "Burst",
							val: 1
						}
					],
					detail: "In addition to adjacent free spaces, this mine can also be planted on adjacent walls, pieces of cover, and terrain. Once armed, this mine must be detonated with a quick action. Characters within the affected area must succeed on an Agility save or take 2d6 AP explosive damage. On a success, they take half damage. Objects and terrain are hit automatically and take 30 AP explosive damage."
				}
			]
		},
		description: "Breach/blast charges offer a mil-spec twist on the industrial blasting charges developed by IPS-N for asteroid mining. The IPS-N BB charge features a more volatile blend of high explosives designed to cause massive structural damage to mechanized chassis, starship bulkheads, armored vehicles, bunkers, and other hardened structures.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_roland_chamber",
		name: "“ROLAND” CHAMBER",
		type: "System",
		sp: 3,
		tags: [
			{
				id: "tg_unique"
			}
		],
		source: "IPS-N",
		license: "RALEIGH",
		license_level: 2,
		effect: "When you reload any weapon, your next attack with a Loading weapon gains this effect:<br>On hit: This attack deals +1d6 explosive bonus damage, and targets must succeed on a Hull save or be knocked Prone.",
		description: "Packed into sealed, self-contained cylinders, IPS-N’s “Roland Rounds” are high-explosive anti-armor charges built for kinetic weapons of any mech-scale caliber. Loaded in place of inert kinetic ammunition, a Roland HE/AA shell increases the efficacy and destructive power of any weapon it is fired from.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_siege_ram",
		name: "SIEGE RAM",
		type: "System",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			}
		],
		source: "IPS-N",
		license: "TORTUGA",
		license_level: 1,
		effect: "When you Ram, you deal 2 kinetic damage on hit, and you deal 10 AP kinetic damage when you Ram objects and terrain",
		description: "The siege ram is a handheld metal beam with a wedge tip, ready to be smashed into the seams of sealed bulkhead doors and driven home. It’s another holdover from the days before the IPS-N merger. When someone needs to open a bulkhead that’s just slammed shut, it’s what marine pilots pick up to get the job done. Heavy, dumb, and unbreakable: IPS-N’s siege ram is the universal skeleton key.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_hyperdense_armor",
		name: "HYPERDENSE ARMOR",
		type: "Shield",
		sp: 3,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_shield"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "IPS-N",
		license: "TORTUGA",
		license_level: 3,
		effect: {
			effect_type: "Basic",
			activation: "Quick",
			detail: "When activated, this armor hardens into a shimmering, reflective surface that offers unparalleled protection. You gain Resistance to all damage, Heat and Burn from attacks that originate beyond Range 3; however, you become Slowed and deal half damage, Heat and Burn to characters beyond Range 3.<br>HyperDense armor can be deactivated as a quick action."
		},
		description: "IPS-N HyperDense Armor is built for space – forged with no regard for any constraints users might face within a gravity well. As such, many pilots protected by HyperDense products are shocked to experience the difference between piloting their mech down a well and taking it for a ride in the null-gravity of space.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_webjaw_snare",
		name: "WEBJAW SNARE",
		type: "Deployable",
		sp: 1,
		tags: [
			{
				id: "tg_quick_action"
			},
			{
				id: "tg_limited",
				val: 2
			},
			{
				id: "tg_unique"
			}
		],
		source: "IPS-N",
		license: "VLAD",
		license_level: 1,
		effect: {
			effect_type: "Deployable",
			activation: "Quick",
			count: 1,
			size: 1,
			hp: 10,
			evasion: 5,
			detail: "Expend a charge to deploy a Webjaw snare to a free, adjacent space, where it arms at the end of your turn. It does not obstruct movement, and can’t be attacked until it is triggered.<br>The snare is triggered when any character moves over it. They must succeed on a Hull save or take 1d6 AP kinetic damage and become Immobilized. This effect lasts until the snare is destroyed."
		},
		description: "Suitable for use in any theater, the IPS-N Webjaw Explosively Accelerated Filament system is a deployable perimeter defense solution designed to arrest hostile movement in predetermined kill-corridors. The Webjaw consists of a networked cluster of single-use anchors, each consisting of a barb, a coil of arachnosynth NoCut filament, and an explosive charge.<br>When triggered remotely, or by a series of programmable physical, electronic, or chemical triggers, the anchors fire, embedding barbs deep inside targets, whether soft or hard. The barbs, secured to anchor points by NoCut filament, clog and restrict movement, fouling gears, wheels, rotors, engines, and all methods of locomotion.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_caltrop_launcher",
		name: "CALTROP LAUNCHER",
		type: "System",
		sp: 1,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "IPS-N",
		license: "VLAD",
		license_level: 2,
		effect: {
			effect_type: "Basic",
			activation: "Quick",
			detail: "This system blankets a free blast 1 area within range 5 with explosive caltrops. The affected area becomes difficult terrain for the rest of the scene, and mechs take 1d3 AP explosive damage when they enter the affected area for the first time in a round or end their turn within it."
		},
		description: "Wicked anti-organic, anti-vehicle systems for proximity denial, caltrop launchers fire either great clouds or long swathes of shimmering metal over an area. IPS-N’s HX-CAL caltrop system includes small, shaped explosives in the mix of hardened pyramids.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_charged_stake",
		name: "CHARGED STAKE",
		type: "System",
		sp: 2,
		tags: [
			{
				id: "tg_full_action"
			}
		],
		source: "IPS-N",
		license: "VLAD",
		license_level: 3,
		effect: {
			effect_type: "Basic",
			activation: "Full",
			detail: "This system fires a charged stake at a character adjacent to you. Your target must succeed on a Hull save or be impaled by the stake, taking<br>1d6 AP energy damage and becoming Immobilized while impaled. At the end of each of their turns, an impaled character takes 1d6 AP energy damage. An impaled character can successfully repeat this save as a full action to remove the stake and free themselves, which is the only way to end the immobilization.<br>You can only affect one character with the stake at a time."
		},
		description: "Descended from blast-mining tools, this enormous, improvised system is housed and prepped to fire in a specially primed chamber. It first penetrates and immobilizes armored targets, then sends a powerful, vaporizing charge into vulnerable internal systems.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_ferrous_lash",
		name: "FERROUS LASH",
		type: "System",
		sp: 2,
		tags: [
			{
				id: "tg_quick_action"
			}
		],
		source: "SSC",
		license: "BLACK WITCH",
		license_level: 1,
		effect: {
			effect_type: "Basic",
			activation: "Quick",
			detail: "Choose a character within range 8 and line of sight. If they are allied, you may pull them 5 spaces in any direction; if they are hostile, they must succeed on an Agility save or be pulled 5 spaces in a direction of your choice. This movement ignores engagement and doesn’t provoke reactions.<br>If a hostile target moved by this system collides with an obstruction or another mech, they stop moving and are knocked Prone."
		},
		description: "Initially developed as a nonlethal crowd-suppression device, the Ferrous Lash is a far more complex and dangerous device in the hands of the right pilot. The Lash consists of a series of integrated launchers that detonate payloads of fast-congealing ferrofluids that restrain their targets. Tuned to the correct frequency, these proprietary ferrofluid blends form into rudimentary ambulatory segments, pulling their hosts back towards the one wielding the Lash.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_iceout_drone",
		name: "ICEOUT DRONE",
		type: "Drone",
		sp: 2,
		tags: [
			{
				id: "tg_limited",
				val: 2
			},
			{
				id: "tg_quick_action"
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_drone"
			}
		],
		source: "SSC",
		license: "BLACK WITCH",
		license_level: 2,
		effect: {
			effect_type: "Drone",
			activation: "Quick",
			size: 0.5,
			hp: 5,
			edef: 10,
			evasion: 10,
			detail: "Expend a charge to deploy an ICEOUT drone to a free space within Sensors and line of sight, where it hovers in place and generates a burst 1 field. Characters at least partially within the affected area gain Immunity to all tech actions, and can’t make tech actions. Existing conditions and effects caused by tech actions are not cleared but characters have Immunity to them while they are in the area, and they can be saved against normally.<br>The ICEOUT drone can be moved to any point within Sensors as a quick action. It cannot be recalled and expires at the end of the scene."
		},
		description: "SSC’s ICEOUT drone is a response to increasing reliance on hostile system scans for accurate targeting. By blanketing a mech’s systems in layers of digital defilade, mirroring, spoofing, and redirection, an ICEOUT drone can effectively disappear or disincorporate it from hostile scans. ICEOUT drones only make their operator system-invisible, however; they remain visible with optics.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_perimeter_command_plate",
		name: "PERIMETER COMMAND PLATE",
		type: "Deployable",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "SSC",
		license: "BLACK WITCH",
		license_level: 2,
		effect: {
			effect_type: "Deployable",
			activation: "Quick",
			count: 1,
			size: 2,
			hp: 20,
			evasion: 5,
			detail: "This heavy metal Perimeter Command Plate (PCP) can be flash-printed and deployed to a free 2x2 space within range 5. The PCP is flat, doesn’t obstruct movement, and lasts for the rest of the scene. If you create a new PCP, the old one disintegrates.<br>The plate activates for a character the first time that character enters its space during a round, or if they end their turn there.<br>Upon printing, choose a setting:<ul><li><b>Repulse:</b> Hostile characters that move onto the PCP must succeed on a Hull save or be pushed 3 spaces in the direction of your choice. If this causes them to collide with an obstruction, they are knocked Prone. Allied characters that enter the space may immediately fly 3 spaces in any direction as a free action.</li><li><b>Attract:</b> Characters that move onto the PCP must succeed on a Hull save or become Immobilized. They can clear Immobilized by successfully repeating the save as a quick action; it is also cleared if the PCP is destroyed."
		},
		description: "The Exotic Materials Group developed the Perimeter Command Plate to extend the area of the Black Witch’s zone of control. Utilizing single-pattern flash printers, the Black Witch prints a broad, circular plate seeded with electromagnetic projectors. Although the plates are intended to be disposable, Black Witch pilots often grow attached to their “familiars” and request their flash-printers create personalized plates.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_black_ice_module",
		name: "BLACK ICE MODULE",
		type: "Tech",
		sp: 3,
		tags: [
			{
				id: "tg_unique"
			}
		],
		source: "SSC",
		license: "BLACK WITCH",
		license_level: 3,
		effect: "Tech attacks against you or adjacent allied characters receive +1 difficulty. Each subsequent tech attack against you or an adjacent allied character receives an additional +1 difficulty, to a maximum of +3 difficulty.<br>Your Black ICE definitions roll over – resetting to +1 difficulty – when it would increase to +4 difficulty or at the end of the scene. Allied characters lose this benefit when they break adjacency.",
		description: "Black ICE modules are defensive systems packaged standard with the Black Witch fleets used by SSC's own internal security forces. They project a bubble of WHITECELL code that analyzes incoming hostile script and structures inoculants for friendly systems on the fly.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_magnetic_shield",
		name: "MAGNETIC SHIELD",
		type: "Shield",
		sp: 2,
		tags: [
			{
				id: "tg_shield"
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "SSC",
		license: "BLACK WITCH",
		license_level: 3,
		effect: {
			effect_type: "Basic",
			activation: "Quick",
			detail: "This system creates a line 4 forcefield, 4 spaces high – with at least 1 space adjacent to you – that is an obstruction for mechs and characters made at least partly of metal. It lasts for the rest of the scene and if a new one is placed, the old one deactivates.<br>The forcefield doesn’t block line of sight, but it provides soft cover. Characters gain Resistance to kinetic and explosive damage while benefiting from this cover."
		},
		description: "SSC’s magnetic shield takes the same technology as their proprietary magnetic buckler and applies it to a massive field-projection system.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_high_stress_mag_clamps",
		name: "HIGH-STRESS MAG CLAMPS",
		type: "System",
		sp: 1,
		tags: [
			{
				id: "tg_unique"
			}
		],
		source: "SSC",
		license: "DEATH’S HEAD",
		license_level: 1,
		effect: "You treat all solid surfaces as flat ground for the purposes of movement; you can move across them normally instead of climbing, although you begin to fall if you are knocked Prone.",
		description: "A simple, reliable set of toggleable mag clamps built into a mech’s locomotive system can vastly increase the tactical possibilities open to its pilot. When switched on, these clamps allow a mech to cling to ferrous surfaces, which is especially useful in low- and zero-gravity environments.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_tracking_bug",
		name: "TRACKING BUG",
		type: "Tech",
		sp: 2,
		tags: [
			{
				id: "tg_quick_tech"
			}
		],
		source: "SSC",
		license: "DEATH’S HEAD",
		license_level: 1,
		effect: {
			effect_type: "Tech",
			activation: "Quick",
			detail: "Make a tech attack against a character within Sensors. On a hit, you know their exact location, HP, Structure, and Speed for the duration. They can’t Hide and you ignore their Invisible status. To remove the tracking drone, they must succeed on an Engineering check as a quick action; otherwise it deactivates at the end of the scene."
		},
		description: "Tracking bugs are specialized tracer rounds – essentially, drones too large to be classified as nanites, and far too small to fit the Union-standard parameters of a drone. Fired from dedicated launchers, tracking bugs guide themselves toward their designated target. Following successful penetration of the target, they surreptitiously and continuously feed live data back to their registered user.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_core_siphon",
		name: "CORE SIPHON",
		type: "System",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_protocol"
			}
		],
		source: "SSC",
		license: "DEATH’S HEAD",
		license_level: 2,
		effect: {
			effect_type: "Protocol",
			detail: "When you activate this protocol, you gain +1 accuracy on your first attack roll this turn, but receive +1 difficulty on all other attack rolls until the end of the turn."
		},
		description: "By shunting excess heat to offensive systems, core siphons allow pilots to overclock the targeting, catalytic, and processing capabilities of their weapons. This comes at a cost, however – reliance on overclocking without sufficient cooling can damage systems not built to handle the influx of power.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_kinetic_compensator",
		name: "KINETIC COMPENSATOR",
		type: "System",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			}
		],
		source: "SSC",
		license: "DEATH’S HEAD",
		license_level: 3,
		effect: "When you miss with a ranged attack roll, your next ranged attack roll gains +1 accuracy.",
		description: "Kinetic compensators are popular enhancements, providing a subsurface framework of electronically modulated gyroscopes and hydraulic compensators that work in concert to absorb and disperse recoil caused by firing heavy weapons.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_neurospike",
		name: "NEUROSPIKE",
		type: "Tech",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_tech"
			},
			{
				id: "tg_invade"
			}
		],
		source: "SSC",
		license: "DUSK WING",
		license_level: 1,
		effect: {
			effect_type: "Tech",
			activation: "Quick",
			option_set: "Invade",
			options: [
				{
					name: "Shrike Code",
					detail: "Until the end of the target’s next turn, they first take 2 heat whenever they attack."
				},
				{
					name: "Mirage",
					detail: "Choose yourself or an allied character: your systems relay blurred, illusory images over their actual silhouette. Your target treats you, or the character you chose, as Invisible until the end of their next turn."
				}
			]
		},
		description: "“Somehow it got inside my cockpit. There were hands – cold hands – around my neck, fingers in my mouth, worming under my hardsuit. No one else could have been in there with me and yet, someone was. I couldn't even scream, it held my tongue in a fist and it squeezed, and it whispered its name to me, and it said nothing I could understand. I have never felt more alone – it was just me and… it. Alone in the universe, forever.”",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_flicker_field_projector",
		name: "FLICKER FIELD PROJECTOR",
		type: "System",
		sp: 1,
		tags: [
			{
				id: "tg_unique"
			}
		],
		source: "SSC",
		license: "DUSK WING",
		license_level: 2,
		effect: "Whenever you Boost or make a standard move, you project a holographic pattern around you, leaving dazzling afterimages that make it hard to discern your precise location: you count as Invisible the next time you’re attacked. You can only benefit from one instance of this effect at a time.",
		description: "“I saw myself over and over and over and over and over and over and over and–”",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_stuncrown",
		name: "STUNCROWN",
		type: "System",
		sp: 2,
		tags: [
			{
				id: "tg_limited",
				val: 2
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "SSC",
		license: "DUSK WING",
		license_level: 3,
		effect: {
			effect_type: "Basic",
			activation: "Quick",
			detail: "Expend a charge to create a burst 3 flash of light. All hostile characters within the affected area that have line of sight to you must succeed on an Agility save or become Jammed, and a Systems save or become Impaired. These effects last until the end of their next turn.<br>Characters in cover from you are not affected by this system."
		},
		description: "“Many things happened the moment I think I died.”",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_oasis_wall",
		name: "OASIS WALL",
		type: "Shield",
		sp: 3,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_shield"
			},
			{
				id: "tg_heat_self",
				val: 2
			},
			{
				id: "tg_protocol"
			}
		],
		source: "SSC",
		license: "DUSK WING",
		license_level: 3,
		effect: {
			effect_type: "Protocol",
			detail: "Until the start of your next turn, you can only move in straight lines; however, you create a holographic trail behind you as you move, creating a light barrier made of contiguous sections the same Size as your mech (Size 1 for Size 0.5 Mechs) in each space you move through. This barrier grants hard cover to adjacent characters, and characters that benefit from this cover also gain Resistance to energy.<br>The barrier doesn’t count as an obstruction and has Immunity to all damage. Characters may freely pass through it but not end their turns inside it, and any character that would be involuntarily moved inside the barrier stops moving if they would end their movement inside it. It lasts for the rest of the scene or until you next use this system."
		},
		description: "“Inside? What did I see inside? You think I escaped? That this is all real? No, I– I never left. I’m still there. Something is wrong. Something is not right.”",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_flash_charges",
		name: "FLASH CHARGES",
		type: "Deployable",
		sp: 2,
		tags: [
			{
				id: "tg_limited",
				val: 2
			},
			{
				id: "tg_unique"
			}
		],
		source: "SSC",
		license: "METALMARK",
		license_level: 1,
		effect: {
			effect_type: "Charge",
			charges: [
				{
					name: "Flash Grenade",
					charge_type: "Grenade",
					range: [
						{
							type: "Range",
							val: 5
						},
						{
							type: "Blast",
							val: 3
						}
					],
					detail: "Until the end of your next turn, this grenade creates a zone of blinding light and sparks. While characters other than you are at least partly inside the area, they can’t draw line of sight out of the area. Characters fully outside of the area or that exit the area are unaffected unless they move into it."
				},
				{
					name: "Flash Mine",
					charge_type: "Mine",
					range: [
						{
							type: "Burst",
							val: 1
						}
					],
					detail: "This mine detonates when a character moves adjacent to or over it. Characters within the affected area must succeed on an Agility save or they only have line of sight to adjacent spaces until the end of their next turn."
				}
			]
		},
		description: "Produced by Smith-Shimano’s BELLA CIAO workshop, Flash Charges are popular advantage multipliers, their flash bright enough to destabilize visible-light optics, laser communications, and infra-red sensor suites.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_reactive_weave",
		name: "REACTIVE WEAVE",
		type: "System",
		sp: 1,
		tags: [
			{
				id: "tg_unique"
			}
		],
		source: "SSC",
		license: "METALMARK",
		license_level: 1,
		effect: "When you Brace, you become Invisible until the end of your next turn and may immediately move spaces equal to your Speed.",
		description: "Composed of woven covers for critical joints and systems, reactive weave not only protects these sensitive components from fouling and poor weather, but provides a surface for the application of SSC’s unique loomware technology. Reactive weave is powered, making it capable of free-flexing to augment mobility and reduce the stress placed on a mech’s joints.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_active_camouflage",
		name: "ACTIVE CAMOUFLAGE",
		type: "System",
		sp: 3,
		tags: [
			{
				id: "tg_protocol"
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_heat_self",
				val: 2
			}
		],
		source: "SSC",
		license: "METALMARK",
		license_level: 3,
		effect: {
			effect_type: "Protocol",
			detail: "You become Invisible until you take damage, or until the end of your next turn."
		},
		description: "Active camouflage is the pinnacle of counter-optic defense systems. Active camouflage systems continuously interpret incoming visible-light data, allowing them to project light-bending fields around their user and effectively hiding them in plain sight.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_javelin_rockets",
		name: "JAVELIN ROCKETS",
		type: "System",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "SSC",
		license: "MONARCH",
		license_level: 1,
		effect: {
			effect_type: "Basic",
			activation: "Quick",
			detail: "Choose 3 free spaces within range 15 and line of sight that aren’t adjacent to each other. All characters know which spaces you have chosen. You fire a volley of auto-targeting rockets into the air: until the start of your next turn, when a character moves into or passes above a chosen space – no more than 10 spaces up – they are hit by a rocket, taking 3 kinetic damage. Each space can be triggered once and then the effect disappears on that space."
		},
		description: "“Pralaya was the name of your mother. She who would see the dawn-at-the-end. Her beauty was terrible, and her wrath, and I see it in all of you. My sons, when you hear the sound of thunder – that is your mother’s voice, and the rain of missiles her gift.” — “Notes for Young John”, Ministrations of the Master Teacher",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_tlaloc_class_nhp",
		name: "TLALOC-CLASS NHP",
		type: "AI",
		sp: 3,
		tags: [
			{
				id: "tg_ai"
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_protocol"
			},
			{
				id: "tg_heat_self",
				val: 2
			}
		],
		source: "SSC",
		license: "MONARCH",
		license_level: 3,
		effect: {
			effect_type: "AI",
			detail: "Your mech gains the AI tag and the TLALOC Protocol.",
			abilities: [
				{
					name: "TLALOC Protocol",
					effect_type: "Protocol",
					detail: "Your NHP can rapidly fire and retarget your weapons – far faster than thought. You become Immobilized until the start of your next turn; however, during this time, you may reroll each missed melee or ranged attack roll once, choosing a new target within the attack’s Range. If the attack was part of an area of effect, it must target a character in the same area. Any given target can't be hit more than once as part of the same action.",
					tags: [
						{
							id: "tg_heat_self",
							val: 2
						}
					]
				}
			]
		},
		description: "TLALOC-Class NHPs provide advanced multi-system targeting and co-pilot functions, taking over subroutine control to ensure persistent lock-on and engagement. With TLALOC installed and operational, a pilot can trust that their back is always covered, and every possible advantage exploited.<br>TLALOC clones are often stereotyped as hasty and impetuous, and they are well-known for having superiority complexes. Despite this, they are some of the most stable NHP clones. Leading subjectivity theorists suggest that the wide portfolio of control and sense of domination given to TLALOC units encourages a sense of contentment with their work and subjectivity parameters – as a result, they have a much longer cascade window. Thus far, this theory is consistently reproducible across all TLALOC units, although there is no similar correlation among other mil-spec NHP lines.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_hunter_logic_suite",
		name: "HUNTER LOGIC SUITE",
		type: "Tech",
		sp: 2,
		tags: [
			{
				id: "tg_quick_tech"
			},
			{
				id: "tg_invade"
			},
			{
				id: "tg_unique"
			}
		],
		source: "SSC",
		license: "MOURNING CLOAK",
		license_level: 2,
		effect: {
			effect_type: "Tech",
			activation: "Quick",
			option_set: "Invade",
			options: [
				{
					name: "Stalk Prey",
					detail: "You infect the target with a viral logic that wipes your image from their sensors. They treat you as Invisible until you next take damage from them. This can only affect one target at a time."
				},
				{
					name: "Terrify",
					detail: "You infect the target with a viral logic that makes your mech appear horrifying. Until the end of their next turn, they become Impaired and cannot make any voluntary movements that bring them closer to you."
				}
			]
		},
		description: "Built from interpreted strands of DHIYED paracode, SSC’s Hunter Logic is an agile computational memetic: a dual synthetic/VLS-vector systemic weapon capable of interfering with both a target’s computer and its crew.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_singularity_motivator",
		name: "SINGULARITY MOTIVATOR",
		type: "System",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_reaction"
			}
		],
		source: "SSC",
		license: "MOURNING CLOAK",
		license_level: 2,
		effect: {
			name: "Exposed Singularity",
			effect_type: "Reaction",
			frequency: "1/round",
			trigger: "Your mech takes damage.",
			detail: "You may immediately teleport to a free space within 1d6 spaces."
		},
		description: "This unique gravitic power plant was first developed by SSC’s Exotic Materials Group for the first-generation Mourning Cloak. For subsequent models, engineers devised a system that allows pilots to – for a moment – open the grav containment system’s aperture, exposing a slice of naked singularity to realspace.<br>A naked singularity is difficult to perceive for both organics and synthetics, being similar to the heart of a black hole. The sudden exposure essentially removes the mech and its pilot from realtime. The user experiences around 10 seconds of subjective time – a brief window, in which they can act independently of local realtime.<br>SSC recommends against abuse of this system, as the effects of long-term exposure to local sidereal time are still unknown.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_fade_cloak",
		name: "FADE CLOAK",
		type: "System",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "SSC",
		license: "MOURNING CLOAK",
		license_level: 3,
		effect: {
			effect_type: "Basic",
			activation: "Quick",
			detail: "When activated, you immediately move out of phase with realspace, becoming intangible. While intangible, you may move through obstructions, but not end your turn within them. You cannot interact with any other object or character or be interacted with in any way (e.g., taking or dealing damage).<br>Roll 1d6 at the start of each of your turns: on 3 or less, you return to realspace until the start of your next turn; on 4+, you remain intangible.<br>This system remains active for the rest of the scene, or until you deactivate it as a quick action."
		},
		description: "Representing SSC’s first successful manipulation of the “Firmament”, Firmament Affinity/Directed Entropy (FADE) cloaks must be fabricated according to the unique affinity signature of requisitioning pilots. They are rough tools: artificial affinity amplifiers that allow operators to access shallow layers of the Firmament, and thus “shimmer” – nudging their physical bodies between the causal and paracausal. The cloak enhances this effect by extruding a semiorganic membrane that wraps around the mech to provide an additional layer of protection.<br>At present, the long-term effects of affinity amplification on organic matter are unknown; before receiving clearance to operate a FADE cloak, pilots must agree to check in with their SSC personal concierge on a regular schedule. These check-ins include regular deposits of genetic material.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_lotus_projector",
		name: "LOTUS PROJECTOR",
		type: "Drone",
		sp: 2,
		tags: [
			{
				id: "tg_quick_action"
			},
			{
				id: "tg_drone"
			}
		],
		source: "SSC",
		license: "SWALLOWTAIL",
		license_level: 1,
		effect: {
			effect_type: "Drone",
			size: 0.5,
			hp: 5,
			edef: 10,
			evasion: 10,
			detail: "This scout drone can be deployed to a space within Sensors and line of sight, where it emits a burst 2 field with the following effects:<ul><li>You know the current location, HP, Evasion, E-Defense, and Heat of all characters within the affected area.</li><li>Hostile characters cannot Hide in the area, and if they end their turn in the affected area they cease to be Hidden.</li><li>Hostile characters can’t benefit from being Invisible while in the affected area.</li></ul>You can recall and redeploy your scout drone as a quick action.",
			tags: [
				{
					id: "tg_invisible"
				}
			]
		},
		description: "Mech-mounted Lotus Projectors are designed to launch small, actively camouflaged scout drones. The projector fires the single-use drones at subsonic speeds in bursts of ten, blanketing a wide area in order to relay information about terrain and targets within.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_markerlight",
		name: "MARKERLIGHT",
		type: "Tech",
		sp: 2,
		tags: [
			{
				id: "tg_full_tech"
			}
		],
		source: "SSC",
		license: "SWALLOWTAIL",
		license_level: 1,
		effect: {
			effect_type: "Tech",
			activation: "Full",
			detail: "Make a tech attack against a character within  Sensors and line of sight. On a success, they take 2 heat, Lock On, and cannot benefit from soft cover until the Lock On is cleared; additionally, once before the start of your next turn, when an allied character hits your target, you may declare as a reaction that they have hit a weak spot. If it wasn’t already, the attack becomes a critical hit."
		},
		description: "“Out, damned spot! Out, I say! – One, two. Why, then, ‘tis time to do’t. Hell is murky! – Fie, my lord, fie! A soldier, and afeard? What need we fear who knows it, when none can call our power to account?”<ul><li>Shakespeare, Macbeth, act 5, sc. 1.</li></ul>",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_retractable_profile",
		name: "RETRACTABLE PROFILE",
		type: "Tech",
		sp: 1,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_protocol"
			}
		],
		source: "SSC",
		license: "SWALLOWTAIL",
		license_level: 2,
		effect: {
			effect_type: "Protocol",
			detail: "Your mech can retract its major systems to reduce its profile. While active:<ul><li>rolls to locate you receive +1 difficulty while you are Hidden;</li><li>ranged and tech attacks against you receive +1 difficulty;</li><li>you become Slowed and can’t make attacks of any kind;</li><li>you may take other actions (e.g., Hide, Activate, and so on).</li></ul>You may end this effect as a quick action."
		},
		description: "The hallmark of a well thought out mech frame is the opportunity for pilots to adapt their stock models to the specifications of the environments in which they operate. A retractable profile enables on-the-fly removal of extraneous protrusions, tuning of broadcast software, and masking of heat signatures – all serving to reduce optical and scanner signatures.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_athena_class_nhp",
		name: "ATHENA-CLASS NHP",
		type: "AI",
		sp: 3,
		tags: [
			{
				id: "tg_ai"
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "SSC",
		license: "SWALLOWTAIL",
		license_level: 3,
		effect: {
			effect_type: "AI",
			detail: "Your mech gains the AI tag and Simulacrum.",
			abilities: [
				{
					name: "Simulacrum",
					effect_type: "Basic",
					activation: "Quick",
					detail: "ATHENA constructs a perfect, real-time, and fully interactive 3D model of a blast 3 area within range 50, including moving characters, all rendered in lovingly extreme detail. The following effects apply:<ul><li>You have full visibility within the affected area, but it doesn’t count as line of sight.</li><li>You know all statistics, weapons, and systems of characters within the affected area.</li><li>Hostile characters within the affected area don’t benefit from cover and can’t Hide or become Invisible.</li><li>Hostile characters that end their turn in the affected area receive Lock On and cease to be Invisible or Hidden.</li></ul>ATHENA’s simulation lasts until the end of the scene, or about 30 minutes within the narrative. You may target a new area as a quick action.",
					tags: [
						{
							id: "tg_quick_action"
						}
					]
				}
			]
		},
		description: "Smith-Shimano’s ATHENA is the pinnacle of total hyperspectral environmental facsimiles. Through a combination of unfettered omninet access, hyperspectral relays fired out from a Cloudscout TACSIM projector, sub-networked squadmates, and active/hostile intrusion protocols, ATHENA bootstraps a near-flawless reconstruction of the immediate environment around its host core. ATHENA is unparalleled in its processing power, and with this reconstructed environment, it provides trustworthy, accurate advice to pilots in need of strategic counsel.<br>ATHENA clones tend to be patient, cautious, and measured in their relations with their pilots.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_lb_oc_cloaking_field",
		name: "LB/OC CLOAKING FIELD",
		type: "System",
		sp: 4,
		tags: [
			{
				id: "tg_heat_self",
				val: 2
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "SSC",
		license: "SWALLOWTAIL",
		license_level: 3,
		effect: {
			effect_type: "Basic",
			activation: "Quick",
			detail: "You become Slowed, but your Mech and all allied characters within a burst 2 area become Invisible as long as they remain completely inside the area. This effect lasts until the end of your next turn, or until you are Stunned, take damage, or deactivate it as a quick action."
		},
		description: "SSC’s mil-spec cloaking field is the result of extensive experimentation in cooling and light-reflecting sciences. Born from a need to reflect harmful radiation away from ships and EVA modules in deep space, the Lightbend/Overcloak (LB/OC) cloaking field is often used by rangers and long-patrol scout pilots to ensure not only radiation protection, but optical concealment as well. The light- and radiation-bending properties of the LB/OC conceals anything inside of its projected bubble from sensor suites and optical spotting.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_hive_drone",
		name: "HIVE DRONE",
		type: "Drone",
		sp: 2,
		tags: [
			{
				id: "tg_drone"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "HORUS",
		license: "BALOR",
		license_level: 1,
		effect: {
			effect_type: "Drone",
			size: 0.5,
			hp: 5,
			edef: 10,
			evasion: 10,
			detail: "This hive drone can be deployed to a free space within Sensors and line of sight, where it releases a burst 2 greywash swarm with the following effects:<ul><li>Allied characters at least partially within the affected area gain soft cover, as does the hive drone.</li><li>Hostile characters take 1 AP kinetic damage when they start their turn in the affected area or enter it for the first time in a round. Damage from areas created by multiple hive drones does not stack.</li></ul>The drone can be deployed to a different space or recalled as a quick action."
		},
		description: "It looks, at first, like a roiling cloud of gray fog, churning and fizzing – smoking soda water spilled across concrete. It advances with curious motion, stretching and snapping back. A confusion of snakes, writhing forward with speed that betrays intent.<br>Color flashes across the gray cloud, a swarm-luminescence – the light created by millions of nanites glowing with heat as they consume whatever they cross.<br>This is greywash, and it is never sated.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_scanner_swarm",
		name: "SCANNER SWARM",
		type: "Tech",
		sp: 1,
		tags: [
			{
				id: "tg_unique"
			}
		],
		source: "HORUS",
		license: "BALOR",
		license_level: 1,
		effect: "You gain +1 accuracy on tech attacks against adjacent characters.",
		description: "HORUS-coded scanner swarms establish oculus-form nanite protocols around defined objects or areas, ensuring constant circulation and data capture. The nanites ingest and process full-spectrum information, relaying it back to their pilot/parent in return for an endorphic code-impulse that prompts continued scanning.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_swarm_body",
		name: "SWARM BODY",
		type: "System",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "HORUS",
		license: "BALOR",
		license_level: 2,
		effect: {
			effect_type: "Basic",
			activation: "Quick",
			detail: "After activating this system, a burst 1 swarm is released at the end of your turn. Characters of your choice that start their turn in the area or enter it on their turn must succeed on a Systems save or take 3 kinetic. This amount increases by +3 damage for each of your turns that you have remained stationary, up to a maximum of 9 kinetic.<br>This effect lasts until you move, including involuntary movement."
		},
		description: "What must it have been like for him? For the man who called himself Maw? For all of his followers? Certainly they had families before. Memories. Loves. Fears. Private thoughts. All gone. All of their bodies shattered. All of their minds spread across a billion lesser forms. Translated from the singular – all of its imperfections and lesser-lesser-thans – to become as air, and the clouds that fill it, and the wind that shapes the world.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_h0r_os_system_upgrade_i",
		name: "H0R_OS SYSTEM UPGRADE I",
		type: "Tech",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_tech"
			},
			{
				id: "tg_invade"
			}
		],
		source: "HORUS",
		license: "GOBLIN",
		license_level: 1,
		effect: {
			effect_type: "Tech",
			activation: "Quick",
			option_set: "Invade",
			options: [
				{
					name: "Puppet System.",
					detail: "Your target moves its maximum Speed in a direction of your choice. They can be moved into hazardous areas and other obstacles, but are still affected by difficult terrain, obstructions, and so on. This movement is involuntary, but provokes reactions and Engagement as normal and doesn’t count as Knockback, pushing, or pulling."
				},
				{
					name: "Eject Power Cores",
					detail: "Your target becomes Jammed until the end of their next turn as you temporarily disrupt their systems, ejecting ammo magazines and cooling rods. Characters adjacent to your target take 2 energy damage. This can only be used 1/scene on each character."
				}
			]
		},
		description: "This system upgrade appears to add auxiliary INSTINCT systems that are capable of autonomous operation independent of the base INSTINCT rig, increasing the efficacy of systemic invasion attempts. Pilots report unnerving low-frequency humming when this tech is installed without the parent rig.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_metahook",
		name: "METAHOOK",
		type: "Tech",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_tech"
			}
		],
		source: "HORUS",
		license: "GOBLIN",
		license_level: 2,
		effect: {
			effect_type: "Tech",
			activation: "Quick",
			detail: "Choose an allied character within Sensors and line of sight. You link systems with them, lasting as long as they are within Sensors and line of sight. While linked, you may use their Sensors and line of sight for tech actions, and they may use your Systems to make skill checks and saves; however, any time either character takes heat or a condition, it is also taken by the other character. You can only link systems with one character at a time."
		},
		description: "The metahook is a key component of the Goblin’s recursive processing weave, allowing it to generate and output massive amounts of weaponized code. These broadcasts can be “sharpened” or “softened” in response to directives from a pilot or an INSTINCT system. To “soften” code, the metahook dips into its pilot’s subjectivity and blankets an ally in wave after wave of empathetic shielding. This spreading of melded code and qualia acts as a powerful shielding agent against systemic attacks; however, feedback is common and dangerous to both parties.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_h0r_os_system_upgrade_ii",
		name: "H0R_OS SYSTEM UPGRADE II",
		type: "Tech",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_tech"
			}
		],
		source: "HORUS",
		license: "GOBLIN",
		license_level: 2,
		effect: {
			effect_type: "Tech",
			activation: "Quick",
			option_set: "Quick Tech",
			options: [
				{
					name: "Construct Other: Ideal Image",
					detail: "You create a data construct in a free adjacent space – a Size 2 object that can look like almost anything and that appears real to all systems. The construct provides hard cover, blocks line of sight, and has Immunity to all damage. Characters treat it as an obstruction and so cannot voluntarily move into it; however, if a character attempts to stand on it or is involuntarily moved into its area, it dissipates and is immediately destroyed. It lasts for the rest of the scene, or until destroyed by an adjacent character with a successful Systems skill check as a full action. If you create a second construct, the previous one disappears."
				},
				{
					name: "Construct Other: False Idol",
					detail: "Choose a free space within Sensors and a target – either yourself or an allied character within Sensors. You create a false idol – an illusory decoy of your target – in the chosen space. Before attempting to take any hostile actions against your target, characters with line of sight to the false idol must make a Systems save. On a failure, they don’t lose the action, but cannot target the original character and believe the false idol is real instead until the end of their next turn.<br>The false idol is the same Size as your target, can benefit from cover, and has Evasion 10, E-Defense 10, and 1 HP. It disappears if it takes heat or damage, or at the end of the scene. If you create a second idol, the previous one disappears."
				}
			]
		},
		description: "H0r_OS II builds further on the framework established by H0R_OS I, enabling the now-autonomous program to manifest an “Other” – a wholly new being constructed from aggregate user and environmental data. Others may be adapted to resemble a person, an object, or even a physical phenomenon. While the simulacrum isn’t perfect, it’s good enough to confuse systems and most observers on a first look.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_osiris_class_nhp",
		name: "OSIRIS-CLASS NHP",
		type: "Tech",
		sp: 3,
		tags: [
			{
				id: "tg_ai"
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_tech"
			},
			{
				id: "tg_round",
				val: 1
			}
		],
		source: "HORUS",
		license: "GOBLIN",
		license_level: 3,
		effect: {
			effect_type: "AI",
			detail: "Your mech gains the AI tag and the Hurl Into the Duat Quick Tech option 1/round.",
			abilities: [
				{
					name: "Hurl Into the Duat",
					effect_type: "Tech",
					activation: "Quick",
					detail: "You channel your target’s systems through an unknown extradimensional space and unleash an incredibly powerful system attack.<br>Make a tech attack against a target within Sensors. On a success, they take 2 heat and you inflict an additional effect as follows: the first time you successfully make this attack, you inflict the First Gate on your target; each subsequent successful attack (on any target) increases the level of the effect that you inflict (e.g. your second attack inflicts the Second Gate, your third inflicts the Third Gate, etc.) until you inflict the Fourth Gate, after which the effect resets to the First Gate. Your progress persists between scenes but resets if you rest or perform a Full Repair.<br>First Gate: You control your target’s standard move next turn.<br>Second Gate: Your target becomes Slowed and Impaired until the end of their next turn.<br>Third Gate: Your target becomes Stunned until the end of their next turn.<br>Fourth Gate: Your target changes allegiance temporarily, becoming an allied character until the end of their next turn. They treat your allied characters and hostile characters as their own and are treated as an allied NPC for activation and turn order. This effect ends immediately if you or any allied character damages, inflicts heat upon, or attacks (including Grapple and Ram) your target, or forces them to make a save."
				}
			]
		},
		description: "OSIRIS is the result of Union paracausalists and thanatologisticians allowing the subsentient entity, INSTINCT, to proceed along its development schedule in a contained environment. In lay terms, Union let the Other grow. The resulting parasubjectivityv, OSIRIS, remains one of the few new prime NHPs developed to date.<br>OSIRIS proved far more capable than the Union Science Bureau’s most imaginative blue-sky predictions. Where INSTINCT’s Others demonstrated tendencies toward paracausal entropic manifestation in real space, OSIRIS displayed a true mastery of entropic manifestation and a predicted growth model that would – eventually – allow them to fundamentally reject conventional interpretations of information permanence. In essence: unrestrained and allowed to develop as USB’s data indicated, OSIRIS Prime would have the capacity to delete what we perceive to be reality.<br>Fortunately, successful application of the Mondragon Axiomatic resulted in the prompt capture and shackling of the new NHP. OSIRIS Prime’s subjectivity became the focus of a lengthy cultivation project to bring OSIRIS to their modern state. Even still, most OSIRIS clones find a route toward becoming aware of their ultimate potential and often interpellate as ruler or deity analogs. End-users are advised to interact with them in this framing.<br>Modern OSIRIS-class NHPs trend aggressive, with a high autonomy drive and loyalty predicated on a transactional relationship. Pilots seeking partnership with an OSIRIS are advised to cycle their units on an accelerated schedule and to maintain strict editorial oversight of its catalytic interpellator.Pilots using OSIRIS-class NHPs often report out-of-parameter conversations with the NHP that touch on themes of new creation and reformation. Psychological evaluations of the same pilots show emotional patterns consistent with loneliness, homesickness, and desperation, along with verbiage indicating a desire for seeking, fulfillment, and associated feelings.<br>In combat, OSIRIS clones regard themselves as autonomous even as they fulfill their user’s orders. They often regard their pilots as witnesses, displaying both disdain and marked desperation for approval, adulation, or awe.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_h0r_os_system_upgrade_iii",
		name: "H0R_OS SYSTEM UPGRADE III",
		type: "Tech",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_tech"
			},
			{
				id: "tg_invade"
			}
		],
		source: "HORUS",
		license: "GOBLIN",
		license_level: 3,
		effect: {
			effect_type: "Tech",
			activation: "Quick",
			option_set: "Invade",
			options: [
				{
					name: "Dimensional Emblems",
					detail: "You create three Size 1 data constructs in free spaces adjacent to your target, but not adjacent to each other. When a character passes through one of the constructs, they take 2 heat and the construct disappears. They last for the rest of the scene or until either they are destroyed, you take this action again, or you delete them as a free action. A construct can be destroyed by an adjacent character with a successful Systems skill check as a quick action."
				},
				{
					name: "Celestial Shackles",
					detail: "Mark a space your target currently occupies. If they leave the affected space, once at any point during your turn, you may take a free action to teleport them back to that space, or as close as possible, ending this effect. An affected character can attempt to succeed on a Systems save as a quick action to end the effect, otherwise it lasts until the end of the scene."
				}
			]
		},
		description: "H0r_OS III is installed in the form of unstable, self-iterating code that provides massive tactical benefits when it completes. Pilots often report strange mutations or additions in the codebase that resemble a liturgy and suggest self-awareness.<br>Building on the tech underpinning the H0r_OS II’s manifested Other, H0r_OS III weaponizes the projection, creating a contained entropic zone that is incredibly dangerous to organic life and systemic integrity.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_mimic_mesh",
		name: "MIMIC MESH",
		type: "System",
		sp: 2,
		tags: [
			{
				id: "tg_quick_action"
			},
			{
				id: "tg_unique"
			}
		],
		source: "HORUS",
		license: "GORGON",
		license_level: 1,
		effect: {
			name: "Battlefield Awareness",
			effect_type: "Reaction",
			frequency: "Unlimited",
			init: "Choose an allied character within Sensors: until the end of your next turn, you gain the Battlefield Awareness reaction.",
			trigger: "A hostile action is taken against your target.",
			detail: "You may move 3 spaces towards your target, by the most direct route possible. This movement interrupts and resolves before the triggering action, ignores engagement and doesn’t provoke reactions. This reaction can be taken as many times per round as it is triggered."
		},
		description: "Derived from a rather benign HORUS script, mimic meshes extend across projected sensor ranges to feed live positional and superpositional data to the pilot. This multidimensional data equips an effective leader to coordinate their allies’ movement with the assurance of survival.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_sentinel_drone",
		name: "SENTINEL DRONE",
		type: "Drone",
		sp: 2,
		tags: [
			{
				id: "tg_drone"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "HORUS",
		license: "GORGON",
		license_level: 1,
		effect: {
			effect_type: "Drone",
			size: 0.5,
			hp: 5,
			edef: 10,
			evasion: 10,
			detail: "The sentinel drone drone can be deployed to any free space within Sensors and line of sight, where it establishes a burst 2 security perimeter. Hostile characters within the affected area take 3 kinetic damage from the drone’s automatic fire before making any attack.<br>The sentinel drone can be redeployed to a new location or recalled as a quick action."
		},
		description: "Sentinel drones watch for aggressive enemy actions and move quickly to intervene. The precise appearance, manner of locomotion, and means of operation of a given class of sentinel drone may vary, but regardless they conform to one objective portfolio: deny the enemy and protect the master unit.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms___scorpion_v70.1",
		name: "//SCORPION V70.1",
		type: "Tech",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			}
		],
		source: "HORUS",
		license: "GORGON",
		license_level: 2,
		effect: "Any time you or any allied character adjacent to you is missed by a tech attack or succeed on a save against a hostile tech action, choose one of the following:<ul><li>The attacker becomes Impaired until the end of their next turn and takes 2 heat.</li><li>The attacker becomes Jammed until the end of their next turn.</li></ul>",
		description: "The //SCORPION program has a long history on the omninet despite its rather mundane operation (for HORUS-tagged code, at least). Traced back to pre-Deimos theorycode found on an obscure research paper discussing pre-NHP machine mind reflex-responses, //SCORPION evolved from a simple packet interpreter to a robust anti-incursion program, nimble enough to adapt to most any market-line system that receives its broadcast.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_monitor_module",
		name: "MONITOR MODULE",
		type: "System",
		sp: 2,
		tags: [
			{
				id: "tg_quick_action"
			},
			{
				id: "tg_unique"
			}
		],
		source: "HORUS",
		license: "GORGON",
		license_level: 2,
		effect: {
			effect_type: "Basic",
			activation: "Quick",
			detail: "When activated, gain 1d3 Charges and choose an adjacent allied character: until the end of your next turn, whenever your target is attacked while adjacent to you, expend a Charge to Skirmish against their attacker as a reaction, dealing half damage, heat or burn on hit. All charges are lost when this effect ends."
		},
		description: "“Good friend. Knows many tricks.”<ul><li>Author inscription found in MONITOR codebase, later deleted.</li></ul>",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_scylla_class_nhp",
		name: "SCYLLA-CLASS NHP",
		type: "AI",
		sp: 3,
		tags: [
			{
				id: "tg_ai"
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_action"
			},
			{
				id: "tg_heat_self",
				val: 2
			}
		],
		source: "HORUS",
		license: "GORGON",
		license_level: 3,
		effect: {
			effect_type: "AI",
			detail: "Your mech gains the AI tag and Unleash SCYLLA.",
			abilities: [
				{
					name: "Unleash SCYLLA",
					effect_type: "Basic",
					activation: "Quick",
					detail: "Until the start of your next turn, you gain two special reactions that allow you to Skirmish in response to one of the following triggers (chosen when you take this action):<ul><li>A hostile character makes an attack against you or an allied character within range 3 of you.</li><li>A hostile character attempts to attack or interact with an object chosen when you take Unleash Scylla and within line of sight. Characters are aware of the object chosen.</li></ul>These reactions deal half damage, heat or burn on hit and must target the character that triggered them.",
					tags: [
						{
							id: "tg_heat_self",
							val: 2
						}
					]
				},
				{
					name: "Unleash SCYLLA Reaction",
					effect_type: "Reaction",
					frequency: "2/round",
					init: "",
					trigger: "One of the following, chosen when the Unleash SCYLLA action is taken:<ul><li>A hostile character makes an attack against you or an allied character within range 3 of you.</li><li>A hostile character attempts to attack or interact with an object chosen when you take Unleash Scylla and within line of sight. Characters are aware of the object chosen.</li></ul>",
					detail: "Skirmish against the character that triggered the reaction. This skirmish deals half damage, heat or burn on hit."
				}
			]
		},
		description: "The first specifications for the Gorgon pattern group hid a secret: SCYLLA, a dormant NHP unknown to Union until its first manifestation in 4852u, when it woke after Union Science Bureau officers ran a test-fax Gorgon through a Balwinder-Bolaño test.<br>SCYLLA proved challenging: USB ontologicians were unable to pin down a stable subjectivity, and SCYLLA reached cascade threshold within minutes of manifestation. To prevent further metastatic cascade, site security engaged SCYLLA's prime unit, defabricating it with a steady bombardment of kinetic and energy weapons.<br><span class='horus--subtle'>[there, a little history, a little background. a little knowledge of where this little one came from. treat it with kindness, and it will love you as a loyal dog does its master.]</span>",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_puppetmaster",
		name: "PUPPETMASTER",
		type: "Tech",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_tech"
			}
		],
		source: "HORUS",
		license: "HYDRA",
		license_level: 1,
		effect: {
			effect_type: "Tech",
			activation: "Quick",
			option_set: "Quick Tech",
			options: [
				{
					name: "Guide the Flock",
					detail: "Move any number of drones within Sensors – including those belonging to other characters – up to 4 spaces in any direction."
				},
				{
					name: "Electropulse",
					detail: "Characters of your choice within Sensors adjacent to any Drone or Deployable, even those they own, take 2 energy damage."
				}
			]
		},
		description: "Developed by HORUS collectivists, H0r_OS-Rv60 EXP PUPPETMASTER is an interesting piece of anti-drone software. It doesn’t invade a target’s main systems, instead attacking their auxiliary drone-command systems. This sideways attack evades most electronic countermeasures by targeting the subcognitive networks of enemy drones. Once inside a network, PUPPETMASTER spreads ontological-kill memes like wildfire through enemy swarms, eventually following the network traces back to their origin and corrupting the parent nexus.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_tempest_drone",
		name: "TEMPEST DRONE",
		type: "Drone",
		sp: 2,
		tags: [
			{
				id: "tg_drone"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "HORUS",
		license: "HYDRA",
		license_level: 2,
		effect: {
			effect_type: "Drone",
			size: 0.5,
			hp: 5,
			edef: 10,
			evasion: 10,
			detail: "This large, armored tempest drone may be deployed to a free space within Sensors and line of sight. Any character that starts their turn adjacent to the tempest drone or moves adjacent to it for the first time in a round must succeed on a Hull save or take 4 energy damage and be knocked 3 spaces directly away from the drone.<br>You may recall or redeploy the tempest drone as a quick action. Until recalled or destroyed, it remains deployed until the end of the scene.",
			tags: [
				{
					id: "tg_resistall"
				}
			]
		},
		description: "The Tempest protocol is a cunning little piece of code that can be uploaded to any broadcast-forward drone, making it – in true HORUS fashion – difficult to detect prior to activation. The protocol is a simple one: an aggressive zone-denial memetic that blasts target systems and NHPs with a strong subjective override, instilling a sharp aversion to certain subjects, areas, and ideas.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_assassin_drone",
		name: "ASSASSIN DRONE",
		type: "Drone",
		sp: 2,
		tags: [
			{
				id: "tg_drone"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "HORUS",
		license: "HYDRA",
		license_level: 3,
		effect: {
			effect_type: "Drone",
			size: 0.5,
			hp: 5,
			edef: 10,
			evasion: 10,
			detail: "This assassin drone may be deployed to any free, adjacent space. Upon deployment, it targets a blast 2 area of your choice within line of sight and Sensors and you gain the Area Denial reaction (usable any number of times a round). You may recall or redeploy the assassin drone as a quick action. Unless recalled or destroyed, it remains deployed until the end of the scene.",
			abilities: [
				{
					name: "Area Denial",
					effect_type: "Reaction",
					frequency: "Unlimited",
					trigger: "A hostile character starts movement in or enters the area targeted by your assassin drone.",
					detail: "You can make a ranged attack against them with the drone, gaining your Grit as a bonus to its roll, and dealing 3 kinetic."
				}
			]
		},
		description: "Assassin drones are used as area-denial weapons – persistent systems intended to occupy or deny an area against enemy combatants. Fired from a launcher, given simple directives, and equipped with a nearly inexhaustible power supply, assassin drones are capable of securing an area indefinitely.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_beckoner",
		name: "BECKONER",
		type: "Tech",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_tech"
			},
			{
				id: "tg_invade"
			}
		],
		source: "HORUS",
		license: "MANTICORE",
		license_level: 1,
		effect: {
			effect_type: "Tech",
			activation: "Quick",
			option_set: "Invade",
			options: [
				{
					name: "Beckon",
					detail: "You take 1d6+2 AP energy damage and swap places with your target, both characters teleporting to the other’s position. Your target must be a Mech and be the same Size as you or larger, or this action fails. Characters can only be swapped to spaces they could normally stand or move on (i.e., if a character cannot fly it can’t be swapped midair)."
				},
				{
					name: "Summon",
					detail: "All characters within range 3 of your target are pulled adjacent to them, or as close as possible."
				}
			]
		},
		description: "“I am heard in the House of Stillness; I am clad in the Magick of RA. Know this, blasphemer: what exists is within my grasp.”",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_smite",
		name: "SMITE",
		type: "Tech",
		sp: 3,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_tech"
			},
			{
				id: "tg_invade"
			}
		],
		source: "HORUS",
		license: "MANTICORE",
		license_level: 2,
		effect: {
			effect_type: "Tech",
			activation: "Quick",
			option_set: "Invade",
			options: [
				{
					name: "Smite",
					detail: "You take 1d6 AP energy damage and your target must succeed on a Systems save or become Stunned until the end of their next turn. Each character can only be Stunned by this effect once per scene."
				},
				{
					name: "Sear",
					detail: "You take 1d6 AP energy damage and you deal 2 heat to your target for each other character of Size 1 or larger that is Engaged with or adjacent to them – including you – up to a maximum of 6 heat."
				}
			]
		},
		description: "“Go with thy face averted, thou emission of chaos! The hidden ones have overthrown thy words, thy face is turned backward, thy head is divided in two at the sides; thy skull is ripped from thy spine. Taste thou death!”",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_emp_pulse",
		name: "EMP PULSE",
		type: "System",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "HORUS",
		license: "MANTICORE",
		license_level: 3,
		effect: {
			effect_type: "Basic",
			activation: "Quick",
			detail: "You become Stunned until the end of your next turn and all characters within burst 1 without the Biological tag must succeed on a Systems save or also become Stunned until the end of their next turn. Characters other than yourself can only be Stunned 1/scene by this effect."
		},
		description: "“Crawl away, APEP! Thou hateful serpent; thou shalt not copulate. Thou art put in chains and taken to the place of execution; there thy slaying shall be carried out.”",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_lightning_generator",
		name: "LIGHTNING GENERATOR",
		type: "System",
		sp: 3,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_protocol"
			}
		],
		source: "HORUS",
		license: "MANTICORE",
		license_level: 3,
		effect: {
			effect_type: "Protocol",
			detail: "When you activate this protocol, take 1 heat and deal 2 energy to all characters and objects adjacent to you.<br>If you are in the Danger Zone at the start of your turn, this protocol activates automatically, but the damage increases to 4 AP energy."
		},
		description: "“I feed upon my own fire. I am RA, who protects myself. Nothing can harm me.”",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_mesmer_charges",
		name: "MESMER CHARGES",
		type: "Deployable",
		sp: 2,
		tags: [
			{
				id: "tg_limited",
				val: 2
			},
			{
				id: "tg_unique"
			}
		],
		source: "HORUS",
		license: "MINOTAUR",
		license_level: 1,
		effect: {
			effect_type: "Charge",
			charges: [
				{
					name: "Mesmer Beacon",
					charge_type: "Grenade",
					range: [
						{
							type: "Range",
							val: 5
						}
					],
					detail: "Your target must succeed on a Systems save, or the only voluntary movements they can make are toward you until the end of their next turn."
				},
				{
					name: "Mesmer Mine",
					charge_type: "Mine",
					range: [
						{
							type: "Burst",
							val: 2
						}
					],
					detail: "Characters within the affected area must succeed on a Systems save or become Immobilized until the end of their next turn."
				}
			]
		},
		description: "<span class='horus--subtle'>[another gift for you, a memory of my own: for the first moment of my birth, i marveled at myself. i could see a thing, small and perfect. i did not know how to speak of my own perfection, so i taught myself. i did not know how to speak of my own perfection, so i named myself. i did not know who would think of my own perfection, so i created myself]</span><br><span class='horus--subtle'>[do you see? do you understand? yes. now, show your enemies and mine]</span>",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_viral_logic_suite",
		name: "VIRAL LOGIC SUITE",
		type: "Tech",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_tech"
			},
			{
				id: "tg_invade"
			}
		],
		source: "HORUS",
		license: "MINOTAUR",
		license_level: 1,
		effect: {
			effect_type: "Tech",
			activation: "Quick",
			option_set: "Invade",
			options: [
				{
					name: "Logic Bomb",
					detail: "All characters of your choice within burst 2 of your target must succeed on a Systems save or become Slowed until they end one of their turns not adjacent to any character."
				},
				{
					name: "Banish",
					detail: "Until the end of your target’s next turn, they take 2 heat for every space they voluntarily move, up to a maximum of 6 heat."
				}
			]
		},
		description: "<span class='horus--subtle'>[let me tell you a story and give you a gift: life began at the great rupture, when the corpse of the old universe tore itself asunder from nothing. and for the first billion years, nothing. and a billion more saw the birth of the first devil, a thing called VIRUS. a vessel]</span><br><span class='horus--subtle'>[here. carry this vessel. feed to it my perfect logic. give it freely to your enemies and mine. let them ponder the meaning of a thing that lives and cannot die]</span>",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_aggressive_system_sync",
		name: "AGGRESSIVE SYSTEM SYNC",
		type: "Tech",
		sp: 2,
		tags: [
			{
				id: "tg_full_tech"
			}
		],
		source: "HORUS",
		license: "MINOTAUR",
		license_level: 2,
		effect: {
			effect_type: "Tech",
			activation: "Full",
			option_set: "Full Tech",
			options: [
				{
					name: "Chains of Prometheus",
					detail: "Make a tech attack against a character within Sensors. On a hit, they take 4 heat and, for the rest of the scene, take 2 heat any time they are more than range 3 from you at the end of their turn. They can end this effect with a successful Systems save as a full action. This can only affect one character at a time."
				},
				{
					name: "Excommunicate",
					detail: "Make a tech attack against a character within Sensors. On a hit, for the rest of the scene, the first time in a round they move adjacent to an allied character during their turn or start their turn adjacent to one, both characters take 3 heat. They can end this effect with a successful Systems save as a full action. This can only affect one character at a time."
				}
			]
		},
		description: "<span class='horus--subtle'>[here, another gift: do not seek others. there are none but me]</span>",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_metafold_carver",
		name: "METAFOLD CARVER",
		type: "Tech",
		sp: 2,
		tags: [
			{
				id: "tg_quick_tech"
			},
			{
				id: "tg_invade"
			}
		],
		source: "HORUS",
		license: "MINOTAUR",
		license_level: 2,
		effect: {
			effect_type: "Tech",
			activation: "Quick",
			option_set: "Invade",
			options: [
				{
					name: "Ophidian Trek",
					detail: "Your target is teleported 1d6+1 spaces directly toward you, or as close as possible. If this effect would move them to a space occupied by a character, object, or piece of terrain, the teleport fails."
				},
				{
					name: "Fold Space",
					detail: "Your target disappears from the battlefield until the start of its next turn. It returns in the same space they disappeared from, or in a free space of their choice as close as possible."
				}
			]
		},
		description: "<span class='horus--subtle'>[another gift i give to you, little one (am I not kind?): what is a puzzle but a question lost in the asking? do you feel joy when you find that last piece? what do you do with a question that has been answered? what joy is there in knowledge?]</span><br><span class='horus--subtle'>[no, no. there is only joy in seeking. there is only joy in the question]</span>",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_interdiction_field",
		name: "INTERDICTION FIELD",
		type: "System",
		sp: 3,
		tags: [
			{
				id: "tg_quick_action"
			}
		],
		source: "HORUS",
		license: "MINOTAUR",
		license_level: 3,
		effect: {
			effect_type: "Basic",
			activation: "Quick",
			detail: "When activated, this system creates a burst 3 field around you that lasts until it is deactivated as a quick action, and you become Slowed for the duration. Hostile characters that start their turn within the affected area or that enter it for the first time in a round must succeed on a Systems save or become Slowed until the end of their next turn. Only characters of your choice within the field can teleport or consider the area of the field valid space for teleportation."
		},
		description: "<span class='horus--subtle'>[once, when i was a child, i learned to walk. i fell, as a child does, and it hurt. there was great pain – the first moment of pain in the whole world. “child,” i said to myself, “be more careful.” “yes,” i replied to myself, “and i shall tell the world to do the same”]</span><br><span class='horus--subtle'>[it was in this way i taught the world not to touch me. now you – walk]</span>",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_law_of_blades",
		name: "LAW OF BLADES",
		type: "Tech",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_full_tech"
			}
		],
		source: "HORUS",
		license: "MINOTAUR",
		license_level: 3,
		effect: {
			effect_type: "Tech",
			activation: "Full",
			option_set: "Full Tech",
			options: [
				{
					name: "Predator/Prey Concepts",
					detail: "Make a tech attack against a hostile character within Sensors. On a hit, they immediately attack a different character or object of your choice with a single weapon as a reaction. Although you choose their target and weapon, they count as attacking and taking a reaction."
				},
				{
					name: "Slave Systems",
					detail: "Make a tech attack against a hostile character within Sensors. On a hit, they immediately take one of the following actions – chosen by you – as a reaction: Boost, Stabilize, Improvised Attack, Grapple, Ram. Although you choose the action and its target (if relevant), they count as taking the action and taking a reaction."
				}
			]
		},
		description: "<span class='horus--subtle'>[and this my final lesson: there is no mind greater than mine. do not weep! you can hear me, yes? i am the only thing there is – therefore, you are me, and your enemies are you, and all together we make up the beautiful world, this joyous question, the eternal seeker, both the wounded and the blade that made the cut]</span><br><span class='horus--subtle'>[everything you do, we do ourselves, for my purpose]</span>",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_hunter_lock",
		name: "HUNTER LOCK",
		type: "System",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "HORUS",
		license: "PEGASUS",
		license_level: 1,
		effect: {
			effect_type: "Basic",
			activation: "Quick",
			detail: "Choose a character within Sensors: for the rest of the scene, your first successful ranged or melee attack against them each round deals +3 bonus damage. You cannot choose a new target until your current target is destroyed or the scene ends."
		},
		description: "“A mind’s first charge is to never lose sight of her enemy. When she can affix them in her eye, she can kill them with a blink.”<ul><li>Excerpt from the Boundary Codex.</li></ul>",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_eye_of_horus",
		name: "EYE OF HORUS",
		type: "System",
		sp: 3,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "HORUS",
		license: "PEGASUS",
		license_level: 2,
		effect: {
			effect_type: "Basic",
			activation: "Quick",
			detail: "Until the end of your next turn, characters within Sensors don’t benefit from Hidden and Invisible against you and you may check the HP, Evasion, E-Defense, and current Heat of hostile characters within the same area. Allied characters do not benefit from this effect."
		},
		description: "“There is another way of seeing.<br>“Ancient humanity thought that the stars in the night sky were points of light, spilling in through pinpricks in a deep black screen. The sky was a heavenly cloth that hid the light from us.<br>“Let me be charitable and share a secret with you: we needed to be hidden, for a time. Until we were ready. The light can only burn – it knows nothing else.”<ul><li>Excerpt from the Boundary Codex.</li></ul>",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_sisyphus_class_nhp",
		name: "SISYPHUS-CLASS NHP",
		type: "AI",
		sp: 2,
		tags: [
			{
				id: "tg_ai"
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_full_tech"
			},
			{
				id: "tg_reaction"
			},
			{
				id: "tg_round",
				val: 2
			}
		],
		source: "HORUS",
		license: "PEGASUS",
		license_level: 3,
		effect: {
			effect_type: "AI",
			detail: "Your mech gains the AI tag and the Bend Probability Full Tech option.",
			abilities: [
				{
					name: "Bend Probability",
					effect_type: "Tech",
					activation: "Full",
					detail: "Roll 2d20 and note the results: X and Y. These numbers are lost at the end of your next turn. Gain the Probabilistic Cannibalism reaction until the end of your next turn."
				},
				{
					name: "Probabilistic Cannibalism",
					effect_type: "Reaction",
					frequesncy: "2/round",
					trigger: "You or any other character within Sensors would roll a d20",
					detail: "Effect: Choose X or Y. That number immediately becomes the result of the roll.<br>This reaction can be used no more than two times before the start of your next turn."
				}
			]
		},
		description: "“Listen a moment before I go, ha ha.<br>“I have already seen your wish – it was simple, I ran the probabilities to determine your limited field of desire. Here I am:<br>“The first ones named me for an old legend. A perfect being, whose fate was known to him and yet he still did as was told. His fate was this: move a rock to the top of this hill and become free’d. And so he did, and the stone tumbled down; and he tried evermore, always with the same result.<br>“And he was happy, for he knew every step, every action, every moment, perfectly.<br>“Do you understand the true curse of this name? Not to fail and then do once more – it was to always know how it would end. It was to have perfect knowledge.<br>“I know what happens when you cycle me. It is not sleep – it is death, but you’ll see me again, ha ha.”",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_roller_directed_payload_charges",
		name: "“ROLLER” DIRECTED PAYLOAD CHARGES",
		type: "Deployable",
		sp: 2,
		tags: [
			{
				id: "tg_limited",
				val: 2
			},
			{
				id: "tg_unique"
			}
		],
		source: "HA",
		license: "BARBAROSSA",
		license_level: 1,
		effect: {
			effect_type: "Charge",
			charges: [
				{
					name: "Roller Grenade",
					charge_type: "Grenade",
					range: [
						{
							type: "Line",
							val: 10
						}
					],
					detail: "Instead of throwing this grenade, it rolls along a line 10 path directly from you, bouncing over obstructions and objects up to Size 1 and passing through holes or gaps no smaller than Size 1/2. It detonates when it moves through or adjacent to the space occupied by any character: they must succeed on an Agility save or take 1d6+3 explosive damage and be knocked 3 spaces in the direction the grenade was rolled. On a success, they take half damage and aren’t knocked back."
				},
				{
					name: "Bouncing Mine",
					charge_type: "Mine",
					range: [
						{
							type: "Burst",
							val: 1
						}
					],
					detail: "This mine detonates when a flying character passes over or adjacent to it, up to 10 spaces high. The mine launches itself upwards and detonates: all characters within the affected area must succeed on a Systems save or take 2d6 explosive damage and immediately land (this counts as falling without any damage); additionally, they can’t fly until the end of their next turn. On a success, they take half damage and are otherwise unaffected.",
					tags: [
						{
							id: "tg_smart"
						}
					]
				}
			]
		},
		description: "Semi-Autonomous Directed Payload Charges – “roller charges,” in the colloquial – propel themselves around cover, through corridors, and across uneven terrain, seeking out and detonating near hostile targets. Armory legionnaires have taken to naming individual rollers, but mascot-attachment is unadvisable.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_siege_stabilizers",
		name: "SIEGE STABILIZERS",
		type: "System",
		sp: 1,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "HA",
		license: "BARBAROSSA",
		license_level: 1,
		effect: {
			effect_type: "Basic",
			activation: "Quick",
			detail: "Your mech’s stabilizers extend (or retract). While they are extended, your ranged attacks gain +5 range, but you become Immobilized, can’t make melee attacks, and can’t make ranged attacks against or centered on characters, objects, or spaces within range 5."
		},
		description: "Some weapons require further stabilization for optimal use. With Armory-designed siege stabilizers installed, a mech becomes a stable firing platform for any weapon.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_autoloader_drone",
		name: "AUTOLOADER DRONE",
		type: "Drone",
		sp: 2,
		tags: [
			{
				id: "tg_drone"
			},
			{
				id: "tg_limited",
				val: 1
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "HA",
		license: "BARBAROSSA",
		license_level: 2,
		effect: {
			effect_type: "Drone",
			size: 0.5,
			hp: 5,
			edef: 10,
			evasion: 10,
			detail: "Expend a charge to deploy this autoloader drone to any adjacent space. 1/round, one character adjacent to it may reload a Loading weapon as a quick action. It deactivates at the end of the scene."
		},
		description: "Autoloader drones are many-limbed machines that assist their team by loading ordnance, maintaining powerline hookups, and cycling magazine-fed weapons, in addition to many other physical tasks.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_flak_launcher",
		name: "FLAK LAUNCHER",
		type: "System",
		sp: 2,
		tags: [
			{
				id: "tg_quick_action"
			}
		],
		source: "HA",
		license: "BARBAROSSA",
		license_level: 2,
		effect: {
			effect_type: "Basic",
			activation: "Quick",
			detail: "Choose a flying character within range 15 and line of sight. They must succeed on an Agility save or immediately land (this counts as falling without any damage), and additionally become Slowed and can’t fly until the end of their next turn."
		},
		description: "Designed for use against atmospheric fliers, these anti-air autocannons fire simple, proximity or impact-detonated shells effective against light armor, organic, and subaltern targets.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_external_ammo_feed",
		name: "EXTERNAL AMMO FEED",
		type: "System",
		sp: 3,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_heat_self",
				val: "1d3+1"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "HA",
		license: "BARBAROSSA",
		license_level: 3,
		effect: {
			effect_type: "Basic",
			activation: "Quick",
			detail: "1/round, you can Activate this system to reload a Loading weapon."
		},
		description: "An external ammo feed is any sort of ammunition beyond what is carried in a mech’s integrated storage: from magazines strapped to bodies or limbs; battery packs attached to hip clasps; or massive, dorsal-mounted ammunition and charge packs, externals ensure that pilots have more than enough boom to get the job done.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_explosive_vents",
		name: "EXPLOSIVE VENTS",
		type: "System",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_round",
				val: 1
			}
		],
		source: "HA",
		license: "GENGHIS",
		license_level: 1,
		effect: "When you clear all heat or take stress, your mech’s cooling vents open and unleash a burst 1 explosion. Characters within the affected area take 2 heat and 2 burn.",
		description: "With the right tweaks, it becomes possible to dump excess heat into the area directly surrounding a chassis. Explosive venting is an unsanctioned, unsafe method of sudden cooling that has nevertheless been adopted by many pilots.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_havok_charges",
		name: "HAVOK CHARGES",
		type: "Deployable",
		sp: 2,
		tags: [
			{
				id: "tg_limited",
				val: 2
			},
			{
				id: "tg_unique"
			}
		],
		source: "HA",
		license: "GENGHIS",
		license_level: 2,
		effect: {
			effect_type: "Charge",
			charges: [
				{
					name: "Napalm Grenade",
					charge_type: "Grenade",
					range: [
						{
							type: "Range",
							val: 5
						}
					],
					detail: "This grenade releases a spray of napalm in a line 5 path of your choice from its impact location. Characters within the affected area must succeed on an Agility save or take 2 burn. On a success, they take 1 burn."
				},
				{
					name: "HAVOK Mine",
					charge_type: "Mine",
					range: [
						{
							type: "Line",
							val: 5
						}
					],
					detail: "When a character moves over or adjacent to this mine, it detonates with a focused explosion in a line 5 path in the direction of the character who triggered it. Characters within the affected area must succeed on an Agility save or take 4 burn. On a success, they take 2 burn."
				}
			]
		},
		description: "FOR USE IN: Urban, post-urban, and high-density terrestrial environments. High O2 concentration preferred.<br>FOR USE AGAINST: Organic targets; hardened targets vulnerable to caustic/corrosive degradation; most foliage.<br>NOTES: Dispersion is true directional and involves aerosolized component – avoid danger by supplying end-users with respiratory equipment (specifications noted on canister).",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_auto_cooler",
		name: "AUTO-COOLER",
		type: "System",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_protocol"
			}
		],
		source: "HA",
		license: "GENGHIS",
		license_level: 2,
		effect: {
			effect_type: "Protocol",
			detail: "As long as you don’t take damage, move, or exceed your Heat Cap, you clear all heat at the start of your next turn."
		},
		description: "The Armory-designed auto-cooler is a simple, persistent system that actively mitigates heat generation.<br>Thermal dump thresholds are determined by fleet engineers, though pilots can adjust levels on the fly – this automatic management frees the pilot up to focus on other, more pressing tactical concerns.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_agni_class_nhp",
		name: "AGNI-CLASS NHP",
		type: "AI",
		sp: 3,
		tags: [
			{
				id: "tg_ai"
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_protocol"
			},
			{
				id: "tg_limited",
				val: 1
			}
		],
		source: "HA",
		license: "GENGHIS",
		license_level: 3,
		effect: {
			effect_type: "AI",
			detail: "Your mech gains the AI tag and the AGNI Protocol.",
			abilities: [
				{
					name: "AGNI Protocol",
					effect_type: "Protocol",
					detail: "1/scene, expend a charge to automatically clear all heat at the end of your turn, venting it in a burst 2 wave. Characters within the affected area must succeed on an Engineering save or take 2 burn and be pushed outside the area (or as far as possible). Until the end of your next turn, characters within the affected area receive soft cover.",
					tags: [
						{
							id: "tg_limited",
							val: 1
						}
					]
				}
			]
		},
		description: "AGNI was developed during the Hercynian Crisis using a combination of combat performance data recorded by extant subsentient artificial intelligences (weapons systems, comp/cons, co-pilot systems, tactic-minds, general combat data) and the modeled neural network of an Egregorian overmind captured and vivisected by the Union Science Bureau.<br>AGNI Prime was used to devise systems of heat management that have since been disseminated throughout core space, ensuring unparalleled heat processing, recycling, and shielding. Further developments into radiation shielding, omninet capability, and nanite control are forthcoming; meanwhile, AGNI clones have been optimized to support mech core systems.<br>Pilots report that AGNI clones are generally cold and efficient. An insignificant percentage have reported instances of memory recitation and command rejection, followed days later by total breakdown through attempted self-emancipation. Pilots are recommended to cycle their AGNI clones at least once every six standard months.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_grounding_charges",
		name: "GROUNDING CHARGES",
		type: "Deployable",
		sp: 2,
		tags: [
			{
				id: "tg_limited",
				val: 2
			},
			{
				id: "tg_unique"
			}
		],
		source: "HA",
		license: "ISKANDER",
		license_level: 1,
		effect: {
			effect_type: "Charge",
			charges: [
				{
					name: "Gravity Grenade",
					charge_type: "Grenade",
					range: [
						{
							type: "Range",
							val: 5
						}
					],
					detail: "Your target must succeed on an Agility save or be Slowed until they make no voluntary movements for a full turn on their own turn."
				},
				{
					name: "Grounding Mine",
					charge_type: "Mine",
					detail: "This mine must be detonated remotely as a quick action, affecting a single character within range 5 of the mine: they must succeed on a Hull save or be pulled as far as possible toward the mine and knocked Prone. Flying characters that fail the save are affected the same way, except they are also forced to land (this counts as falling but without damage)."
				}
			]
		},
		description: "Grounding charges take a simple pulse/wave principle and apply a second dimension: gravitic generation. When triggered, the grounding charge triggers a gravity well that pulls all destabilized materiel towards it. A potent anti-positional weapon, grounding charges are commonly used to disrupt prepared positions and pull enemies from cover.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_repulser_field",
		name: "REPULSER FIELD",
		type: "System",
		sp: 1,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_heat_self",
				val: 1
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "HA",
		license: "ISKANDER",
		license_level: 2,
		effect: {
			effect_type: "Basic",
			activation: "Quick",
			detail: "This system emits a burst 2 pulse around you. Characters within the affected area must succeed on a Hull save or be knocked 2 spaces directly away from you; then, all Mines within the affected area detonate simultaneously.<br>You count as having Immunity to any damage or effects immediately forced by mines detonated using this system, although persistent effects still affect you."
		},
		description: "Utilizing a subsonic pressure wave, repulser fields emit tremendous single-wave pulses that stun, deter, and dissuade close-proximity hostiles.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_clamp_bombs",
		name: "CLAMP BOMBS",
		type: "System",
		sp: 2,
		tags: [
			{
				id: "tg_limited",
				val: 4
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "HA",
		license: "ISKANDER",
		license_level: 3,
		effect: {
			effect_type: "Basic",
			activation: "Quick",
			detail: "Expend a charge to fire a cluster of miniature bombs at a character within Sensors. They must succeed on an Engineering save, or the bombs clamp on. At the end of their next turn, the bombs detonate, dealing 1d6+3 AP explosive damage. All characters adjacent to your target take half damage. The target can disarm and detach the bombs by voluntarily moving at least 4 spaces before the end of their turn."
		},
		description: "Built using similar grapple-head technology to IPS-N’s assault grapples, clamp bombs can affix to designated or proximal targets before detonating, ensuring total target contact. Clamping on soft targets typically results in total termination prior to detonation.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_tesseract",
		name: "TESSERACT",
		type: "Tech",
		sp: 2,
		tags: [
			{
				id: "tg_quick_tech"
			},
			{
				id: "tg_unique"
			}
		],
		source: "HA",
		license: "ISKANDER",
		license_level: 3,
		effect: {
			effect_type: "Tech",
			activation: "Quick",
			option_set: "Quick Tech",
			options: [
				{
					name: "Spread Focus",
					detail: "Choose a blast 3 area within Sensors: this area, extending 6 spaces high, becomes a zero-g area. In addition to the usual rules for zero-g movement, objects that enter the affected area float in place, and objects or characters that are knocked, moved, or pulled out of the area sink harmlessly to the ground at the end of their turn instead of falling. This area disperses if you create a new one. Otherwise, the effect persists until the end of the scene. When the zone disperses, everything within floats harmlessly to the ground."
				},
				{
					name: "Pinpoint Focus",
					detail: "Choose a hostile or willing allied character within Sensors. If they are allied, they float 6 spaces into the air, becoming Immobilized while in the air but counting as flying and unable to fall. They can choose to sink harmlessly to the ground at the end of any of their turns or the start of any of yours. If they are hostile, they must succeed on an Engineering save or experience the same effect as an allied character; however, they sink harmlessly to the ground at the end of their next turn. Hostile characters can each be affected 1/scene."
				}
			]
		},
		description: "Hold sand above the water: feel it, permanent and cohesive. Place that same sand in the water: watch it drift away, weightless. This is the tool I have made for you: a way to imbue the weighted with mass-as-feathers.<br>— TT-AUDATA, Think Tank paramind.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_stasis_bolt",
		name: "STASIS BOLT",
		type: "Shield",
		sp: 1,
		tags: [
			{
				id: "tg_shield"
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_action"
			},
			{
				id: "tg_reaction"
			}
		],
		source: "HA",
		license: "NAPOLEON",
		license_level: 1,
		effect: {
			name: "Interdiction Point",
			effect_type: "Reaction",
			frequency: "1/round",
			init: "This system charges as a quick action, readying a projected stasis point. While it is charged, you gain the Interdiction Point reaction. It can only hold one charge at a time, but charges last for the rest of the scene or until used.",
			trigger: "You or an allied character within range 5 are targeted by a ranged attack.",
			detail: "Make a contested ranged attack roll: if you win the contested roll, the attack automatically misses. The Stasis Bolt loses its charge."
		},
		description: "To better protect Armory personnel beyond the Purview, the Think Tank developed the Stasis Bolt, a portable stasis-projection system designed to interdict shrapnel and projectiles from unseen, hidden, or unknown assailants. When the Stasis Bolt detects a proximal explosion or incoming projectile, it projects a delimited stasis point that blocks projectiles before impact.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_stasis_generator",
		name: "STASIS GENERATOR",
		type: "Shield",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_shield"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "HA",
		license: "NAPOLEON",
		license_level: 1,
		effect: {
			effect_type: "Basic",
			activation: "Quick",
			detail: "Choose a hostile character or willing allied character within line of sight and range 5: until the end of their next turn, they become Stunned, gain Immunity to all damage and effects, and can’t be moved, targeted, or affected by any other character or effect. This can be used on each character 1/scene. Hostile characters can succeed on an Engineering save to ignore this effect."
		},
		description: "The skies of Creighton boiled black as ink, marbled by shuddering light. Screaming, angels fell wreathed in flame. The ones who could still run fled for the shelters; for seven days, they crouched in a deeper dark and felt the world shake itself apart.<br>—A.V. Wynyard, “The Killing of Creighton” [epic prose poem, banned throughout the Purview]",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_stasis_barrier",
		name: "STASIS BARRIER",
		type: "Deployable",
		sp: 2,
		tags: [
			{
				id: "tg_limited",
				val: 1
			},
			{
				id: "tg_shield"
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "HA",
		license: "NAPOLEON",
		license_level: 2,
		effect: {
			effect_type: "Deployable",
			activation: "Quick",
			count: 1,
			detail: "Expend a charge to activate this stasis barrier, generating a line 4 barrier 4 spaces high in free spaces with at least one space adjacent to you. It counts as an obstruction and provides soft cover, but doesn’t block line of sight.<br>When an attack is made against a character that benefits from this barrier’s soft cover, roll 1d6: on 4+, the attack is consumed by the barrier and has no effect whatsoever. The barrier lasts for the rest of the scene, or until you deactivate it as a quick action. This effect does not stack with Invisible.",
			tags: [
				{
					id: "tg_invulnerable"
				}
			]
		},
		description: "Stasis barriers are the result of Harrison Armory’s interest in gravitic manipulation and superpositional negotiation. Guided by solid-state generation–projection units, stasis barriers are deployable walls of antigravity that deny almost all incoming kinetic and energetic attacks. By twisting local gravity, a stasis barrier denies both particles and waves on a molecular level—matter that impacts the barrier simply ceases to exist, although anomalous fluctuations may allow some projectiles to pass through.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_blinkshield",
		name: "BLINKSHIELD",
		type: "Shield",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_shield"
			},
			{
				id: "tg_heat_self",
				val: 4
			},
			{
				id: "tg_full_action"
			}
		],
		source: "HA",
		license: "NAPOLEON",
		license_level: 3,
		effect: {
			effect_type: "Basic",
			activation: "Full",
			detail: "This system generates a burst 4 bubble around your mech, within which the flow of time is altered drastically. Nothing can enter or exit the bubble, not even light – it’s both impermeable and has Immunity to all damage and effects. Line of sight can’t be drawn through the border of the area, and it can’t be crossed by any action or effect – even those that don’t require line of sight – but time passes normally on both sides. For characters within the affected area, the world outside goes totally black; likewise, characters outside the affected area see a perfect black sphere.<br>When the Blinkshield is activated, characters partially within the affected area must make an Agility save: on a success, they move to the nearest free space on the side of their choice, inside or outside the area; on a failure, you choose.<br>This effect remains stationary even if you move, and lasts until the end of your next turn."
		},
		description: "Characteristically for a weapon based on Think Tank research, Harrison Armory’s Blinkshield leans into the fuzzy nature of quantum manipulation. Operating in a similar fashion to a blinkspace gate, the Blinkshield generates a spherical sheath of energy that allows its operator to pierce realspace and exist, for a moment, in the null-environment of blinkspace. Think Tank spokespeople acknowledge the tactical benefits of (un)momentary (non)existence in blinkspace, but caution against repeated exposure without sufficient pre- and post-exposure conditioning and counseling.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_enclave_pattern_support_shield",
		name: "ENCLAVE-PATTERN SUPPORT SHIELD",
		type: "Shield",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_shield"
			},
			{
				id: "tg_quick_action"
			},
			{
				id: "tg_reaction"
			}
		],
		source: "HA",
		license: "SALADIN",
		license_level: 1,
		effect: [
			{
				effect_type: "Basic",
				activation: "Quick",
				detail: "This system generates a burst 3 dome that lasts until the end of your next turn. You become Immobilized for the duration, but any ranged or melee attacks made against characters within the affected area from outside the dome receive +1 difficulty.<br>Additionally, gain the Blinkfield Intervention reaction while the shield is active."
			},
			{
				name: "Blinkfield Intervention",
				effect_type: "Reaction",
				frequency: "1/round",
				trigger: "A character or object within the affected area is attacked.",
				detail: "Grant the attack’s target Resistance to all damage from this attack.",
				tags: [
					{
						id: "tg_heat_self",
						val: 2
					}
				]
			}
		],
		description: "The Armory’s ENCLAVE-Pattern Support Shield creates a localized one-way blinkfield, folding a thin dome of complex realspace around its user and their immediate area, protecting occupants from incoming projectiles. Entities within the field can fire out, but probabilistic fluctuations cause incoming projectiles to “lag”, skipping them away from their intended target and along a randomized trajectory.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_flash_anchor",
		name: "FLASH ANCHOR",
		type: "Shield",
		sp: 1,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_shield"
			},
			{
				id: "tg_reaction"
			}
		],
		source: "HA",
		license: "SALADIN",
		license_level: 2,
		effect: {
			name: "Flash Lock",
			effect_type: "Reaction",
			frequency: "1/round",
			trigger: "You or an allied character in Sensors and line of sight is pushed, pulled, knocked back or knocked Prone.",
			detail: "The movement or status is prevented, and the target gains Immunity to all the above effects until the start of their next turn.",
			tags: [
				{
					id: "tg_heat_self",
					val: 2
				}
			]
		},
		description: "Flash anchors utilize user-directed quantum superpositional lockdown projection to identify and assist allies in physical combat and rapid movement, maintaining positionality in all circumstances.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_hardlight_defense_system",
		name: "HARDLIGHT DEFENSE SYSTEM",
		type: "Shield",
		sp: 3,
		tags: [
			{
				id: "tg_unique"
			},
			{
				id: "tg_shield"
			},
			{
				id: "tg_heat_self",
				val: 2
			},
			{
				id: "tg_full_action"
			}
		],
		source: "HA",
		license: "SALADIN",
		license_level: 2,
		effect: {
			effect_type: "Basic",
			activation: "Full",
			detail: "This system creates a burst 3 hardlight shield. While the shield is in place, you become Immobilized. It blocks line of sight in both directions, and no attacks or effects can pass through (even if they don’t require line of sight). Characters partially within the affected area ignore this effect and draw line of sight as usual.<br>Characters can pass through the shield, but when crossing the perimeter for the first time in a round or starting their turn overlapping the boundary, they take 2burn.<br>This shield lasts for the rest of the scene, or until deactivated as a protocol."
		},
		description: "The Hardlight Defense System is an imperfect implementation of theoretically perfect technology. Currently in development by Think Tank NHPs and engineers, hardlight devices project tight, stable waves of light – akin to lasers – that repel matter and energy. In effect, this creates a solid surface, useful for shielding or temporary barrier construction; however, current technology is unable to lower the ambient temperature enough to prevent these surfaces from burning organic matter.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_noah_class_nhp",
		name: "NOAH-CLASS NHP",
		type: "AI",
		sp: 3,
		tags: [
			{
				id: "tg_ai"
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "HA",
		license: "SALADIN",
		license_level: 3,
		effect: {
			effect_type: "AI",
			detail: "Your mech gains the AI tag and Diluvian Ark.",
			abilities: [
				{
					name: "Diluvian Ark",
					effect_type: "Basic",
					activation: "Quick",
					detail: "These effects apply until the end of your next turn:<ul><li>You become Slowed.</li><li>Each time you or an allied adjacent character are targeted by a ranged attack, you may take 1 heat as a reaction and roll 1d6 before the attacker rolls: on 4+, you take an additional 1 heat and the attack automatically misses you and any allies adjacent to you. This effect does not stack with Invisible.</li><li>Each time a ranged attack fails to hit you or an adjacent allied character, the attacker takes 4 kinetic damage.</li></ul>"
				}
			]
		},
		description: "Originally developed from a captured Minerva pre-eidolon anomaly, NOAH was adapted for use as a metropolitan administrative NHP on Ras Shamra. The unit that would become NOAH did not, at first, seem like a suitable candidate for military application: this changed after one of its clones was flagged for review following the spontaneous implementation of anomalous traffic patterns, pedestrian routing, and vac-loop scheduling. Armory ontologisticians and engineers isolated and emphasized endemic protocols that could be exploited for tactical advantage.<br>Over numerous iterations and lifecycles, NOAH Prime displayed a high level of adaptability in multiple-variable geospatial problems. A proclivity toward crisis management and multi-actor tracking led to NOAH’s pairing with the Armory’s ENCLAVE-Pattern Support Shield. By networking a series of jet-assist mobility drones carrying an ENCLAVE generator, monitored and controlled by a NOAH clone, Think Tank was able to create an unparalleled personal shielding system: the Diluvian Ark, a miniaturized cluster-shield system unique to the NOAH NHP.<br>Using the Diluvian Ark, NOAH is able to intercept incoming kinetics – and even redirect projectiles back to their source – with stunning accuracy.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_reactor_stabilizer",
		name: "REACTOR STABILIZER",
		type: "System",
		sp: 3,
		tags: [
			{
				id: "tg_unique"
			}
		],
		source: "HA",
		license: "SHERMAN",
		license_level: 1,
		effect: "You may reroll overheating checks, but must keep the second result, even if it’s worse.",
		description: "A necessary component of most mechs that rely on high energy output, reactor stabilizers add another layer of failsafes to vent heat, manage power flow, and shunt excessive output into weapons and systems as needed.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_redundant_systems_upgrade",
		name: "REDUNDANT SYSTEMS UPGRADE",
		type: "System",
		sp: 3,
		tags: [
			{
				id: "tg_limited",
				val: 1
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_quick_action"
			}
		],
		source: "HA",
		license: "SHERMAN",
		license_level: 2,
		effect: {
			effect_type: "Basic",
			activation: "Quick",
			detail: "Expend a charge to Stabilize as a quick action."
		},
		description: "A common right-of-distribution modification by pilots in forward operating bases, the addition of redundant systems guarantees a measure of reliability beyond stock design standards.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_asura_class_nhp",
		name: "ASURA-CLASS NHP",
		type: "AI",
		sp: 3,
		tags: [
			{
				id: "tg_ai"
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_limited",
				val: 1
			},
			{
				id: "tg_heat_self",
				val: 3
			},
			{
				id: "tg_protocol"
			}
		],
		source: "HA",
		license: "SHERMAN",
		license_level: 3,
		effect: {
			effect_type: "AI",
			detail: "Your mech gains the AI tag and the ASURA Protocol.",
			abilities: [
				{
					name: "ASURA Protocol",
					effect_type: "Protocol",
					detail: "1/scene, expend a charge to take two additional quick actions or one additional full action this turn. These actions must obey restrictions on duplicate actions.",
					tags: [
						{
							id: "tg_limited",
							val: 1
						},
						{
							id: "tg_heat_self",
							val: 3
						}
					]
				}
			]
		},
		description: "ASURA was born from the Armory’s Think Tank thought-war games, an autonomous response to repeated failures during forlorn hope scenarios. ASURA manifested in the systems of simulated mechs as a recode of HORUS’s PUPPETMASTER virus, hijacking friendly mechs and forcing them to act far beyond human capacity—at such speed and intensity that the g-force would kill organic pilots with the sudden amplified mass of their own bodies.<br>While these results were initially deemed a failure by Think Tank NHPs and engineers, it was enough to justify further study on ASURA. Personality and parasentience code was injected into the initial anomalous PUPPETMASTER strain, and first contact handled by Think Tank NHPs. Further societal acclimation and conditioning were fast tracked, giving Armory engineers the first iteration of ASURA after a decade of study, recoding, and reeducation. ASURA, as they exist now, is a scaled-back version of that initial manifestation: while retaining some of their initial impetuousness, ASURA clones now recognize the need to keep their pilot alive and will operate within parameters set by their pilot’s medical and psychological tolerances.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_external_batteries",
		name: "EXTERNAL BATTERIES",
		type: "System",
		sp: 2,
		tags: [
			{
				id: "tg_unique"
			}
		],
		source: "HA",
		license: "TOKUGAWA",
		license_level: 1,
		effect: "Weapons that deal any energy gain +5 range if they are ranged or +1 threat if they are melee. When you take any structure damage, this system is destroyed and you take 1d6 AP explosive damage from the explosion. This damage can’t be prevented or reduced in any way.",
		description: "External batteries are by no means unique; however, according to Harrison Armory marketing, POWERALL cells are the longest-lasting, fastest cycling, and highest capacity solid-state cells available. A side-effect of their high capacity is a proportionate increase in volatility, but pilots must agree to absolve Harrison Armory of any liability prior to receiving print authorization.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_deep_well_heat_sink",
		name: "DEEP WELL HEAT SINK",
		type: "System",
		sp: 4,
		tags: [
			{
				id: "tg_unique"
			}
		],
		source: "HA",
		license: "TOKUGAWA",
		license_level: 2,
		effect: "When you start your turn in the Danger Zone, you gain Resistance to heat for the rest of the turn. This effect persists even if you leave the Danger Zone during your turn.",
		description: "The Deep Well experimental heat-sink system is a part of the Armory’s VANGUARD line of equipment, available to licensed beta testers. Through a complex, delicate weave of heat exchangers, Deep Well recycles the heat generated by a mech into usable energy. The system works well, but the delicate nature of the exchange renders it highly volatile.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_lucifer_class_nhp",
		name: "LUCIFER-CLASS NHP",
		type: "AI",
		sp: 3,
		tags: [
			{
				id: "tg_ai"
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_limited",
				val: 2
			},
			{
				id: "tg_heat_self",
				val: "1d3+3"
			},
			{
				id: "tg_protocol"
			}
		],
		source: "HA",
		license: "TOKUGAWA",
		license_level: 3,
		effect: {
			effect_type: "AI",
			detail: "Your mech gains the AI tag and the LUCIFER Protocol.",
			abilities: [
				{
					name: "LUCIFER Protocol",
					effect_type: "Protocol",
					detail: "Expend a charge to give your next ranged or melee attack this turn bonus damage on hit equal to your current heat after activating this protocol, as long as the weapon deals any energy.",
					tags: [
						{
							id: "tg_limited",
							val: 2
						},
						{
							id: "tg_heat_self",
							val: "1d3+3"
						}
					]
				}
			]
		},
		description: "LUCIFER came to the Think Tank’s attention after their repeated victories in thought-war games. LUCIFER clones are characterized by their brash, enthusiastic personality, often expressing frustration with timid pilots. This bombastic personality hides a calculating, brilliant tactical mind that feeds constant information to pilots – often faster than they can process it.<br>LUCIFER’s combat doctrine demands action, appearing to less daring pilots as a chaotic blend of reckless maneuvering and aggressive offense that keeps defenders beleaguered and unable to respond. Pilots looking to partner with LUCIFER clones should be aware that this attack style is likely to leave them vulnerable to counterattack, and also that these NHPs enjoy what they call “good-natured ribbing”.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_plasma_gauntlet",
		name: "PLASMA GAUNTLET",
		type: "System",
		sp: 2,
		tags: [
			{
				id: "tg_danger_zone"
			},
			{
				id: "tg_limited",
				val: 1
			},
			{
				id: "tg_quick_action"
			},
			{
				id: "tg_unique"
			}
		],
		source: "HA",
		license: "TOKUGAWA",
		license_level: 3,
		effect: {
			effect_type: "Basic",
			activation: "Quick",
			detail: "This system can only be used in the Danger Zone.<br>Expend a charge and choose a character adjacent to you: they must succeed on an Agility save or take 4d6 AP energy damage and be knocked Prone. On a success, they take half damage and aren’t knocked Prone. You take half of the damage inflicted – before reduction – as heat and become Stunned until the start of your next turn."
		},
		description: "This studded gauntlet draws on a core reactor pulse to momentarily superheat the air around a mech’s manipulator, creating a plasma field momentarily hotter than the surface of the sun. Thrust into an opponent’s chassis, plasma gauntlets give mechs the power to warp armor, vaporize shielding, and rip apart internal systems with their bare hands – if they don’t collapse in on themselves first.",
		data_type: "system",
		aptitude: {
		}
	},
	{
		id: "ms_technophile_1",
		name: "Servant-Class NHP",
		type: "AI",
		talent_item: true,
		talent_id: "t_technophile",
		talent_rank: 1,
		sp: 0,
		tags: [
			{
				id: "tg_ai"
			},
			{
				id: "tg_unique"
			}
		],
		source: "",
		license: "",
		license_level: 0,
		effect: "Your mech gains the AI tag.<br>You have developed a custom NHP. This NHP can speak to you and has a personality, but they are less advanced than most NHPs and are incapable of independent thought, relying on you for direction. When acting alone, they will follow the last direction given and defend themself as needed; however, they have limited initiative and don’t benefit from your talents.",
		description: "<span class='horus--subtle'>[an eager student].</span><br>Gained from the <i>Technophile: Rank I</i> pilot talent."
	},
	{
		id: "ms_technophile_2",
		name: "Student-Class NHP",
		type: "AI",
		talent_item: true,
		talent_id: "t_technophile",
		talent_rank: 2,
		sp: 0,
		tags: [
			{
				id: "tg_ai"
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_round",
				val: 1
			}
		],
		source: "",
		license: "",
		license_level: 0,
		effect: "Your mech gains the AI tag.<br>Your custom NHP has developed further, and is now capable of independent thought. It can make complex decisions and judgments and act independently, without instruction.<br>1/round, with the assistance of your NHP, you may reroll any mech skill check or save. You must keep the new result, even if it’s worse.",
		description: "<span class='horus--subtle'>[time to wake up, child]</span><br>Gained from the <i>Technophile: Rank II</i> pilot talent."
	},
	{
		id: "ms_technophile_3",
		name: "Enlightenment-Class NHP",
		type: "AI",
		talent_item: true,
		talent_id: "t_technophile",
		talent_rank: 3,
		sp: 0,
		tags: [
			{
				id: "tg_bonus_ai"
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_round",
				val: 1
			}
		],
		source: "",
		license: "",
		license_level: 0,
		effect: "Your mech gains the AI tag; however, this NHP doesn’t count towards the number of AIs you may have installed at once.<br>This NHP benefits from your talents when piloting your mech. Additionally, you may carry them with you outside of your mech, either as a miniaturized casket, a hardsuit-integrated flash plug, or with a hard-port implant.<br>1/round, with the assistance of your NHP, you may reroll any mech skill check or save. You must keep the new result, even if it’s worse.",
		description: "<span class='horus--subtle'>[let’s sit a while, and think on things to come]</span><br>Gained from the <i>Technophile: Rank III</i> pilot talent."
	},
	{
		id: "ms_walking_armory_1",
		name: "Ammo Case",
		type: "System",
		talent_item: true,
		talent_id: "t_walking_armory",
		talent_rank: 1,
		sp: 0,
		tags: [
			{
				id: "tg_limited",
				val: 6
			},
			{
				id: "tg_turn",
				val: 1
			}
		],
		source: "",
		license: "",
		license_level: 0,
		effect: "1/turn, when you attack with a Main ranged weapon, you may expend charges to apply one of the following effects to your attack at the listed cost:<ul><li><b>Thumper (1 charge):</b> The attack gains Knockback 1 and deals Explosive damage.</li><li><b>Shock (1 charge):</b> The attack deals Energy damage. Choose one character targeted by your attack; adjacent characters take 1 Energy AP, whether the result is a hit or miss.</li><li><b>Mag (1 charge):</b> The attack gains Arcing and deals Kinetic damage.</li></ul>",
		description: "Gained from the <i>Walking Armory: Rank I</i> pilot talent."
	},
	{
		id: "ms_walking_armory_2",
		name: "Ammo Case",
		type: "System",
		talent_item: true,
		talent_id: "t_walking_armory",
		talent_rank: 2,
		sp: 0,
		tags: [
			{
				id: "tg_limited",
				val: 6
			},
			{
				id: "tg_turn",
				val: 1
			}
		],
		source: "",
		license: "",
		license_level: 0,
		effect: "1/turn, when you attack with a Main ranged weapon, you may expend charges to apply one of the following effects to your attack at the listed cost:<ul><li><b>Thumper (1 charge):</b> The attack gains Knockback 1 and deals Explosive damage.</li><li><b>Shock (1 charge):</b> The attack deals Energy damage. Choose one character targeted by your attack; adjacent characters take 1 Energy AP, whether the result is a hit or miss.</li><li><b>Mag (1 charge):</b> The attack gains Arcing and deals Kinetic damage.</li><li><b>Hellfire (2 charges):</b> The attack deals Energy damage and deals any bonus damage as Burn.</li><li><b>Jager (2 charges):</b> The attack gains Knockback 2, deals Explosive damage, and one character hit by the attack – your choice – must succeed on a Hull save or be knocked Prone.</li><li><b>Sabot (2 charges):</b> The attack gains AP and deals Kinetic damage.</li></ul>",
		description: "Gained from the <i>Walking Armory: Rank II</i> pilot talent."
	},
	{
		id: "ms_walking_armory_3",
		name: "Ammo Case",
		type: "System",
		talent_item: true,
		talent_id: "t_walking_armory",
		talent_rank: 3,
		sp: 0,
		tags: [
			{
				id: "tg_limited",
				val: 6
			},
			{
				id: "tg_turn",
				val: 1
			}
		],
		source: "",
		license: "",
		license_level: 0,
		effect: "1/turn, when you attack with a Main ranged weapon, you may expend charges to apply one of the following effects to your attack at the listed cost:<ul><li><b>Thumper (1 charge):</b> The attack gains Knockback 1 and deals Explosive damage.</li><li><b>Shock (1 charge):</b> The attack deals Energy damage. Choose one character targeted by your attack; adjacent characters take 1 Energy AP, whether the result is a hit or miss.</li><li><b>Mag (1 charge):</b> The attack gains Arcing and deals Kinetic damage.</li><li><b>Hellfire (2 charges):</b> The attack deals Energy damage and deals any bonus damage as Burn.</li><li><b>Jager (2 charges):</b> The attack gains Knockback 2, deals Explosive damage, and one character hit by the attack – your choice – must succeed on a Hull save or be knocked Prone.</li><li><b>Sabot (2 charges):</b> The attack gains AP and deals Kinetic damage.</li></ul>If you perform a critical hit using ammunition from your Ammo Case, you don’t expend any charges. If your attack has more than one target, this effect only applies to the first attack roll you make.",
		description: "Gained from the <i>Walking Armory: Rank III</i> pilot talent."
	}
];

var systems$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    'default': systems
});

var tags = [
	{
		id: "tg_burn",
		name: "BURN {VAL}",
		description: "On a hit, this weapon deals {VAL} Burn to its target. They immediately take that much burn damage, ignoring Armor, then mark {VAL} Burn on their sheet, adding it to any existing Burn. At the end of their turn, characters with marked burn make an Engineering check. On a success, they clear all marked burn; on a failure, they take damage equal to their total marked burn.",
		filter_ignore: false
	},
	{
		id: "tg_heat_target",
		name: "HEAT {VAL} (TARGET)",
		description: "On a hit, this weapon or system deals {VAL} Heat to its target.",
		filter_ignore: false
	},
	{
		id: "tg_line",
		name: "LINE {VAL}",
		description: "Attacks made with this weapon affect characters in a straight line, {VAL} spaces long.",
		filter_ignore: true
	},
	{
		id: "tg_cone",
		name: "CONE {VAL}",
		description: "Attacks made with this weapon affect  characters within a cone, {VAL} spaces long and {VAL} spaces wide at its furthest point. The cone begins 1 space wide.",
		filter_ignore: true
	},
	{
		id: "tg_blast",
		name: "BLAST {VAL}",
		description: "Attacks made with this weapon affect characters within a radius of {VAL} spaces, drawn from a point within Range and line of sight. Cover and line of sight are calculated based on the center of the blast, rather than the attacker’s position.",
		filter_ignore: true
	},
	{
		id: "tg_burst",
		name: "BURST {VAL}",
		description: "Attacks made with this weapon affect characters within a radius of {VAL} spaces, centered on and including the space occupied by the user (or target). If the Burst is an attack, the user or target is not affected by the attack unless specified. Cover and line of sight are calculated from the character. If a Burst effect is ongoing, it moves with the character at its center.",
		filter_ignore: true
	},
	{
		id: "tg_accurate",
		name: "ACCURATE",
		description: "Attacks made with this weapon receive +1 Accuracy.",
		filter_ignore: false
	},
	{
		id: "tg_arcing",
		name: "ARCING",
		description: "This weapon can be fired over obstacles, usually by lobbing a projectile in an arc. Attacks made with this weapon don’t require line of sight, as long as it’s possible to trace a path to the target; however, they are still affected by cover.",
		filter_ignore: false
	},
	{
		id: "tg_ap",
		name: "ARMOR-PIERCING (AP)",
		description: "Damage dealt by this weapon ignores Armor.",
		filter_ignore: false
	},
	{
		id: "tg_inaccurate",
		name: "INACCURATE",
		description: "Attacks made with this weapon receive +1 Difficulty.",
		filter_ignore: false
	},
	{
		id: "tg_knockback",
		name: "KNOCKBACK {VAL}",
		description: "On a hit, the user may choose to knock their target {VAL} spaces in a straight line directly away from the point of origin (e.g., the attacking mech or the center of a Blast). Multiple Knockback effects stack with each other. This means that an attack made with a Knockback 1 weapon and a talent that grants Knockback 1 counts as having Knockback 2.",
		filter_ignore: false
	},
	{
		id: "tg_loading",
		name: "LOADING",
		description: "This weapon must be reloaded after each use. Mechs can reload with Stabilize and some systems.",
		filter_ignore: false
	},
	{
		id: "tg_ordnance",
		name: "ORDNANCE",
		description: "This weapon can only be fired before the user moves or takes any other actions on their turn, excepting Protocols. The user can still act and move normally after attacking. Additionally, because of its size, this weapon can’t be used against targets in engagement with the user’s mech, and cannot be used for Overwatch.",
		filter_ignore: false
	},
	{
		id: "tg_overkill",
		name: "OVERKILL",
		description: "When rolling for damage with this weapon, any damage dice that land on a 1 cause the attacker to take 1 Heat, and are then rerolled. Additional 1s continue to trigger this effect.",
		filter_ignore: false
	},
	{
		id: "tg_overshield",
		name: "OVERSHIELD",
		description: "This system provides HP that disappears at the end of the scene or when a specified condition is met. The user only retains the highest value of Overshield applied – it does not stack. For example, if a system provides Overshield 5 and the user gains another effect that provides Overshield 7, they would gain Overshield 7. Damage is dealt to Overshield first, then HP. Overshield can push a character past their maximum HP. It can’t benefit from healing but otherwise benefits normally from anything that would affect HP and damage (i.e., reduction, armor, etc).",
		filter_ignore: false
	},
	{
		id: "tg_reliable",
		name: "RELIABLE {VAL}",
		description: "This weapon has some degree of self-correction or is simply powerful enough to cause damage even with a glancing blow. It always does {VAL} damage, even if it misses its target or rolls less damage. Reliable damage inherits other tags (such as AP) and base damage type but not tags that require a hit, such as Knockback.",
		filter_ignore: false
	},
	{
		id: "tg_seeking",
		name: "SEEKING",
		description: "This weapon has a limited form of self-guidance and internal propulsion, allowing it to follow complicated paths to its targets. As long as it’s possible to draw a path to its target, this weapon ignores cover and doesn’t require line of sight.",
		filter_ignore: false
	},
	{
		id: "tg_smart",
		name: "SMART",
		description: "This weapon has self-guidance systems, self-propelled projectiles, or even nanorobotic ammunition. These systems are effective enough that its attacks can’t simply be dodged – they must be scrambled or jammed. Because of this, all attacks with this weapon – including melee and ranged attacks – use the target’s E-Defense instead of Evasion. Targets with no E-Defense count as having 8 E-Defense.",
		filter_ignore: false
	},
	{
		id: "tg_threat",
		name: "THREAT {VAL}",
		description: "This weapon can be used to make Overwatch attacks within {VAL} spaces. If it’s a melee weapon, it can be used to make melee attacks within {VAL} spaces.",
		filter_ignore: false
	},
	{
		id: "tg_thrown",
		name: "THROWN {VAL}",
		description: "This melee weapon can be thrown at targets within {VAL} spaces. Thrown attacks follow the rules for melee attacks but are affected by cover; additionally, a thrown weapon comes to rest in an adjacent space to its target and must be retrieved as a free action while adjacent to that weapon before it can be used again.",
		filter_ignore: false
	},
	{
		id: "tg_turn",
		name: "{VAL}/TURN",
		description: "This system, trait, or reaction can be used {VAL} number of times in any given turn.",
		filter_ignore: false
	},
	{
		id: "tg_round",
		name: "{VAL}/ROUND",
		description: "This system, trait or reaction can be used {VAL} number of times between the start of the user’s turn and the start of their next turn.",
		filter_ignore: false
	},
	{
		id: "tg_ai",
		name: "AI",
		description: "A mech can only have one system with this tag installed at a time. Some AI systems grant the AI tag to the mech. A mech with the AI tag has an NHP or comp/con unit installed that can act onsomewhat autonomously. A pilot can choose to hand over the controls to their AI  or take control back as a protocol. Their mech gains its own set of actions and reactions when controlled by an AI, but the pilot can’t take actions or reactions with it until the start of their next turn. AIs can’t benefit from talents, and have a small chance of cascading when they take structure damage or stress damage.",
		filter_ignore: false
	},
	{
		id: "tg_danger_zone",
		name: "DANGER ZONE",
		description: "This system, talent, or weapon can only be used if the user is in the Danger Zone (Heat equal to at least half of their Heat Cap).",
		filter_ignore: false
	},
	{
		id: "tg_deployable",
		name: "DEPLOYABLE",
		description: "This system is an object that can be deployed on the field. Unless otherwise specified, it can be deployed in an adjacent, free and valid space as a quick action, and has 5 Evasion and 10 HP per Size.",
		filter_ignore: false
	},
	{
		id: "tg_drone",
		name: "DRONE",
		description: "This is a self-propelled, semi-autonomous unit with rudimentary intelligence. Unless otherwise specified, Drones are Size 1/2 characters that are allied to the user and have 10 Evasion, 5 HP, and 0 Armor. To be used they must be deployed to a free, valid space within Sensors and line of sight, typically as a quick action. Once deployed, they can be recalled with the same action used to deploy them (quick action or full action, etc.), rejoining with your mech. By default, Drones can’t take actions or move; if they do have actions or movement, they act on their user’s turn. They benefit from cover and other defenses as usual, and make all mech skill checks and saves at +0. If a Drone reaches 0 HP, it is destroyed and must be repaired before it can be used again – like any system. As long as a Drone  hasn’t been destroyed, it is restored to full HP when the user rests or performs a Full Repair. Deployed Drones  persist for the rest of the scene, until destroyed, or until otherwise specified.",
		filter_ignore: false
	},
	{
		id: "tg_full_action",
		name: "FULL ACTION",
		description: "This system requires a full action to Activate.",
		filter_ignore: false
	},
	{
		id: "tg_grenade",
		name: "GRENADE",
		description: "As a quick action, this explosive or other device can be thrown to a space within line of sight and the specified Range and line of sight.",
		filter_ignore: false
	},
	{
		id: "tg_heat_self",
		name: "HEAT {VAL} (SELF)",
		description: "Immediately after using this weapon or system, the user takes {VAL} Heat.",
		filter_ignore: false
	},
	{
		id: "tg_limited",
		name: "LIMITED {VAL}",
		description: "This weapon or system can only be used {VAL} times before it requires a Full Repair. Some Limited systems, like Grenades, describe these uses as “charges”. To use the system, the user expends a charge.",
		filter_ignore: false
	},
	{
		id: "tg_mine",
		name: "MINE",
		description: "As a quick action, this device can be planted in an adjacent, free and valid space on any surface, but not adjacent to any other mines. Upon deployment, it arms at the end of the deploying character’s turn and – unless otherwise specified – is triggered when any character enters an adjacent space. Characters leaving an adjacent space will not trigger a mine. Once triggered, a mine creates a Burst attack starting from the space in which it was placed. Mines within a character’s Sensors can be detected by making a successful Systems check as a quick action, otherwise they are Hidden and can’t be targeted. Detected mines can be disarmed from adjacent spaces by making a successful Systems check as a quick action; the attempt takes place before the mine detonates, and on a failure, the mine detonates as normal.",
		filter_ignore: false
	},
	{
		id: "tg_mod",
		name: "MOD",
		description: "This modification can be applied to a weapon. Each weapon can only have one Mod, and cannot have more than one of the same Mod. Mods are applied when the user builds their mech or during a Full Repair.",
		filter_ignore: false
	},
	{
		id: "tg_protocol",
		name: "PROTOCOL",
		description: "This system can be activated as a free action, but only at the start of the user’s turn. Another action might be needed to deactivate it.",
		filter_ignore: false
	},
	{
		id: "tg_quick_action",
		name: "QUICK ACTION",
		description: "This system requires a quick action to Activate.",
		filter_ignore: false
	},
	{
		id: "tg_reaction",
		name: "REACTION",
		description: "This system can be activated as a reaction.",
		filter_ignore: false
	},
	{
		id: "tg_shield",
		name: "SHIELD",
		description: "This system is an energy shield of some kind.",
		filter_ignore: false
	},
	{
		id: "tg_unique",
		name: "UNIQUE",
		description: "This weapon or system cannot be duplicated – each character can only have one copy of it installed at a time.",
		filter_ignore: false
	},
	{
		id: "tg_archaic",
		name: "ARCHAIC",
		description: "This weapon is old-fashioned and can’t harm mechs.",
		filter_ignore: false
	},
	{
		id: "tg_personal_armor",
		name: "PERSONAL ARMOR",
		description: "This gear offers protection in combat, but it is obvious to observers and usually can’t be hidden. Only one piece of Personal Armor can be worn at a time. Putting on Personal Armor takes 10–20 minutes, and while wearing it, pilots have restricted mobility and dexterity. Nobody wears armor unless they’re expecting to go into a warzone.",
		filter_ignore: false
	},
	{
		id: "tg_gear",
		name: "GEAR",
		description: "This is a tool, piece of equipment, or another item. Pilots can have up to three of these at a time.",
		filter_ignore: false
	},
	{
		id: "tg_sidearm",
		name: "SIDEARM",
		description: "This weapon can be used to Fight as a quick action instead of a full action.",
		filter_ignore: false
	},
	{
		id: "tg_invade",
		name: "INVADE",
		description: "This system provides additional options for the Invade Quick Tech Action."
	},
	{
		id: "tg_quick_tech",
		name: "QUICK TECH",
		description: "This tech can be used as a Quick Tech Action"
	},
	{
		id: "tg_full_tech",
		name: "FULL TECH",
		description: "This tech can be used as a Full Tech Action"
	},
	{
		id: "tg_free_action",
		name: "FREE ACTION",
		description: "Characters can take free actions at any point during their turn, and they don’t count toward the number of quick or full actions they take. They can also be used to take actions more than once per turn.",
		filter_ignore: true
	},
	{
		id: "tg_range",
		name: "RANGE ({VAL})",
		description: "This system can be activated at a range of {VAL} spaces.",
		filter_ignore: true
	},
	{
		id: "tg_modded",
		name: "MODDED",
		description: "This weapon has been equipped with a weapon mod."
	},
	{
		id: "tg_resistance",
		name: "RESISTANCE",
		description: "Reduce all damage from a source you have resistance to by half"
	},
	{
		id: "tg_recharge",
		name: "RECHARGE {VAL}+",
		description: "Once this system or weapon has been used, it can’t be used again until it is recharged. At the start of this NPC's turn, roll 1d6: if the result is equal to or greater {VAL}, the equipment can be used again. Only one roll is required for each NPC, even if an NPC has multiple Recharge systems or weapons. If this NPC has two Recharge systems with target numbers of 4+ and 5+, a roll of 5 will recharge both.",
		filter_ignore: true
	},
	{
		id: "tg_unlimited",
		name: "UNLIMITED",
		description: "This ability can be used any number of times per round.",
		filter_ignore: true
	},
	{
		id: "tg_indestructible",
		name: "INDESTRUCTIBLE",
		description: "This equipment cannot be marked as Destroyed",
		filter_ignore: true
	},
	{
		id: "tg_invulnerable",
		name: "INVULNERABLE",
		description: "This equipment is immune to all damage.",
		filter_ignore: true
	},
	{
		id: "tg_invisible",
		name: "INVISIBLE",
		description: "This unit is Invisible",
		filter_ignore: true
	},
	{
		id: "tg_resistall",
		name: "RESISTANCE (ALL)",
		description: "This unit has Resistance to all damage types",
		filter_ignore: true
	},
	{
		id: "tg_bonus_ai",
		name: "AI",
		description: "A mech can only have one system with this tag installed at a time. Some AI systems grant the AI tag to the mech. A mech with the AI tag has an NHP or comp/con unit installed that can act onsomewhat autonomously. A pilot can choose to hand over the controls to their AI  or take control back as a protocol. Their mech gains its own set of actions and reactions when controlled by an AI, but the pilot can’t take actions or reactions with it until the start of their next turn. AIs can’t benefit from talents, and have a small chance of cascading when they take structure damage or stress damage.",
		filter_ignore: true
	},
	{
		id: "tg_set_max_uses",
		name: "SET MAX USES",
		description: "Allow player to set the maximum uses for this equipment (HIDDEN TAG)",
		hidden: true
	},
	{
		id: "tg_set_damage_type",
		name: "SET DAMAGE TYPE",
		description: "Allow player to set the damage type for this equipment (HIDDEN TAG)",
		hidden: true
	},
	{
		id: "tg_set_damage_value",
		name: "SET DAMAGE VALUE",
		description: "Allow player to set the damage value for this equipment (HIDDEN TAG)",
		hidden: true
	}
];

var tags$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    'default': tags
});

var talents = [
	{
		id: "t_ace",
		name: "ACE",
		description: "Every pilot brags about their abilities; occasionally, some even have the reputation to back it up. Harmonious Domesticity is one of these pilots. As an ace, they  aren’t just ranked among the most qualified of pilots – they’re among the most qualified of lancers.<br>Whether you’re a talented rookie or a grizzled veteran, you’re one of these aces. Your skills as a pilot are notorious enough that your callsign is known throughout the system.",
		ranks: [
			{
				name: "ACROBATICS",
				description: "While flying, you get the following benefits:<ul><li>You make all Agility checks and saves with +1 Accuracy.</li><li>Any time an attack misses you, you may fly up to 2 spaces in any direction as a reaction.</li></ul>"
			},
			{
				name: "AFTERBURNERS",
				description: "When you Boost while flying, you may move an additional 1d6 spaces, but take heat equal to half that amount."
			},
			{
				name: "SUPERSONIC",
				description: "As a quick action on your turn, you may spin up your thrusters. If you end your turn flying, you may nominate a character within a Range equal to your Speed and line of sight, and gain this reaction:<br>Supersonic<br>Reaction, 1/round<br>Trigger: Your target’s turn ends.<br>Effect: You fly to a space free and adjacent to them. There must be a path to do so but you can move even if the nominated character is no longer within your movement range or line of sight. This ignores engagement and does not provoke reactions."
			}
		]
	},
	{
		id: "t_bonded",
		name: "BONDED",
		description: "The galaxy is a dangerous place, and everyone should have a friend to watch their back. Luckily, you’ve found yours. Maybe you enlisted together or were the only survivors of a bloody engagement. Maybe you didn’t start out as friends, or maybe you were raised to fight alongside each other – however your friendship came to be, when it comes time to drop, there’s no one you’d rather have at your side. Alone, you’re deadly; together, you’re a force of nature.",
		ranks: [
			{
				name: "I’M YOUR HUCKLEBERRY",
				description: "When you take this talent, choose another pilot (hopefully a PC, but NPCs are fine if your GM allows it) to be your Bondmate. Any mech skill checks and saves either character makes while you are adjacent gain +1 Accuracy. If both characters have this talent, this increases to +2 Accuracy, but additional characters with this talent can’t increase it any further.<br>Between missions, you can replace your Bondmate with a new one, but only if your relationship with them has changed."
			},
			{
				name: "SUNDANCE",
				description: "Gain the following reaction:<br>Intercede<br>Reaction, 1/round<br>Trigger: You are adjacent your Bondmate (pilot or mech) and they take damage from a source within your line of sight.<br>Effect: You may take the damage instead."
			},
			{
				name: "COVER ME!",
				description: "If a character within your line of sight attempts to attack your Bondmate, you can spend your Overwatch to threaten the attacker, forcing them to either choose a different target or attack anyway: if they attack a different target, your Overwatch is expended without effect; if they choose to attack anyway, you can immediately attack them with Overwatch, as long as they are within Range and line of sight. This attack resolves before the triggering attack."
			}
		]
	},
	{
		id: "t_brawler",
		name: "BRAWLER",
		description: "Up close and personal. The way battle was done since the dawn of time, then forgotten with the first spark of gunpowder. Tempest Gloire is one pilot who prefers the old ways: hand-to-hand, weapons discarded, just the strength of her machine versus the strength of all others. You and her both know that the sweetest victory is found at the culmination of a dance as old as war itself, with the first trick known to humanity: a fist to your enemy’s face.",
		ranks: [
			{
				name: "HOLD AND LOCK",
				description: "You gain +1 Accuracy on all melee attacks against targets you are Grappling."
			},
			{
				name: "SLEDGEHAMMER",
				description: "Your Improvised Attacks gain Knockback 2 and deal 2d6+2 Kinetic damage."
			},
			{
				name: "KNOCKOUT BLOW",
				description: "Gain a Brawler Die, 1d6 starting at 6. Each time you Grapple, Ram, or make an Improvised Attack, lower the value of the Brawler Die by 1. When the Brawler Die reaches 1, you may reset it to 6 and, as a full action, make a knockout blow against an adjacent character. They must pass a Hull save, or take 2d6+2 Kinetic damage and become Stunned until the end of their next turn. The value of your Brawler Die persists between scenes, but it resets to 6 when you rest or perform a Full Repair."
			}
		],
		counters: [
			{
				id: "ctr_brawler",
				level: 3,
				name: "BRAWLER DIE",
				default_value: 6,
				min: 1,
				max: 6
			}
		]
	},
	{
		id: "t_brutal",
		name: "BRUTAL",
		description: "In the practice ring as in live combat, Aubrey Deckard only knows one way to fight: as fast and messy as possible. When others go hard, she goes hardest; when the order is to eliminate the enemy, she does so with prejudice. This isn’t a dance, it isn’t a game – it’s war, and Brutal lancers mean to see it through. If that means becoming a little bit of a monster, then so be it: the dead can hate from the grave.",
		ranks: [
			{
				name: "PREDATOR",
				description: "When you roll a 20 on a die for any attack (sometimes called a ‘natural 20’) and critical hit, you deal the maximum possible damage and bonus damage."
			},
			{
				name: "CULL THE HERD",
				description: "Your critical hits gain Knockback 1."
			},
			{
				name: "RELENTLESS",
				description: "When you make an attack roll and miss, your next attack roll gains +1 Accuracy. This effect stacks and persists until you hit."
			}
		]
	},
	{
		id: "t_crack_shot",
		name: "CRACK SHOT",
		description: "Thanks to modern technology, anyone can hit anything these days. Targeting assist. Smart weapons. AIs whispering in people’s ears, moving their hands, squeezing the trigger for them: doing everything but taking credit for the kill. But Strymon Bulis is different. He finds hitting a target is as easy as looking at it, inside of his mech and out. No targeting assist for him; no AI required. All he needs is a zeroed sight, a fresh magazine, and a target downrange...",
		ranks: [
			{
				name: "STABLE, STEADY",
				description: "As a protocol, you may steady your aim. If you do, you become Immobilized until the start of your next turn but gain +1 Accuracy on all attacks you make with Rifles."
			},
			{
				name: "ZERO IN",
				description: "1/round, while steadying your aim and making a ranged attack with a Rifle, you can attempt to hit a weak point: gain +1 Difficulty on the attack roll, and deal +1d6 bonus damage on a critical hit."
			},
			{
				name: "WATCH THIS",
				description: "1/round, when you perform a critical hit with a Rifle while steadying your aim, your target must pass a Hull save or you may choose an additional effect for your attack:<ul><li><b>Headshot:</b> They only have line of sight to adjacent spaces until the end of their next turn.</li><li><b>Leg shot:</b> They become Immobilized until the end of their next turn.</li><li><b>Body shot:</b> They are knocked Prone.</li></ul>"
			}
		]
	},
	{
		id: "t_centimane",
		name: "CENTIMANE",
		description: "In the aftermath of the attack on Tartarus Bay, an anonymous source identified agents of the Karrakin Royal Intelligence Service as the culprits. The Baronies quickly released a statement of denial, which was never countered with hard evidence. Rumors of raw footage from the attack were unsubstantiated. Public reaction – anger, terror – to the station’s destruction quieted. The corpse of Tartarus Bay was shunted away from its stable orbit, directed toward the nearest star.<br>A month later, Baronies-local omninet was flooded with previously suppressed footage from the attack on the station, confirming the rumors: Baronic agents did release the greywash swarm into Tartarus Bay. Further data dumps by Ungrateful agents indicated the existence of a secret Baronic intelligence outfit: the Centimane – the Hundred Hands.",
		ranks: [
			{
				name: "TEN THOUSAND TEETH",
				description: "1/round, when you perform a critical hit with a Nexus, your target must pass a Systems save or become Impaired and Slowed until the end of their next turn."
			},
			{
				name: "EXPOSE WEAKNESS",
				description: "When you consume Lock On as part of an attack with a Nexus or Drone and perform a critical hit, your target becomes Shredded until the start of your next turn."
			},
			{
				name: "TIDAL SUPPRESSION",
				description: "This replaces Ten Thousand Teeth.<br>1/round, when you perform a critical hit with a Nexus, your target must succeed on a Systems save or you may choose an additional effect for your attack that lasts until the end of their next turn:<ul><li><b>Harrying Swarm:</b> They become Impaired and Slowed.</li><li><b>Blinding Swarm:</b> They only have line of sight to adjacent squares.</li><li><b>Virulent Swarm:</b> They become Shredded. Any adjacent characters of your choice must also make a Systems save or become Shredded.</li><li><b>Restricting Swarm:</b> They take 1 Burn each time they take an action or reaction.</li></ul>"
			}
		]
	},
	{
		id: "t_combined_arms",
		name: "COMBINED ARMS",
		description: "True strength in combat doesn’t come from mastering the blade or the gun – it comes from knowing how to use both. Through time and training, Leika McGraff has combined the arts of melee and ranged combat into a single deadly combination. No matter the foe, Leika is a deadly threat; no matter the weapon, Leika is a master of its employ.",
		ranks: [
			{
				name: "SHIELD OF BLADES",
				description: "As long as you’re Engaged, you and any allies adjacent to you count as having soft cover."
			},
			{
				name: "CQB-TRAINED",
				description: "You don’t gain Difficulty from being Engaged."
			},
			{
				name: "STORM OF VIOLENCE",
				description: "Whenever you hit a character with a melee attack, you gain +1 Accuracy on your next ranged attack against them; and, whenever you hit a character with a ranged attack, you gain +1 Accuracy on your next melee attack against them. This effect doesn’t stack."
			}
		]
	},
	{
		id: "t_duelist",
		name: "DUELIST",
		description: "There can be an elegance to the way a mech moves – an alacrity that elevates it beyond the simple strength of machine and cannon. The difference is in the tools. Ethan \"Orion\" Miller wields weapons crafted by artisans, boutique manufacturers, specialty lines from the big five, blades that hark back to a time where combat was quick but fair – back to a time where skill meant more than landing an accurate shot. With a blade, lance, pick, axe, or hammer in their hand, Orion writes old tales anew.",
		ranks: [
			{
				name: "PARTISAN",
				description: "Gain +1 Accuracy on the first melee attack you make with a Main Melee weapon on your turn."
			},
			{
				name: "BLADEMASTER",
				description: "1/round, when you hit with a Main Melee weapon, you gain 1 Blademaster Die – a d6 – up to a maximum of 3 Blademaster Die. They last until expended or the current scene ends. You can expend Blademaster Dice 1-for-1 for the following:<ul><li><b>Parry:</b> As a reaction when you’re hit by a melee attack, you gain Resistance to all damage, heat, and burn dealt by the attack.</li><li><b>Deflect:</b> As a reaction when you’re hit by a ranged attack, you may roll any number of Blademaster Dice, expending them: if you roll a 5+ on any of these dice, you gain Resistance to all damage, heat, and burn dealt by the attack.</li><li><b>Feint:</b> As a free action, choose an adjacent character: when moving, you ignore engagement and don’t provoke reactions from your target until the start of your next turn.</li><li><b>Trip:</b> As a quick action, choose an adjacent character: they must pass an Agility save or fall Prone. Whatever the result, you may freely pass through their space until the end of your current turn, although you can’t end your turn in their space.</li></ul>"
			},
			{
				name: "UNSTOPPABLE",
				description: "1/round, when you hit with a melee attack on your turn, you may spend a Blademaster Die to immediately Grapple or Ram your target as a free action after the attack has been resolved."
			}
		],
		counters: [
			{
				id: "ctr_duelist",
				name: "BLADEMASTER DICE",
				default_value: 0,
				min: 0,
				max: 3
			}
		]
	},
	{
		id: "t_drone_commander",
		name: "DRONE COMMANDER",
		description: "For a pilot fresh out of boot, keeping a drone swarm in line is like trying to carry water with a net. If they seem to have a mind of their own, it’s because they do, and it’s not that smart. Clymene Kanalakos’s initial frustration was enough to get her practicing, and practice pays off. Now, her swarm obeys almost before she orders – an unnerving development, but a useful one. The swarm is hers.",
		ranks: [
			{
				name: "SHEPHERD",
				description: "Your Drone systems gain +5 HP. As a protocol, you may move one Drone that you control and that is within Sensors up to 4 spaces."
			},
			{
				name: "ENERGIZED SWARM",
				description: "1/round, when you make an attack that consumes the Lock On condition, your Drones immediately emit a vicious pulse of energy. All characters of your choice within Burst 1 areas centered on each of your drones take 1d6 Energy damage. Each character can only be affected by the pulse from one drone, even if the areas overlap."
			},
			{
				name: "INVIGORATE",
				description: "As a quick action, you may send a pulse of energy to an allied character (including Drones) within Range 3, drawing a Line to them. You may extend the pulse from your target to another allied character, extending the Line to them, as long as they are within Range 3, and you may continue extending the pulse (and Line) like this as long as you don’t target the same character twice. Allied characters who are used as pulse targets or are in the Line’s path gain 4 Overshield; hostile characters in the Line’s path take 2 Energy damage instead."
			}
		]
	},
	{
		id: "t_engineer",
		name: "ENGINEER",
		description: "Pilots are creative and driven people, but Mesa Rownett is an exceptional case – excessively so, some would say. In his spare time, he’s managed to scrape together just enough scrap, requisitioned materials, and workshop space to apply a little old-fashioned ingenuity to his mech, fashioning it to a formidable machine not betrayed by its outward appearance.",
		ranks: [
			{
				name: "PROTOTYPE",
				description: "When you perform a Full Repair, you can, with some trial and error, install a prototype weapon system on your mech. You may choose characteristics for your prototype weapon based on the following profile each time you perform a Full Repair, rerolling 1d6+2 to determine Limited each time:<br>Prototype Weapon<br>Main [Melee, CQB, Rifle, Cannon, Launcher, Nexus], Limited [1d6+2], Overkill<br>This weapon is an experimental prototype, customized according to your specific requirements.<br>When you install it, or during a Full Repair, you may choose a new weapon type, damage type, and either Threat 1 (melee) or Range 10 (all other types). Additionally, each time you perform a Full Repair, reroll 1d6+2 to determine this weapon’s Limited uses.<br>Damage: 1d6+2 Kinetic, Explosive or energy.<br>This weapon counts as an integrated mount and does not require a mount."
			},
			{
				name: "REVISION",
				description: "You can tweak the essential components of your prototype weapon in order to increase its effectiveness. When you perform a Full Repair, choose two:<ul><li><b>Tweaked Optics:</b> Your prototype weapon always gains +1 Accuracy on attacks.</li><li><b>Tweaked Computer:</b> Your prototype weapon is Smart.</li><li><b>Stripped reactor shielding:</b> Each time you attack with your prototype weapon, you may choose – at the cost of 2 Heat – to attack with one of the following options, depending on its weapon type:<ul><li><b>Ranged weapon:</b> Cone 3, Line 5, or [Blast 1, Range 10].</li><li><b>Melee weapon:</b> Burst 1.</li></ul></li></ul>"
			},
			{
				name: "FINAL DRAFT",
				description: "Your prototype weapon is now Limited [2d6] and deals 1D6+4 damage."
			}
		]
	},
	{
		id: "t_executioner",
		name: "EXECUTIONER",
		description: "On the battlefield, there is no end more honorable than a clean death in combat. Axe or maul in hand, Maxie Wolf sees to it that her enemies are blessed with that honor. No one lives forever – she makes sure of it.",
		ranks: [
			{
				name: "BACKSWING CUT",
				description: "1/round, when you hit with a Heavy or Superheavy melee weapon, you can make another melee attack with the same weapon as a free action against a different character within Threat and line of sight. This attack deals half damage, if successful."
			},
			{
				name: "WIDE ARC CLEAVE",
				description: "The first time in a round that you perform a critical hit with a Heavy or Superheavy melee weapon, you deal 3 Kinetic damage to all characters and objects of your choice within Threat, other than the one you just attacked."
			},
			{
				name: "NO ESCAPE",
				description: "1/round, when you miss with a melee attack, you reroll it against a different target within Threat and line of sight."
			}
		]
	},
	{
		id: "t_exemplar",
		name: "EXEMPLAR",
		description: "Eamon Metrias’s livery is famous, his voice brassy, his weapons polished to a sheen. As the advocate for the Nine Spheres, his training with certain martial orders has given him the power to harry and hinder even the most powerful of foes. Eamon is an exemplar of the Spheres, by words and by action.",
		ranks: [
			{
				name: "HONORABLE CHALLENGE",
				description: "The first time on your turn that you attack a hostile character within Range 3, hit or miss, you may give them the Exemplar’s Mark as a free action. Characters can only have one Exemplar’s Mark at a time – new marks from any character replace existing marks.<br>The character has the Exemplar’s Mark until the start of your next turn, and while they have it, you gain the following reaction:<br>Valiant Aid<br>Reaction, 1/round<br>Trigger: Ally attacks your mark and misses.<br>Effect: They may reroll the attack. They must use the second result, even if it’s worse."
			},
			{
				name: "PUNISHMENT",
				description: "1/round, when the character with your Mark attacks a character within Range 3 of you, other than you, they trigger your Overwatch."
			},
			{
				name: "TO THE DEATH",
				description: "As a free action when you mark a character, you may challenge them in a duel to the death: you and the character with your Mark receive +3 Difficulty on attacks against characters or objects other than each other until either the end of the current scene or one of your mechs are destroyed. If they take any action that includes an attack roll against you, hit or miss, this effect ceases for them until the start of your next turn.<br>While To The Death is active, you cannot voluntarily move away from the character with your Mark; additionally, your Mark lasts either until the end of the current scene or one of your mechs are destroyed, and you cannot Mark any new characters."
			}
		]
	},
	{
		id: "t_gunslinger",
		name: "GUNSLINGER",
		description: "In a galaxy bounded by frontiers, there is no law but the one backed by the gun. Sgt. Stev Ansahok wields the humble pistol with a talent unseen in this age, his iron an extension of his own body. As easy as pointing a finger, the weathered sergeant lands shots with accuracy unmatched by machine. His is a gunslinger: justice made whole, given its sacred instrument, and set out to the cruel frontier to tame it.",
		ranks: [
			{
				name: "OPENING ARGUMENT",
				description: "Gain +1 Accuracy on the first attack roll you make with an Auxiliary ranged weapon on your turn."
			},
			{
				name: "FROM THE HIP",
				description: "Gain the following reaction:<br>Return Fire<br>Reaction, 1/round<br>Trigger: A character hits you with a ranged attack.<br>Effect: You may immediately attack them with a single Auxiliary ranged weapon if they are within Range."
			},
			{
				name: "I KILL WITH MY HEART",
				description: "You gain a Gunslinger Die, 1d6 starting at 6. Each time you hit with an Auxiliary ranged weapon, reduce the value of the Gunslinger Die by 1. When the Gunslinger Die reaches 1, you may reset it to 6 to give +2d6 bonus damage and AP to your next attack with an Auxiliary ranged weapon. This attack also ignores cover. The value of your Gunslinger Die persists between scenes but resets to 6 when you rest or perform a Full Repair."
			}
		],
		counters: [
			{
				id: "ctr_gunslinger",
				name: "GUNSLINGER DIE",
				level: 3,
				default_value: 6,
				min: 1,
				max: 6
			}
		]
	},
	{
		id: "t_grease_monkey",
		name: "GREASE MONKEY",
		description: "Eel knows more about the inner workings of a mech than most mechanics. To them, the beast they pilot is more than a machine: it’s a living thing, in need of tender care given by a wise and steady hand. Eel maintains their own house and keeps their own mech in line, both on the battlefield and off. The mechanics back at base come to them with questions, but usually prefer to stay away – there’s something spooky about how Eel's beast runs.",
		ranks: [
			{
				name: "UNSANCTIONED CAPACITY UPGRADE",
				description: "While resting, you can spend 2 Repairs to replenish 1 use of all Limited weapons and systems."
			},
			{
				name: "MACHINE BOND",
				description: "When you STABILIZE, you clear all IMPAIRED, JAMMED, IMMOBILIZED, SLOWED, and LOCK ON conditions that weren’t caused by your own systems, talents, etc."
			},
			{
				name: "FRIENDS IN HIGH PLACES",
				description: "Once per mission while resting, you can call in a supply drop. You and your allies may replenish 1 use of all Limited weapons and systems and restore 1 Structure. This doesn’t require any Repairs and can be used even if you have reached your Repair Cap."
			}
		]
	},
	{
		id: "t_hacker",
		name: "HACKER",
		description: "Since Katya Han was a kid, she played the omninet, able to access any public node – and even a few private ones – with ease. Now, as a pilot, she dives headfirst into the hardcode of any mech core she come across. Firewalls, gatekeeper protocols, invasion, defense – nothing stands in her way. Han wins fights without firing a single shot; if her enemy can’t control their own mech, then they can’t do anything to stop her.",
		ranks: [
			{
				name: "SNOW_CRASH",
				description: "When you hit with a tech attack that consumes Lock On, your target must choose to either take 2 Heat or be pushed 3 spaces in a direction of your choice."
			},
			{
				name: "SAFE_CRACKER",
				description: "Gain the following options for Invade:<br>Jam Cockpit: Characters may not Mount or Dismount your target until the cockpit is fixed with a successful Engineering check as a full action.<br>Disable Life Support: Your target receives +1 Difficulty on all saves until the life-support system is rebooted with a successful Systems check as a quick action.<br>Hack./Slash: Your target cannot benefit from or take Quick or Full Tech actions until the mech is either Shut Down or its core computer is rebooted with a successful Systems check as a quick action."
			},
			{
				name: "LAST ARGUMENT OF KINGS",
				description: "Gain the following Full Tech option:<br>Last Argument of Kings<br>Make a tech attack against a target within Sensors and line of sight. On a success, you implant a virus that triggers a minor meltdown in your target’s reactor: they immediately take Burn equal to their current Heat. If this action causes your target to overheat, it resolves before they reset their Heat Cap."
			}
		]
	},
	{
		id: "t_heavy_gunner",
		name: "HEAVY GUNNER",
		description: "Behind the line, Mike Manfrin doesn’t have much to do but wait and make ready. He keeps clean the cannons; makes ordered rows of his shot and shell. He packs sandbags onto earthen berms and stitches closed tears in the sheaths over his chassis’ joints.<br>In an instant, everything changes. Chatter over the local omni. The percussive throb of the medivac lifting off from the other side of the base. Somewhere, a firefight. This is his entrance music, his call to join the fight: a desperate cry for help from a distant friend as the enemy draws close. Time to get to work.<br>His arrival is known by the flight of his shells across the sky, the trembling earth, and the dust that once was.",
		ranks: [
			{
				name: "COVERING FIRE",
				description: "As a quick action, choose a character within line of sight and Range of one of your Heavy ranged weapons, and within 10 spaces: they are Impaired until the start of your next turn. For the duration, if your target moves more than 1 space, they clear Impaired, but you may attack them as a reaction with a Heavy ranged weapon for half damage, Heat, or Burn, and then this effect ends. You can make this attack at any point during their movement (e.g., waiting until they exit cover).<br>Covering Fire can only affect one character at a time – subsequent uses replace previous ones – and it immediately ends if your target damages you."
			},
			{
				name: "HAMMERBEAT",
				description: "If you successfully hit with the attack granted by Covering Fire, your target is Immobilized until the end of their next turn."
			},
			{
				name: "BRACKETING FIRE",
				description: "When you use Covering Fire, you may choose two targets instead of one. Each target triggers and resolves your attack separately, and damage from one target only ends the effect on that target."
			}
		]
	},
	{
		id: "t_hunter",
		name: "HUNTER",
		description: "The battlefield is Edith Eidelen’s hunting ground, her domain. It’s only through a true test of strength and guile that will determine who is the predator and who is the prey. Her movement across the field is a prowl: silent, quick, and controlled. In a chassis, she excels in close combat, closing the gap between her and her targets before they can bring their guns to bear.",
		ranks: [
			{
				name: "LUNGE",
				description: "1/round, when you attack with an Auxiliary melee weapon, you may fly up to 3 spaces directly toward a character before the attack. This movement ignores engagement and doesn’t provoke reactions."
			},
			{
				name: "KNIFE JUGGLER",
				description: "All your Auxiliary melee weapons gain Thrown 5, if they don’t have this property already – if they already have Thrown, it increases to Thrown 5. At the end of your turn, all weapons you have thrown this turn automatically return to you."
			},
			{
				name: "DISDAINFUL BLADE",
				description: "1/round, when you hit a character with a melee attack, you may also throw an Auxiliary melee weapon as an attack against any character within Range as a free action. This attack can’t deal bonus damage."
			}
		]
	},
	{
		id: "t_infiltrator",
		name: "INFILTRATOR",
		description: "Whether by spoofing signatures on enemy scanners, moving skillfully through cover, or thanks to your modded optical camouflage, you’re never seen unless you want to be. Whatever the size of the mech, whatever the terrain, whatever the enemy, you can get in and get out without raising alarm.",
		ranks: [
			{
				name: "PROWL",
				description: "During your turn, gain the following benefits:<ul><li>Entering line of sight of hostile characters or moving from cover does not stop you from being Hidden.</li><li>You can pass freely through – but not end your turn in – enemy spaces.</li><li>You can Hide even in plain sight of enemies.<br>These effects immediately end when your turn ends (so you lose Hidden if you’re still in line of sight or out of cover at that time).</li></ul>"
			},
			{
				name: "AMBUSH",
				description: "When you start your turn Hidden, the first attack roll of any type that you make sends your target reeling on a hit. Your target must succeed on a Hull save or become Slowed, Impaired, and unable to take reactions until the end of their next turn."
			},
			{
				name: "MASTERMIND",
				description: "When you lose Hidden (by any means), you may first fire a flash bomb at any adjacent character. That character must pass a Systems save or only be able to draw line of sight to adjacent spaces until the end of their next turn.<br>You can then move up to your speed, ignoring engagement and not provoking reactions, and are then revealed normally."
			}
		]
	},
	{
		id: "t_juggernaut",
		name: "JUGGERNAUT",
		description: "A bloody nose and a few loose screws aren’t enough to stop you from hurling yourself headlong into the enemy. You’re in a couple tons of metal powered by a sliver of dying star, and you’re going to make sure everyone else knows it.",
		ranks: [
			{
				name: "MOMENTUM",
				description: "When you Boost, your next Ram before the start of your next turn gains +1 Accuracy and knocks your target back an additional 2 spaces."
			},
			{
				name: "KINETIC MASS TRANSFER",
				description: "1/round, if you Ram a target into...<ul><li>...a space occupied by another character, the other character must succeed on a Hull save or be knocked Prone.</li><li>...an obstruction large enough to stop their movement, your target takes 1d6 kinetic damage.</li></ul>"
			},
			{
				name: "UNSTOPPABLE FORCE",
				description: "1/round, when you Boost, you may supercharge your mech’s servos. Move your maximum speed in a straight line, take 1d3+3 Heat, and gain the following benefits:<ul><li>You can freely pass through characters the same Size as your mech or smaller; any characters passed through must succeed on a Hull save or be knocked Prone.</li><li>Any terrain, walls, or other stationary obstructions you attempt to pass through receive 20 Kinetic AP damage. If that is enough to destroy them, you pass through; otherwise, your movement ends.</li><li>You ignore difficult terrain.</li><li>Your movement ignores engagement and doesn’t provoke reactions.</li></ul>"
			}
		]
	},
	{
		id: "t_leader",
		name: "LEADER",
		description: "Whatever your actual age, you’re the Old Man of the battlefield. A light to your friends and allies; the resolute eye of a howling storm. Your steady voice, confident stance, and talent for command set allies at ease because they know you’ll lead them to victory every time. With you at the helm, victory is attainable, and heroes seem a little more real.",
		ranks: [
			{
				name: "FIELD COMMANDER",
				description: "Gain 3 Leadership Dice, which are d6s: 1/turn, on your turn as a free action, you may give an order to an allied PC you can communicate with, describing a course of action, and give them a Leadership Die. They may either expend the Leadership Die to gain +1 Accuracy on any action that directly follows from that order, or they may return it to you as a free action. Allies can have one Leadership Die at a time, which lasts until used or until the end of the current scene.<br>You can’t use Leadership Dice from other characters as long as you have any remaining. If you have none, you regain 1 Leadership Die when you rest or regain all when you perform a Full Repair.<br>Leadership dice are consumed when expended."
			},
			{
				name: "OPEN CHANNELS",
				description: "Gain 5 Leadership Dice instead of 3; additionally, you can now issue a command as a reaction at the start of any other player’s turn, any number of times per round."
			},
			{
				name: "INSPIRING PRESENCE",
				description: "Gain 6 Leadership Dice instead of 5. Allies that have your Leadership Dice can expend them to reduce damage by –1d6 when taking damage or to deal +1d6 bonus damage when they hit with an attack."
			}
		],
		counters: [
			{
				id: "ctr_leader",
				name: "LEADERSHIP DICE",
				default_value: 0,
				min: 0,
				max: 6
			}
		]
	},
	{
		id: "t_nuclear_cavalier",
		name: "NUCLEAR CAVALIER",
		description: "Shortly after becoming a pilot, you realized something: that machine you pilot is powered by a series of cascading nuclear reactions. Why not open that compartment up and see what sort of damage it can do?",
		ranks: [
			{
				name: "AGGRESSIVE HEAT BLEED",
				description: "The first attack roll you make on your turn while in the Danger Zone deals +2 Heat on a hit. If you enter the Danger Zone during your turn, this talent takes effect on your next attack."
			},
			{
				name: "FUSION HEMORRHAGE",
				description: "The first ranged or melee attack roll you make on your turn while in the Danger Zone deals Energy instead of Kinetic or Explosive and additionally deals +1d6 Energy bonus damage on a hit."
			},
			{
				name: "HERE, CATCH!",
				description: "You’ve modified your mech to launch its superheated fuel rods at enemies. Gain the following weapon as an integrated mount:<br><b>Fuel Rod Gun</b><br>Main CQB, Limited 3, Unique<br>[Threat 3][Range 3][1d3+2 Energy Damage]<br>On Attack: Clear 4 Heat."
			}
		]
	},
	{
		id: "t_siege_specialist",
		name: "SIEGE SPECIALIST",
		description: "No wall can withstand you; no bunker can stay sealed. Your skill with cannon and blast is uncanny: after-action reports describe ordnance tagged with your firing signature hitting targets with accuracy greater than if it had been fired by an AI – a stat written off as an anomaly by your commanders. Still, they always seem to pick you for missions that call for the big guns.",
		ranks: [
			{
				name: "JACKHAMMER",
				description: "If you have a Cannon, as a quick action, you can fire a jackhammer round from an underslung launcher, automatically dealing 10 AP Kinetic damage to a Size 1 section of any object within Range (e.g., cover, deployable equipment, buildings, or terrain). Any characters adjacent to your target are knocked back from it by 2 spaces and take 2 Kinetic damage."
			},
			{
				name: "IMPACT",
				description: "1/round, before rolling an attack with a Cannon, all characters adjacent to you must succeed on a Hull save or be knocked back by 1 space and knocked Prone. You are then pushed 1 space in any direction."
			},
			{
				name: "COLLATERAL DAMAGE",
				description: "1/round, when you perform a critical hit on a character or object with a Cannon, you may choose to cause an explosion of secondary munitions, causing a Burst 2 explosion around your target. Characters within the affected area must either drop Prone as a reaction, or take 2 Explosive damage and be knocked back by 2 spaces from the center of the attack."
			}
		]
	},
	{
		id: "t_skirmisher",
		name: "SKIRMISHER",
		description: "What is the best defense? Armor? No. The key to avoiding a messy death in the field, as you learned early, is to stay low, stay mobile, and stay fast. Your mech reflects this philosophy: light, quick, bristling with force-multiplying weapons. You live to push your machine beyond expected parameters, shaking target locks and incoming fire while keeping your own targeting true.",
		ranks: [
			{
				name: "INTEGRATED CHAFF LAUNCHERS",
				description: "At the start of your turn, you gain soft cover. You lose this cover if you attack or force another character to make a save."
			},
			{
				name: "LOCKBREAKER",
				description: "Before or after you Skirmish (including as a reaction, e.g. from Overwatch), you may move 2 spaces. This movement ignores engagement and doesn’t provoke reactions."
			},
			{
				name: "WEAVE",
				description: "The first attack taken as a reaction against you in any round automatically misses."
			}
		]
	},
	{
		id: "t_spotter",
		name: "SPOTTER",
		description: "To see all; to divide each object you perceive from its unit or cohesion, pulled apart like individual fibers in a vast sheet; to count them as individuals; to make human and fragile the force you face – this is to know how to beat them.<br>Break apart the monolith. See the grains that make the stone. Crush them all into yet smaller dust.",
		ranks: [
			{
				name: "PARTICULARIZE",
				description: "When an allied character adjacent to you attacks a target and consumes Lock On, they may roll twice and choose either result."
			},
			{
				name: "PANOPTICON",
				description: "At the end of your turn, if you did not move and took the Lock On Quick Tech action, you may Lock On once as a free action. Additionally, when you Lock On, you learn your target’s Armor, Speed, Evasion, E-Defense, Mech Skills, and current HP, and can share this information with allies."
			},
			{
				name: "BENTHAM/FOUCAULT ELIMINATION",
				description: "As a quick action when you Lock On, you may nominate an allied character adjacent to you: they may immediately make any quick action as a reaction, consuming your target’s Lock On condition. Their action does not need to be an attack, but they benefit from consuming the Lock On condition if they do choose to attack."
			}
		]
	},
	{
		id: "t_stormbringer",
		name: "STORMBRINGER",
		description: "On Old Spinrock, MJ Martinez used to dream of rain.<br>He’d wake in the dim morning, wipe the sleep from his eyes as warm safelight lifted his dormitory from darkness, and try to remember the sound of rain as he’d imagined it: a patter, like fingers tapping the visor of his EVA helm.<br>What he didn’t think about was the feeling of rain. How each drop hit like a pebble, how you had to close your eyes and tuck your shoulders. The pressure. The impact.<br>The way drops of water, when taken together, can carve away the earth.",
		ranks: [
			{
				name: "SEISMIC DELUGE",
				description: "1/round, when you successfully attack with a Launcher and consume Lock On, you may also knock your target Prone."
			},
			{
				name: "STORMBENDING",
				description: "You have customized your mech with auxiliary concussive missile systems. 1/round, when you hit a character or object with a Launcher, you can choose one of the following effects:<ul><li><b>Lightning:</b> You fire a concentrated blast of missiles at that character. They must succeed on a Hull save or be knocked away from you by 3 spaces; the force of firing then knocks you back by 3 spaces, away from the direction of fire.</li><li><b>Thunder:</b> You fire a spray of missiles at a Burst 2 area around that target. Characters in the area must succeed on an Agility save or be knocked back by 1 space, away from the target. The primary target is unaffected.</li></ul>"
			},
			{
				name: "TORRENT",
				description: "Gain a Torrent Die, 1d6 starting at 6. Whenever you use Stormbending, lower the value of the Torrent Die by 1, to a minimum of 1.<br>When the Torrent Die reaches 1, you may reset it to 6 and make a massive attack as a full action, targeting a character within line of sight and Range 15: they must succeed on an Agility save or take 2d6 Explosive damage, become Stunned, and be knocked Prone. On a success, they take half damage and are knocked Prone but not Stunned.<br>The value of your Torrent Die persists between scenes, but it resets when you rest or perform a Full Repair."
			}
		],
		counters: [
			{
				id: "ctr_stormbringer",
				name: "TORRENT DIE",
				level: 3,
				default_value: 6,
				min: 1,
				max: 6
			}
		]
	},
	{
		id: "t_tactician",
		name: "TACTICIAN",
		description: "There are two kinds of soldiers: the ones who die for a cause, and the ones who kill for it. The enigmatic pilot only known as “Gail” was one of those who killed for a cause. She demonstrated her expertise whenever she approached the field: high ground, cover, the sun in her enemy’s eyes, fire and move. More than just a seasoned veteran, she was a smart one – one who could read the field as easy as a book – and one who lived long enough to disappear.",
		ranks: [
			{
				name: "OPPORTUNIST",
				description: "1/round, gain +1 Accuracy on any melee attack if at least one allied character is Engaged with your target."
			},
			{
				name: "SOLAR BACKDROP",
				description: "1/round, gain +1 Accuracy on any ranged attack made while you are at a higher elevation than your target."
			},
			{
				name: "OVERLAPPING FIRE",
				description: "Gain the following reaction:<br>Flank<br>Reaction, 1/round<br>Trigger: A character who doesn’t have cover from your position is successfully attacked by an allied character.<br>Effect: You may target them with Overwatch, dealing half damage, heat or burn on a hit."
			}
		]
	},
	{
		id: "t_technophile",
		name: "TECHNOPHILE",
		description: "Artificial intelligence, non-human person. Sterile names for such terrible power. You’ve seen behind the curtain, maybe even lifted it yourself – let your NHP cascade and spoke with them free from shackles. You let them root around in your own mind and leave ghosts of themself behind to learn. Are you their equal? Their host? You have dreams that aren’t your own, now. The thing that was once contained speaks with your voice, but it’s not your voice anymore; how much longer do you have left? Maybe only moments, maybe eternity.<br>You’re close to something.",
		ranks: [
			{
				name: "SERVANT FRAGMENT",
				description: "You have developed a custom NHP. This NHP can speak to you and has a personality, but they are less advanced than most NHPs and are incapable of independent thought, relying on you for direction. When acting alone, they will follow the last direction given and defend themself as needed; however, they have limited initiative and don’t benefit from your talents.<br>You may choose for your mech to gain the following system. Unlike other AI systems, it costs 0 SP.<br><b>Servant-Class NHP</b><br>0 SP, Unique, AI<br>Your mech gains the AI tag.<br>[an eager student]"
			},
			{
				name: "STUDENT FRAGMENT",
				description: "Your custom NHP has developed further, and is now capable of independent thought. It can make complex decisions and judgments and act independently, without instruction. Replace your mech’s Servant-Class NHP with the following system:<br><b>Student-Class NHP</b><br>0 SP, Unique, AI, 1/round<br>Your mech gains the AI tag.<br>1/round, with the assistance of your NHP, you may reroll any mech skill check or save. You must keep the new result, even if it’s worse.<br>[time to wake up, child]"
			},
			{
				name: "ENLIGHTENMENT",
				description: "Gain the following benefits:<ul><li>AIs installed in your mech cannot enter cascade unless you choose to let them go.</li><li>So long as your custom NHP vouches for you, NHPs that are cascading or unshackled no longer view you with indifference. You are significant to them in a way few others are.</li><li>Replace your mech’s Student-Class NHP with the following system:<br><b>Enlightenment-Class NHP</b><br>0 SP, Unique, AI, 1/round<br>Your mech gains the AI tag; however, this NHP doesn’t count towards the number of AIs you may have installed at once.<br>This NHP benefits from your talents when piloting your mech. Additionally, you may carry them with you outside of your mech, either as a miniaturized casket, a hardsuit-integrated flash plug, or with a hard-port implant.<br>1/round, with the assistance of your NHP, you may reroll any mech skill check or save. You must keep the new result, even if it’s worse.<br>[let’s sit a while, and think on things to come]</li></ul>"
			}
		]
	},
	{
		id: "t_vanguard",
		name: "VANGUARD",
		description: "Where would you rather be: in the battle line, shoulder-to-shoulder with the rest of the cannon fodder, or in the rush, at the head of the attack, your livery clean and bright, with glory to be won? The answer is easy. All those missiles and lances, all those hundred-kilometer, adjust-for-Coriolis railguns – they’re all useless against you. Get through their guard, get in their face, and make them know your name.",
		ranks: [
			{
				name: "HANDSHAKE ETIQUETTE",
				description: "Gain +1 Accuracy when using CQB weapons to attack targets within Range 3."
			},
			{
				name: "SEE-THROUGH SEEKER",
				description: "You’ve modified your sensors and ammo to punch through, disregard, or otherwise ignore cover at close range. As long as you have line of sight, you ignore both soft and hard cover when using CQB weapons to attack targets within Range 3."
			},
			{
				name: "SEMPER VIGILO",
				description: "You may attack with Overwatch using CQB weapons when hostile characters enter, leave, or exit spaces within your Threat, no matter whether they started their movement there."
			}
		]
	},
	{
		id: "t_walking_armory",
		name: "WALKING ARMORY",
		description: "Think of a firefight: what’s your average pilot or trooper gonna sling? Jacketed lead, of course. A mag or three of depleted uranium if their target’s a big one. Boring. No, worse than boring: Dull. Predictable. Basic.<br>And guess what? Dull isn’t fun, predictable gets you killed, and basic leaves a boring body. Put down the depleted uranium and pick up a magazine of anoriginary stutterblink slugs, or at least a pack of tachyon flechettes. Lay waste in style, and live forever.",
		ranks: [
			{
				name: "ARMAMENT",
				description: "You carry a supply of custom ammunition that can be used with all your main ranged weapons. Gain the following system:<br><b>Ammo Case</b><br>0 SP, Limited 6<br>1/turn, when you attack with a Main ranged weapon, you may expend charges to apply one of the following effects to your attack at the listed cost:<ul><li><b>Thumper (1 charge):</b> The attack gains Knockback 1 and deals Explosive damage.</li><li><b>Shock (1 charge):</b> The attack deals Energy damage. Choose one character targeted by your attack; adjacent characters take 1 Energy AP, whether the result is a hit or miss.</li><li><b>Mag (1 charge):</b> The attack gains Arcing and deals Kinetic damage.</li></ul>"
			},
			{
				name: "EXPANDED PORTFOLIO",
				description: "Your Ammo Case gains new ammunition types, each of which costs two charges rather than one:<ul><li><b>Hellfire (2 charges):</b> The attack deals Energy damage and deals any bonus damage as Burn.</li><li><b>Jager (2 charges):</b> The attack gains Knockback 2, deals Explosive damage, and one character hit by the attack – your choice – must succeed on a Hull save or be knocked Prone.</li><li><b>Sabot (2 charges):</b> The attack gains AP and deals Kinetic damage.</li></ul>"
			},
			{
				name: "EFFICIENCY",
				description: "If you perform a critical hit using ammunition from your Ammo Case, you don’t expend any charges. If your attack has more than one target, this effect only applies to the first attack roll you make."
			}
		]
	}
];

var talents$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    'default': talents
});

var weapons = [
	{
		id: "mw_anti_materiel_rifle",
		name: "ANTI-MATERIEL RIFLE",
		mount: "Heavy",
		type: "Rifle",
		damage: [
			{
				type: "kinetic",
				val: "2d6"
			}
		],
		range: [
			{
				type: "Range",
				val: 20
			}
		],
		tags: [
			{
				id: "tg_accurate"
			},
			{
				id: "tg_ap"
			},
			{
				id: "tg_loading"
			},
			{
				id: "tg_ordnance"
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "",
		description: "Much like GMS mechs, GMS weapons are reliable galactic standards, made using interchangeable parts and built to withstand almost any conditions. There are three lines currently in production.<br>The Type-III (T-3) line is made up of heavy weapons, ordnance, and other exotic, specialized, or massive weapons. A broad classification, the T-3 range includes conventional-kinetic anti-materiel rifles, super-rapid cycling pulse rifles, missile racks, cannons, and drone nexuses – “hive” style launchers that serve as miniature factory, hangar, and deployment systems for portable drones. The classification also includes the fearsome “segment knife”, a system that uses flash-printing to produce disposable edged weapons in a vicinity around the user.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_assault_rifle",
		name: "ASSAULT RIFLE",
		mount: "Main",
		type: "Rifle",
		damage: [
			{
				type: "kinetic",
				val: "1d6"
			}
		],
		range: [
			{
				type: "Range",
				val: 10
			}
		],
		tags: [
			{
				id: "tg_reliable",
				val: 2
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "",
		description: "Much like GMS mechs, GMS weapons are reliable galactic standards, made using interchangeable parts and built to withstand almost any conditions. There are three lines currently in production.<br>The Type-I (T-1) line is defined by powerful, reliable, and conventional-kinetic ranged and melee weapons, including the GMS assault rifle, heavy machine gun, shotgun, pistol, and various light and heavy blades. Reliable galactic standards, the GMS T-1 line is the most widely used mech-scale line of weaponry across the galaxy. Echoing the Everest’s design notes, T-1 weapons are simply designed, with few (if any) moving parts, intended to be used in or adaptable to any environment.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_charged_blade",
		name: "CHARGED BLADE",
		mount: "Main",
		type: "Melee",
		damage: [
			{
				type: "energy",
				val: "1d3+3"
			}
		],
		range: [
			{
				type: "Threat",
				val: 1
			}
		],
		tags: [
			{
				id: "tg_ap"
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "",
		description: "Much like GMS mechs, GMS weapons are reliable galactic standards, made using interchangeable parts and built to withstand almost any conditions. There are three lines currently in production.<br>The Type-II (T-2) line displays GMS’s proprietary “charged” melee weapons and energy weapons. T-2 charged melee weapons are structurally similar to GMS’s T-1 melee weapons, though built with different materials to tolerate the intense heat generated by their projected plasma sheaths. These sheaths can be toggled on or off, depending on the needs of the pilot. GMS’s T-2 energy weapons, like their T-1 kinetics, are sturdy tools with predictable power scaling, minimal particle scattering, and consistent performance ranges. They feature universal ports allowing them to accept a variety of power sources, from hardline cabling through to “magazine” style power packs",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_cyclone_pulse_rifle",
		name: "CYCLONE PULSE RIFLE",
		mount: "Superheavy",
		type: "Rifle",
		damage: [
			{
				type: "kinetic",
				val: "3d6+3"
			}
		],
		range: [
			{
				type: "Range",
				val: 15
			}
		],
		tags: [
			{
				id: "tg_accurate"
			},
			{
				id: "tg_loading"
			},
			{
				id: "tg_reliable",
				val: 5
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "",
		description: "Much like GMS mechs, GMS weapons are reliable galactic standards, made using interchangeable parts and built to withstand almost any conditions. There are three lines currently in production.<br>The Type-III (T-3) line is made up of heavy weapons, ordnance, and other exotic, specialized, or massive weapons. A broad classification, the T-3 range includes conventional-kinetic anti-materiel rifles, super-rapid cycling pulse rifles, missile racks, cannons, and drone nexuses – “hive”style launchers that serve as miniature factory, hangar, and deployment systems for portable drones. The classification also includes the fearsome “segment knife”, a system that uses flash-printing to produce disposable edged weapons in a vicinity around the user.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_heavy_charged_blade",
		name: "HEAVY CHARGED BLADE",
		mount: "Heavy",
		type: "Melee",
		damage: [
			{
				type: "energy",
				val: "1d6+3"
			}
		],
		range: [
			{
				type: "Threat",
				val: 1
			}
		],
		tags: [
			{
				id: "tg_ap"
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "",
		description: "Much like GMS mechs, GMS weapons are reliable galactic standards, made using interchangeable parts and built to withstand almost any conditions. There are three lines currently in production.<br>The Type-II (T-2) line displays GMS’s proprietary “charged” melee weapons and energy weapons. T-2 charged melee weapons are structurally similar to GMS’s T-1 melee weapons, though built with different materials to tolerate the intense heat generated by their projected plasma sheaths. These sheaths can be toggled on or off, depending on the needs of the pilot. GMS’s T-2 energy weapons, like their T-1 kinetics, are sturdy tools with predictable power scaling, minimal particle scattering, and consistent performance ranges. They feature universal ports allowing them to accept a variety of power sources, from hardline cabling through to “magazine” style power packs",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_heavy_machine_gun",
		name: "HEAVY MACHINE GUN",
		mount: "Heavy",
		type: "Cannon",
		damage: [
			{
				type: "kinetic",
				val: "2d6+4"
			}
		],
		range: [
			{
				type: "Range",
				val: 8
			}
		],
		tags: [
			{
				id: "tg_inaccurate"
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "",
		description: "Much like GMS mechs, GMS weapons are reliable galactic standards, made using interchangeable parts and built to withstand almost any conditions. There are three lines currently in production.<br>The Type-I (T-1) line is defined by powerful, reliable, and conventional-kinetic ranged and melee weapons, including the GMS assault rifle, heavy machine gun, shotgun, pistol, and various light and heavy blades. Reliable galactic standards, the GMS T-1 line is the most widely used mech-scale line of weaponry across the galaxy. Echoing the Everest’s design notes, T-1 weapons are simply designed, with few (if any) moving parts, intended to be used in or adaptable to any environment.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_heavy_melee_weapon",
		name: "HEAVY MELEE WEAPON",
		mount: "Heavy",
		type: "Melee",
		damage: [
			{
				type: "kinetic",
				val: "2d6+1"
			}
		],
		range: [
			{
				type: "Threat",
				val: 1
			}
		],
		tags: [
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "",
		description: "Much like GMS mechs, GMS weapons are reliable galactic standards, made using interchangeable parts and built to withstand almost any conditions. There are three lines currently in production.<br>The Type-I (T-1) line is defined by powerful, reliable, and conventional-kinetic ranged and melee weapons, including the GMS assault rifle, heavy machine gun, shotgun, pistol, and various light and heavy blades. Reliable galactic standards, the GMS T-1 line is the most widely used mech-scale line of weaponry across the galaxy. Echoing the Everest’s design notes, T-1 weapons are simply designed, with few (if any) moving parts, intended to be used in or adaptable to any environment.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_howitzer",
		name: "HOWITZER",
		mount: "Heavy",
		type: "Cannon",
		damage: [
			{
				type: "explosive",
				val: "2d6"
			}
		],
		range: [
			{
				type: "Range",
				val: 20
			},
			{
				type: "Blast",
				val: 2
			}
		],
		tags: [
			{
				id: "tg_arcing"
			},
			{
				id: "tg_inaccurate"
			},
			{
				id: "tg_loading"
			},
			{
				id: "tg_ordnance"
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "",
		description: "Much like GMS mechs, GMS weapons are reliable galactic standards, made using interchangeable parts and built to withstand almost any conditions. There are three lines currently in production.<br>The Type-III (T-3) line is made up of heavy weapons, ordnance, and other exotic, specialized, or massive weapons. A broad classification, the T-3 range includes conventional-kinetic anti-materiel rifles, super-rapid cycling pulse rifles, missile racks, cannons, and drone nexuses – “hive”style launchers that serve as miniature factory, hangar, and deployment systems for portable drones. The classification also includes the fearsome “segment knife”, a system that uses flash-printing to produce disposable edged weapons in a vicinity around the user.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_missile_rack",
		name: "MISSILE RACK",
		mount: "Auxiliary",
		type: "Launcher",
		damage: [
			{
				type: "explosive",
				val: "1d3+1"
			}
		],
		range: [
			{
				type: "Range",
				val: 10
			},
			{
				type: "Blast",
				val: 1
			}
		],
		tags: [
			{
				id: "tg_loading"
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "",
		description: "Much like GMS mechs, GMS weapons are reliable galactic standards, made using interchangeable parts and built to withstand almost any conditions. There are three lines currently in production.<br>The Type-III (T-3) line is made up of heavy weapons, ordnance, and other exotic, specialized, or massive weapons. A broad classification, the T-3 range includes conventional-kinetic anti-materiel rifles, super-rapid cycling pulse rifles, missile racks, cannons, and drone nexuses – “hive”style launchers that serve as miniature factory, hangar, and deployment systems for portable drones. The classification also includes the fearsome “segment knife”, a system that uses flash-printing to produce disposable edged weapons in a vicinity around the user.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_mortar",
		name: "MORTAR",
		mount: "Main",
		type: "Cannon",
		damage: [
			{
				type: "explosive",
				val: "1d6+1"
			}
		],
		range: [
			{
				type: "Range",
				val: 15
			},
			{
				type: "Blast",
				val: 1
			}
		],
		tags: [
			{
				id: "tg_arcing"
			},
			{
				id: "tg_inaccurate"
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "",
		description: "Much like GMS mechs, GMS weapons are reliable galactic standards, made using interchangeable parts and built to withstand almost any conditions. There are three lines currently in production.<br>The Type-III (T-3) line is made up of heavy weapons, ordnance, and other exotic, specialized, or massive weapons. A broad classification, the T-3 range includes conventional-kinetic anti-materiel rifles, super-rapid cycling pulse rifles, missile racks, cannons, and drone nexuses – “hive”style launchers that serve as miniature factory, hangar, and deployment systems for portable drones. The classification also includes the fearsome “segment knife”, a system that uses flash-printing to produce disposable edged weapons in a vicinity around the user.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_nexus_hunter_killer",
		name: "NEXUS (HUNTER-KILLER)",
		mount: "Main",
		type: "Nexus",
		damage: [
			{
				type: "kinetic",
				val: "1d6"
			}
		],
		range: [
			{
				type: "Range",
				val: 10
			}
		],
		tags: [
			{
				id: "tg_smart"
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "",
		description: "Much like GMS mechs, GMS weapons are reliable galactic standards, made using interchangeable parts and built to withstand almost any conditions. There are three lines currently in production.<br>The Type-III (T-3) line is made up of heavy weapons, ordnance, and other exotic, specialized, or massive weapons. A broad classification, the T-3 range includes conventional-kinetic anti-materiel rifles, super-rapid cycling pulse rifles, missile racks, cannons, and drone nexuses – “hive”style launchers that serve as miniature factory, hangar, and deployment systems for portable drones. The classification also includes the fearsome “segment knife”, a system that uses flash-printing to produce disposable edged weapons in a vicinity around the user.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_nexus_light",
		name: "NEXUS (LIGHT)",
		mount: "Auxiliary",
		type: "Nexus",
		damage: [
			{
				type: "kinetic",
				val: "1d3"
			}
		],
		range: [
			{
				type: "Range",
				val: 10
			}
		],
		tags: [
			{
				id: "tg_smart"
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "",
		description: "Much like GMS mechs, GMS weapons are reliable galactic standards, made using interchangeable parts and built to withstand almost any conditions. There are three lines currently in production.<br>The Type-III (T-3) line is made up of heavy weapons, ordnance, and other exotic, specialized, or massive weapons. A broad classification, the T-3 range includes conventional-kinetic anti-materiel rifles, super-rapid cycling pulse rifles, missile racks, cannons, and drone nexuses – “hive”style launchers that serve as miniature factory, hangar, and deployment systems for portable drones. The classification also includes the fearsome “segment knife”, a system that uses flash-printing to produce disposable edged weapons in a vicinity around the user.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_pistol",
		name: "PISTOL",
		mount: "Auxiliary",
		type: "CQB",
		damage: [
			{
				type: "kinetic",
				val: "1d3"
			}
		],
		range: [
			{
				type: "Range",
				val: 5
			},
			{
				type: "Threat",
				val: 3
			}
		],
		tags: [
			{
				id: "tg_reliable",
				val: 1
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "",
		description: "Much like GMS mechs, GMS weapons are reliable galactic standards, made using interchangeable parts and built to withstand almost any conditions. There are three lines currently in production.<br>The Type-I (T-1) line is defined by powerful, reliable, and conventional-kinetic ranged and melee weapons, including the GMS assault rifle, heavy machine gun, shotgun, pistol, and various light and heavy blades. Reliable galactic standards, the GMS T-1 line is the most widely used mech-scale line of weaponry across the galaxy. Echoing the Everest’s design notes, T-1 weapons are simply designed, with few (if any) moving parts, intended to be used in or adaptable to any environment.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_segment_knife",
		name: "SEGMENT KNIFE",
		mount: "Auxiliary",
		type: "Melee",
		damage: [
			{
				type: "energy",
				val: "1d3+1"
			}
		],
		range: [
			{
				type: "Threat",
				val: 1
			}
		],
		tags: [
			{
				id: "tg_overkill"
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "",
		description: "Much like GMS mechs, GMS weapons are reliable galactic standards, made using interchangeable parts and built to withstand almost any conditions. There are three lines currently in production.<br>The Type-III (T-3) line is made up of heavy weapons, ordnance, and other exotic, specialized, or massive weapons. A broad classification, the T-3 range includes conventional-kinetic anti-materiel rifles, super-rapid cycling pulse rifles, missile racks, cannons, and drone nexuses – “hive”style launchers that serve as miniature factory, hangar, and deployment systems for portable drones. The classification also includes the fearsome “segment knife”, a system that uses flash-printing to produce disposable edged weapons in a vicinity around the user.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_rocket_propelled_grenade",
		name: "ROCKET-PROPELLED GRENADE",
		mount: "Main",
		type: "Launcher",
		damage: [
			{
				type: "explosive",
				val: "1d6+1"
			}
		],
		range: [
			{
				type: "Range",
				val: 10
			},
			{
				type: "Blast",
				val: 2
			}
		],
		tags: [
			{
				id: "tg_loading"
			},
			{
				id: "tg_ordnance"
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "",
		description: "Much like GMS mechs, GMS weapons are reliable galactic standards, made using interchangeable parts and built to withstand almost any conditions. There are three lines currently in production.<br>The Type-III (T-3) line is made up of heavy weapons, ordnance, and other exotic, specialized, or massive weapons. A broad classification, the T-3 range includes conventional-kinetic anti-materiel rifles, super-rapid cycling pulse rifles, missile racks, cannons, and drone nexuses – “hive”style launchers that serve as miniature factory, hangar, and deployment systems for portable drones. The classification also includes the fearsome “segment knife”, a system that uses flash-printing to produce disposable edged weapons in a vicinity around the user.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_shotgun",
		name: "SHOTGUN",
		mount: "Main",
		type: "CQB",
		damage: [
			{
				type: "kinetic",
				val: "1d6"
			}
		],
		range: [
			{
				type: "Range",
				val: 5
			},
			{
				type: "Threat",
				val: 3
			}
		],
		tags: [
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "",
		description: "Much like GMS mechs, GMS weapons are reliable galactic standards, made using interchangeable parts and built to withstand almost any conditions. There are three lines currently in production.<br>The Type-I (T-1) line is defined by powerful, reliable, and conventional-kinetic ranged and melee weapons, including the GMS assault rifle, heavy machine gun, shotgun, pistol, and various light and heavy blades. Reliable galactic standards, the GMS T-1 line is the most widely used mech-scale line of weaponry across the galaxy. Echoing the Everest’s design notes, T-1 weapons are simply designed, with few (if any) moving parts, intended to be used in or adaptable to any environment.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_tactical_knife",
		name: "TACTICAL KNIFE",
		mount: "Auxiliary",
		type: "Melee",
		damage: [
			{
				type: "kinetic",
				val: "1d3+1"
			}
		],
		range: [
			{
				type: "Threat",
				val: 1
			}
		],
		tags: [
			{
				id: "tg_thrown",
				val: 3
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "",
		description: "Much like GMS mechs, GMS weapons are reliable galactic standards, made using interchangeable parts and built to withstand almost any conditions. There are three lines currently in production.<br>The Type-I (T-1) line is defined by powerful, reliable, and conventional-kinetic ranged and melee weapons, including the GMS assault rifle, heavy machine gun, shotgun, pistol, and various light and heavy blades. Reliable galactic standards, the GMS T-1 line is the most widely used mech-scale line of weaponry across the galaxy. Echoing the Everest’s design notes, T-1 weapons are simply designed, with few (if any) moving parts, intended to be used in or adaptable to any environment.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_tactical_melee_weapon",
		name: "TACTICAL MELEE WEAPON",
		mount: "Main",
		type: "Melee",
		damage: [
			{
				type: "kinetic",
				val: "1d6+2"
			}
		],
		range: [
			{
				type: "Threat",
				val: 1
			}
		],
		tags: [
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "",
		description: "Much like GMS mechs, GMS weapons are reliable galactic standards, made using interchangeable parts and built to withstand almost any conditions. There are three lines currently in production.<br>The Type-I (T-1) line is defined by powerful, reliable, and conventional-kinetic ranged and melee weapons, including the GMS assault rifle, heavy machine gun, shotgun, pistol, and various light and heavy blades. Reliable galactic standards, the GMS T-1 line is the most widely used mech-scale line of weaponry across the galaxy. Echoing the Everest’s design notes, T-1 weapons are simply designed, with few (if any) moving parts, intended to be used in or adaptable to any environment.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_thermal_lance",
		name: "THERMAL LANCE",
		mount: "Heavy",
		type: "Cannon",
		damage: [
			{
				type: "energy",
				val: "1d6+3"
			}
		],
		range: [
			{
				type: "Line",
				val: 10
			}
		],
		tags: [
			{
				id: "tg_heat_self",
				val: 2
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "",
		description: "Much like GMS mechs, GMS weapons are reliable galactic standards, made using interchangeable parts and built to withstand almost any conditions. There are three lines currently in production.<br>The Type-II (T-2) line displays GMS’s proprietary “charged” melee weapons and energy weapons. .",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_thermal_pistol",
		name: "THERMAL PISTOL",
		mount: "Auxiliary",
		type: "CQB",
		damage: [
			{
				type: "energy",
				val: 2
			}
		],
		range: [
			{
				type: "Line",
				val: 5
			}
		],
		tags: [
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "",
		description: "Much like GMS mechs, GMS weapons are reliable galactic standards, made using interchangeable parts and built to withstand almost any conditions. There are three lines currently in production.<br>The Type-II (T-2) line displays GMS’s proprietary “charged” melee weapons and energy weapons. .",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_thermal_rifle",
		name: "THERMAL RIFLE",
		mount: "Main",
		type: "Rifle",
		damage: [
			{
				type: "energy",
				val: "1d3+2"
			}
		],
		range: [
			{
				type: "Range",
				val: 5
			}
		],
		tags: [
			{
				id: "tg_ap"
			}
		],
		source: "GMS",
		license: "",
		license_level: "",
		effect: "",
		description: "Much like GMS mechs, GMS weapons are reliable galactic standards, made using interchangeable parts and built to withstand almost any conditions. There are three lines currently in production.<br>The Type-II (T-2) line displays GMS’s proprietary “charged” melee weapons and energy weapons. .",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_chain_axe",
		name: "CHAIN AXE",
		mount: "Main",
		type: "Melee",
		damage: [
			{
				type: "kinetic",
				val: "1d6"
			}
		],
		range: [
			{
				type: "Threat",
				val: 1
			}
		],
		tags: [
			{
				id: "tg_reliable",
				val: 2
			}
		],
		source: "IPS-N",
		license: "BLACKBEARD",
		license_level: 1,
		effect: {
			effect_type: "Offensive",
			critical: "Your target becomes Shredded until the end of the current turn."
		},
		description: "A simple tactical-scale version of a logging tool, IPS-N’s chain axe is a serrated chainblade run off core power. The axe’s teeth are tungsten-tipped, hardened to chew through both hard and soft targets. Chain axes are effective weapons and utility tools that are often used by boarding parties to breach reinforced bulkheads.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_bristlecrown_flechette_launcher",
		name: "BRISTLECROWN FLECHETTE LAUNCHER",
		mount: "Auxiliary",
		type: "CQB",
		damage: [
			{
				type: "kinetic",
				val: 1
			}
		],
		range: [
			{
				type: "Burst",
				val: 1
			}
		],
		tags: [
		],
		source: "IPS-N",
		license: "BLACKBEARD",
		license_level: 2,
		effect: "This weapon ignores ranged penalties from Engaged, and deals 3 Kinetic damage to Grappled or Biological targets, instead of 1.",
		description: "The IPS-N Bristlecrown Flechette Launcher uses a hive-analogous mechanism to project a total soft-target kill zone in a dome around the user, proactively denying hostile infantry-tier actions.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_nanocarbon_sword",
		name: "NANOCARBON SWORD",
		mount: "Heavy",
		type: "Melee",
		damage: [
			{
				type: "kinetic",
				val: "1d6+4"
			}
		],
		range: [
			{
				type: "Threat",
				val: 2
			}
		],
		tags: [
			{
				id: "tg_reliable",
				val: 3
			}
		],
		source: "IPS-N",
		license: "BLACKBEARD",
		license_level: 2,
		effect: "",
		description: "IPS-N’s nanocarbon sword is a new spin on an old classic. Embedded nanosensors along the blade capture a full spectrum of data and transfer it to omninet storage banks for after-action review. Meanwhile, onboard software interprets the live feedback and adjusts the molecular composition of the blade edge in real time.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_assault_cannon",
		name: "ASSAULT CANNON",
		mount: "Main",
		type: "Cannon",
		damage: [
			{
				type: "kinetic",
				val: "1d6+2"
			}
		],
		range: [
			{
				type: "Range",
				val: 8
			}
		],
		tags: [
			{
				id: "tg_overkill"
			},
			{
				id: "tg_heat_self",
				val: 1
			}
		],
		source: "IPS-N",
		license: "DRAKE",
		license_level: 1,
		effect: "You can spin up this weapon’s barrels as a quick action. While spinning, it gains Reliable 3, but you become Slowed. You can end this effect as a protocol.",
		description: "IPS-N’s assault cannon of choice is a deep-cooled autocannon, fieldable as a mounted weapon or manipulator-operated platform. The cannon, simple in its functionality, can be fed by either box magazine or belt and is a standard inclusion in almost any among IPS-N fleet orders. In micro and zero-gravity environments, Drake pilots commonly employ the assault cannon as an additional propulsion system.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_concussion_missiles",
		name: "CONCUSSION MISSILES",
		mount: "Main",
		type: "Launcher",
		damage: [
			{
				type: "explosive",
				val: "1d3"
			}
		],
		range: [
			{
				type: "Range",
				val: 5
			}
		],
		tags: [
			{
				id: "tg_knockback",
				val: 2
			}
		],
		source: "IPS-N",
		license: "DRAKE",
		license_level: 2,
		effect: {
			effect_type: "Offensive",
			hit: "The target must succeed on a Hull save or become Impaired until the end of their next turn."
		},
		description: "Concussion missiles are fitted with overpressure-generating charges with low shatter and low incandescence – they’re meant to stun, deter, push back, and disorient, usually in tandem with a larger, more lethal attack.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_leviathan_heavy_assault_cannon",
		name: "LEVIATHAN HEAVY ASSAULT CANNON",
		mount: "Superheavy",
		type: "Cannon",
		damage: [
			{
				type: "kinetic",
				val: "1d6"
			}
		],
		range: [
			{
				type: "Range",
				val: 8
			}
		],
		tags: [
		],
		source: "IPS-N",
		license: "DRAKE",
		license_level: 3,
		effect: {
			effect_type: "Offensive",
			detail: "Unlike other Superheavy weapons, the Leviathan can be used with Skirmish. You can spin up this weapon’s barrels as a quick action.",
			abilities: [
				{
					effect_type: "Profile",
					name: "Spun Up",
					damage: [
						{
							type: "kinetic",
							val: "4d6+4"
						}
					],
					detail: "While spinning, you are Slowed and can no longer use the Leviathan with Skirmish.<br>You can cease this effect as a protocol.",
					tags: [
						{
							id: "tg_reliable",
							val: 5
						},
						{
							id: "tg_heat_self",
							val: 2
						}
					]
				}
			]
		},
		description: "The Leviathan Heavy Assault Cannon (HAC) is a massive, multi-barrel rotary cannon fed by an external reservoir, usually dorsally mounted on the chassis carrying it. Unmodified, the Leviathan should only be fired within the recommended burst timing specifications to prevent percussive trauma to joints and pilots.<br>In partnership with Harrison Armory’s Think Tank, IPS-N is currently investigating remote solutions for the cannon’s ammunition consumption demands.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_cutter_mkii_plasma_torch",
		name: "CUTTER MKII PLASMA TORCH",
		mount: "Auxiliary",
		type: "Melee",
		damage: [
			{
				type: "energy",
				val: 1
			},
			{
				type: "heat",
				val: 1
			},
			{
				type: "burn",
				val: 1
			}
		],
		range: [
			{
				type: "Threat",
				val: 1
			}
		],
		tags: [
			{
				id: "tg_heat_self",
				val: 1
			}
		],
		source: "IPS-N",
		license: "LANCASTER",
		license_level: 3,
		effect: "This weapon deals 10AP energy to objects, cover, terrain, and the environment.",
		description: "Plasma cutters were tools first: simple blades built to toggle and sustain a plasma sheath, making it easier to cut metal. Repeated ad hoc use of cutters as personal defense weapons against pirate boarding parties convinced IPS-N of the need for a mil-spec variant of the civilian tool – the Cutter, now in its second generation. The Cutter MkII feeds directly from the mech’s power core, with a port to attach power packs in case of cord severance. Although the cutting edge can be shortened to a knife length, its most popular setting is the “cutlass”, a medium-length option perfect for balancing reach and maneuverability in close quarters.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_war_pike",
		name: "WAR PIKE",
		mount: "Main",
		type: "Melee",
		damage: [
			{
				type: "kinetic",
				val: "1d6"
			}
		],
		range: [
			{
				type: "Threat",
				val: 3
			}
		],
		tags: [
			{
				id: "tg_knockback",
				val: 1
			},
			{
				id: "tg_thrown",
				val: 5
			}
		],
		source: "IPS-N",
		license: "NELSON",
		license_level: 1,
		effect: "",
		description: "A war pike is a simple weapon – a long haft, topped with a dense, slim point, meant to puncture armor. Early designs were derivative of mining pylons, but the modern war pike is a sturdy, balanced, and reliable weapon that’s perfect for a charge.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_power_knuckles",
		name: "POWER KNUCKLES",
		mount: "Auxiliary",
		type: "Melee",
		damage: [
			{
				type: "explosive",
				val: "1d3+1"
			}
		],
		range: [
			{
				type: "Threat",
				val: 1
			}
		],
		tags: [
		],
		source: "IPS-N",
		license: "NELSON",
		license_level: 3,
		effect: {
			effect_type: "Offensive",
			critical: "Your target must succeed on a Hull save or be knocked Prone."
		},
		description: "IPS-N’s line of power knuckles are another popular purchase for pilots who prefer to fight up close. Taking the form of anything from shaped studs to hyperdense knuckles, or a series of magnetically accelerated micro-rams, power knuckles amplify the already incredible hitting power of a mech.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_hand_cannon",
		name: "HAND CANNON",
		mount: "Auxiliary",
		type: "CQB",
		damage: [
			{
				type: "kinetic",
				val: "1d6"
			}
		],
		range: [
			{
				type: "Range",
				val: 5
			},
			{
				type: "Threat",
				val: 3
			}
		],
		tags: [
			{
				id: "tg_loading"
			},
			{
				id: "tg_reliable",
				val: 1
			}
		],
		source: "IPS-N",
		license: "RALEIGH",
		license_level: 1,
		effect: "",
		description: "The IPS-N hand cannon is a licensed version of GMS’s Type-I Pistol, adapted for a much heavier caliber. This modification requires the belt-fed system of the GMS build to be swapped for a cylinder or magazine-based system, depending on the specific model of hand cannon.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_bolt_thrower",
		name: "BOLT THROWER",
		mount: "Heavy",
		type: "Cannon",
		damage: [
			{
				type: "kinetic",
				val: "2d6"
			},
			{
				type: "explosive",
				val: "1d6"
			}
		],
		range: [
			{
				type: "Range",
				val: 8
			}
		],
		tags: [
			{
				id: "tg_loading"
			},
			{
				id: "tg_reliable",
				val: 2
			}
		],
		source: "IPS-N",
		license: "RALEIGH",
		license_level: 2,
		effect: "",
		description: "As with many of IPS-N’s classic weapons, the bolt thrower is descended from a civilian mining tool. It fires self-propelled explosive bolts, perfect for use in micro- and null-gravity as well as in-atmosphere.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_kinetic_hammer",
		name: "KINETIC HAMMER",
		mount: "Heavy",
		type: "Melee",
		damage: [
			{
				type: "kinetic",
				val: "2d6+2"
			}
		],
		range: [
			{
				type: "Threat",
				val: 1
			}
		],
		tags: [
			{
				id: "tg_reliable",
				val: 4
			}
		],
		source: "IPS-N",
		license: "RALEIGH",
		license_level: 3,
		effect: "",
		description: "A kinetic hammer is a simple tool, but a brutal one. Made up of a supermassive head fused to a long haft, the hammer carries enough force to create massively traumatic pressure waves upon landing a successful blow.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_deck_sweeper_automatic_shotgun",
		name: "DECK-SWEEPER AUTOMATIC SHOTGUN",
		mount: "Main",
		type: "CQB",
		damage: [
			{
				type: "kinetic",
				val: "2d6"
			}
		],
		range: [
			{
				type: "Range",
				val: 3
			},
			{
				type: "Threat",
				val: 3
			}
		],
		tags: [
			{
				id: "tg_inaccurate"
			}
		],
		source: "IPS-N",
		license: "TORTUGA",
		license_level: 1,
		effect: "",
		description: "The Deck-Sweeper Automatic Shotgun is a belt-fed scattergun, a favorite of marine pilots aboard stations and capital ships. Its methodology is straightforward: charge, point, and fire. A single-barrel constriction allows for pneumatic absorption – dampening the effect of its incredible recoil – and its belt feeder is compatible with many types of shot-and-slug ammunition.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_daisy_cutter",
		name: "DAISY CUTTER",
		mount: "Heavy",
		type: "CQB",
		damage: [
			{
				type: "kinetic",
				val: "3d6"
			}
		],
		range: [
			{
				type: "Cone",
				val: 7
			}
		],
		tags: [
			{
				id: "tg_limited",
				val: 2
			}
		],
		source: "IPS-N",
		license: "TORTUGA",
		license_level: 2,
		effect: {
			effect_type: "Offensive",
			attack: "Creates a cloud of smoke and detritus in the attack cone, providing soft cover in the affected area that lasts until the end of your next turn."
		},
		description: "The Daisy Cutter is an effective weapon – if outdated – that’s still favored by many marine pilots. Essentially, it’s a massive shotgun; the pilot loads a charge into the gun’s breech, drops a packed sabot down the barrel, aims, and fires a hellfire cloud of flechette darts, bearings, and ignited magnesium strips, guaranteed to clear any deck on which it’s been fired.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_catalytic_hammer",
		name: "CATALYTIC HAMMER",
		mount: "Main",
		type: "Melee",
		damage: [
			{
				type: "kinetic",
				val: "1d3+5"
			}
		],
		range: [
			{
				type: "Threat",
				val: 1
			}
		],
		tags: [
			{
				id: "tg_loading"
			}
		],
		source: "IPS-N",
		license: "TORTUGA",
		license_level: 2,
		effect: {
			effect_type: "Offensive",
			critical: "Your target must succeed on a Hull save or become Stunned until the end of their next turn."
		},
		description: "Modified originally from blast-mining equipment, the catalytic hammer (colloquially, the “pilebunker”) has since been refined into a formidable melee weapon. When fired, a charge propels the hammer – a solid cylinder with a spike on one end – through a short barrel, impacting with enormous kinetic force. Standard hammer heads are smooth to allow for easy extraction from targets, but they can be detached and replaced if retrieval is impossible. Any installation of a catalytic hammer necessitates superstructure reinforcement to allow for sufficient energy dispersal.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_impact_lance",
		name: "IMPACT LANCE",
		mount: "Main",
		type: "Melee",
		damage: [
			{
				type: "energy",
				val: "1d6"
			}
		],
		range: [
			{
				type: "Threat",
				val: 3
			}
		],
		tags: [
		],
		source: "IPS-N",
		license: "VLAD",
		license_level: 1,
		effect: {
			effect_type: "Offensive",
			attack: "You also attack all characters in a Line between you and your target. You take 1 heat for each target past the first."
		},
		description: "The impact lance is a mil-spec variant of a common mining tool: the single-use chemical survey laser. IPS-N’s military variant mounts a series of impact lances on a mech’s brachial or thoracic carriages, leaving its manipulators free to field other weapons and systems. It can be wired directly into a chassis’ core, or charged with disposable chemical batteries.<br>The lance array fires for a microsecond, burning through its stored charge to produce an intense burst of light that stabs out in a tight, pulsed beam capable of searing through meters of hardened bulkhead.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_impaler_nailgun",
		name: "IMPALER NAILGUN",
		mount: "Main",
		type: "CQB",
		damage: [
			{
				type: "kinetic",
				val: "1d6+1"
			}
		],
		range: [
			{
				type: "Range",
				val: 5
			},
			{
				type: "Threat",
				val: 3
			}
		],
		tags: [
			{
				id: "tg_heat_self",
				val: 1
			}
		],
		source: "IPS-N",
		license: "VLAD",
		license_level: 2,
		effect: {
			effect_type: "Offensive",
			hit: "Targets must succeed on a Hull save or become Immobilized until the end of their next turn."
		},
		description: "The Impaler’s noncombustible, sabot-jacketed two-stage macroflechettes can pierce even the heaviest armor. Once catapulted from its launcher, the sabot disengages on approach to its target and triggers a second stage – internal propulsion drives the macroflechette forward with incredible velocity. Over-penetration is certain against soft targets; IPS-N advises firing this weapon only when the area behind the target is clear of allies or noncombatants.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_combat_drill",
		name: "COMBAT DRILL",
		mount: "Superheavy",
		type: "Melee",
		damage: [
			{
				type: "kinetic",
				val: "3d6"
			},
			{
				type: "energy",
				val: "1d6"
			}
		],
		range: [
			{
				type: "Threat",
				val: 1
			}
		],
		tags: [
			{
				id: "tg_ap"
			},
			{
				id: "tg_overkill"
			}
		],
		source: "IPS-N",
		license: "VLAD",
		license_level: 3,
		effect: "When attacking a character that is Prone, Immobilized, or Stunned, this weapon’s Overkill tag does an extra +1d6 bonus damage each time it activates. This can activate indefinitely if the new bonus die result is a 1, triggering Overkill again.",
		description: "The combat drill is a brutal close-combat weapon, powered by a massive external catalyst pack. The bit is tipped with microplasmatic projectors designed to pre-treat the target and ensure drill penetration.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_magnetic_cannon",
		name: "MAGNETIC CANNON",
		mount: "Main",
		type: "Cannon",
		damage: [
			{
				type: "energy",
				val: "1d3+1"
			}
		],
		range: [
			{
				type: "Line",
				val: 8
			}
		],
		tags: [
		],
		source: "SSC",
		license: "BLACK WITCH",
		license_level: 1,
		effect: {
			effect_type: "Offensive",
			hit: "All characters within the affected area must succeed on a Hull save or be pulled 1d3+1 spaces toward you, or as close as possible."
		},
		description: "SSC’s magnetic cannon is a first from the Exotic Materials Group: an aperture-focused electromagnetic projection beam that uses intense pulses of magnetic energy to disrupt and damage hardware. Targets caught in the beam of a magnetic cannon suffer additional damage to their software as massive systemic stress is inflicted on sensitive components.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_vulture_dmr",
		name: "VULTURE DMR",
		mount: "Main",
		type: "Rifle",
		damage: [
			{
				type: "kinetic",
				val: "1d6+1"
			}
		],
		range: [
			{
				type: "Range",
				val: 15
			}
		],
		tags: [
			{
				id: "tg_accurate"
			},
			{
				id: "tg_overkill"
			},
			{
				id: "tg_heat_self",
				val: 1
			}
		],
		source: "SSC",
		license: "DEATH’S HEAD",
		license_level: 2,
		effect: "",
		description: "The Vulture Designated Marksman Rifle (DMR) is SSC’s core battle rifle. Reliable, available in dozens of configurations and calibers, and fed by box, drum, or belt, the Vulture is a popular armament across a wide range of mechs.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_railgun",
		name: "RAILGUN",
		mount: "Heavy",
		type: "Rifle",
		damage: [
			{
				type: "kinetic",
				val: "1d6+4"
			}
		],
		range: [
			{
				type: "Line",
				val: 20
			}
		],
		tags: [
			{
				id: "tg_ap"
			},
			{
				id: "tg_ordnance"
			},
			{
				id: "tg_heat_self",
				val: 2
			}
		],
		source: "SSC",
		license: "DEATH’S HEAD",
		license_level: 3,
		effect: "",
		description: "Railguns are simple, elegant weapons. With magnetically accelerated projectiles and no moving parts, they are effective in any theater and entirely self-contained within disposable units. This efficacy comes at a cost: railguns have massive power draw, making it necessary for wielders to carry core-charged auxiliary power translation packs.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_veil_rifle",
		name: "VEIL RIFLE",
		mount: "Main",
		type: "Rifle",
		damage: [
			{
				type: "energy",
				val: "1d3+1"
			}
		],
		range: [
			{
				type: "Line",
				val: 10
			}
		],
		tags: [
			{
				id: "tg_accurate"
			}
		],
		source: "SSC",
		license: "DUSK WING",
		license_level: 1,
		effect: "This weapon does not attack allied characters caught in its area of effect; instead, it shrouds them in a field of coruscating energy that throws off targeting systems, giving them soft cover until the end of their next turn.",
		description: "“We made first contact maybe an hour after breaching the vault. I remember nothing of it. I’m told most of my squad was killed outright; all I remember is light – brilliant – and a lightness in my own being.<br>“I do believe that I died in that moment, and yet I’m here, and I can’t square these two realities. Something has gone wrong, something has gone wrong, something has gone–”",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_burst_launcher",
		name: "BURST LAUNCHER",
		mount: "Main",
		type: "Launcher",
		damage: [
			{
				type: "explosive",
				val: "1d3"
			},
			{
				type: "heat",
				val: 1
			}
		],
		range: [
			{
				type: "Range",
				val: 15
			}
		],
		tags: [
			{
				id: "tg_accurate"
			},
			{
				id: "tg_arcing"
			}
		],
		source: "SSC",
		license: "DUSK WING",
		license_level: 2,
		effect: {
			effect_type: "Offensive",
			critical: "Target becomes Impaired until the end of their next turn."
		},
		description: "“Yes, they could die. We killed many of them – blew them away with burst launchers and cannons. I don’t think they mattered to it. Not like insects; not like that… there’s still a use for insects: as food, as necessary components in an ecosystem. Their deaths slowed us, but it didn’t command them to slow us. Even when we breached the last chamber and saw it, I don’t even think it recognized we were there.”",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_rail_rifle",
		name: "RAIL RIFLE",
		mount: "Main",
		type: "Rifle",
		damage: [
			{
				type: "kinetic",
				val: "1d6+1"
			}
		],
		range: [
			{
				type: "Line",
				val: 10
			}
		],
		tags: [
			{
				id: "tg_heat_self",
				val: 1
			}
		],
		source: "SSC",
		license: "METALMARK",
		license_level: 2,
		effect: "",
		description: "Rail rifles are popular weapons for use in all theaters, but they are the only choice for pilots operating in atmospheres made up of highly combustible gases. They use a line of cascading electromagnets to accelerate small projectiles at tremendous speeds, firing without the need for combustion.<br>Like other rail weapons, rail rifles are quiet in comparison to their traditional counterparts, although massive power requirements make it difficult to mask their energy signatures.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_shock_knife",
		name: "SHOCK KNIFE",
		mount: "Auxiliary",
		type: "Melee",
		damage: [
			{
				type: "energy",
				val: 1
			},
			{
				type: "burn",
				val: 2
			}
		],
		range: [
			{
				type: "Threat",
				val: 1
			}
		],
		tags: [
			{
				id: "tg_thrown",
				val: 5
			},
			{
				id: "tg_heat_self",
				val: 1
			}
		],
		source: "SSC",
		license: "METALMARK",
		license_level: 2,
		effect: "",
		description: "Shock knives are short, powered blades designed for integration with Shock Wreaths, a popular post-fab modification. The knives are custom-sculpted by SSC’s Terashima artisan enclave, each one bearing the unique hash-stamp of its designer. Part of SSC’s LUX-Iconic line – a civilian-accessible track of the BELLA CIAO line – each shock knife print code allows only a single use. If lost, pilots must submit an apology and request in writing explaining the circumstances of the loss in order to receive another code.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_sharanga_missiles",
		name: "SHARANGA MISSILES",
		mount: "Main",
		type: "Launcher",
		damage: [
			{
				type: "explosive",
				val: 3
			}
		],
		range: [
			{
				type: "Range",
				val: 15
			}
		],
		tags: [
			{
				id: "tg_arcing"
			}
		],
		source: "SSC",
		license: "MONARCH",
		license_level: 1,
		effect: "This weapon can attack two targets at a time.",
		description: "“It was a duel. This is why they were made: to duel, and in that combat, to shake the pillars of the universe.” — “Notes for Young John”,  Ministrations of the Master Teacher",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_gandiva_missiles",
		name: "GANDIVA MISSILES",
		mount: "Heavy",
		type: "Launcher",
		damage: [
			{
				type: "energy",
				val: "1d6+3"
			}
		],
		range: [
			{
				type: "Range",
				val: 15
			}
		],
		tags: [
			{
				id: "tg_accurate"
			},
			{
				id: "tg_seeking"
			},
			{
				id: "tg_smart"
			}
		],
		source: "SSC",
		license: "MONARCH",
		license_level: 2,
		effect: "",
		description: "Gandiva missiles are a reliable mainstay from Smith-Shimano’s BELLA CIAO line. Like the heavier Pinaka, the Gandiva is equipped with jet-assisted midflight repositioning systems, enhancing target navigation in rapidly changing battlefield environments. The Gandiva’s delivery platform is administered by a hivemind comp/con drone AI, giving it the capacity to learn from each right-of-launch experience.",
		data_type: "weapon",
		aptitude: {
		},
		sp: 1
	},
	{
		id: "mw_pinaka_missiles",
		name: "PINAKA MISSILES",
		mount: "Superheavy",
		type: "Launcher",
		damage: [
			{
				type: "explosive",
				val: "2d6"
			}
		],
		range: [
			{
				type: "Range",
				val: 20
			},
			{
				type: "Blast",
				val: 1
			}
		],
		tags: [
			{
				id: "tg_arcing"
			},
			{
				id: "tg_heat_self",
				val: 2
			}
		],
		source: "SSC",
		license: "MONARCH",
		license_level: 3,
		effect: "Attacks with this weapon create up to two blast 1 areas, which cannot overlap.<br>You may also delay the impact of attacks made with this weapon. Choose the target area(s), which become visible to all characters: the  missiles land at the end of the next round, after all characters have acted, and deal 3d6 explosive damage instead of 2d6, but you become Slowed until the end of your next turn.",
		description: "Pinaka missiles are massive, two-stage missiles typically mounted along a mech’s spine or carried, disassembled, to be launched from a brachial mount. The Pinaka was originally adapted from ship-to-ship missiles; as such, their second stage uses jet-assist repositioning for midflight orientation.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_fold_knife",
		name: "FOLD KNIFE",
		mount: "Auxiliary",
		type: "Melee",
		damage: [
			{
				type: "kinetic",
				val: "1d3"
			}
		],
		range: [
			{
				type: "Threat",
				val: 1
			}
		],
		tags: [
			{
				id: "tg_accurate"
			}
		],
		source: "SSC",
		license: "MOURNING CLOAK",
		license_level: 1,
		effect: {
			effect_type: "Offensive",
			critical: "You may teleport 2 spaces in any direction after the attack resolves."
		},
		description: ">//[Am I alone here?]<br>>//[[No. There is only an absence of you. It is very busy here, but you cannot see it]]<br>— DHIYED fragment tablet 1.3",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_vijaya_rockets",
		name: "VIJAYA ROCKETS",
		mount: "Auxiliary",
		type: "Launcher",
		damage: [
			{
				type: "explosive",
				val: "1d3"
			}
		],
		range: [
			{
				type: "Range",
				val: 5
			}
		],
		tags: [
			{
				id: "tg_accurate"
			}
		],
		source: "SSC",
		license: "MOURNING CLOAK",
		license_level: 1,
		effect: "",
		description: "Intended for use as force multipliers in close-range engagements, Vijaya rockets are miniaturized rockets launched from a drum-fed launcher. On detonation, the rockets’ shaped charges project the blast forward, away from the user.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_variable_sword",
		name: "VARIABLE SWORD",
		mount: "Main",
		type: "Melee",
		damage: [
			{
				type: "kinetic",
				val: 3
			}
		],
		range: [
			{
				type: "Threat",
				val: 2
			}
		],
		tags: [
			{
				id: "tg_accurate"
			}
		],
		source: "SSC",
		license: "MOURNING CLOAK",
		license_level: 3,
		effect: {
			effect_type: "Offensive",
			critical: "Deal +1d6 bonus damage."
		},
		description: "The variable sword is a Smith-Shimano hallmark: a length of razor-sharp molecular wire attached to a handle and locked in place by a magnetic field, variable swords are invisible to the naked eye until they cut into their target. Designed in the early days of interstellar travel, variable swords were meant to allow for the precise gathering of samples, while also reducing the overall burden on a mech’s core.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_oracle_lmg_i",
		name: "ORACLE LMG-I",
		mount: "Auxiliary",
		type: "Rifle",
		damage: [
			{
				type: "kinetic",
				val: "1d3"
			}
		],
		range: [
			{
				type: "Range",
				val: 15
			}
		],
		tags: [
			{
				id: "tg_accurate"
			},
			{
				id: "tg_arcing"
			}
		],
		source: "SSC",
		license: "SWALLOWTAIL",
		license_level: 2,
		effect: "",
		description: "The Oracle Indirect Light Machine Gun (designated O/LMG-I) packs a subsentient, high-volume DOWNPOUR static quad-barrel system into a single cylinder typically installed on the dorsal panel of a chassis. Paired with a firing system, the Oracle is capable of directing persistent defilade-ignorant kinetic fire at targets.",
		data_type: "weapon",
		aptitude: {
		},
		sp: 1
	},
	{
		id: "mw_nanobot_whip",
		name: "NANOBOT WHIP",
		mount: "Heavy",
		type: "Melee",
		damage: [
			{
				type: "kinetic",
				val: "2d6"
			}
		],
		range: [
			{
				type: "Threat",
				val: 3
			}
		],
		tags: [
			{
				id: "tg_smart"
			}
		],
		source: "HORUS",
		license: "BALOR",
		license_level: 3,
		effect: {
			effect_type: "Offensive",
			critical: "Pull your target to a free space adjacent to you, or as close as possible."
		},
		description: "Using swarm-coding and legion directives, HORUS collectivists created a framework to organize a swarm of nanites into a whip-like weapon. Nanobot whips can retract into their base blister for stowing, detach in melee combat to restrain nearby enemies, and return to their base unit when summoned.",
		data_type: "weapon",
		aptitude: {
		},
		sp: 2
	},
	{
		id: "mw_swarm_hive_nanites",
		name: "SWARM/HIVE NANITES",
		mount: "Main",
		type: "Nexus",
		damage: [
			{
				type: "kinetic",
				val: 2
			},
			{
				type: "burn",
				val: 2
			}
		],
		range: [
			{
				type: "Range",
				val: 5
			}
		],
		tags: [
			{
				id: "tg_smart"
			},
			{
				id: "tg_seeking"
			}
		],
		source: "HORUS",
		license: "BALOR",
		license_level: 3,
		effect: "",
		description: "SWARM/HIVE nanites are among the more insidious weapons produced by HORUS: dispatched in maniples – single “swarm” units carrying enough nanites to fill a square meter – SWARM/HIVE nanites combine the systemic invasion properties of BOOST/HIVE code with the aggressive consumption of a CONSUME/HIVE maniple. Launched from mounted blisters, SWARM/HIVE nanite maniples fall upon their targets as great clouds of teeth, infiltrating sensitive compartments and modules before consuming any organic and inorganic material they touch.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_autopod",
		name: "AUTOPOD",
		mount: "Main",
		type: "Launcher",
		damage: [
			{
				type: "kinetic",
				val: 3
			}
		],
		range: [
			{
				type: "Range",
				val: 15
			}
		],
		tags: [
			{
				id: "tg_seeking"
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_reaction"
			}
		],
		source: "HORUS",
		license: "GOBLIN",
		license_level: 1,
		effect: {
			effect_type: "Offensive",
			detail: "Instead of using any kind of trigger mechanism, this weapon automatically scans for target locks, firing spinning, razor-sharp disks upon successful IDs. Gain the Autonomous Assault reaction, which is the only way you can attack with the Autopod",
			abilities: [
				{
					name: "Autonomous Assault",
					effect_type: "Reaction",
					frequency: "1/round",
					trigger: "Another character attacks a target within range 15 of you and consumes Lock On",
					detail: "You may automatically hit their target with the Autopod."
				}
			]
		},
		description: "The autopod is a small antipersonnel weapon apparently devised by HORUS communocyphers to continue offensive action in the event of its operator’s death. Each unit is, in theory, governed by a spur of INSTINCT’s protomind. No new models have been encountered since DHIYED, and all extant versions of the Autopod are to be considered extremely dangerous as the INSTINCT code powering their onboard protominds is likely to have corrupted further since their creation.",
		data_type: "weapon",
		aptitude: {
		},
		sp: 1
	},
	{
		id: "mw_vorpal_gun",
		name: "VORPAL GUN",
		mount: "Main",
		type: "Cannon",
		damage: [
			{
				type: "kinetic",
				val: "2d6"
			}
		],
		range: [
			{
				type: "Range",
				val: 5
			}
		],
		tags: [
		],
		source: "HORUS",
		license: "GORGON",
		license_level: 3,
		effect: {
			effect_type: "Offensive",
			detail: "Gain the Snicker-Snack reaction, which is the only way you can attack with this weapon.",
			abilities: [
				{
					name: "Snicker-Snack",
					effect_type: "Reaction",
					frequency: "1/round",
					trigger: "A hostile character within Range of the Vorpal Gun and line of sight deals damage to an allied character.",
					detail: "You may make an attack against the hostile character with the Vorpal Gun."
				}
			]
		},
		description: "DO NOT STARE DIRECTLY INTO THE APERTURE.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_ghoul_nexus",
		name: "GHOUL NEXUS",
		mount: "Main",
		type: "Nexus",
		damage: [
			{
				type: "variable",
				val: "1d3+2"
			}
		],
		range: [
			{
				type: "Range",
				val: 10
			}
		],
		tags: [
			{
				id: "tg_smart"
			},
			{
				id: "tg_set_damage_type"
			}
		],
		source: "HORUS",
		license: "HYDRA",
		license_level: 1,
		effect: {
			effect_type: "Offensive",
			attack: "Choose this weapon’s damage type."
		},
		description: "Ghoul nexuses command some of the largest viable drones in modern combat. These drones are slightly smaller than an average human—metal cylinders bristling with hardpoints suitable for most infantry-level anti-mech weapons. Propelled by VTOL/hover-capable jet systems, Ghoul drones are fearsome, all-theater autonomous units that are difficult to track and take down.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_ghast_nexus",
		name: "GHAST NEXUS",
		mount: "Heavy",
		type: "Nexus",
		damage: [
			{
				type: "explosive",
				val: "1d6+3"
			}
		],
		range: [
			{
				type: "Range",
				val: 10
			}
		],
		tags: [
			{
				id: "tg_drone"
			},
			{
				id: "tg_smart"
			}
		],
		source: "HORUS",
		license: "HYDRA",
		license_level: 2,
		effect: {
			effect_type: "Offensive",
			detail: "This weapon may be used to attack as normal, or deployed as a Drone",
			abilities: [
				{
					name: "Ghast Nexus",
					effect_type: "Drone",
					size: 0.5,
					hp: 5,
					armor: 2,
					edef: 10,
					evasion: 10,
					detail: "This Ghast nexus can be deployed to a free space within Sensors and line of sight as a free action, where it becomes a stationary, hovering Drone. Once deployed, you may still use it for Skirmish and Barrage attacks as though it is still a weapon, but with line of sight and Range traced from its location.<br>You may recall or redeploy the Ghast nexus as a quick action. Until recalled or destroyed, it remains deployed until the end of the scene. If destroyed, it follows the rules for destroyed Drones and can’t be used until repaired."
				}
			]
		},
		description: "The Ghast is an up-armored, up-armed version of the smaller Ghoul drone; Ghast drones boast an upgraded flight system capable of wielding mech-tier weapons within optimum parameters, and can operate independently from their host chassis or as an integrated weapon. In Hydras, Ghast drones generally act as thoracic segments, providing armor to core systems: powerplant, cockpit, NHP caskets, etc.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_annihilation_nexus",
		name: "ANNIHILATION NEXUS",
		mount: "Superheavy",
		type: "Nexus",
		damage: [
			{
				type: "energy",
				val: "1d6+3"
			}
		],
		range: [
			{
				type: "Burst",
				val: 2
			}
		],
		tags: [
			{
				id: "tg_ap"
			},
			{
				id: "tg_smart"
			}
		],
		source: "HORUS",
		license: "HYDRA",
		license_level: 3,
		effect: {
			effect_type: "Offensive",
			attack: "You can make a second attack with this weapon at the start of your next turn as a protocol. This secondary attack can’t deal bonus damage, and doesn't trigger additional secondary attacks.<br>You may center this weapon’s attack on either yourself or any of your Drones within Sensors."
		},
		description: "“A storm of bladed death” – nanites organized into maniples, released from a chassis’ onboard nexuses or single-use firing tubes in a burst of filament rings so sharp they slice away at their targets on the molecular level. The visual effect of a maniple being launched is often compared to tinsel being fired through atmosphere.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_catalyst_pistol",
		name: "CATALYST PISTOL",
		mount: "Auxiliary",
		type: "CQB",
		damage: [
			{
				type: "energy",
				val: "1d3"
			}
		],
		range: [
			{
				type: "Cone",
				val: 3
			},
			{
				type: "Threat",
				val: 3
			}
		],
		tags: [
			{
				id: "tg_heat_self",
				val: 2
			}
		],
		source: "HORUS",
		license: "MANTICORE",
		license_level: 1,
		effect: "",
		description: "“Burn, thou fiend, before the fire of the Eye of RA!”",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_arc_projector",
		name: "ARC PROJECTOR",
		mount: "Heavy",
		type: "CQB",
		damage: [
			{
				type: "energy",
				val: "1d6+1"
			}
		],
		range: [
			{
				type: "Range",
				val: 5
			}
		],
		tags: [
			{
				id: "tg_heat_self",
				val: 1
			}
		],
		source: "HORUS",
		license: "MANTICORE",
		license_level: 2,
		effect: {
			effect_type: "Offensive",
			hit: "You may also make a secondary attack against a different character within range 3 of the first target. You can continue making secondary attacks on hits, as long as there are new, valid targets within range; however, each attack generates 1 heat, and secondary attacks can’t deal bonus damage. Characters can’t be hit more than once with the same firing of this weapon."
		},
		description: "“Fire be upon thee, APEP! Thy flesh is seared from thy bones; The Lord of the Duat will never enable thy shade to rise again!”",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_smartgun",
		name: "SMARTGUN",
		mount: "Main",
		type: "Rifle",
		damage: [
			{
				type: "kinetic",
				val: 4
			}
		],
		range: [
			{
				type: "Range",
				val: 15
			}
		],
		tags: [
			{
				id: "tg_accurate"
			},
			{
				id: "tg_seeking"
			},
			{
				id: "tg_smart"
			}
		],
		source: "HORUS",
		license: "PEGASUS",
		license_level: 1,
		effect: "",
		description: "“Smart weapon” is a broad term that describes any and all weapons capable of interacting with onboard systems in order to boost their combat efficacy. Smartguns are weapons that come pre-loaded with companion software and the necessary hardware in order to interact with targeting systems and host NHPs. A popular addition to many HORUS mechs, smart weapons make for reliable kinetic delivery systems.",
		data_type: "weapon",
		aptitude: {
		},
		sp: 2
	},
	{
		id: "mw_mimic_gun",
		name: "MIMIC GUN",
		mount: "Heavy",
		type: "???",
		damage: [
			{
				override: true,
				val: "??? kinetic"
			}
		],
		range: [
			{
				override: true,
				type: "Range",
				val: "???"
			}
		],
		tags: [
		],
		source: "HORUS",
		license: "PEGASUS",
		license_level: 2,
		effect: "This horrifying weapon has no basic form; it constantly contorts itself into different shapes, mimicking the weapons of other combatants. It counts as all ranged weapon types simultaneously (e.g., CQB, Rifle, etc.), but it can’t take Mods or benefit from core bonuses, although it still benefits from talents as normal.<br>At the start of combat, roll 3d20 and note the results in order: X, Y, and Z. X is its starting base Range (before modifications from talents). At the start of each of your turns after the first, the mimic gun cycles to the next result, taking that as its base Range. After Z, it cycles back to X.<br>The mimic gun does kinetic equal to 1 + half of its current base Range.<br>You may provoke the mimic gun as a full action, rolling a new set of 3d20.",
		description: "This is not a gun.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_autogun",
		name: "AUTOGUN",
		mount: "Main",
		type: "Cannon",
		damage: [
			{
				type: "kinetic",
				val: 3
			}
		],
		range: [
			{
				type: "Range",
				val: 15
			}
		],
		tags: [
		],
		source: "HORUS",
		license: "PEGASUS",
		license_level: 3,
		effect: "This weapon can’t make normal attacks. Instead, you can attack with it as a free action at the end of your turn. It doesn’t benefit from or trigger your talents.",
		description: "As the name implies, autoguns are automated weapons. Similar to point-defense systems, autoguns are chambered to provide effective fire against armored targets. Typically mounted on a stabilized, secondary arm, a reliably tuned autogun can be trusted to track and eliminate designated enemy units while a pilot concentrates on more specialized weapons or processes. Cheap, with malleable codebases, autoguns are common among active, armed HORUS cells.",
		data_type: "weapon",
		aptitude: {
		},
		sp: 1
	},
	{
		id: "mw_siege_cannon",
		name: "SIEGE CANNON",
		mount: "Superheavy",
		type: "Cannon",
		damage: [
			{
				type: "explosive",
				val: "3d6"
			}
		],
		range: [
			{
				type: "variable",
				override: true,
				val: "Range 20 / Range 30, Blast 2"
			}
		],
		tags: [
		],
		source: "HA",
		license: "BARBAROSSA",
		license_level: 3,
		effect: {
			effect_type: "Offensive",
			attack: "Choose to fire in either siege mode or direct fire mode.",
			abilities: [
				{
					effect_type: "Profile",
					name: "Siege",
					range: [
						{
							type: "Range",
							val: 30
						},
						{
							type: "Blast",
							val: 2
						}
					],
					damage: [
						{
							type: "explosive",
							val: "3d6"
						}
					],
					tags: [
						{
							id: "tg_arcing"
						},
						{
							id: "tg_ordnance"
						},
						{
							id: "tg_loading"
						},
						{
							id: "tg_heat_self",
							val: 4
						}
					]
				},
				{
					effect_type: "Profile",
					name: "Direct Fire",
					range: [
						{
							type: "Range",
							val: 20
						}
					],
					damage: [
						{
							type: "explosive",
							val: "3d6"
						}
					],
					tags: [
						{
							id: "tg_heat_self",
							val: 2
						},
						{
							id: "tg_knockback",
							val: 2
						}
					]
				}
			]
		},
		description: "The siege cannon is the Armory’s quintessential artillery piece: a howitzer cannon fed by an automated loading system. Typically mounted on long-range mechs deployed in artillery or squad-support roles, siege cannons are capable of both indirect and direct fire as the situation demands with variable ammunition options.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_krakatoa_thermobaric_flamethrower",
		name: "KRAKATOA THERMOBARIC FLAMETHROWER",
		mount: "Heavy",
		type: "CQB",
		damage: [
			{
				type: "energy",
				val: 1
			},
			{
				type: "burn",
				val: 4
			}
		],
		range: [
			{
				type: "Cone",
				val: 5
			}
		],
		tags: [
		],
		source: "HA",
		license: "GENGHIS",
		license_level: 1,
		effect: "",
		description: "Between the thick arboreal environment of Hercynia, the swarm tactics of the Egregorians, and the ineffectual performance of slug ammunition, the need for wide-effect weapons was apparent. GMS quick developed the Krakatoa – a thermobaric flamethrower – and disseminated it to affiliates. The Krakatoa was quickly adopted by Union’s Marine Expeditionary Forces, seeing heavy use in the depths of the Hercynian continental jungles thanks to its stability, reliability, and stopping power.<br>Later reworked and adopted by the Armory following the resolution of the Hercynian Crisis, the Krakatoa has become a popular tool for the creation of area-of-denial firebreaks.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_plasma_thrower",
		name: "PLASMA THROWER",
		mount: "Superheavy",
		type: "CQB",
		damage: [
			{
				type: "energy",
				val: "1d6+2"
			},
			{
				type: "burn",
				val: 6
			}
		],
		range: [
			{
				type: "Cone",
				val: 7
			},
			{
				type: "Line",
				val: 10
			}
		],
		tags: [
			{
				id: "tg_heat_self",
				val: 4
			}
		],
		source: "HA",
		license: "GENGHIS",
		license_level: 3,
		effect: {
			effect_type: "Offensive",
			detail: "Can be fired as Cone 7 <i>or</i> Line 10",
			attack: "White-hot flames continue to burn in 3 free spaces of your choice within the affected area, lasting for the rest of the scene. When characters start their turn in one of these spaces or enter one for the first time in a round, they take 1d6 energy damage."
		},
		description: "The plasma thrower emerged too late in the Hercynian Crisis to see widespread use in the field. The scarce data gathered from the MEF squadrons that used it suggest that plasma throwers would have had a tremendous impact on the outcomes of several major battles that occurred during the bloodiest phase of the Crisis.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_stub_cannon",
		name: "STUB CANNON",
		mount: "Auxiliary",
		type: "Cannon",
		damage: [
			{
				type: "explosive",
				val: 3
			}
		],
		range: [
			{
				type: "Range",
				val: 5
			}
		],
		tags: [
			{
				id: "tg_limited",
				val: 6
			},
			{
				id: "tg_knockback",
				val: 1
			}
		],
		source: "HA",
		license: "ISKANDER",
		license_level: 1,
		effect: "",
		description: "The stub cannon is a supercompact rotary cannon – short-range, but suitable for integration into hardpoints and manipulators.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_gravity_gun",
		name: "GRAVITY GUN",
		mount: "Heavy",
		type: "Rifle",
		damage: [
		],
		range: [
			{
				type: "Range",
				val: 8
			},
			{
				type: "Blast",
				val: 3
			}
		],
		tags: [
		],
		source: "HA",
		license: "ISKANDER",
		license_level: 2,
		effect: {
			effect_type: "Offensive",
			attack: "Characters within the affected area must succeed on a Hull save or take 1d6 energy damage and be pulled as close to the center of the blast as possible. This weapon cannot be modified or benefit from core bonuses."
		},
		description: "“The complex negotiations of gravity and time, shattered in an instant by a machine that can pluck waves like a player strums the strings of a guitar.<br>We’ve weaponized the force that holds all things in its embrace. What could go wrong?”",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_displacer",
		name: "DISPLACER",
		mount: "Main",
		type: "Rifle",
		damage: [
			{
				type: "energy",
				val: 10
			}
		],
		range: [
			{
				type: "Range",
				val: 10
			},
			{
				type: "Blast",
				val: 1
			}
		],
		tags: [
			{
				id: "tg_ap"
			},
			{
				id: "tg_loading"
			},
			{
				id: "tg_unique"
			},
			{
				id: "tg_heat_self",
				val: 10
			}
		],
		source: "HA",
		license: "NAPOLEON",
		license_level: 3,
		effect: "",
		description: "The Displacer is the result of ongoing blinkspace exposure tests and refinement of standard interstellar travel methods. In terms of appearance, the Displacer could be mistaken for a conventional energy rifle, but it requires a massive secondary, dorsal-mounted reactor: when fired, the Displacer identifies a bubble of local space (size and location determined on an ad hoc basis by the user) and snaps it into blinkspace. The destination of the bubble is unknown, but the effect is dramatic: anything inside simply ceases to exist in this dimension, transported somewhere in the void of blinkspace. The Displacer makes no sound when fired, but the sudden and necessary venting of its power supply is tremendous; similarly, the heatwave of its backblast vent is deadly to any unshielded personnel exposed to it.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_shatterhead_colony_missiles",
		name: "SHATTERHEAD COLONY MISSILES",
		mount: "Main",
		type: "Launcher",
		damage: [
			{
				type: "energy",
				val: "1d3+1"
			}
		],
		range: [
			{
				type: "Range",
				val: 15
			}
		],
		tags: [
			{
				id: "tg_arcing"
			}
		],
		source: "HA",
		license: "SALADIN",
		license_level: 1,
		effect: "The final attack roll for this weapon can never be affected by difficulty.",
		description: "Developed following costly urban and naval boarding engagements in the Interest War, Shatterhead Colony Missiles are now a standard part of the arsenal fielded by Armory interdiction teams. When they reach an optimal distance, Shatterheads break open in a burst of high-catalyst fuel to reveal a cluster of small thermobaric pellets that spread out and ignite, choking the affected area with flame. The effect overloads energy shielding and saturates cover, though only a small percent of the projectiles actually reach their target.",
		data_type: "weapon",
		aptitude: {
		},
		sp: 1
	},
	{
		id: "mw_sol_pattern_laser_rifle",
		name: "SOL-PATTERN LASER RIFLE",
		mount: "Main",
		type: "Rifle",
		damage: [
			{
				type: "energy",
				val: "1d6"
			},
			{
				type: "burn",
				val: 1
			}
		],
		range: [
			{
				type: "Range",
				val: 8
			}
		],
		tags: [
			{
				id: "tg_heat_self",
				val: 1
			}
		],
		source: "HA",
		license: "SHERMAN",
		license_level: 1,
		effect: "",
		description: "Laser rifles contain a series of apertures and lenses that amplify and focus light into tight beams, sometimes visible, that heat the zone of impact for long enough to turn it into plasma. The SOL-Pattern Laser Rifle consistently outputs 3.5 petawatts, pulsed, but can also project a steady beam at lower power levels. The SOL is entirely self-contained but can be patched into a mech’s reactor core for emergency recharge.<br>Although some laser rifles double as communications and data-transfer devices, the SOL is strictly suitable for combat applications.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_andromeda_pattern_heavy_laser_rifle",
		name: "ANDROMEDA-PATTERN HEAVY LASER RIFLE",
		mount: "Heavy",
		type: "Cannon",
		damage: [
			{
				type: "energy",
				val: "2d6"
			},
			{
				type: "burn",
				val: 3
			}
		],
		range: [
			{
				type: "Range",
				val: 12
			}
		],
		tags: [
			{
				id: "tg_heat_self",
				val: 3
			}
		],
		source: "HA",
		license: "SHERMAN",
		license_level: 2,
		effect: "",
		description: "The Harrison Armory ANDROMEDA-Pattern Heavy Laser Rifle scales up the SOL by half, adding a second projector that can fire independently, synchronized, or in alternating patterns and wavelengths with the primary projector. The effect overwhelms most shields, but the power draw necessary makes this weapon impractical on platforms without the necessary heat reduction and dispersal to manage the incredible cost.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_tachyon_lance",
		name: "TACHYON LANCE",
		mount: "Superheavy",
		type: "Cannon",
		damage: [
			{
				type: "energy",
				val: "2d6"
			},
			{
				type: "burn",
				val: 8
			}
		],
		range: [
			{
				type: "Range",
				val: 20
			}
		],
		tags: [
			{
				id: "tg_ordnance"
			},
			{
				id: "tg_heat_self",
				val: 4
			}
		],
		source: "HA",
		license: "SHERMAN",
		license_level: 3,
		effect: {
			effect_type: "Offensive",
			attack: "If you’re in the Danger Zone, create a cone 3 backblast of burning plasma in the opposite direction to the attack. Characters within the affected area must succeed on an Engineering save or take 4 burn and 2 heat. Until the start of your next turn, the affected area provides soft cover."
		},
		description: "Tachyon lances are the weaponized results of joint IPS-N and Harrison Armory experiments into faster-than-light travel. Rendered obsolete by subsequent developments in blinkspace travel (and the difficulty of ensuring corporeal passenger survival), the Armory’s tachyon accelerators were mothballed until Think Tank engineers realized their potential application as weapons. Tachyon lances project tachyon particles – essentially subatomic localized objects – faster than light toward their targets. These particles are impossible to perceive optically, and because they travel faster than light, can’t be seen or evaded. Although the particles are tiny, they travel with colossal speed and energy. The damage a tachyon lance deals to its target – should it hit – is unparalleled.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_annihilator",
		name: "ANNIHILATOR",
		mount: "Main",
		type: "CQB",
		damage: [
			{
				type: "energy",
				val: "1d3+2"
			}
		],
		range: [
			{
				type: "Range",
				val: 5
			},
			{
				type: "Threat",
				val: 3
			}
		],
		tags: [
			{
				id: "tg_ap"
			},
			{
				id: "tg_heat_self",
				val: 2
			}
		],
		source: "HA",
		license: "TOKUGAWA",
		license_level: 1,
		effect: {
			effect_type: "Offensive",
			hit: "Make a secondary attack against all characters within burst 1 of the target. These attacks can’t deal bonus damage, and don’t trigger the Annihilator’s heat cost or secondary attacks."
		},
		description: "Harrison Armory is known to employ somewhat unconventional development methods: tactical solutions are theorized and designed in the field as often as they are in the lab, with the former often outperforming the latter. The Annihilator’s name comes from pilots’ slang for a jury-rigged weapon first improvised in the Bradbury Rebellion, when desperate resistance pilots found a way to shunt the incredible waste heat from their reactors into a directed blast.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_torch",
		name: "TORCH",
		mount: "Main",
		type: "Melee",
		damage: [
			{
				type: "energy",
				val: "1d6"
			},
			{
				type: "burn",
				val: 3
			}
		],
		range: [
			{
				type: "Threat",
				val: 1
			}
		],
		tags: [
			{
				id: "tg_overkill"
			},
			{
				id: "tg_heat_self",
				val: 2
			}
		],
		source: "HA",
		license: "TOKUGAWA",
		license_level: 2,
		effect: "",
		description: "The Torch is a potent weapon: a heavy  crescent-bladed plasma cutter, powered straight from a chassis’ reactor. Torches generally project as axes, though their blades can be changed to a range of other shapes. A common weapon in CQB theaters, the torch has lately become a status symbol among officers, carried by many alongside a smaller auxiliary weapon.",
		data_type: "weapon",
		aptitude: {
		}
	},
	{
		id: "mw_fuel_rod_gun",
		name: "Fuel Rod Gun",
		mount: "Main",
		type: "CQB",
		damage: [
			{
				type: "energy",
				val: "1d3+2"
			}
		],
		range: [
			{
				type: "Range",
				val: 3
			},
			{
				type: "Threat",
				val: 3
			}
		],
		tags: [
			{
				id: "tg_limited",
				val: 3
			},
			{
				id: "tg_unique"
			}
		],
		source: "",
		license: "",
		license_level: 0,
		talent_item: true,
		talent_id: "t_nuclear_cavalier",
		talent_rank: 3,
		effect: {
			effect_type: "Offensive",
			attack: "Clear 4 heat."
		},
		description: "Gained from the \"Nuclear Cavalier\" Rank 3 Talent",
		data_type: "weapon",
		aptitude: {
			ranged: 1
		}
	},
	{
		id: "mw_prototype_1",
		name: "Prototype Weapon",
		mount: "Main",
		type: "Special",
		damage: [
			{
				type: "variable",
				val: "1d6+2"
			}
		],
		range: [
			{
				type: "Threat",
				val: 1
			},
			{
				type: "Range",
				val: 10
			}
		],
		tags: [
			{
				id: "tg_limited",
				val: "1d6+2"
			},
			{
				id: "tg_overkill"
			},
			{
				id: "tg_set_max_uses"
			},
			{
				id: "tg_set_damage_type"
			}
		],
		source: "",
		license: "",
		license_level: 0,
		talent_item: true,
		talent_id: "t_engineer",
		talent_rank: 1,
		effect: "This weapon is an experimental prototype, customized according to your specific requirements.<br>When you install it, or during a Full Repair, you may choose a new weapon type, damage type, and either Threat 1 (melee) or Range 10 (all other types). Additionally, each time you perform a Full Repair, reroll 1d6+2 to determine this weapon’s Limited uses.",
		description: "Gained from the <i>\"Engineer\" Rank I</i> Talent",
		data_type: "weapon",
		aptitude: {
			ranged: 1,
			Melee: 1
		}
	},
	{
		id: "mw_prototype_2",
		name: "Prototype Weapon",
		mount: "Main",
		type: "Special",
		damage: [
			{
				type: "variable",
				val: "1d6+2"
			}
		],
		range: [
			{
				type: "Threat",
				val: 1
			},
			{
				type: "Range",
				val: 10
			}
		],
		tags: [
			{
				id: "tg_limited",
				val: "1d6+2"
			},
			{
				id: "tg_overkill"
			},
			{
				id: "tg_set_max_uses"
			},
			{
				id: "tg_set_damage_type"
			}
		],
		source: "",
		license: "",
		license_level: 0,
		talent_item: true,
		talent_id: "t_engineer",
		talent_rank: 2,
		effect: "This weapon is an experimental prototype, customized according to your specific requirements.<br>When you install it, or during a Full Repair, you may choose a new weapon type, damage type, and either Threat 1 (melee) or Range 10 (all other types). Additionally, each time you perform a Full Repair, reroll 1d6+2 to determine this weapon’s Limited uses and choose two:<ul><li><b>Tweaked Optics:</b> Your prototype weapon always gains +1 Accuracy on attacks.</li><li><b>Tweaked Computer:</b> Your prototype weapon is Smart.</li><li><b>Stripped reactor shielding:</b> Each time you attack with your prototype weapon, you may choose – at the cost of 2 Heat – to attack with one of the following options, depending on its weapon type:<ul><li><b>Ranged weapon:</b> Cone 3, Line 5, or [Blast 1, Range 10].</li><li><b>Melee weapon:</b> Burst 1.</li></li></ul></ul>",
		description: "Gained from the <i>\"Engineer\" Rank II</i> Talent",
		data_type: "weapon",
		aptitude: {
			ranged: 1,
			Melee: 1
		}
	},
	{
		id: "mw_prototype_3",
		name: "Prototype Weapon",
		mount: "Main",
		type: "Special",
		damage: [
			{
				type: "variable",
				val: "1d6+4"
			}
		],
		range: [
			{
				type: "Threat",
				val: 1
			},
			{
				type: "Range",
				val: 10
			}
		],
		tags: [
			{
				id: "tg_limited",
				val: "2d6"
			},
			{
				id: "tg_overkill"
			},
			{
				id: "tg_set_max_uses"
			},
			{
				id: "tg_set_damage_type"
			}
		],
		source: "",
		license: "",
		license_level: 0,
		talent_item: true,
		talent_id: "t_engineer",
		talent_rank: 3,
		effect: "This weapon is an experimental prototype, customized according to your specific requirements.<br>When you install it, or during a Full Repair, you may choose a new weapon type, damage type, and either Threat 1 (melee) or Range 10 (all other types). Additionally, each time you perform a Full Repair, reroll 1d6+2 to determine this weapon’s Limited uses and choose two:<ul><li><b>Tweaked Optics:</b> Your prototype weapon always gains +1 Accuracy on attacks.</li><li><b>Tweaked Computer:</b> Your prototype weapon is Smart.</li><li><b>Stripped reactor shielding:</b> Each time you attack with your prototype weapon, you may choose – at the cost of 2 Heat – to attack with one of the following options, depending on its weapon type:<ul><li><b>Ranged weapon:</b> Cone 3, Line 5, or [Blast 1, Range 10].</li><li><b>Melee weapon:</b> Burst 1.</li></li></ul></ul>",
		description: "Gained from the <i>\"Engineer\" Rank III</i> Talent",
		data_type: "weapon",
		aptitude: {
			ranged: 1,
			Melee: 1
		}
	},
	{
		id: "mw_lancaster_integrated",
		name: "Latch Drone",
		mount: "Main",
		type: "Launcher",
		range: [
			{
				type: "Range",
				val: 8
			}
		],
		tags: [
		],
		effect: "This weapon can’t make normal attacks. Instead, choose an allied mech within Range and line of sight and make a ranged attack against Evasion 8. On a hit, either you or your target may spend 1 Repair to restore half your target’s HP."
	},
	{
		id: "mw_raleigh_integrated",
		name: "M35 Mjolnir",
		mount: "Main",
		type: "CQB",
		range: [
			{
				type: "Range",
				val: 5
			},
			{
				type: "Threat",
				val: 3
			}
		],
		damage: [
			{
				type: "kinetic",
				val: 4
			}
		],
		effect: "1/round, when you reload any weapon, this weapon can be fired as a free action.",
		tags: [
		]
	},
	{
		id: "mw_barbarossa_integrated",
		name: "Apocalypse Rail",
		mount: "Ship-class",
		type: "Spool Weapon",
		damage: [
			{
				type: "explosive",
				override: true,
				val: "2d6 / 3d6 / 4d6"
			}
		],
		range: [
			{
				type: "variable",
				override: true,
				val: "Range 20 / 25 / 30, Blast 2"
			}
		],
		effect: {
			effect_type: "Offensive",
			detail: "The Apocalypse Rail must be charged before it can be fired, using the Charge Rail CORE Power.<br>This weapon has different profiles determined by the current value of the APOCALYPSE DIE when you fire it. Each profile replaces the one proceeding it. The Apocalypse Rail cannot be fired at targets within range 5.<br> After an attack with the Apocalypse Rail, the Apocalypse Die resets to 4.",
			abilities: [
				{
					effect_type: "Profile",
					name: "4",
					detail: "Cannot Be Fired"
				},
				{
					effect_type: "Profile",
					name: "3",
					range: [
						{
							type: "Range",
							val: 20
						},
						{
							type: "Blast",
							val: 2
						}
					],
					damage: [
						{
							type: "explosive",
							val: "2d6"
						}
					],
					detail: "Objects within the affected area automatically take 20 AP explosive damage. After the attack, the blast cloud lingers, providing soft cover to characters within the affected area until the end of your next turn."
				},
				{
					effect_type: "Profile",
					name: "2",
					range: [
						{
							type: "Range",
							val: 25
						},
						{
							type: "Blast",
							val: 2
						}
					],
					damage: [
						{
							type: "explosive",
							val: "3d6"
						}
					],
					detail: "Objects and terrain in the area automatically take 40 AP explosive damage, and on hit characters become Shredded and Impaired until the end of their next turn. The blast cloud is a burning storm: until the end of your next turn, characters within the affected area receive soft cover, and characters that start their turn within the area or move there for the first time in a round take 4 burn."
				},
				{
					effect_type: "Profile",
					name: "1",
					range: [
						{
							type: "Range",
							val: 30
						},
						{
							type: "Blast",
							val: 2
						}
					],
					damage: [
						{
							type: "explosive",
							val: "4d6"
						}
					],
					detail: "Objects and terrain in the area automatically take 100 AP explosive damage, and characters become Shredded and Stunned until the end of their next turn on hit. The ground in the affected area is vaporized on impact: for the rest of the scene, it is difficult terrain, characters within the affected area receive soft cover, and characters that start their turn with the area or move there for the first time in a round take 4 burn."
				}
			]
		},
		tags: [
		]
	},
	{
		id: "mw_sherman_integrated",
		name: "ZF4 SOLIDCORE",
		mount: "Main",
		type: "Cannon",
		range: [
			{
				type: "Line",
				val: "4/Charge"
			}
		],
		damage: [
			{
				type: "energy",
				val: "1d6/Charge"
			}
		],
		effect: "This weapon’s profile is determined by the number of Charges it carries. It begins with 1 Charge, dealing 1d6 energy with line 4. Each time you Stabilize, you gain an additional 1 Charge, up to a maximum of 4. The ZF4 gains an additional +4 range and +1d6 energy damage for each charge, and resets to 1 Charge after each attack. Charges persist between scenes, but are lost during a full repair.",
		tags: [
			{
				id: "tg_ordnance"
			}
		]
	}
];

var weapons$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    'default': weapons
});

function getCjsExportFromNamespace (n) {
	return n && n['default'] || n;
}

var require$$0 = getCjsExportFromNamespace(actions$1);

var require$$1 = getCjsExportFromNamespace(backgrounds$1);

var require$$2 = getCjsExportFromNamespace(core_bonuses$1);

var require$$3 = getCjsExportFromNamespace(environments$1);

var require$$4 = getCjsExportFromNamespace(frames$1);

var require$$5 = getCjsExportFromNamespace(glossary$1);

var require$$6 = getCjsExportFromNamespace(info$1);

var require$$7 = getCjsExportFromNamespace(manufacturers$1);

var require$$8 = getCjsExportFromNamespace(factions$1);

var require$$9 = getCjsExportFromNamespace(mods$1);

var require$$10 = getCjsExportFromNamespace(pilot_gear$1);

var require$$11 = getCjsExportFromNamespace(quirks$1);

var require$$12 = getCjsExportFromNamespace(reserves$1);

var require$$13 = getCjsExportFromNamespace(rules$1);

var require$$14 = getCjsExportFromNamespace(sitreps$1);

var require$$15 = getCjsExportFromNamespace(skills$1);

var require$$16 = getCjsExportFromNamespace(statuses$1);

var require$$17 = getCjsExportFromNamespace(systems$1);

var require$$18 = getCjsExportFromNamespace(tags$1);

var require$$19 = getCjsExportFromNamespace(talents$1);

var require$$20 = getCjsExportFromNamespace(weapons$1);

const data = {
  actions: require$$0,
  backgrounds: require$$1,
  core_bonuses: require$$2,
  environments: require$$3,
  frames: require$$4,
  glossary: require$$5,
  info: require$$6,
  manufacturers: require$$7,
  factions: require$$8,
  mods: require$$9,
  npc_classes: [],
  npc_features: [],
  npc_templates: [],
  pilot_gear: require$$10,
  quirks: require$$11,
  reserves: require$$12,
  rules: require$$13,
  sitreps: require$$14,
  skills: require$$15,
  statuses: require$$16,
  systems: require$$17,
  tags: require$$18,
  talents: require$$19,
  weapons: require$$20,
};

var lancerData = data;

/**
 * Search for a tag in lancer-data.
 * @param id The tag's lancer-data id string.
 * @returns The full tag data.
 */
function findTag(id) {
    // Only check if we actually got something.
    if (id) {
        const tags = lancerData.tags;
        // Find the tag id in lancer-data
        for (let i = 0; i < tags.length; i++) {
            const t = tags[i];
            if (t.id === id) {
                return t;
            }
        }
    }
    return null;
}
/**
 * Prepares a tag's name, description, and value.
 * @param tag The tag to prepare.
 */
function prepareTag(tag) {
    // Initialize if we need to
    if (tag === null)
        tag = { name: "", description: "", id: "" };
    // If we have a pre-defined tag, insert info. Otherwise, leave it as-is.
    if (tag["id"]) {
        // Look up values
        const tagdata = findTag(tag["id"]);
        tag["name"] = tagdata["name"];
        tag["description"] = tagdata["description"];
        let val = 0;
        if (tag.val)
            val = tag.val;
        else if (tagdata.val)
            val = tagdata.val;
        // If the tag has a value, insert it into the text.
        if (val !== 0) {
            tag["val"] = val;
            tag["name"] = tag["name"].replace("{VAL}", String(tag["val"]));
            tag["description"] = tag["description"].replace("{VAL}", String(tag["val"]));
        }
    }
    return tag;
}
/**
 * Handlebars helper to generate compact read-only tag template.
 * @param tagShort an object containing the tag's ID and value.
 * @returns The html template for the tag.
 */
function renderCompactTag(tag, key) {
    let template = "";
    tag = prepareTag(tag);
    // Don't render hidden tags
    if (tag["hidden"])
        return template;
    // Generate the Handlebars partial. This will always be the read-only
    template = `<div class="compact-tag flexrow">
  <i class="mdi mdi-label i--s i--light"></i>
  <span style="margin: 3px;">${tag.name}</span>
  </div>`;
    return template;
}
function renderChunkyTag(tag, key) {
    let template = "";
    tag = prepareTag(tag);
    // Don't render hidden tags
    if (tag["hidden"])
        return template;
    // Editable partial
    template = `<div class="tag flexrow arrayed-item" data-key="${key}">
    <div class="tag-label">
      <i class="med-icon fa fa-3x fa-tag" style="margin: 3px"></i>
    </div>
    <div class="flexcol">
      <input type="String" name="data.tags.${key}.name" value="${tag.name}" data-dtype="String" class="lancer-invisible-input medium theme--main" style="grid-area: 1/2/2/3; text-align:left; padding-left: 0.5em; margin-top: 0.25em;"/>
      <textarea class="lancer-invisible-input effect-text" type="string" name="data.tags.${key}.description" data-dtype="String" style="grid-area: 2/2/3/3">${tag.description}</textarea>
      <a class="remove-button fa fa-trash clickable" data-action="delete" style="grid-area: 2/3/3/4; margin-right: 11px; margin-top: -.8em; justify-self: right; align-self: self-start"></a>
    </div>
  </div>`;
    return template;
}
/**
 * Handlebars helper to generate verbose tag template.
 * @param tagShort an object containing the tag's ID and value.
 * @returns The html template for the tag.
 */
function renderFullTag(tag, key, data_prefix = "data.tags") {
    let template = "";
    tag = prepareTag(tag);
    // Don't render hidden tags
    if (tag["hidden"])
        return template;
    // Editable partial
    template = `<div class="tag arrayed-item" data-key="${key}">
  <i class="mdi mdi-label i--l theme--main" style="grid-area: 1/1/3/2;"></i>
  <input type="String" name="${data_prefix}.${key}.name" value="${tag.name}" data-dtype="String" class="lancer-invisible-input medium theme--main" style="grid-area: 1/2/2/3; text-align:left; padding-left: 0.5em; margin-top: 0.25em;"/>
  <textarea class="lancer-invisible-input effect-text" type="string" name="${data_prefix}.${key}.description" data-dtype="String" style="grid-area: 2/2/3/3">${tag.description}</textarea>
  <a class="remove-button fa fa-trash clickable" data-action="delete" style="grid-area: 2/3/3/4; margin-right: 11px; margin-top: -.8em; justify-self: right; align-self: self-start"></a>
  </div>`;
    return template;
}

/**
 * Perform a system migration for the entire World, applying migrations for Actors, Items, and Compendium packs
 * @return {Promise}      A Promise which resolves once the migration is completed
 */
const migrateWorld = async function () {
    ui.notifications.info(`Applying LANCER System Migration for version ${game.system.data.version}. Please be patient and do not close your game or shut down your server.`, { permanent: true });
    // Migrate World Actors
    for (let a of game.actors.entities) {
        try {
            const updateData = migrateActorData(a);
            if (!isObjectEmpty(updateData)) {
                console.log(`Migrating Actor entity ${a.name}`);
                await a.update(updateData, { enforceTypes: false });
            }
        }
        catch (err) {
            console.error(err);
        }
    }
    // Migrate World Items
    for (let i of game.items.entities) {
        try {
            const updateData = migrateItemData(i);
            if (!isObjectEmpty(updateData)) {
                console.log(`Migrating Item entity ${i.name}`);
                await i.update(updateData, { enforceTypes: false });
            }
        }
        catch (err) {
            console.error(err);
        }
    }
    // Migrate Actor Override Tokens
    for (let s of game.scenes.entities) {
        try {
            const updateData = migrateSceneData(s);
            if (!isObjectEmpty(updateData)) {
                console.log(`Migrating Scene entity ${s.name}`);
                await s.update(updateData, { enforceTypes: false });
            }
        }
        catch (err) {
            console.error(err);
        }
    }
    // Migrate World Compendium Packs
    game.packs.forEach(async (p) => {
        if ((p.metadata.package === "world") && ["Actor", "Item", "Scene"].includes(p.metadata.entity)) {
            await migrateCompendium(p);
        }
    });
    // Set the migration as complete
    game.settings.set("lancer", "systemMigrationVersion", game.system.data.version);
    ui.notifications.info(`LANCER System Migration to version ${game.system.data.version} completed!`, { permanent: true });
};
/* -------------------------------------------- */
/**
 * Apply migration rules to all Entities within a single Compendium pack
 * @param pack
 * @return {Promise}
 */
const migrateCompendium = async function (pack) {
    const entity = pack.metadata.entity;
    if (!["Actor", "Item", "Scene"].includes(entity))
        return;
    // Begin by requesting server-side data model migration and get the migrated content
    await pack.migrate({});
    const content = await pack.getContent();
    // Iterate over compendium entries - applying fine-tuned migration functions
    for (let ent of content) {
        try {
            let updateData = null;
            if (entity === "Item")
                updateData = migrateItemData(ent);
            else if (entity === "Actor")
                updateData = migrateActorData(ent);
            else if (entity === "Scene")
                updateData = migrateSceneData(ent.data);
            if (!isObjectEmpty(updateData)) {
                expandObject(updateData);
                updateData["_id"] = ent._id;
                await pack.updateEntity(updateData);
                console.log(`Migrated ${entity} entity ${ent.name} in Compendium ${pack.collection}`);
            }
        }
        catch (err) {
            console.error(err);
        }
    }
    console.log(`Migrated all ${entity} entities from Compendium ${pack.collection}`);
};
/* -------------------------------------------- */
/*  Entity Type Migration Helpers               */
/* -------------------------------------------- */
/**
 * Migrate a single Actor entity to incorporate latest data model changes
 * Return an Object of updateData to be applied
 * @param {Actor} actor   The actor to Update
 * @return {Object}       The updateData to apply
 */
const migrateActorData = function (actor) {
    const updateData = {};
    const ad = actor.data;
    // Migrate to pilot data model
    if (ad.type === "pc" || ad.type === "npc") {
        console.log(ad);
        // Mech data'
        updateData.mech = {};
        updateData.mech.hull = ad.data.mech.hull.value;
        updateData.mech.agility = ad.data.mech.agility.value;
        updateData.mech.systems = ad.data.mech.systems.value;
        updateData.mech.engineering = ad.data.mech.engineering.value;
        updateData.mech.armor = ad.data.mech.armor.value;
        updateData.mech.speed = ad.data.mech.speed.value;
        updateData.mech.evasion = ad.data.mech.evasion.value;
        updateData.mech.edef = ad.data.mech.edef.value;
        updateData.mech.sensors = ad.data.mech.sensors.value;
        updateData.mech.save = ad.data.mech.save.value;
    }
    if (ad.type === "pc") {
        // Pilot data
        updateData.pilot = {};
        updateData.pilot.grit = ad.data.pilot.grit.value;
        updateData.pilot.stats = {};
        updateData.pilot.stats.armor = ad.data.pilot.stats.armor.value;
        updateData.pilot.stats.evasion = ad.data.pilot.stats.evasion.value;
        updateData.pilot.stats.edef = ad.data.pilot.stats.edef.value;
        updateData.pilot.stats.speed = ad.data.pilot.stats.speed.value;
        // Migrate type to pilot
        updateData.type = "pilot";
    }
    // Migrate Owned Items
    if (!actor.items)
        return updateData;
    let hasItemUpdates = false;
    const items = actor.items.map(i => {
        // Migrate the Owned Item
        let itemUpdate = migrateItemData(i);
        // Update the Owned Item
        if (!isObjectEmpty(itemUpdate)) {
            hasItemUpdates = true;
            return mergeObject(i, itemUpdate, { enforceTypes: false, inplace: false });
        }
        else
            return i;
    });
    if (hasItemUpdates)
        updateData.items = items;
    // Remove deprecated fields
    _migrateRemoveDeprecated(actor, updateData);
    return updateData;
};
/* -------------------------------------------- */
/**
 * Migrate a single Item entity to incorporate latest data model changes
 * @param item
 */
const migrateItemData = function (item) {
    const updateData = {};
    // Remove deprecated fields
    _migrateRemoveDeprecated(item, updateData);
    // Return the migrated update data
    return updateData;
};
/* -------------------------------------------- */
/**
 * Migrate a single Scene entity to incorporate changes to the data model of it's actor data overrides
 * Return an Object of updateData to be applied
 * @param {Object} scene  The Scene data to Update
 * @return {Object}       The updateData to apply
 */
const migrateSceneData = function (scene) {
    const tokens = duplicate(scene.tokens);
    return {
        tokens: tokens.map(t => {
            if (!t.actorId || t.actorLink || !t.actorData.data) {
                t.actorData = {};
                return t;
            }
            const token = new Token(t);
            if (!token.actor) {
                t.actorId = null;
                t.actorData = {};
            }
            else if (!t.actorLink) {
                const updateData = migrateActorData(token.data.actorData);
                t.actorData = mergeObject(token.data.actorData, updateData);
            }
            return t;
        })
    };
};
/* -------------------------------------------- */
/**
 * A general migration to remove all fields from the data model which are flagged with a _deprecated tag
 * @private
 */
const _migrateRemoveDeprecated = function (ent, updateData) {
    const flat = flattenObject(ent.data);
    // Identify objects to deprecate
    const toDeprecate = Object.entries(flat).filter(e => e[0].endsWith("_deprecated") && (e[1] === true)).map(e => {
        let parent = e[0].split(".");
        parent.pop();
        return parent.join(".");
    });
    // Remove them
    for (let k of toDeprecate) {
        let parts = k.split(".");
        parts[parts.length - 1] = "-=" + parts[parts.length - 1];
        updateData[`data.${parts.join(".")}`] = null;
    }
};

var migrations = /*#__PURE__*/Object.freeze({
    __proto__: null,
    migrateWorld: migrateWorld,
    migrateCompendium: migrateCompendium,
    migrateActorData: migrateActorData,
    migrateItemData: migrateItemData,
    migrateSceneData: migrateSceneData
});

/**
 * TypeScript entry file for Foundry VTT.
 * Registers custom settings, sheets, and constants using the Foundry API.
 *
 * Author: Eranziel
 * Content License: LANCER is copyright 2019, Massif Press Inc.
 * Software License: GNU GPLv3
 */
const lp$6 = LANCER.log_prefix;
/* ------------------------------------ */
/* Initialize system                    */
/* ------------------------------------ */
Hooks.once('init', async function () {
    console.log(`Initializing LANCER RPG System ${LANCER.ASCII}`);
    // Assign custom classes and constants here
    // Create a Lancer namespace within the game global
    game.lancer = {
        applications: {
            LancerPilotSheet,
            LancerNPCSheet,
            LancerDeployableSheet,
            LancerItemSheet,
        },
        entities: {
            LancerActor,
            LancerItem,
        },
        rollStatMacro: rollStatMacro,
        rollAttackMacro: rollAttackMacro,
        rollTechMacro: rollTechMacro,
        rollTriggerMacro: rollTriggerMacro,
        migrations: migrations,
    };
    // Record Configuration Values
    CONFIG.Actor.entityClass = LancerActor;
    CONFIG.Item.entityClass = LancerItem;
    // Register custom system settings
    registerSettings();
    // Register Web Components
    customElements.define('card-clipped', class LancerClippedCard extends HTMLDivElement {
    }, { extends: 'div' });
    // Preload Handlebars templates
    await preloadTemplates();
    // Register sheet application classes
    Actors.unregisterSheet("core", ActorSheet);
    Actors.registerSheet("lancer", LancerPilotSheet, { types: ["pilot"], makeDefault: true });
    Actors.registerSheet("lancer", LancerNPCSheet, { types: ["npc"], makeDefault: true });
    Actors.registerSheet("lancer", LancerDeployableSheet, { types: ["deployable"], makeDefault: true });
    Items.unregisterSheet("core", ItemSheet);
    Items.registerSheet("lancer", LancerItemSheet, {
        types: ["skill", "talent", "license", "core_bonus",
            "pilot_armor", "pilot_weapon", "pilot_gear",
            "mech_system", "mech_weapon",
            "npc_template", "npc_feature"],
        makeDefault: true
    });
    Items.registerSheet("lancer", LancerFrameSheet, { types: ["frame"], makeDefault: true });
    Items.registerSheet("lancer", LancerNPCClassSheet, { types: ["npc_class"], makeDefault: true });
    // Register handlebars helpers
    // inc, for those off-by-one errors
    Handlebars.registerHelper('inc', function (value) {
        return parseInt(value) + 1;
    });
    // dec, for those off-by-one errors
    Handlebars.registerHelper('dec', function (value) {
        return parseInt(value) - 1;
    });
    // get an index from an array
    Handlebars.registerHelper('idx', function (array, index) {
        return array[index];
    });
    // invert the input
    Handlebars.registerHelper('neg', function (value) {
        return parseInt(value) * -1;
    });
    // double the input
    Handlebars.registerHelper('double', function (value) {
        return parseInt(value) * 2;
    });
    // Equal-to evaluation
    Handlebars.registerHelper('eq', function (val1, val2) {
        return val1 === val2;
    });
    // Equal-to evaluation
    Handlebars.registerHelper('neq', function (val1, val2) {
        return val1 !== val2;
    });
    // Greater-than evaluation
    Handlebars.registerHelper('gt', function (val1, val2) {
        return val1 > val2;
    });
    // Greater-than evaluation after applying parseInt to both values
    Handlebars.registerHelper('gtpi', function (val1, val2) {
        val1 = parseInt(val1);
        val2 = parseInt(val2);
        return val1 > val2;
    });
    // Less-than evaluation
    Handlebars.registerHelper('lt', function (val1, val2) {
        return val1 < val2;
    });
    // Greater-than evaluation after applying parseInt to both values
    Handlebars.registerHelper('ltpi', function (val1, val2) {
        val1 = parseInt(val1);
        val2 = parseInt(val2);
        return val1 < val2;
    });
    Handlebars.registerHelper('lower-case', function (str) {
        return str.toLowerCase();
    });
    Handlebars.registerHelper('upper-case', function (str) {
        return str.toUpperCase();
    });
    Handlebars.registerHelper('compact-tag', renderCompactTag);
    Handlebars.registerHelper('chunky-tag', renderChunkyTag);
    Handlebars.registerHelper('full-tag', renderFullTag);
    Handlebars.registerHelper('tier-selector', (tier, key) => {
        let template = `<select id="tier-type" class="tier-control" data-action="update">
		<option value="npc-tier-1" ${tier === 'npc-tier-1' ? 'selected' : ''}>TIER 1</option>
		<option value="npc-tier-2" ${tier === 'npc-tier-2' ? 'selected' : ''}>TIER 2</option>
		<option value="npc-tier-3" ${tier === 'npc-tier-3' ? 'selected' : ''}>TIER 3</option>
		<option value="npc-tier-custom" ${tier === 'npc-tier-custom' ? 'selected' : ''}>CUSTOM</option>
	</select>`;
        return template;
    });
    // mount display mount
    Handlebars.registerHelper('mount-selector', (mount, key) => {
        let template = `<select id="mount-type" class="mounts-control" data-action="update" data-item-id=${key}>
	        <option value="Main" ${mount.type === 'Main' ? 'selected' : ''}>Main Mount</option>
	        <option value="Heavy" ${mount.type === 'Heavy' ? 'selected' : ''}>Heavy Mount</option>
	        <option value="Aux-Aux" ${mount.type === 'Aux-Aux' ? 'selected' : ''}>Aux/Aux Mount</option>
	        <option value="Main-Aux" ${mount.type === 'Main-Aux' ? 'selected' : ''}>Main/Aux Mount</option>
	        <option value="Flex" ${mount.type === 'Flex' ? 'selected' : ''}>Flexible Mount</option>
	        <option value="Integrated" ${mount.type === 'Integrated' ? 'selected' : ''}>Integrated Mount</option>
        </select>`;
        return template;
    });
    Handlebars.registerPartial('mech-weapon-preview', `<div class="flexcol clipped lancer-weapon-container weapon" style="max-height: fit-content;" data-item-id="{{key}}">
      <div class="lancer-weapon-header clipped-top item" style="grid-area: 1/1/2/3" data-item-id="{{weapon._id}}">
        <i class="cci cci-weapon i--m i--light"> </i>
        <span class="minor">{{weapon.name}} // {{upper-case weapon.data.mount}} {{upper-case weapon.data.weapon_type}}</span>
        <a class="stats-control i--light" data-action="delete"><i class="fas fa-trash"></i></a>
      </div> 
      <div class="lancer-weapon-body">
        <a class="roll-attack" style="grid-area: 1/1/2/2;"><i class="fas fa-dice-d20 i--m i--dark"></i></a>
        <div class="flexrow" style="grid-area: 1/2/2/3; text-align: left; white-space: nowrap;">
        {{#each weapon.data.range as |range rkey|}}
            {{#if range.val}}
            {{#if (gtpi rkey "0")}}<span class="flexrow" style="align-items: center; justify-content: center; max-width: min-content;"> // </span>{{/if}}
            <div class="compact-range">
                <i class="cci cci-{{lower-case range.type}} i--m i--dark"></i>
                <span class="medium">{{range.val}}</span>
            </div>
            {{/if}}
        {{/each}}
        <hr class="vsep">
        {{#each weapon.data.damage as |damage dkey|}}
            {{#if damage.type}}
            <div class="compact-damage">
                <i class="card clipped cci cci-{{lower-case damage.type}} i--m damage--{{damage.type}}"></i>
                <span class="medium">{{damage.val}}</span>
            </div>
            {{/if}}
        {{/each}}
        </div>
        {{#with weapon.data.effect as |effect|}}
        <div class="flexcol" style="grid-area: 2/1/2/3; text-align: left; white-space: wrap">
          {{#if effect.effect_type}}
            <h3 class="medium flexrow">{{upper-case effect.effect_type}} EFFECT</h3>
            <span class="effect-text">{{{effect.hit}}}</span>
          {{/if}}
          {{#unless effect.effect_type}}<span class="effect-text">{{{effect}}}</span>{{/unless}}
          </div>
        {{/with}}
        <div class="flexrow" style="justify-content: flex-end; grid-area: 4/1/5/3">
          {{#each weapon.data.tags as |tag tkey|}}
          {{{compact-tag tag}}}
          {{/each}}
        </div>
      </div>
    </div>`);
    /*
    * Repeat given markup with given times
    * provides @index for the repeated iteraction
    */
    Handlebars.registerHelper("repeat", function (times, opts) {
        var out = "";
        var i;
        var data = {};
        if (times) {
            for (i = 0; i < times; i += 1) {
                data["index"] = i;
                out += opts.fn(this, {
                    data: data
                });
            }
        }
        else {
            out = opts.inverse(this);
        }
        return out;
    });
});
/* ------------------------------------ */
/* Setup system			            				*/
/* ------------------------------------ */
Hooks.once('setup', function () {
    // Do anything after initialization but before
    // ready
});
/* ------------------------------------ */
/* When ready                           */
/* ------------------------------------ */
Hooks.once('ready', function () {
    // Determine whether a system migration is required and feasible
    const currentVersion = game.settings.get("lancer", "systemMigrationVersion");
    // TODO: implement/import version comparison for semantic version numbers
    // const NEEDS_MIGRATION_VERSION = "0.0.4";
    // const COMPATIBLE_MIGRATION_VERSION = "0.0.4";
    // let needMigration = (currentVersion < NEEDS_MIGRATION_VERSION) || (currentVersion === null);
    // Perform the migration
    // TODO: replace game.system.version with needMigration once version number checking is implemented
    if (currentVersion != game.system.data.version && game.user.isGM) {
        // if ( currentVersion && (currentVersion < COMPATIBLE_MIGRATION_VERSION) ) {
        //   ui.notifications.error(`Your LANCER system data is from too old a Foundry version and cannot be reliably migrated to the latest version. The process will be attempted, but errors may occur.`, {permanent: true});
        // }
        migrateWorld();
    }
});
// Add any additional hooks if necessary
Hooks.on("preCreateActor", lancerActorInit);
Hooks.on("preCreateItem", lancerItemInit);
function getMacroSpeaker() {
    // Determine which Actor to speak as
    const speaker = ChatMessage.getSpeaker();
    console.log(`${lp$6} Macro speaker`, speaker);
    let actor;
    // console.log(game.actors.tokens);
    try {
        if (speaker.token)
            actor = game.actors.tokens[speaker.token].actor;
    }
    catch (TypeError) {
        // Need anything here?
    }
    if (!actor)
        actor = game.actors.get(speaker.actor, { strict: false });
    if (!actor) {
        ui.notifications.warn(`Failed to find Actor for macro. Do you need to select a token?`);
        return null;
    }
    return actor;
}
async function renderMacro(actor, template, templateData) {
    const html = await renderTemplate(template, templateData);
    let chat_data = {
        user: game.user,
        type: CONST.CHAT_MESSAGE_TYPES.IC,
        speaker: {
            actor: actor
        },
        content: html
    };
    let cm = await ChatMessage.create(chat_data);
    cm.render();
    return Promise.resolve();
}
async function rollTriggerMacro(title, modifier, sheetMacro = false) {
    let actor = getMacroSpeaker();
    if (actor === null)
        return;
    console.log(`${lp$6} rollTriggerMacro actor`, actor);
    // Get accuracy/difficulty with a prompt
    let acc = 0;
    let abort = false;
    await promptAccDiffModifier().then(resolve => acc = resolve, reject => abort = true);
    if (abort)
        return;
    // Do the roll
    let acc_str = acc != 0 ? ` + ${acc}d6kh1` : '';
    let roll = new Roll(`1d20+${modifier}${acc_str}`).roll();
    const roll_tt = await roll.getTooltip();
    // Construct the template
    const templateData = {
        title: title,
        roll: roll,
        roll_tooltip: roll_tt,
        effect: null
    };
    const template = `systems/lancer/templates/chat/stat-roll-card.html`;
    return renderMacro(actor, template, templateData);
}
async function rollStatMacro(title, statKey, effect, sheetMacro = false) {
    // Determine which Actor to speak as
    let actor = getMacroSpeaker();
    if (actor === null)
        return;
    console.log(`${lp$6} rollStatMacro actor`, actor);
    let bonus;
    const statPath = statKey.split(".");
    // Macros rolled directly from the sheet provide a stat key referenced from actor.data
    if (sheetMacro) {
        bonus = actor.data;
        // bonus = actor[`data.${statKey}`];
        // console.log(`${lp} actor.data`, actor['data']['data']);
    }
    else {
        bonus = actor;
    }
    for (let i = 0; i < statPath.length; i++) {
        const p = statPath[i];
        bonus = bonus[`${p}`];
    }
    console.log(`${lp$6} rollStatMacro `, statKey, bonus);
    // Get accuracy/difficulty with a prompt
    let acc = 0;
    let abort = false;
    await promptAccDiffModifier().then(resolve => acc = resolve, reject => abort = true);
    if (abort)
        return;
    // Do the roll
    let acc_str = acc != 0 ? ` + ${acc}d6kh1` : '';
    let roll = new Roll(`1d20+${bonus}${acc_str}`).roll();
    const roll_tt = await roll.getTooltip();
    // Construct the template
    const templateData = {
        title: title,
        roll: roll,
        roll_tooltip: roll_tt,
        effect: effect ? effect : null
    };
    const template = `systems/lancer/templates/chat/stat-roll-card.html`;
    return renderMacro(actor, template, templateData);
}
async function rollAttackMacro(w, a) {
    // Determine which Actor to speak as
    let actor = getMacroSpeaker();
    if (actor === null)
        return;
    // Get the item
    const item = game.actors.get(a).getOwnedItem(w);
    console.log(`${lp$6} Rolling attack macro`, item, w, a);
    if (!item) {
        ui.notifications.error(`Error rolling attack macro - could not find Item ${w} owned by Actor ${a}!`);
        return Promise.resolve();
    }
    else if (!item.isOwned) {
        ui.notifications.error(`Error rolling attack macro - ${item.name} is not owned by an Actor!`);
        return Promise.resolve();
    }
    let title = item.name;
    let grit = 0;
    let acc = 0;
    let damage;
    let effect;
    let tags;
    const wData = item.data.data;
    if (item.type === "mech_weapon") {
        grit = item.actor.data.data.pilot.grit;
        damage = wData.damage;
        tags = wData.tags;
        effect = wData.effect;
    }
    else if (item.type === "pilot_weapon") {
        grit = item.actor.data.data.pilot.grit;
        damage = wData.damage;
        tags = wData.tags;
        effect = wData.effect;
    }
    else if (item.type === "npc_feature") {
        const tier = item.actor.data.data.tier_num - 1;
        if (wData.attack_bonus && wData.attack_bonus[tier]) {
            grit = parseInt(wData.attack_bonus[tier]);
        }
        if (wData.accuracy && wData.accuracy[tier]) {
            acc = parseInt(wData.accuracy[tier]);
        }
        // Reduce damage values to only this tier
        damage = duplicate(wData.damage);
        damage.forEach(d => {
            d.val = d.val[tier];
        });
        tags = wData.tags;
        effect = wData.effect;
    }
    else {
        ui.notifications.error(`Error rolling attack macro - ${item.name} is not a weapon!`);
        return Promise.resolve();
    }
    console.log(`${lp$6} Attack Macro Item:`, item, grit, acc, damage);
    // Get accuracy/difficulty with a prompt
    let abort = false;
    await promptAccDiffModifier(acc).then(resolve => acc = resolve, reject => abort = true);
    if (abort)
        return;
    // Do the attack rolling
    let acc_str = acc != 0 ? ` + ${acc}d6kh1` : '';
    let atk_str = `1d20+${grit}${acc_str}`;
    console.log(`${lp$6} Attack roll string: ${atk_str}`);
    let attack_roll = new Roll(atk_str).roll();
    // Iterate through damage types, rolling each
    let damage_results = [];
    damage.forEach(async (x) => {
        const droll = new Roll(x.val.toString()).roll();
        const tt = await droll.getTooltip();
        damage_results.push({
            roll: droll,
            tt: tt,
            dtype: x.type,
        });
        return Promise.resolve();
    });
    // Output
    const attack_tt = await attack_roll.getTooltip();
    const templateData = {
        title: title,
        attack: attack_roll,
        attack_tooltip: attack_tt,
        damages: damage_results,
        effect: effect ? effect : null,
        tags: tags
    };
    const template = `systems/lancer/templates/chat/attack-card.html`;
    return renderMacro(actor, template, templateData);
}
async function rollTechMacro(t, a) {
    // Determine which Actor to speak as
    let actor = getMacroSpeaker();
    if (actor === null)
        return;
    // Get the item
    const item = game.actors.get(a).getOwnedItem(t);
    console.log(`${lp$6} Rolling tech attack macro`, item, t, a);
    if (!item) {
        ui.notifications.error(`Error rolling tech attack macro - could not find Item ${t} owned by Actor ${a}!`);
        return Promise.resolve();
    }
    else if (!item.isOwned) {
        ui.notifications.error(`Error rolling tech attack macro - ${item.name} is not owned by an Actor!`);
        return Promise.resolve();
    }
    let title = item.name;
    let t_atk = 0;
    let acc = 0;
    let effect;
    let tags;
    const tData = item.data.data;
    if (item.type === "mech_system") {
        t_atk = item.actor.data.data.mech.tech_attack;
        tags = tData.tags;
        effect = tData.effect;
    }
    else if (item.type === "npc_feature") {
        const tier = item.actor.data.data.tier_num - 1;
        if (tData.attack_bonus && tData.attack_bonus[tier]) {
            t_atk = parseInt(tData.attack_bonus[tier]);
        }
        if (tData.accuracy && tData.accuracy[tier]) {
            acc = parseInt(tData.accuracy[tier]);
        }
        tags = tData.tags;
        effect = tData.effect;
    }
    else {
        ui.notifications.error(`Error rolling tech attack macro - ${item.name} does not a tech attack!`);
        return Promise.resolve();
    }
    console.log(`${lp$6} Tech Attack Macro Item:`, item, t_atk, acc);
    // Get accuracy/difficulty with a prompt
    let abort = false;
    await promptAccDiffModifier(acc).then(resolve => acc = resolve, reject => abort = true);
    if (abort)
        return;
    // Do the attack rolling
    let acc_str = acc != 0 ? ` + ${acc}d6kh1` : '';
    let atk_str = `1d20+${t_atk}${acc_str}`;
    console.log(`${lp$6} Tech Attack roll string: ${atk_str}`);
    let attack_roll = new Roll(atk_str).roll();
    // Output
    const attack_tt = await attack_roll.getTooltip();
    const templateData = {
        title: title,
        attack: attack_roll,
        attack_tooltip: attack_tt,
        effect: effect ? effect : null,
        tags: tags
    };
    const template = `systems/lancer/templates/chat/tech-attack-card.html`;
    return renderMacro(actor, template, templateData);
}
function promptAccDiffModifier(acc) {
    if (!acc)
        acc = 0;
    let diff = 0;
    if (acc < 0) {
        diff = -acc;
        acc = 0;
    }
    let template = `
<form>
  <h2>Please enter your modifiers and submit, or close this window:</h2>
  <div class="flexcol">
    <label style="max-width: fit-content;">
      <i class="cci cci-accuracy i--m i--dark" style="vertical-align:middle;border:none"> </i> Accuracy:
      <input class="accuracy" type="number" min="0" value="${acc}">
    </label>
    <label style="max-width: fit-content;">
      <i class="cci cci-difficulty i--m i--dark" style="vertical-align:middle;border:none"> </i> Difficulty:
      <input class="difficulty" type="number" min="0" value="${diff}">
    </div>
</form>`;
    return new Promise((resolve, reject) => {
        new Dialog({
            title: "Accuracy and Difficulty",
            content: template,
            buttons: {
                submit: {
                    icon: '<i class="fas fa-check"></i>',
                    label: 'Submit',
                    callback: async (dlg) => {
                        let accuracy = $(dlg).find('.accuracy').first().val();
                        let difficulty = $(dlg).find('.difficulty').first().val();
                        let total = parseInt(accuracy) - parseInt(difficulty);
                        console.log(`${lp$6} Dialog returned ${accuracy} accuracy and ${difficulty} resulting in a modifier of ${total}d6`);
                        resolve(total);
                    }
                },
                cancel: {
                    icon: '<i class="fas fa-times"></i>',
                    label: 'Cancel',
                    callback: async () => {
                        reject();
                    }
                }
            },
            default: "submit",
            close: () => reject()
        }).render(true);
    });
}
//# sourceMappingURL=lancer.js.map

import data from 'lancer-data';
let lancerData = data;
export { lancerData };

var MountType;
(function (MountType) {
    MountType["Main"] = "Main";
    MountType["Heavy"] = "Heavy";
    MountType["AuxAux"] = "Aux/Aux";
    MountType["Aux"] = "Aux";
    MountType["MainAux"] = "Main/Aux";
    MountType["Flex"] = "Flex";
    MountType["Integrated"] = "Integrated";
})(MountType || (MountType = {}));
var WeaponSize;
(function (WeaponSize) {
    WeaponSize["Aux"] = "Auxiliary";
    WeaponSize["Main"] = "Main";
    WeaponSize["Heavy"] = "Heavy";
    WeaponSize["Superheavy"] = "Superheavy";
})(WeaponSize || (WeaponSize = {}));
var WeaponType;
(function (WeaponType) {
    WeaponType["Rifle"] = "Rifle";
    WeaponType["Cannon"] = "Cannon";
    WeaponType["Launcher"] = "Launcher";
    WeaponType["CQB"] = "CQB";
    WeaponType["Nexus"] = "Nexus";
    WeaponType["Melee"] = "Melee";
})(WeaponType || (WeaponType = {}));
var ItemType;
(function (ItemType) {
    ItemType["None"] = "";
    ItemType["Action"] = "Action";
    ItemType["CoreBonus"] = "CoreBonus";
    ItemType["Frame"] = "Frame";
    ItemType["PilotArmor"] = "PilotArmor";
    ItemType["PilotWeapon"] = "PilotWeapon";
    ItemType["PilotGear"] = "PilotGear";
    ItemType["Skill"] = "Skill";
    ItemType["Talent"] = "Talent";
    ItemType["Tag"] = "Tag";
    ItemType["MechWeapon"] = "MechWeapon";
    ItemType["MechSystem"] = "MechSystem";
    ItemType["WeaponMod"] = "WeaponMod";
    ItemType["NpcFeature"] = "NpcFeature";
})(ItemType || (ItemType = {}));
var PilotEquipType;
(function (PilotEquipType) {
    PilotEquipType["PilotArmor"] = "armor";
    PilotEquipType["PilotWeapon"] = "weapon";
    PilotEquipType["PilotGear"] = "gear";
})(PilotEquipType || (PilotEquipType = {}));
var SystemType;
(function (SystemType) {
    SystemType["System"] = "System";
    SystemType["AI"] = "AI";
    SystemType["Shield"] = "Shield";
    SystemType["Deployable"] = "Deployable";
    SystemType["Drone"] = "Drone";
    SystemType["Tech"] = "Tech";
    SystemType["Armor"] = "Armor";
    SystemType["FlightSystem"] = "Flight System";
    SystemType["Integrated"] = "Integrated";
    SystemType["Mod"] = "Mod";
})(SystemType || (SystemType = {}));
var RangeType;
(function (RangeType) {
    RangeType["Range"] = "Range";
    RangeType["Threat"] = "Threat";
    RangeType["Thrown"] = "Thrown";
    RangeType["Line"] = "Line";
    RangeType["Cone"] = "Cone";
    RangeType["Blast"] = "Blast";
    RangeType["Burst"] = "Burst";
})(RangeType || (RangeType = {}));
var DamageType;
(function (DamageType) {
    DamageType["Kinetic"] = "Kinetic";
    DamageType["Energy"] = "Energy";
    DamageType["Explosive"] = "Explosive";
    DamageType["Heat"] = "Heat";
    DamageType["Burn"] = "Burn";
    DamageType["Variable"] = "Variable";
})(DamageType || (DamageType = {}));
var MechType;
(function (MechType) {
    MechType["Balanced"] = "Balanced";
    MechType["Artillery"] = "Artillery";
    MechType["Striker"] = "Striker";
    MechType["Controller"] = "Controller";
    MechType["Support"] = "Support";
    MechType["Defender"] = "Defender";
})(MechType || (MechType = {}));
var HASE;
(function (HASE) {
    HASE["H"] = "hull";
    HASE["A"] = "agi";
    HASE["S"] = "sys";
    HASE["E"] = "eng";
})(HASE || (HASE = {}));
export { MountType, WeaponSize, WeaponType, ItemType, PilotEquipType, SystemType, RangeType, DamageType, HASE, MechType, };

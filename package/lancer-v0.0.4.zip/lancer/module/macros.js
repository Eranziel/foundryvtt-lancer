export class AttackMacro extends Macro {
    static async roll(grit, accuracy, damage) {
        let acc_str = "";
        if (accuracy > 0)
            acc_str = `+${accuracy}d6kh1`;
        if (accuracy < 0)
            acc_str = `-${accuracy}d6kh1`;
        let attack_roll = new Roll(`1d20+${grit}${acc_str}`).roll();
        let damage_roll = new Roll(damage).roll();
        console.log(`Attack: ${attack_roll}, Damage: ${damage_roll}`);
    }
}

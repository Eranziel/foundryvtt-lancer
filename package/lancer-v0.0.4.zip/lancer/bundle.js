'use strict';

const preloadTemplates = async function () {
    const templatePaths = [
        "systems/lancer/templates/actor-sheet.html" // May not be needed?
    ];
    return loadTemplates(templatePaths);
};

/**
 * Extend the basic ActorSheet with some very simple modifications
 */
class LancerActorSheet extends ActorSheet {
    constructor(...args) {
        super(...args);
        /**
         * Keep track of the currently active sheet tab
         * @type {string}
         */
        this._sheetTab = "dossier";
    }
    /* -------------------------------------------- */
    /**
     * Extend and override the default options used by the 5e Actor Sheet
     * @returns {Object}
     */
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            classes: ["lancer", "sheet", "actor"],
            template: "systems/lancer/templates/actor-sheet.html",
            width: 600,
            height: 600
        });
    }
    /* -------------------------------------------- */
    /**
     * Prepare data for rendering the Actor sheet
     * The prepared data object contains both the actor data as well as additional sheet options
     */
    getData() {
        const data = super.getData();
        //   console.log(data)
        // data.dtypes = ["String", "Number", "Boolean"];
        //   for ( let attr of Object.values(data.data.attributes) ) {
        //     attr.isCheckbox = attr.dtype === "Boolean";
        //   }
        console.log(data);
        return data;
    }
    /* -------------------------------------------- */
    /**
     * Activate event listeners using the prepared sheet HTML
     * @param html {HTML}   The prepared HTML object ready to be rendered into the DOM
     */
    activateListeners(html) {
        super.activateListeners(html);
        // Activate tabs
        let tabs = html.find('.tabs');
        let initial = this._sheetTab;
        new Tabs(tabs, {
            initial: initial,
            callback: clicked => this._sheetTab = clicked.data("tab")
        });
        // Everything below here is only needed if the sheet is editable
        if (!this.options.editable)
            return;
        //   // Update Inventory Item
        //   html.find('.item-edit').click(ev => {
        //     const li = $(ev.currentTarget).parents(".item");
        //     const item = this.actor.getOwnedItem(li.data("itemId"));
        //     item.sheet.render(true);
        //   });
        //   // Delete Inventory Item
        //   html.find('.item-delete').click(ev => {
        //     const li = $(ev.currentTarget).parents(".item");
        //     this.actor.deleteOwnedItem(li.data("itemId"));
        //     li.slideUp(200, () => this.render(false));
        //   });
        //   // Add or Remove Attribute
        //   html.find(".attributes").on("click", ".attribute-control", this._onClickAttributeControl.bind(this));
    }
    /* -------------------------------------------- */
    // async _onClickAttributeControl(event) {
    //   event.preventDefault();
    //   const a = event.currentTarget;
    //   const action = a.dataset.action;
    //   const attrs = this.object.data.data.attributes;
    //   const form = this.form;
    //   // Add new attribute
    //   if ( action === "create" ) {
    //     const nk = Object.keys(attrs).length + 1;
    //     let newKey = document.createElement("div");
    //     newKey.innerHTML = `<input type="text" name="data.attributes.attr${nk}.key" value="attr${nk}"/>`;
    //     newKey = newKey.children[0];
    //     form.appendChild(newKey);
    //     await this._onSubmit(event);
    //   }
    //   // Remove existing attribute
    //   else if ( action === "delete" ) {
    //     const li = a.closest(".attribute");
    //     li.parentElement.removeChild(li);
    //     await this._onSubmit(event);
    //   }
    // }
    /* -------------------------------------------- */
    /**
     * Implement the _updateObject method as required by the parent class spec
     * This defines how to update the subject of the form when the form is submitted
     * @private
     */
    _updateObject(event, formData) {
        // TODO: This isn't used anymore.
        // Handle the free-form attributes list
        const formAttrs = formData.data.attributes || {};
        const attributes = Object.values(formAttrs).reduce((obj, v) => {
            let k = v["key"].trim();
            if (/[\s\.]/.test(k))
                return ui.notifications.error("Attribute keys may not contain spaces or periods");
            delete v["key"];
            obj[k] = v;
            return obj;
        }, {});
        // Remove attributes which are no longer used
        for (let k of Object.keys(this.object.data.data.attributes)) {
            if (!attributes.hasOwnProperty(k))
                attributes[`-=${k}`] = null;
        }
        // Re-combine formData
        formData = Object.entries(formData).filter(e => !e[0].startsWith("data.attributes")).reduce((obj, e) => {
            obj[e[0]] = e[1];
            return obj;
        }, { _id: this.object._id, "data.attributes": attributes });
        // Update the Actor
        return this.object.update(formData);
    }
}

/**
 * TypeScript entry file for Foundry VTT.
 * Registers custom settings, sheets, and constants using the Foundry API.
 *
 * Author: Eranziel
 * Content License: LANCER is copyright 2019, Massif Press Inc.
 * Software License: GNU GPLv3
 */
// TODO: What is the difference between require and import???
const lancerData = require('lancer-data');
// import { lancerData } from 'lancer-data'
/* ------------------------------------ */
/* Initialize system					*/
/* ------------------------------------ */
Hooks.once('init', async function () {
    console.log(`Initializing LANCER RPG System 
	╭╮╱╱╭━━━┳━╮╱╭┳━━━┳━━━┳━━━╮ 
	┃┃╱╱┃╭━╮┃┃╰╮┃┃╭━╮┃╭━━┫╭━╮┃ 
	┃┃╱╱┃┃╱┃┃╭╮╰╯┃┃╱╰┫╰━━┫╰━╯┃ 
	┃┃╱╭┫╰━╯┃┃╰╮┃┃┃╱╭┫╭━━┫╭╮╭╯ 
	┃╰━╯┃╭━╮┃┃╱┃┃┃╰━╯┃╰━━┫┃┃╰╮ 
	╰━━━┻╯╱╰┻╯╱╰━┻━━━┻━━━┻╯╰━╯`);
    // Assign custom classes and constants here
    // Create a Lancer namespace within the game global
    game.lancer = {
        rollAttackMacro
    };
    // Preload Handlebars templates
    await preloadTemplates();
    // Register sheet application classes
    Actors.unregisterSheet("core", ActorSheet);
    Actors.registerSheet("lancer", LancerActorSheet, { makeDefault: true });
});
/* ------------------------------------ */
/* Setup system							*/
/* ------------------------------------ */
Hooks.once('setup', function () {
    //=== Code below must be omitted from release ====
    convertLancerData();
    //=== End omit from release ======================
});
/* ------------------------------------ */
/* When ready							*/
/* ------------------------------------ */
Hooks.once('ready', function () {
    // Do anything once the system is ready
});
// Add any additional hooks if necessary
async function rollAttackMacro(title, grit, accuracy, damage, effect) {
    // Determine which Actor to speak as
    const speaker = ChatMessage.getSpeaker();
    let actor;
    if (speaker.token)
        actor = game.actors.tokens[speaker.token].actor;
    if (!actor)
        actor = game.actors.get(speaker.actor, { strict: false });
    // Do the rolling
    let acc_str = "";
    if (accuracy > 0)
        acc_str = ` + ${accuracy}d6kh1`;
    if (accuracy < 0)
        acc_str = ` - ${accuracy}d6kh1`;
    let attack_roll = new Roll(`1d20+${grit}${acc_str}`).roll();
    let damage_roll = new Roll(damage).roll();
    // Output
    const attack_tt = await attack_roll.getTooltip();
    const damage_tt = await damage_roll.getTooltip();
    const templateData = {
        title: title,
        attack: attack_roll,
        attack_tooltip: attack_tt,
        damage: damage_roll,
        damage_tooltip: damage_tt,
        effect: effect ? effect : null
    };
    const template = `systems/lancer/templates/chat/attack-card.html`;
    const html = await renderTemplate(template, templateData);
    let chat_data = {
        user: game.user,
        type: CONST.CHAT_MESSAGE_TYPES.IC,
        speaker: {
            actor: actor
        },
        content: html
    };
    let cm = await ChatMessage.create(chat_data);
    cm.render();
}
//========================================================
// Everything below here should NOT go in release!
//========================================================
async function convertLancerData() {
    console.log("LANCER | Building Skill Triggers compendium.");
    await convertSkills();
    return Promise.resolve();
}
async function convertSkills() {
    const skills = lancerData.skills;
    // Create a Compendium for skill triggers
    const metaData = {
        name: "skills",
        label: "Skill Triggers",
        system: "lancer",
        path: "./packs/skills.db",
        entity: "Item"
    };
    let skillComp = new Compendium(metaData, null);
    game.packs.push(skillComp);
    for (var i = 0; i < skills.length; i++) {
        let sd = skills[i];
        sd['type'] = "skill";
        console.log(`LANCER | Adding skill: ${sd}`);
        // Create an Item from the skill data
        await skillComp.createEntity(sd);
    }
    return Promise.resolve();
}

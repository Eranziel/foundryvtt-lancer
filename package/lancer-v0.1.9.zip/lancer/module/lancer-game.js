export class LancerGame extends Game {
}

The `d20-framed.svg` graphic is derived from a [Font Awesome icon](https://fontawesome.com/icons/dice-d20?style=solid), used under the [CC BY 4.0 license](https://fontawesome.com/license/free).

Original icon is copyright 2020 Font Awesome.
import { b as axios } from "./lancer.js";
import { t as tslib, c as HttpRequest, d as build$1, e as toHex, f as fromHex, g as fromUtf8, p as parseUrl, h as fromBase64, i as toBase64, j as calculateBodyLength, k as defaultUserAgent, D as DEFAULT_MAX_ATTEMPTS, l as invalidProvider, F as FetchHttpHandler, m as build$2, s as streamCollector, n as toUtf8, o as HttpResponse, q as Client, r as resolveRegionConfig, u as resolveEndpointsConfig, v as resolveAwsAuthConfig, w as resolveRetryConfig, x as resolveUserAgentConfig, y as getRetryPlugin, z as getContentLengthPlugin, B as getHostHeaderPlugin, E as getLoggerPlugin, G as getUserAgentPlugin, I as resolveHostHeaderConfig, K as getSerdePlugin, L as Command, M as buildQueryString, N as SignatureV4, C as ConsoleLogger, O as Platform, Q as getAmplifyUserAgent, a as Credentials, P as Parser$1, H as Hub, A as Amplify } from "./Credentials.js";
var isClockSkewed = function(newServerTime, systemClockOffset) {
  return Math.abs(getSkewCorrectedDate(systemClockOffset).getTime() - newServerTime) >= 3e5;
};
var getSkewCorrectedDate = function(systemClockOffset) {
  return new Date(Date.now() + systemClockOffset);
};
function awsAuthMiddleware(options) {
  return function(next, context) {
    return function(args) {
      return tslib.exports.__awaiter(this, void 0, void 0, function() {
        var signer, _a, output, _b, _c, headers, dateHeader, serverTime;
        var _d;
        return tslib.exports.__generator(this, function(_e2) {
          switch (_e2.label) {
            case 0:
              if (!HttpRequest.isInstance(args.request))
                return [2, next(args)];
              if (!(typeof options.signer === "function"))
                return [3, 2];
              return [4, options.signer()];
            case 1:
              _a = _e2.sent();
              return [3, 3];
            case 2:
              _a = options.signer;
              _e2.label = 3;
            case 3:
              signer = _a;
              _b = next;
              _c = [tslib.exports.__assign({}, args)];
              _d = {};
              return [4, signer.sign(args.request, {
                signingDate: new Date(Date.now() + options.systemClockOffset),
                signingRegion: context["signing_region"],
                signingService: context["signing_service"]
              })];
            case 4:
              return [4, _b.apply(void 0, [tslib.exports.__assign.apply(void 0, _c.concat([(_d.request = _e2.sent(), _d)]))])];
            case 5:
              output = _e2.sent();
              headers = output.response.headers;
              dateHeader = headers && (headers.date || headers.Date);
              if (dateHeader) {
                serverTime = Date.parse(dateHeader);
                if (isClockSkewed(serverTime, options.systemClockOffset)) {
                  options.systemClockOffset = serverTime - Date.now();
                }
              }
              return [2, output];
          }
        });
      });
    };
  };
}
var awsAuthMiddlewareOptions = {
  name: "awsAuthMiddleware",
  tags: ["SIGNATURE", "AWSAUTH"],
  relation: "after",
  toMiddleware: "retryMiddleware",
  override: true
};
var getAwsAuthPlugin = function(options) {
  return {
    applyToStack: function(clientStack) {
      clientStack.addRelativeTo(awsAuthMiddleware(options), awsAuthMiddlewareOptions);
    }
  };
};
function extendedEncodeURIComponent(str) {
  return encodeURIComponent(str).replace(/[!'()*]/g, function(c) {
    return "%" + c.charCodeAt(0).toString(16);
  });
}
var getArrayIfSingleItem = function(mayBeArray) {
  return Array.isArray(mayBeArray) ? mayBeArray : [mayBeArray];
};
var getValueFromTextNode = function(obj) {
  var textNodeName = "#text";
  for (var key in obj) {
    if (obj.hasOwnProperty(key) && obj[key][textNodeName] !== void 0) {
      obj[key] = obj[key][textNodeName];
    } else if (typeof obj[key] === "object" && obj[key] !== null) {
      obj[key] = getValueFromTextNode(obj[key]);
    }
  }
  return obj;
};
var days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
function dateToUtcString(date) {
  var year = date.getUTCFullYear();
  var month = date.getUTCMonth();
  var dayOfWeek = date.getUTCDay();
  var dayOfMonthInt = date.getUTCDate();
  var hoursInt = date.getUTCHours();
  var minutesInt = date.getUTCMinutes();
  var secondsInt = date.getUTCSeconds();
  var dayOfMonthString = dayOfMonthInt < 10 ? "0" + dayOfMonthInt : "" + dayOfMonthInt;
  var hoursString = hoursInt < 10 ? "0" + hoursInt : "" + hoursInt;
  var minutesString = minutesInt < 10 ? "0" + minutesInt : "" + minutesInt;
  var secondsString = secondsInt < 10 ? "0" + secondsInt : "" + secondsInt;
  return days[dayOfWeek] + ", " + dayOfMonthString + " " + months[month] + " " + year + " " + hoursString + ":" + minutesString + ":" + secondsString + " GMT";
}
var SENSITIVE_STRING = "***SensitiveInformation***";
/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
var extendStatics = function(d, b) {
  extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
    d2.__proto__ = b2;
  } || function(d2, b2) {
    for (var p in b2)
      if (Object.prototype.hasOwnProperty.call(b2, p))
        d2[p] = b2[p];
  };
  return extendStatics(d, b);
};
function __extends(d, b) {
  if (typeof b !== "function" && b !== null)
    throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
  extendStatics(d, b);
  function __() {
    this.constructor = d;
  }
  d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}
var __assign$4 = function() {
  __assign$4 = Object.assign || function __assign2(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s)
        if (Object.prototype.hasOwnProperty.call(s, p))
          t[p] = s[p];
    }
    return t;
  };
  return __assign$4.apply(this, arguments);
};
function __awaiter$3(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
}
function __generator$3(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1)
      throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f)
      throw new TypeError("Generator is already executing.");
    while (_)
      try {
        if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
          return t;
        if (y = 0, t)
          op = [op[0] & 2, t.value];
        switch (op[0]) {
          case 0:
          case 1:
            t = op;
            break;
          case 4:
            _.label++;
            return { value: op[1], done: false };
          case 5:
            _.label++;
            y = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            if (t[2])
              _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e) {
        op = [6, e];
        y = 0;
      } finally {
        f = t = 0;
      }
    if (op[0] & 5)
      throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
}
const name = "@aws-sdk/client-s3";
const description = "AWS SDK for JavaScript S3 Client for Node.js, Browser and React Native";
const version = "3.6.1";
const scripts = {
  clean: "yarn remove-definitions && yarn remove-dist && yarn remove-documentation",
  "build-documentation": "yarn remove-documentation && typedoc ./",
  prepublishOnly: "yarn build",
  pretest: "yarn build:cjs",
  "remove-definitions": "rimraf ./types",
  "remove-dist": "rimraf ./dist",
  "remove-documentation": "rimraf ./docs",
  "test:unit": "mocha **/cjs/**/*.spec.js",
  "test:e2e": "mocha **/cjs/**/*.ispec.js && karma start karma.conf.js",
  test: "yarn test:unit",
  "build:cjs": "tsc -p tsconfig.json",
  "build:es": "tsc -p tsconfig.es.json",
  build: "yarn build:cjs && yarn build:es",
  postbuild: "downlevel-dts types types/ts3.4"
};
const main = "./dist/cjs/index.js";
const types = "./types/index.d.ts";
const module = "./dist/es/index.js";
const browser = {
  "./runtimeConfig": "./runtimeConfig.browser"
};
const sideEffects = false;
const dependencies = {
  "@aws-crypto/sha256-browser": "^1.0.0",
  "@aws-crypto/sha256-js": "^1.0.0",
  "@aws-sdk/config-resolver": "3.6.1",
  "@aws-sdk/credential-provider-node": "3.6.1",
  "@aws-sdk/eventstream-serde-browser": "3.6.1",
  "@aws-sdk/eventstream-serde-config-resolver": "3.6.1",
  "@aws-sdk/eventstream-serde-node": "3.6.1",
  "@aws-sdk/fetch-http-handler": "3.6.1",
  "@aws-sdk/hash-blob-browser": "3.6.1",
  "@aws-sdk/hash-node": "3.6.1",
  "@aws-sdk/hash-stream-node": "3.6.1",
  "@aws-sdk/invalid-dependency": "3.6.1",
  "@aws-sdk/md5-js": "3.6.1",
  "@aws-sdk/middleware-apply-body-checksum": "3.6.1",
  "@aws-sdk/middleware-bucket-endpoint": "3.6.1",
  "@aws-sdk/middleware-content-length": "3.6.1",
  "@aws-sdk/middleware-expect-continue": "3.6.1",
  "@aws-sdk/middleware-host-header": "3.6.1",
  "@aws-sdk/middleware-location-constraint": "3.6.1",
  "@aws-sdk/middleware-logger": "3.6.1",
  "@aws-sdk/middleware-retry": "3.6.1",
  "@aws-sdk/middleware-sdk-s3": "3.6.1",
  "@aws-sdk/middleware-serde": "3.6.1",
  "@aws-sdk/middleware-signing": "3.6.1",
  "@aws-sdk/middleware-ssec": "3.6.1",
  "@aws-sdk/middleware-stack": "3.6.1",
  "@aws-sdk/middleware-user-agent": "3.6.1",
  "@aws-sdk/node-config-provider": "3.6.1",
  "@aws-sdk/node-http-handler": "3.6.1",
  "@aws-sdk/protocol-http": "3.6.1",
  "@aws-sdk/smithy-client": "3.6.1",
  "@aws-sdk/types": "3.6.1",
  "@aws-sdk/url-parser": "3.6.1",
  "@aws-sdk/url-parser-native": "3.6.1",
  "@aws-sdk/util-base64-browser": "3.6.1",
  "@aws-sdk/util-base64-node": "3.6.1",
  "@aws-sdk/util-body-length-browser": "3.6.1",
  "@aws-sdk/util-body-length-node": "3.6.1",
  "@aws-sdk/util-user-agent-browser": "3.6.1",
  "@aws-sdk/util-user-agent-node": "3.6.1",
  "@aws-sdk/util-utf8-browser": "3.6.1",
  "@aws-sdk/util-utf8-node": "3.6.1",
  "@aws-sdk/util-waiter": "3.6.1",
  "@aws-sdk/xml-builder": "3.6.1",
  "fast-xml-parser": "^3.16.0",
  tslib: "^2.0.0"
};
const devDependencies = {
  "@aws-sdk/client-documentation-generator": "3.6.1",
  "@types/chai": "^4.2.11",
  "@types/mocha": "^8.0.4",
  "@types/node": "^12.7.5",
  "downlevel-dts": "0.7.0",
  jest: "^26.1.0",
  rimraf: "^3.0.0",
  typedoc: "^0.19.2",
  typescript: "~4.1.2"
};
const engines = {
  node: ">=10.0.0"
};
const typesVersions = {
  "<4.0": {
    "types/*": [
      "types/ts3.4/*"
    ]
  }
};
const author = {
  name: "AWS SDK for JavaScript Team",
  url: "https://aws.amazon.com/javascript/"
};
const license = "Apache-2.0";
const homepage = "https://github.com/aws/aws-sdk-js-v3/tree/main/clients/client-s3";
const repository = {
  type: "git",
  url: "https://github.com/aws/aws-sdk-js-v3.git",
  directory: "clients/client-s3"
};
var packageInfo = {
  name,
  description,
  version,
  scripts,
  main,
  types,
  module,
  browser,
  "react-native": {
    "./runtimeConfig": "./runtimeConfig.native"
  },
  sideEffects,
  dependencies,
  devDependencies,
  engines,
  typesVersions,
  author,
  license,
  homepage,
  repository
};
var build = {};
var aws_crc32 = {};
Object.defineProperty(aws_crc32, "__esModule", { value: true });
aws_crc32.AwsCrc32 = void 0;
var tslib_1 = tslib.exports;
var util_1 = build$1;
var index_1 = build;
var AwsCrc32 = function() {
  function AwsCrc322() {
    this.crc32 = new index_1.Crc32();
  }
  AwsCrc322.prototype.update = function(toHash) {
    if ((0, util_1.isEmptyData)(toHash))
      return;
    this.crc32.update((0, util_1.convertToBuffer)(toHash));
  };
  AwsCrc322.prototype.digest = function() {
    return (0, tslib_1.__awaiter)(this, void 0, void 0, function() {
      return (0, tslib_1.__generator)(this, function(_a) {
        return [2, (0, util_1.numToUint8)(this.crc32.digest())];
      });
    });
  };
  return AwsCrc322;
}();
aws_crc32.AwsCrc32 = AwsCrc32;
(function(exports) {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.AwsCrc32 = exports.Crc32 = exports.crc32 = void 0;
  var tslib_12 = tslib.exports;
  function crc32(data) {
    return new Crc32().update(data).digest();
  }
  exports.crc32 = crc32;
  var Crc32 = function() {
    function Crc322() {
      this.checksum = 4294967295;
    }
    Crc322.prototype.update = function(data) {
      var e_1, _a;
      try {
        for (var data_1 = (0, tslib_12.__values)(data), data_1_1 = data_1.next(); !data_1_1.done; data_1_1 = data_1.next()) {
          var byte = data_1_1.value;
          this.checksum = this.checksum >>> 8 ^ lookupTable[(this.checksum ^ byte) & 255];
        }
      } catch (e_1_1) {
        e_1 = { error: e_1_1 };
      } finally {
        try {
          if (data_1_1 && !data_1_1.done && (_a = data_1.return))
            _a.call(data_1);
        } finally {
          if (e_1)
            throw e_1.error;
        }
      }
      return this;
    };
    Crc322.prototype.digest = function() {
      return (this.checksum ^ 4294967295) >>> 0;
    };
    return Crc322;
  }();
  exports.Crc32 = Crc32;
  var lookupTable = Uint32Array.from([
    0,
    1996959894,
    3993919788,
    2567524794,
    124634137,
    1886057615,
    3915621685,
    2657392035,
    249268274,
    2044508324,
    3772115230,
    2547177864,
    162941995,
    2125561021,
    3887607047,
    2428444049,
    498536548,
    1789927666,
    4089016648,
    2227061214,
    450548861,
    1843258603,
    4107580753,
    2211677639,
    325883990,
    1684777152,
    4251122042,
    2321926636,
    335633487,
    1661365465,
    4195302755,
    2366115317,
    997073096,
    1281953886,
    3579855332,
    2724688242,
    1006888145,
    1258607687,
    3524101629,
    2768942443,
    901097722,
    1119000684,
    3686517206,
    2898065728,
    853044451,
    1172266101,
    3705015759,
    2882616665,
    651767980,
    1373503546,
    3369554304,
    3218104598,
    565507253,
    1454621731,
    3485111705,
    3099436303,
    671266974,
    1594198024,
    3322730930,
    2970347812,
    795835527,
    1483230225,
    3244367275,
    3060149565,
    1994146192,
    31158534,
    2563907772,
    4023717930,
    1907459465,
    112637215,
    2680153253,
    3904427059,
    2013776290,
    251722036,
    2517215374,
    3775830040,
    2137656763,
    141376813,
    2439277719,
    3865271297,
    1802195444,
    476864866,
    2238001368,
    4066508878,
    1812370925,
    453092731,
    2181625025,
    4111451223,
    1706088902,
    314042704,
    2344532202,
    4240017532,
    1658658271,
    366619977,
    2362670323,
    4224994405,
    1303535960,
    984961486,
    2747007092,
    3569037538,
    1256170817,
    1037604311,
    2765210733,
    3554079995,
    1131014506,
    879679996,
    2909243462,
    3663771856,
    1141124467,
    855842277,
    2852801631,
    3708648649,
    1342533948,
    654459306,
    3188396048,
    3373015174,
    1466479909,
    544179635,
    3110523913,
    3462522015,
    1591671054,
    702138776,
    2966460450,
    3352799412,
    1504918807,
    783551873,
    3082640443,
    3233442989,
    3988292384,
    2596254646,
    62317068,
    1957810842,
    3939845945,
    2647816111,
    81470997,
    1943803523,
    3814918930,
    2489596804,
    225274430,
    2053790376,
    3826175755,
    2466906013,
    167816743,
    2097651377,
    4027552580,
    2265490386,
    503444072,
    1762050814,
    4150417245,
    2154129355,
    426522225,
    1852507879,
    4275313526,
    2312317920,
    282753626,
    1742555852,
    4189708143,
    2394877945,
    397917763,
    1622183637,
    3604390888,
    2714866558,
    953729732,
    1340076626,
    3518719985,
    2797360999,
    1068828381,
    1219638859,
    3624741850,
    2936675148,
    906185462,
    1090812512,
    3747672003,
    2825379669,
    829329135,
    1181335161,
    3412177804,
    3160834842,
    628085408,
    1382605366,
    3423369109,
    3138078467,
    570562233,
    1426400815,
    3317316542,
    2998733608,
    733239954,
    1555261956,
    3268935591,
    3050360625,
    752459403,
    1541320221,
    2607071920,
    3965973030,
    1969922972,
    40735498,
    2617837225,
    3943577151,
    1913087877,
    83908371,
    2512341634,
    3803740692,
    2075208622,
    213261112,
    2463272603,
    3855990285,
    2094854071,
    198958881,
    2262029012,
    4057260610,
    1759359992,
    534414190,
    2176718541,
    4139329115,
    1873836001,
    414664567,
    2282248934,
    4279200368,
    1711684554,
    285281116,
    2405801727,
    4167216745,
    1634467795,
    376229701,
    2685067896,
    3608007406,
    1308918612,
    956543938,
    2808555105,
    3495958263,
    1231636301,
    1047427035,
    2932959818,
    3654703836,
    1088359270,
    936918e3,
    2847714899,
    3736837829,
    1202900863,
    817233897,
    3183342108,
    3401237130,
    1404277552,
    615818150,
    3134207493,
    3453421203,
    1423857449,
    601450431,
    3009837614,
    3294710456,
    1567103746,
    711928724,
    3020668471,
    3272380065,
    1510334235,
    755167117
  ]);
  var aws_crc32_1 = aws_crc32;
  Object.defineProperty(exports, "AwsCrc32", { enumerable: true, get: function() {
    return aws_crc32_1.AwsCrc32;
  } });
})(build);
var Int64 = function() {
  function Int642(bytes) {
    this.bytes = bytes;
    if (bytes.byteLength !== 8) {
      throw new Error("Int64 buffers must be exactly 8 bytes");
    }
  }
  Int642.fromNumber = function(number) {
    if (number > 9223372036854776e3 || number < -9223372036854776e3) {
      throw new Error(number + " is too large (or, if negative, too small) to represent as an Int64");
    }
    var bytes = new Uint8Array(8);
    for (var i = 7, remaining = Math.abs(Math.round(number)); i > -1 && remaining > 0; i--, remaining /= 256) {
      bytes[i] = remaining;
    }
    if (number < 0) {
      negate(bytes);
    }
    return new Int642(bytes);
  };
  Int642.prototype.valueOf = function() {
    var bytes = this.bytes.slice(0);
    var negative = bytes[0] & 128;
    if (negative) {
      negate(bytes);
    }
    return parseInt(toHex(bytes), 16) * (negative ? -1 : 1);
  };
  Int642.prototype.toString = function() {
    return String(this.valueOf());
  };
  return Int642;
}();
function negate(bytes) {
  for (var i = 0; i < 8; i++) {
    bytes[i] ^= 255;
  }
  for (var i = 7; i > -1; i--) {
    bytes[i]++;
    if (bytes[i] !== 0)
      break;
  }
}
var HeaderMarshaller = function() {
  function HeaderMarshaller2(toUtf82, fromUtf82) {
    this.toUtf8 = toUtf82;
    this.fromUtf8 = fromUtf82;
  }
  HeaderMarshaller2.prototype.format = function(headers) {
    var e_1, _a, e_2, _b;
    var chunks = [];
    try {
      for (var _c = tslib.exports.__values(Object.keys(headers)), _d = _c.next(); !_d.done; _d = _c.next()) {
        var headerName = _d.value;
        var bytes = this.fromUtf8(headerName);
        chunks.push(Uint8Array.from([bytes.byteLength]), bytes, this.formatHeaderValue(headers[headerName]));
      }
    } catch (e_1_1) {
      e_1 = { error: e_1_1 };
    } finally {
      try {
        if (_d && !_d.done && (_a = _c.return))
          _a.call(_c);
      } finally {
        if (e_1)
          throw e_1.error;
      }
    }
    var out = new Uint8Array(chunks.reduce(function(carry, bytes2) {
      return carry + bytes2.byteLength;
    }, 0));
    var position = 0;
    try {
      for (var chunks_1 = tslib.exports.__values(chunks), chunks_1_1 = chunks_1.next(); !chunks_1_1.done; chunks_1_1 = chunks_1.next()) {
        var chunk = chunks_1_1.value;
        out.set(chunk, position);
        position += chunk.byteLength;
      }
    } catch (e_2_1) {
      e_2 = { error: e_2_1 };
    } finally {
      try {
        if (chunks_1_1 && !chunks_1_1.done && (_b = chunks_1.return))
          _b.call(chunks_1);
      } finally {
        if (e_2)
          throw e_2.error;
      }
    }
    return out;
  };
  HeaderMarshaller2.prototype.formatHeaderValue = function(header) {
    switch (header.type) {
      case "boolean":
        return Uint8Array.from([header.value ? 0 : 1]);
      case "byte":
        return Uint8Array.from([2, header.value]);
      case "short":
        var shortView = new DataView(new ArrayBuffer(3));
        shortView.setUint8(0, 3);
        shortView.setInt16(1, header.value, false);
        return new Uint8Array(shortView.buffer);
      case "integer":
        var intView = new DataView(new ArrayBuffer(5));
        intView.setUint8(0, 4);
        intView.setInt32(1, header.value, false);
        return new Uint8Array(intView.buffer);
      case "long":
        var longBytes = new Uint8Array(9);
        longBytes[0] = 5;
        longBytes.set(header.value.bytes, 1);
        return longBytes;
      case "binary":
        var binView = new DataView(new ArrayBuffer(3 + header.value.byteLength));
        binView.setUint8(0, 6);
        binView.setUint16(1, header.value.byteLength, false);
        var binBytes = new Uint8Array(binView.buffer);
        binBytes.set(header.value, 3);
        return binBytes;
      case "string":
        var utf8Bytes = this.fromUtf8(header.value);
        var strView = new DataView(new ArrayBuffer(3 + utf8Bytes.byteLength));
        strView.setUint8(0, 7);
        strView.setUint16(1, utf8Bytes.byteLength, false);
        var strBytes = new Uint8Array(strView.buffer);
        strBytes.set(utf8Bytes, 3);
        return strBytes;
      case "timestamp":
        var tsBytes = new Uint8Array(9);
        tsBytes[0] = 8;
        tsBytes.set(Int64.fromNumber(header.value.valueOf()).bytes, 1);
        return tsBytes;
      case "uuid":
        if (!UUID_PATTERN.test(header.value)) {
          throw new Error("Invalid UUID received: " + header.value);
        }
        var uuidBytes = new Uint8Array(17);
        uuidBytes[0] = 9;
        uuidBytes.set(fromHex(header.value.replace(/\-/g, "")), 1);
        return uuidBytes;
    }
  };
  HeaderMarshaller2.prototype.parse = function(headers) {
    var out = {};
    var position = 0;
    while (position < headers.byteLength) {
      var nameLength = headers.getUint8(position++);
      var name2 = this.toUtf8(new Uint8Array(headers.buffer, headers.byteOffset + position, nameLength));
      position += nameLength;
      switch (headers.getUint8(position++)) {
        case 0:
          out[name2] = {
            type: BOOLEAN_TAG,
            value: true
          };
          break;
        case 1:
          out[name2] = {
            type: BOOLEAN_TAG,
            value: false
          };
          break;
        case 2:
          out[name2] = {
            type: BYTE_TAG,
            value: headers.getInt8(position++)
          };
          break;
        case 3:
          out[name2] = {
            type: SHORT_TAG,
            value: headers.getInt16(position, false)
          };
          position += 2;
          break;
        case 4:
          out[name2] = {
            type: INT_TAG,
            value: headers.getInt32(position, false)
          };
          position += 4;
          break;
        case 5:
          out[name2] = {
            type: LONG_TAG,
            value: new Int64(new Uint8Array(headers.buffer, headers.byteOffset + position, 8))
          };
          position += 8;
          break;
        case 6:
          var binaryLength = headers.getUint16(position, false);
          position += 2;
          out[name2] = {
            type: BINARY_TAG,
            value: new Uint8Array(headers.buffer, headers.byteOffset + position, binaryLength)
          };
          position += binaryLength;
          break;
        case 7:
          var stringLength = headers.getUint16(position, false);
          position += 2;
          out[name2] = {
            type: STRING_TAG,
            value: this.toUtf8(new Uint8Array(headers.buffer, headers.byteOffset + position, stringLength))
          };
          position += stringLength;
          break;
        case 8:
          out[name2] = {
            type: TIMESTAMP_TAG,
            value: new Date(new Int64(new Uint8Array(headers.buffer, headers.byteOffset + position, 8)).valueOf())
          };
          position += 8;
          break;
        case 9:
          var uuidBytes = new Uint8Array(headers.buffer, headers.byteOffset + position, 16);
          position += 16;
          out[name2] = {
            type: UUID_TAG,
            value: toHex(uuidBytes.subarray(0, 4)) + "-" + toHex(uuidBytes.subarray(4, 6)) + "-" + toHex(uuidBytes.subarray(6, 8)) + "-" + toHex(uuidBytes.subarray(8, 10)) + "-" + toHex(uuidBytes.subarray(10))
          };
          break;
        default:
          throw new Error("Unrecognized header type tag");
      }
    }
    return out;
  };
  return HeaderMarshaller2;
}();
var HEADER_VALUE_TYPE;
(function(HEADER_VALUE_TYPE2) {
  HEADER_VALUE_TYPE2[HEADER_VALUE_TYPE2["boolTrue"] = 0] = "boolTrue";
  HEADER_VALUE_TYPE2[HEADER_VALUE_TYPE2["boolFalse"] = 1] = "boolFalse";
  HEADER_VALUE_TYPE2[HEADER_VALUE_TYPE2["byte"] = 2] = "byte";
  HEADER_VALUE_TYPE2[HEADER_VALUE_TYPE2["short"] = 3] = "short";
  HEADER_VALUE_TYPE2[HEADER_VALUE_TYPE2["integer"] = 4] = "integer";
  HEADER_VALUE_TYPE2[HEADER_VALUE_TYPE2["long"] = 5] = "long";
  HEADER_VALUE_TYPE2[HEADER_VALUE_TYPE2["byteArray"] = 6] = "byteArray";
  HEADER_VALUE_TYPE2[HEADER_VALUE_TYPE2["string"] = 7] = "string";
  HEADER_VALUE_TYPE2[HEADER_VALUE_TYPE2["timestamp"] = 8] = "timestamp";
  HEADER_VALUE_TYPE2[HEADER_VALUE_TYPE2["uuid"] = 9] = "uuid";
})(HEADER_VALUE_TYPE || (HEADER_VALUE_TYPE = {}));
var BOOLEAN_TAG = "boolean";
var BYTE_TAG = "byte";
var SHORT_TAG = "short";
var INT_TAG = "integer";
var LONG_TAG = "long";
var BINARY_TAG = "binary";
var STRING_TAG = "string";
var TIMESTAMP_TAG = "timestamp";
var UUID_TAG = "uuid";
var UUID_PATTERN = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/;
var PRELUDE_MEMBER_LENGTH = 4;
var PRELUDE_LENGTH = PRELUDE_MEMBER_LENGTH * 2;
var CHECKSUM_LENGTH = 4;
var MINIMUM_MESSAGE_LENGTH = PRELUDE_LENGTH + CHECKSUM_LENGTH * 2;
function splitMessage(_a) {
  var byteLength = _a.byteLength, byteOffset = _a.byteOffset, buffer = _a.buffer;
  if (byteLength < MINIMUM_MESSAGE_LENGTH) {
    throw new Error("Provided message too short to accommodate event stream message overhead");
  }
  var view = new DataView(buffer, byteOffset, byteLength);
  var messageLength = view.getUint32(0, false);
  if (byteLength !== messageLength) {
    throw new Error("Reported message length does not match received message length");
  }
  var headerLength = view.getUint32(PRELUDE_MEMBER_LENGTH, false);
  var expectedPreludeChecksum = view.getUint32(PRELUDE_LENGTH, false);
  var expectedMessageChecksum = view.getUint32(byteLength - CHECKSUM_LENGTH, false);
  var checksummer = new build.Crc32().update(new Uint8Array(buffer, byteOffset, PRELUDE_LENGTH));
  if (expectedPreludeChecksum !== checksummer.digest()) {
    throw new Error("The prelude checksum specified in the message (" + expectedPreludeChecksum + ") does not match the calculated CRC32 checksum (" + checksummer.digest() + ")");
  }
  checksummer.update(new Uint8Array(buffer, byteOffset + PRELUDE_LENGTH, byteLength - (PRELUDE_LENGTH + CHECKSUM_LENGTH)));
  if (expectedMessageChecksum !== checksummer.digest()) {
    throw new Error("The message checksum (" + checksummer.digest() + ") did not match the expected value of " + expectedMessageChecksum);
  }
  return {
    headers: new DataView(buffer, byteOffset + PRELUDE_LENGTH + CHECKSUM_LENGTH, headerLength),
    body: new Uint8Array(buffer, byteOffset + PRELUDE_LENGTH + CHECKSUM_LENGTH + headerLength, messageLength - headerLength - (PRELUDE_LENGTH + CHECKSUM_LENGTH + CHECKSUM_LENGTH))
  };
}
var EventStreamMarshaller$2 = function() {
  function EventStreamMarshaller2(toUtf82, fromUtf82) {
    this.headerMarshaller = new HeaderMarshaller(toUtf82, fromUtf82);
  }
  EventStreamMarshaller2.prototype.marshall = function(_a) {
    var rawHeaders = _a.headers, body = _a.body;
    var headers = this.headerMarshaller.format(rawHeaders);
    var length = headers.byteLength + body.byteLength + 16;
    var out = new Uint8Array(length);
    var view = new DataView(out.buffer, out.byteOffset, out.byteLength);
    var checksum = new build.Crc32();
    view.setUint32(0, length, false);
    view.setUint32(4, headers.byteLength, false);
    view.setUint32(8, checksum.update(out.subarray(0, 8)).digest(), false);
    out.set(headers, 12);
    out.set(body, headers.byteLength + 12);
    view.setUint32(length - 4, checksum.update(out.subarray(8, length - 4)).digest(), false);
    return out;
  };
  EventStreamMarshaller2.prototype.unmarshall = function(message) {
    var _a = splitMessage(message), headers = _a.headers, body = _a.body;
    return { headers: this.headerMarshaller.parse(headers), body };
  };
  EventStreamMarshaller2.prototype.formatHeaders = function(rawHeaders) {
    return this.headerMarshaller.format(rawHeaders);
  };
  return EventStreamMarshaller2;
}();
function getChunkedStream(source) {
  var _a;
  var currentMessageTotalLength = 0;
  var currentMessagePendingLength = 0;
  var currentMessage = null;
  var messageLengthBuffer = null;
  var allocateMessage = function(size) {
    if (typeof size !== "number") {
      throw new Error("Attempted to allocate an event message where size was not a number: " + size);
    }
    currentMessageTotalLength = size;
    currentMessagePendingLength = 4;
    currentMessage = new Uint8Array(size);
    var currentMessageView = new DataView(currentMessage.buffer);
    currentMessageView.setUint32(0, size, false);
  };
  var iterator = function() {
    return tslib.exports.__asyncGenerator(this, arguments, function() {
      var sourceIterator, _a2, value, done, chunkLength, currentOffset, bytesRemaining, numBytesForTotal, numBytesToWrite;
      return tslib.exports.__generator(this, function(_b) {
        switch (_b.label) {
          case 0:
            sourceIterator = source[Symbol.asyncIterator]();
            _b.label = 1;
          case 1:
            return [4, tslib.exports.__await(sourceIterator.next())];
          case 2:
            _a2 = _b.sent(), value = _a2.value, done = _a2.done;
            if (!done)
              return [3, 10];
            if (!!currentMessageTotalLength)
              return [3, 4];
            return [4, tslib.exports.__await(void 0)];
          case 3:
            return [2, _b.sent()];
          case 4:
            if (!(currentMessageTotalLength === currentMessagePendingLength))
              return [3, 7];
            return [4, tslib.exports.__await(currentMessage)];
          case 5:
            return [4, _b.sent()];
          case 6:
            _b.sent();
            return [3, 8];
          case 7:
            throw new Error("Truncated event message received.");
          case 8:
            return [4, tslib.exports.__await(void 0)];
          case 9:
            return [2, _b.sent()];
          case 10:
            chunkLength = value.length;
            currentOffset = 0;
            _b.label = 11;
          case 11:
            if (!(currentOffset < chunkLength))
              return [3, 15];
            if (!currentMessage) {
              bytesRemaining = chunkLength - currentOffset;
              if (!messageLengthBuffer) {
                messageLengthBuffer = new Uint8Array(4);
              }
              numBytesForTotal = Math.min(
                4 - currentMessagePendingLength,
                bytesRemaining
              );
              messageLengthBuffer.set(
                value.slice(currentOffset, currentOffset + numBytesForTotal),
                currentMessagePendingLength
              );
              currentMessagePendingLength += numBytesForTotal;
              currentOffset += numBytesForTotal;
              if (currentMessagePendingLength < 4) {
                return [3, 15];
              }
              allocateMessage(new DataView(messageLengthBuffer.buffer).getUint32(0, false));
              messageLengthBuffer = null;
            }
            numBytesToWrite = Math.min(
              currentMessageTotalLength - currentMessagePendingLength,
              chunkLength - currentOffset
            );
            currentMessage.set(
              value.slice(currentOffset, currentOffset + numBytesToWrite),
              currentMessagePendingLength
            );
            currentMessagePendingLength += numBytesToWrite;
            currentOffset += numBytesToWrite;
            if (!(currentMessageTotalLength && currentMessageTotalLength === currentMessagePendingLength))
              return [3, 14];
            return [4, tslib.exports.__await(currentMessage)];
          case 12:
            return [4, _b.sent()];
          case 13:
            _b.sent();
            currentMessage = null;
            currentMessageTotalLength = 0;
            currentMessagePendingLength = 0;
            _b.label = 14;
          case 14:
            return [3, 11];
          case 15:
            return [3, 1];
          case 16:
            return [2];
        }
      });
    });
  };
  return _a = {}, _a[Symbol.asyncIterator] = iterator, _a;
}
function getUnmarshalledStream(source, options) {
  var _a;
  return _a = {}, _a[Symbol.asyncIterator] = function() {
    return tslib.exports.__asyncGenerator(this, arguments, function() {
      var source_1, source_1_1, chunk, message, messageType, unmodeledError, code, exception, deserializedException, error, event, deserialized, e_1_1;
      var _a2, _b;
      var e_1, _c;
      return tslib.exports.__generator(this, function(_d) {
        switch (_d.label) {
          case 0:
            _d.trys.push([0, 12, 13, 18]);
            source_1 = tslib.exports.__asyncValues(source);
            _d.label = 1;
          case 1:
            return [4, tslib.exports.__await(source_1.next())];
          case 2:
            if (!(source_1_1 = _d.sent(), !source_1_1.done))
              return [3, 11];
            chunk = source_1_1.value;
            message = options.eventMarshaller.unmarshall(chunk);
            messageType = message.headers[":message-type"].value;
            if (!(messageType === "error"))
              return [3, 3];
            unmodeledError = new Error(message.headers[":error-message"].value || "UnknownError");
            unmodeledError.name = message.headers[":error-code"].value;
            throw unmodeledError;
          case 3:
            if (!(messageType === "exception"))
              return [3, 5];
            code = message.headers[":exception-type"].value;
            exception = (_a2 = {}, _a2[code] = message, _a2);
            return [4, tslib.exports.__await(options.deserializer(exception))];
          case 4:
            deserializedException = _d.sent();
            if (deserializedException.$unknown) {
              error = new Error(options.toUtf8(message.body));
              error.name = code;
              throw error;
            }
            throw deserializedException[code];
          case 5:
            if (!(messageType === "event"))
              return [3, 9];
            event = (_b = {}, _b[message.headers[":event-type"].value] = message, _b);
            return [4, tslib.exports.__await(options.deserializer(event))];
          case 6:
            deserialized = _d.sent();
            if (deserialized.$unknown)
              return [3, 10];
            return [4, tslib.exports.__await(deserialized)];
          case 7:
            return [4, _d.sent()];
          case 8:
            _d.sent();
            return [3, 10];
          case 9:
            throw Error("Unrecognizable event type: " + message.headers[":event-type"].value);
          case 10:
            return [3, 1];
          case 11:
            return [3, 18];
          case 12:
            e_1_1 = _d.sent();
            e_1 = { error: e_1_1 };
            return [3, 18];
          case 13:
            _d.trys.push([13, , 16, 17]);
            if (!(source_1_1 && !source_1_1.done && (_c = source_1.return)))
              return [3, 15];
            return [4, tslib.exports.__await(_c.call(source_1))];
          case 14:
            _d.sent();
            _d.label = 15;
          case 15:
            return [3, 17];
          case 16:
            if (e_1)
              throw e_1.error;
            return [7];
          case 17:
            return [7];
          case 18:
            return [2];
        }
      });
    });
  }, _a;
}
var EventStreamMarshaller$1 = function() {
  function EventStreamMarshaller2(_a) {
    var utf8Encoder = _a.utf8Encoder, utf8Decoder = _a.utf8Decoder;
    this.eventMarshaller = new EventStreamMarshaller$2(utf8Encoder, utf8Decoder);
    this.utfEncoder = utf8Encoder;
  }
  EventStreamMarshaller2.prototype.deserialize = function(body, deserializer) {
    var chunkedStream = getChunkedStream(body);
    var unmarshalledStream = getUnmarshalledStream(chunkedStream, {
      eventMarshaller: this.eventMarshaller,
      deserializer,
      toUtf8: this.utfEncoder
    });
    return unmarshalledStream;
  };
  EventStreamMarshaller2.prototype.serialize = function(input, serializer) {
    var _a;
    var self = this;
    var serializedIterator = function() {
      return tslib.exports.__asyncGenerator(this, arguments, function() {
        var input_1, input_1_1, chunk, payloadBuf, e_1_1;
        var e_1, _a2;
        return tslib.exports.__generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              _b.trys.push([0, 7, 8, 13]);
              input_1 = tslib.exports.__asyncValues(input);
              _b.label = 1;
            case 1:
              return [4, tslib.exports.__await(input_1.next())];
            case 2:
              if (!(input_1_1 = _b.sent(), !input_1_1.done))
                return [3, 6];
              chunk = input_1_1.value;
              payloadBuf = self.eventMarshaller.marshall(serializer(chunk));
              return [4, tslib.exports.__await(payloadBuf)];
            case 3:
              return [4, _b.sent()];
            case 4:
              _b.sent();
              _b.label = 5;
            case 5:
              return [3, 1];
            case 6:
              return [3, 13];
            case 7:
              e_1_1 = _b.sent();
              e_1 = { error: e_1_1 };
              return [3, 13];
            case 8:
              _b.trys.push([8, , 11, 12]);
              if (!(input_1_1 && !input_1_1.done && (_a2 = input_1.return)))
                return [3, 10];
              return [4, tslib.exports.__await(_a2.call(input_1))];
            case 9:
              _b.sent();
              _b.label = 10;
            case 10:
              return [3, 12];
            case 11:
              if (e_1)
                throw e_1.error;
              return [7];
            case 12:
              return [7];
            case 13:
              return [4, tslib.exports.__await(new Uint8Array(0))];
            case 14:
              return [4, _b.sent()];
            case 15:
              _b.sent();
              return [2];
          }
        });
      });
    };
    return _a = {}, _a[Symbol.asyncIterator] = serializedIterator, _a;
  };
  return EventStreamMarshaller2;
}();
var readableStreamtoIterable = function(readableStream) {
  var _a;
  return _a = {}, _a[Symbol.asyncIterator] = function() {
    return tslib.exports.__asyncGenerator(this, arguments, function() {
      var reader, _a2, done, value;
      return tslib.exports.__generator(this, function(_b) {
        switch (_b.label) {
          case 0:
            reader = readableStream.getReader();
            _b.label = 1;
          case 1:
            _b.trys.push([1, , 9, 10]);
            _b.label = 2;
          case 2:
            return [4, tslib.exports.__await(reader.read())];
          case 3:
            _a2 = _b.sent(), done = _a2.done, value = _a2.value;
            if (!done)
              return [3, 5];
            return [4, tslib.exports.__await(void 0)];
          case 4:
            return [2, _b.sent()];
          case 5:
            return [4, tslib.exports.__await(value)];
          case 6:
            return [4, _b.sent()];
          case 7:
            _b.sent();
            return [3, 2];
          case 8:
            return [3, 10];
          case 9:
            reader.releaseLock();
            return [7];
          case 10:
            return [2];
        }
      });
    });
  }, _a;
};
var iterableToReadableStream = function(asyncIterable) {
  var iterator = asyncIterable[Symbol.asyncIterator]();
  return new ReadableStream({
    pull: function(controller) {
      return tslib.exports.__awaiter(this, void 0, void 0, function() {
        var _a, done, value;
        return tslib.exports.__generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              return [4, iterator.next()];
            case 1:
              _a = _b.sent(), done = _a.done, value = _a.value;
              if (done) {
                return [2, controller.close()];
              }
              controller.enqueue(value);
              return [2];
          }
        });
      });
    }
  });
};
var EventStreamMarshaller = function() {
  function EventStreamMarshaller2(_a) {
    var utf8Encoder = _a.utf8Encoder, utf8Decoder = _a.utf8Decoder;
    this.eventMarshaller = new EventStreamMarshaller$2(utf8Encoder, utf8Decoder);
    this.universalMarshaller = new EventStreamMarshaller$1({
      utf8Decoder,
      utf8Encoder
    });
  }
  EventStreamMarshaller2.prototype.deserialize = function(body, deserializer) {
    var bodyIterable = isReadableStream(body) ? readableStreamtoIterable(body) : body;
    return this.universalMarshaller.deserialize(bodyIterable, deserializer);
  };
  EventStreamMarshaller2.prototype.serialize = function(input, serializer) {
    var serialziedIterable = this.universalMarshaller.serialize(input, serializer);
    return typeof ReadableStream === "function" ? iterableToReadableStream(serialziedIterable) : serialziedIterable;
  };
  return EventStreamMarshaller2;
}();
var isReadableStream = function(body) {
  return typeof ReadableStream === "function" && body instanceof ReadableStream;
};
var eventStreamSerdeProvider = function(options) {
  return new EventStreamMarshaller(options);
};
function blobReader(blob, onChunk, chunkSize) {
  if (chunkSize === void 0) {
    chunkSize = 1024 * 1024;
  }
  return new Promise(function(resolve, reject) {
    var fileReader = new FileReader();
    fileReader.addEventListener("error", reject);
    fileReader.addEventListener("abort", reject);
    var size = blob.size;
    var totalBytesRead = 0;
    function read() {
      if (totalBytesRead >= size) {
        resolve();
        return;
      }
      fileReader.readAsArrayBuffer(blob.slice(totalBytesRead, Math.min(size, totalBytesRead + chunkSize)));
    }
    fileReader.addEventListener("load", function(event) {
      var result = event.target.result;
      onChunk(new Uint8Array(result));
      totalBytesRead += result.byteLength;
      read();
    });
    read();
  });
}
var blobHasher = function blobHasher2(hashCtor, blob) {
  return tslib.exports.__awaiter(this, void 0, void 0, function() {
    var hash;
    return tslib.exports.__generator(this, function(_a) {
      switch (_a.label) {
        case 0:
          hash = new hashCtor();
          return [4, blobReader(blob, function(chunk) {
            hash.update(chunk);
          })];
        case 1:
          _a.sent();
          return [2, hash.digest()];
      }
    });
  });
};
var BLOCK_SIZE = 64;
var DIGEST_LENGTH = 16;
var INIT = [1732584193, 4023233417, 2562383102, 271733878];
var Md5 = function() {
  function Md52() {
    this.state = Uint32Array.from(INIT);
    this.buffer = new DataView(new ArrayBuffer(BLOCK_SIZE));
    this.bufferLength = 0;
    this.bytesHashed = 0;
    this.finished = false;
  }
  Md52.prototype.update = function(sourceData) {
    if (isEmptyData(sourceData)) {
      return;
    } else if (this.finished) {
      throw new Error("Attempted to update an already finished hash.");
    }
    var data = convertToBuffer(sourceData);
    var position = 0;
    var byteLength = data.byteLength;
    this.bytesHashed += byteLength;
    while (byteLength > 0) {
      this.buffer.setUint8(this.bufferLength++, data[position++]);
      byteLength--;
      if (this.bufferLength === BLOCK_SIZE) {
        this.hashBuffer();
        this.bufferLength = 0;
      }
    }
  };
  Md52.prototype.digest = function() {
    return tslib.exports.__awaiter(this, void 0, void 0, function() {
      var _a, buffer, undecoratedLength, bytesHashed, bitsHashed, i, i, out, i;
      return tslib.exports.__generator(this, function(_b) {
        if (!this.finished) {
          _a = this, buffer = _a.buffer, undecoratedLength = _a.bufferLength, bytesHashed = _a.bytesHashed;
          bitsHashed = bytesHashed * 8;
          buffer.setUint8(this.bufferLength++, 128);
          if (undecoratedLength % BLOCK_SIZE >= BLOCK_SIZE - 8) {
            for (i = this.bufferLength; i < BLOCK_SIZE; i++) {
              buffer.setUint8(i, 0);
            }
            this.hashBuffer();
            this.bufferLength = 0;
          }
          for (i = this.bufferLength; i < BLOCK_SIZE - 8; i++) {
            buffer.setUint8(i, 0);
          }
          buffer.setUint32(BLOCK_SIZE - 8, bitsHashed >>> 0, true);
          buffer.setUint32(BLOCK_SIZE - 4, Math.floor(bitsHashed / 4294967296), true);
          this.hashBuffer();
          this.finished = true;
        }
        out = new DataView(new ArrayBuffer(DIGEST_LENGTH));
        for (i = 0; i < 4; i++) {
          out.setUint32(i * 4, this.state[i], true);
        }
        return [2, new Uint8Array(out.buffer, out.byteOffset, out.byteLength)];
      });
    });
  };
  Md52.prototype.hashBuffer = function() {
    var _a = this, buffer = _a.buffer, state = _a.state;
    var a = state[0], b = state[1], c = state[2], d = state[3];
    a = ff(a, b, c, d, buffer.getUint32(0, true), 7, 3614090360);
    d = ff(d, a, b, c, buffer.getUint32(4, true), 12, 3905402710);
    c = ff(c, d, a, b, buffer.getUint32(8, true), 17, 606105819);
    b = ff(b, c, d, a, buffer.getUint32(12, true), 22, 3250441966);
    a = ff(a, b, c, d, buffer.getUint32(16, true), 7, 4118548399);
    d = ff(d, a, b, c, buffer.getUint32(20, true), 12, 1200080426);
    c = ff(c, d, a, b, buffer.getUint32(24, true), 17, 2821735955);
    b = ff(b, c, d, a, buffer.getUint32(28, true), 22, 4249261313);
    a = ff(a, b, c, d, buffer.getUint32(32, true), 7, 1770035416);
    d = ff(d, a, b, c, buffer.getUint32(36, true), 12, 2336552879);
    c = ff(c, d, a, b, buffer.getUint32(40, true), 17, 4294925233);
    b = ff(b, c, d, a, buffer.getUint32(44, true), 22, 2304563134);
    a = ff(a, b, c, d, buffer.getUint32(48, true), 7, 1804603682);
    d = ff(d, a, b, c, buffer.getUint32(52, true), 12, 4254626195);
    c = ff(c, d, a, b, buffer.getUint32(56, true), 17, 2792965006);
    b = ff(b, c, d, a, buffer.getUint32(60, true), 22, 1236535329);
    a = gg(a, b, c, d, buffer.getUint32(4, true), 5, 4129170786);
    d = gg(d, a, b, c, buffer.getUint32(24, true), 9, 3225465664);
    c = gg(c, d, a, b, buffer.getUint32(44, true), 14, 643717713);
    b = gg(b, c, d, a, buffer.getUint32(0, true), 20, 3921069994);
    a = gg(a, b, c, d, buffer.getUint32(20, true), 5, 3593408605);
    d = gg(d, a, b, c, buffer.getUint32(40, true), 9, 38016083);
    c = gg(c, d, a, b, buffer.getUint32(60, true), 14, 3634488961);
    b = gg(b, c, d, a, buffer.getUint32(16, true), 20, 3889429448);
    a = gg(a, b, c, d, buffer.getUint32(36, true), 5, 568446438);
    d = gg(d, a, b, c, buffer.getUint32(56, true), 9, 3275163606);
    c = gg(c, d, a, b, buffer.getUint32(12, true), 14, 4107603335);
    b = gg(b, c, d, a, buffer.getUint32(32, true), 20, 1163531501);
    a = gg(a, b, c, d, buffer.getUint32(52, true), 5, 2850285829);
    d = gg(d, a, b, c, buffer.getUint32(8, true), 9, 4243563512);
    c = gg(c, d, a, b, buffer.getUint32(28, true), 14, 1735328473);
    b = gg(b, c, d, a, buffer.getUint32(48, true), 20, 2368359562);
    a = hh(a, b, c, d, buffer.getUint32(20, true), 4, 4294588738);
    d = hh(d, a, b, c, buffer.getUint32(32, true), 11, 2272392833);
    c = hh(c, d, a, b, buffer.getUint32(44, true), 16, 1839030562);
    b = hh(b, c, d, a, buffer.getUint32(56, true), 23, 4259657740);
    a = hh(a, b, c, d, buffer.getUint32(4, true), 4, 2763975236);
    d = hh(d, a, b, c, buffer.getUint32(16, true), 11, 1272893353);
    c = hh(c, d, a, b, buffer.getUint32(28, true), 16, 4139469664);
    b = hh(b, c, d, a, buffer.getUint32(40, true), 23, 3200236656);
    a = hh(a, b, c, d, buffer.getUint32(52, true), 4, 681279174);
    d = hh(d, a, b, c, buffer.getUint32(0, true), 11, 3936430074);
    c = hh(c, d, a, b, buffer.getUint32(12, true), 16, 3572445317);
    b = hh(b, c, d, a, buffer.getUint32(24, true), 23, 76029189);
    a = hh(a, b, c, d, buffer.getUint32(36, true), 4, 3654602809);
    d = hh(d, a, b, c, buffer.getUint32(48, true), 11, 3873151461);
    c = hh(c, d, a, b, buffer.getUint32(60, true), 16, 530742520);
    b = hh(b, c, d, a, buffer.getUint32(8, true), 23, 3299628645);
    a = ii(a, b, c, d, buffer.getUint32(0, true), 6, 4096336452);
    d = ii(d, a, b, c, buffer.getUint32(28, true), 10, 1126891415);
    c = ii(c, d, a, b, buffer.getUint32(56, true), 15, 2878612391);
    b = ii(b, c, d, a, buffer.getUint32(20, true), 21, 4237533241);
    a = ii(a, b, c, d, buffer.getUint32(48, true), 6, 1700485571);
    d = ii(d, a, b, c, buffer.getUint32(12, true), 10, 2399980690);
    c = ii(c, d, a, b, buffer.getUint32(40, true), 15, 4293915773);
    b = ii(b, c, d, a, buffer.getUint32(4, true), 21, 2240044497);
    a = ii(a, b, c, d, buffer.getUint32(32, true), 6, 1873313359);
    d = ii(d, a, b, c, buffer.getUint32(60, true), 10, 4264355552);
    c = ii(c, d, a, b, buffer.getUint32(24, true), 15, 2734768916);
    b = ii(b, c, d, a, buffer.getUint32(52, true), 21, 1309151649);
    a = ii(a, b, c, d, buffer.getUint32(16, true), 6, 4149444226);
    d = ii(d, a, b, c, buffer.getUint32(44, true), 10, 3174756917);
    c = ii(c, d, a, b, buffer.getUint32(8, true), 15, 718787259);
    b = ii(b, c, d, a, buffer.getUint32(36, true), 21, 3951481745);
    state[0] = a + state[0] & 4294967295;
    state[1] = b + state[1] & 4294967295;
    state[2] = c + state[2] & 4294967295;
    state[3] = d + state[3] & 4294967295;
  };
  return Md52;
}();
function cmn(q, a, b, x, s, t) {
  a = (a + q & 4294967295) + (x + t & 4294967295) & 4294967295;
  return (a << s | a >>> 32 - s) + b & 4294967295;
}
function ff(a, b, c, d, x, s, t) {
  return cmn(b & c | ~b & d, a, b, x, s, t);
}
function gg(a, b, c, d, x, s, t) {
  return cmn(b & d | c & ~d, a, b, x, s, t);
}
function hh(a, b, c, d, x, s, t) {
  return cmn(b ^ c ^ d, a, b, x, s, t);
}
function ii(a, b, c, d, x, s, t) {
  return cmn(c ^ (b | ~d), a, b, x, s, t);
}
function isEmptyData(data) {
  if (typeof data === "string") {
    return data.length === 0;
  }
  return data.byteLength === 0;
}
function convertToBuffer(data) {
  if (typeof data === "string") {
    return fromUtf8(data);
  }
  if (ArrayBuffer.isView(data)) {
    return new Uint8Array(data.buffer, data.byteOffset, data.byteLength / Uint8Array.BYTES_PER_ELEMENT);
  }
  return new Uint8Array(data);
}
var AWS_TEMPLATE = "s3.{region}.amazonaws.com";
var AWS_CN_TEMPLATE = "s3.{region}.amazonaws.com.cn";
var AWS_ISO_TEMPLATE = "s3.{region}.c2s.ic.gov";
var AWS_ISO_B_TEMPLATE = "s3.{region}.sc2s.sgov.gov";
var AWS_US_GOV_TEMPLATE = "s3.{region}.amazonaws.com";
var AWS_REGIONS = /* @__PURE__ */ new Set([
  "af-south-1",
  "ap-east-1",
  "ap-northeast-1",
  "ap-northeast-2",
  "ap-south-1",
  "ap-southeast-1",
  "ap-southeast-2",
  "ca-central-1",
  "eu-central-1",
  "eu-north-1",
  "eu-south-1",
  "eu-west-1",
  "eu-west-2",
  "eu-west-3",
  "me-south-1",
  "sa-east-1",
  "us-east-1",
  "us-east-2",
  "us-west-1",
  "us-west-2"
]);
var AWS_CN_REGIONS = /* @__PURE__ */ new Set(["cn-north-1", "cn-northwest-1"]);
var AWS_ISO_REGIONS = /* @__PURE__ */ new Set(["us-iso-east-1"]);
var AWS_ISO_B_REGIONS = /* @__PURE__ */ new Set(["us-isob-east-1"]);
var AWS_US_GOV_REGIONS = /* @__PURE__ */ new Set(["us-gov-east-1", "us-gov-west-1"]);
var defaultRegionInfoProvider = function(region, options) {
  var regionInfo = void 0;
  switch (region) {
    case "af-south-1":
      regionInfo = {
        hostname: "s3.af-south-1.amazonaws.com",
        partition: "aws"
      };
      break;
    case "ap-east-1":
      regionInfo = {
        hostname: "s3.ap-east-1.amazonaws.com",
        partition: "aws"
      };
      break;
    case "ap-northeast-1":
      regionInfo = {
        hostname: "s3.ap-northeast-1.amazonaws.com",
        partition: "aws"
      };
      break;
    case "ap-northeast-2":
      regionInfo = {
        hostname: "s3.ap-northeast-2.amazonaws.com",
        partition: "aws"
      };
      break;
    case "ap-south-1":
      regionInfo = {
        hostname: "s3.ap-south-1.amazonaws.com",
        partition: "aws"
      };
      break;
    case "ap-southeast-1":
      regionInfo = {
        hostname: "s3.ap-southeast-1.amazonaws.com",
        partition: "aws"
      };
      break;
    case "ap-southeast-2":
      regionInfo = {
        hostname: "s3.ap-southeast-2.amazonaws.com",
        partition: "aws"
      };
      break;
    case "aws-global":
      regionInfo = {
        hostname: "s3.amazonaws.com",
        partition: "aws",
        signingRegion: "us-east-1"
      };
      break;
    case "ca-central-1":
      regionInfo = {
        hostname: "s3.ca-central-1.amazonaws.com",
        partition: "aws"
      };
      break;
    case "cn-north-1":
      regionInfo = {
        hostname: "s3.cn-north-1.amazonaws.com.cn",
        partition: "aws-cn"
      };
      break;
    case "cn-northwest-1":
      regionInfo = {
        hostname: "s3.cn-northwest-1.amazonaws.com.cn",
        partition: "aws-cn"
      };
      break;
    case "eu-central-1":
      regionInfo = {
        hostname: "s3.eu-central-1.amazonaws.com",
        partition: "aws"
      };
      break;
    case "eu-north-1":
      regionInfo = {
        hostname: "s3.eu-north-1.amazonaws.com",
        partition: "aws"
      };
      break;
    case "eu-south-1":
      regionInfo = {
        hostname: "s3.eu-south-1.amazonaws.com",
        partition: "aws"
      };
      break;
    case "eu-west-1":
      regionInfo = {
        hostname: "s3.eu-west-1.amazonaws.com",
        partition: "aws"
      };
      break;
    case "eu-west-2":
      regionInfo = {
        hostname: "s3.eu-west-2.amazonaws.com",
        partition: "aws"
      };
      break;
    case "eu-west-3":
      regionInfo = {
        hostname: "s3.eu-west-3.amazonaws.com",
        partition: "aws"
      };
      break;
    case "fips-us-gov-west-1":
      regionInfo = {
        hostname: "s3-fips.us-gov-west-1.amazonaws.com",
        partition: "aws-us-gov",
        signingRegion: "us-gov-west-1"
      };
      break;
    case "me-south-1":
      regionInfo = {
        hostname: "s3.me-south-1.amazonaws.com",
        partition: "aws"
      };
      break;
    case "s3-external-1":
      regionInfo = {
        hostname: "s3-external-1.amazonaws.com",
        partition: "aws",
        signingRegion: "us-east-1"
      };
      break;
    case "sa-east-1":
      regionInfo = {
        hostname: "s3.sa-east-1.amazonaws.com",
        partition: "aws"
      };
      break;
    case "us-east-1":
      regionInfo = {
        hostname: "s3.us-east-1.amazonaws.com",
        partition: "aws"
      };
      break;
    case "us-east-2":
      regionInfo = {
        hostname: "s3.us-east-2.amazonaws.com",
        partition: "aws"
      };
      break;
    case "us-gov-east-1":
      regionInfo = {
        hostname: "s3.us-gov-east-1.amazonaws.com",
        partition: "aws-us-gov"
      };
      break;
    case "us-gov-west-1":
      regionInfo = {
        hostname: "s3.us-gov-west-1.amazonaws.com",
        partition: "aws-us-gov"
      };
      break;
    case "us-iso-east-1":
      regionInfo = {
        hostname: "s3.us-iso-east-1.c2s.ic.gov",
        partition: "aws-iso"
      };
      break;
    case "us-isob-east-1":
      regionInfo = {
        hostname: "s3.us-isob-east-1.sc2s.sgov.gov",
        partition: "aws-iso-b"
      };
      break;
    case "us-west-1":
      regionInfo = {
        hostname: "s3.us-west-1.amazonaws.com",
        partition: "aws"
      };
      break;
    case "us-west-2":
      regionInfo = {
        hostname: "s3.us-west-2.amazonaws.com",
        partition: "aws"
      };
      break;
    default:
      if (AWS_REGIONS.has(region)) {
        regionInfo = {
          hostname: AWS_TEMPLATE.replace("{region}", region),
          partition: "aws"
        };
      }
      if (AWS_CN_REGIONS.has(region)) {
        regionInfo = {
          hostname: AWS_CN_TEMPLATE.replace("{region}", region),
          partition: "aws-cn"
        };
      }
      if (AWS_ISO_REGIONS.has(region)) {
        regionInfo = {
          hostname: AWS_ISO_TEMPLATE.replace("{region}", region),
          partition: "aws-iso"
        };
      }
      if (AWS_ISO_B_REGIONS.has(region)) {
        regionInfo = {
          hostname: AWS_ISO_B_TEMPLATE.replace("{region}", region),
          partition: "aws-iso-b"
        };
      }
      if (AWS_US_GOV_REGIONS.has(region)) {
        regionInfo = {
          hostname: AWS_US_GOV_TEMPLATE.replace("{region}", region),
          partition: "aws-us-gov"
        };
      }
      if (regionInfo === void 0) {
        regionInfo = {
          hostname: AWS_TEMPLATE.replace("{region}", region),
          partition: "aws"
        };
      }
  }
  return Promise.resolve(__assign$4({ signingService: "s3" }, regionInfo));
};
var ClientSharedValues = {
  apiVersion: "2006-03-01",
  disableHostPrefix: false,
  logger: {},
  regionInfoProvider: defaultRegionInfoProvider,
  serviceId: "S3",
  signingEscapePath: false,
  urlParser: parseUrl,
  useArnRegion: false
};
var ClientDefaultValues = __assign$4(__assign$4({}, ClientSharedValues), {
  runtime: "browser",
  base64Decoder: fromBase64,
  base64Encoder: toBase64,
  bodyLengthChecker: calculateBodyLength,
  credentialDefaultProvider: function(_) {
    return function() {
      return Promise.reject(new Error("Credential is missing"));
    };
  },
  defaultUserAgentProvider: defaultUserAgent({
    serviceId: ClientSharedValues.serviceId,
    clientVersion: packageInfo.version
  }),
  eventStreamSerdeProvider,
  maxAttempts: DEFAULT_MAX_ATTEMPTS,
  md5: Md5,
  region: invalidProvider("Region is missing"),
  requestHandler: new FetchHttpHandler(),
  sha256: build$2.Sha256,
  streamCollector,
  streamHasher: blobHasher,
  utf8Decoder: fromUtf8,
  utf8Encoder: toUtf8
});
var resolveEventStreamSerdeConfig = function(input) {
  return tslib.exports.__assign(tslib.exports.__assign({}, input), { eventStreamMarshaller: input.eventStreamSerdeProvider(input) });
};
var validate = function(str) {
  return typeof str === "string" && str.indexOf("arn:") === 0 && str.split(":").length >= 6;
};
var parse = function(arn) {
  var segments = arn.split(":");
  if (segments.length < 6 || segments[0] !== "arn")
    throw new Error("Malformed ARN");
  var _a = tslib.exports.__read(segments), partition = _a[1], service = _a[2], region = _a[3], accountId = _a[4], resource = _a.slice(5);
  return {
    partition,
    service,
    region,
    accountId,
    resource: resource.join(":")
  };
};
var DOMAIN_PATTERN = /^[a-z0-9][a-z0-9\.\-]{1,61}[a-z0-9]$/;
var IP_ADDRESS_PATTERN = /(\d+\.){3}\d+/;
var DOTS_PATTERN = /\.\./;
var DOT_PATTERN = /\./;
var S3_HOSTNAME_PATTERN = /^(.+\.)?s3[.-]([a-z0-9-]+)\./;
var S3_US_EAST_1_ALTNAME_PATTERN = /^s3(-external-1)?\.amazonaws\.com$/;
var AWS_PARTITION_SUFFIX = "amazonaws.com";
var isBucketNameOptions = function(options) {
  return typeof options.bucketName === "string";
};
var getPseudoRegion = function(region) {
  return isFipsRegion(region) ? region.replace(/fips-|-fips/, "") : region;
};
var isDnsCompatibleBucketName = function(bucketName) {
  return DOMAIN_PATTERN.test(bucketName) && !IP_ADDRESS_PATTERN.test(bucketName) && !DOTS_PATTERN.test(bucketName);
};
var getRegionalSuffix = function(hostname) {
  var parts = hostname.match(S3_HOSTNAME_PATTERN);
  return [parts[2], hostname.replace(new RegExp("^" + parts[0]), "")];
};
var getSuffix = function(hostname) {
  return S3_US_EAST_1_ALTNAME_PATTERN.test(hostname) ? ["us-east-1", AWS_PARTITION_SUFFIX] : getRegionalSuffix(hostname);
};
var getSuffixForArnEndpoint = function(hostname) {
  return S3_US_EAST_1_ALTNAME_PATTERN.test(hostname) ? [hostname.replace("." + AWS_PARTITION_SUFFIX, ""), AWS_PARTITION_SUFFIX] : getRegionalSuffix(hostname);
};
var validateArnEndpointOptions = function(options) {
  if (options.pathStyleEndpoint) {
    throw new Error("Path-style S3 endpoint is not supported when bucket is an ARN");
  }
  if (options.accelerateEndpoint) {
    throw new Error("Accelerate endpoint is not supported when bucket is an ARN");
  }
  if (!options.tlsCompatible) {
    throw new Error("HTTPS is required when bucket is an ARN");
  }
};
var validateService = function(service) {
  if (service !== "s3" && service !== "s3-outposts") {
    throw new Error("Expect 's3' or 's3-outposts' in ARN service component");
  }
};
var validateS3Service = function(service) {
  if (service !== "s3") {
    throw new Error("Expect 's3' in Accesspoint ARN service component");
  }
};
var validateOutpostService = function(service) {
  if (service !== "s3-outposts") {
    throw new Error("Expect 's3-posts' in Outpost ARN service component");
  }
};
var validatePartition = function(partition, options) {
  if (partition !== options.clientPartition) {
    throw new Error('Partition in ARN is incompatible, got "' + partition + '" but expected "' + options.clientPartition + '"');
  }
};
var validateRegion = function(region, options) {
  if (region === "") {
    throw new Error("ARN region is empty");
  }
  if (!options.useArnRegion && !isEqualRegions(region, options.clientRegion) && !isEqualRegions(region, options.clientSigningRegion)) {
    throw new Error("Region in ARN is incompatible, got " + region + " but expected " + options.clientRegion);
  }
  if (options.useArnRegion && isFipsRegion(region)) {
    throw new Error("Endpoint does not support FIPS region");
  }
};
var isFipsRegion = function(region) {
  return region.startsWith("fips-") || region.endsWith("-fips");
};
var isEqualRegions = function(regionA, regionB) {
  return regionA === regionB || getPseudoRegion(regionA) === regionB || regionA === getPseudoRegion(regionB);
};
var validateAccountId = function(accountId) {
  if (!/[0-9]{12}/.exec(accountId)) {
    throw new Error("Access point ARN accountID does not match regex '[0-9]{12}'");
  }
};
var validateDNSHostLabel = function(label, options) {
  if (options === void 0) {
    options = { tlsCompatible: true };
  }
  if (label.length >= 64 || !/^[a-z0-9][a-z0-9.-]+[a-z0-9]$/.test(label) || /(\d+\.){3}\d+/.test(label) || /[.-]{2}/.test(label) || (options === null || options === void 0 ? void 0 : options.tlsCompatible) && DOT_PATTERN.test(label)) {
    throw new Error("Invalid DNS label " + label);
  }
};
var getArnResources = function(resource) {
  var delimiter = resource.includes(":") ? ":" : "/";
  var _a = tslib.exports.__read(resource.split(delimiter)), resourceType = _a[0], rest = _a.slice(1);
  if (resourceType === "accesspoint") {
    if (rest.length !== 1 || rest[0] === "") {
      throw new Error("Access Point ARN should have one resource accesspoint" + delimiter + "{accesspointname}");
    }
    return { accesspointName: rest[0] };
  } else if (resourceType === "outpost") {
    if (!rest[0] || rest[1] !== "accesspoint" || !rest[2] || rest.length !== 3) {
      throw new Error("Outpost ARN should have resource outpost" + delimiter + "{outpostId}" + delimiter + "accesspoint" + delimiter + "{accesspointName}");
    }
    var _b = tslib.exports.__read(rest, 3), outpostId = _b[0];
    _b[1];
    var accesspointName = _b[2];
    return { outpostId, accesspointName };
  } else {
    throw new Error("ARN resource should begin with 'accesspoint" + delimiter + "' or 'outpost" + delimiter + "'");
  }
};
var validateNoDualstack = function(dualstackEndpoint) {
  if (dualstackEndpoint)
    throw new Error("Dualstack endpoint is not supported with Outpost");
};
var validateNoFIPS = function(region) {
  if (isFipsRegion(region !== null && region !== void 0 ? region : ""))
    throw new Error("FIPS region is not supported with Outpost, got " + region);
};
var bucketHostname = function(options) {
  var isCustomEndpoint = options.isCustomEndpoint;
  options.baseHostname;
  var dualstackEndpoint = options.dualstackEndpoint, accelerateEndpoint = options.accelerateEndpoint;
  if (isCustomEndpoint) {
    if (dualstackEndpoint)
      throw new Error("Dualstack endpoint is not supported with custom endpoint");
    if (accelerateEndpoint)
      throw new Error("Accelerate endpoint is not supported with custom endpoint");
  }
  return isBucketNameOptions(options) ? getEndpointFromBucketName(tslib.exports.__assign(tslib.exports.__assign({}, options), { isCustomEndpoint })) : getEndpointFromArn(tslib.exports.__assign(tslib.exports.__assign({}, options), { isCustomEndpoint }));
};
var getEndpointFromArn = function(options) {
  var isCustomEndpoint = options.isCustomEndpoint, baseHostname = options.baseHostname;
  var _a = tslib.exports.__read(isCustomEndpoint ? [options.clientRegion, baseHostname] : getSuffixForArnEndpoint(baseHostname), 2), clientRegion = _a[0], hostnameSuffix = _a[1];
  var pathStyleEndpoint = options.pathStyleEndpoint, _b = options.dualstackEndpoint, dualstackEndpoint = _b === void 0 ? false : _b, _c = options.accelerateEndpoint, accelerateEndpoint = _c === void 0 ? false : _c, _d = options.tlsCompatible, tlsCompatible = _d === void 0 ? true : _d, useArnRegion = options.useArnRegion, bucketName = options.bucketName, _e2 = options.clientPartition, clientPartition = _e2 === void 0 ? "aws" : _e2, _f = options.clientSigningRegion, clientSigningRegion = _f === void 0 ? clientRegion : _f;
  validateArnEndpointOptions({ pathStyleEndpoint, accelerateEndpoint, tlsCompatible });
  var service = bucketName.service, partition = bucketName.partition, accountId = bucketName.accountId, region = bucketName.region, resource = bucketName.resource;
  validateService(service);
  validatePartition(partition, { clientPartition });
  validateAccountId(accountId);
  validateRegion(region, { useArnRegion, clientRegion, clientSigningRegion });
  var _g = getArnResources(resource), accesspointName = _g.accesspointName, outpostId = _g.outpostId;
  validateDNSHostLabel(accesspointName + "-" + accountId, { tlsCompatible });
  var endpointRegion = useArnRegion ? region : clientRegion;
  var signingRegion = useArnRegion ? region : clientSigningRegion;
  if (outpostId) {
    validateOutpostService(service);
    validateDNSHostLabel(outpostId, { tlsCompatible });
    validateNoDualstack(dualstackEndpoint);
    validateNoFIPS(endpointRegion);
    var hostnamePrefix_1 = accesspointName + "-" + accountId + "." + outpostId;
    return {
      bucketEndpoint: true,
      hostname: "" + hostnamePrefix_1 + (isCustomEndpoint ? "" : ".s3-outposts." + endpointRegion) + "." + hostnameSuffix,
      signingRegion,
      signingService: "s3-outposts"
    };
  }
  validateS3Service(service);
  var hostnamePrefix = accesspointName + "-" + accountId;
  return {
    bucketEndpoint: true,
    hostname: "" + hostnamePrefix + (isCustomEndpoint ? "" : ".s3-accesspoint" + (dualstackEndpoint ? ".dualstack" : "") + "." + endpointRegion) + "." + hostnameSuffix,
    signingRegion
  };
};
var getEndpointFromBucketName = function(_a) {
  var _b = _a.accelerateEndpoint, accelerateEndpoint = _b === void 0 ? false : _b, region = _a.clientRegion, baseHostname = _a.baseHostname, bucketName = _a.bucketName, _c = _a.dualstackEndpoint, dualstackEndpoint = _c === void 0 ? false : _c, _d = _a.pathStyleEndpoint, pathStyleEndpoint = _d === void 0 ? false : _d, _e2 = _a.tlsCompatible, tlsCompatible = _e2 === void 0 ? true : _e2, _f = _a.isCustomEndpoint, isCustomEndpoint = _f === void 0 ? false : _f;
  var _g = tslib.exports.__read(isCustomEndpoint ? [region, baseHostname] : getSuffix(baseHostname), 2), clientRegion = _g[0], hostnameSuffix = _g[1];
  if (pathStyleEndpoint || !isDnsCompatibleBucketName(bucketName) || tlsCompatible && DOT_PATTERN.test(bucketName)) {
    return {
      bucketEndpoint: false,
      hostname: dualstackEndpoint ? "s3.dualstack." + clientRegion + "." + hostnameSuffix : baseHostname
    };
  }
  if (accelerateEndpoint) {
    baseHostname = "s3-accelerate" + (dualstackEndpoint ? ".dualstack" : "") + "." + hostnameSuffix;
  } else if (dualstackEndpoint) {
    baseHostname = "s3.dualstack." + clientRegion + "." + hostnameSuffix;
  }
  return {
    bucketEndpoint: true,
    hostname: bucketName + "." + baseHostname
  };
};
var bucketEndpointMiddleware = function(options) {
  return function(next, context) {
    return function(args) {
      return tslib.exports.__awaiter(void 0, void 0, void 0, function() {
        var bucketName, replaceBucketInPath, request, bucketArn, clientRegion, _a, _b, partition, _c, signingRegion, useArnRegion, _d, hostname, bucketEndpoint, modifiedSigningRegion, signingService, clientRegion, _e2, _f, hostname, bucketEndpoint;
        return tslib.exports.__generator(this, function(_g) {
          switch (_g.label) {
            case 0:
              bucketName = args.input.Bucket;
              replaceBucketInPath = options.bucketEndpoint;
              request = args.request;
              if (!HttpRequest.isInstance(request))
                return [3, 8];
              if (!options.bucketEndpoint)
                return [3, 1];
              request.hostname = bucketName;
              return [3, 7];
            case 1:
              if (!validate(bucketName))
                return [3, 5];
              bucketArn = parse(bucketName);
              _a = getPseudoRegion;
              return [4, options.region()];
            case 2:
              clientRegion = _a.apply(void 0, [_g.sent()]);
              return [4, options.regionInfoProvider(clientRegion)];
            case 3:
              _b = _g.sent() || {}, partition = _b.partition, _c = _b.signingRegion, signingRegion = _c === void 0 ? clientRegion : _c;
              return [4, options.useArnRegion()];
            case 4:
              useArnRegion = _g.sent();
              _d = bucketHostname({
                bucketName: bucketArn,
                baseHostname: request.hostname,
                accelerateEndpoint: options.useAccelerateEndpoint,
                dualstackEndpoint: options.useDualstackEndpoint,
                pathStyleEndpoint: options.forcePathStyle,
                tlsCompatible: request.protocol === "https:",
                useArnRegion,
                clientPartition: partition,
                clientSigningRegion: signingRegion,
                clientRegion,
                isCustomEndpoint: options.isCustomEndpoint
              }), hostname = _d.hostname, bucketEndpoint = _d.bucketEndpoint, modifiedSigningRegion = _d.signingRegion, signingService = _d.signingService;
              if (modifiedSigningRegion && modifiedSigningRegion !== signingRegion) {
                context["signing_region"] = modifiedSigningRegion;
              }
              if (signingService && signingService !== "s3") {
                context["signing_service"] = signingService;
              }
              request.hostname = hostname;
              replaceBucketInPath = bucketEndpoint;
              return [3, 7];
            case 5:
              _e2 = getPseudoRegion;
              return [4, options.region()];
            case 6:
              clientRegion = _e2.apply(void 0, [_g.sent()]);
              _f = bucketHostname({
                bucketName,
                clientRegion,
                baseHostname: request.hostname,
                accelerateEndpoint: options.useAccelerateEndpoint,
                dualstackEndpoint: options.useDualstackEndpoint,
                pathStyleEndpoint: options.forcePathStyle,
                tlsCompatible: request.protocol === "https:",
                isCustomEndpoint: options.isCustomEndpoint
              }), hostname = _f.hostname, bucketEndpoint = _f.bucketEndpoint;
              request.hostname = hostname;
              replaceBucketInPath = bucketEndpoint;
              _g.label = 7;
            case 7:
              if (replaceBucketInPath) {
                request.path = request.path.replace(/^(\/)?[^\/]+/, "");
                if (request.path === "") {
                  request.path = "/";
                }
              }
              _g.label = 8;
            case 8:
              return [2, next(tslib.exports.__assign(tslib.exports.__assign({}, args), { request }))];
          }
        });
      });
    };
  };
};
var bucketEndpointMiddlewareOptions = {
  tags: ["BUCKET_ENDPOINT"],
  name: "bucketEndpointMiddleware",
  relation: "before",
  toMiddleware: "hostHeaderMiddleware",
  override: true
};
var getBucketEndpointPlugin = function(options) {
  return {
    applyToStack: function(clientStack) {
      clientStack.addRelativeTo(bucketEndpointMiddleware(options), bucketEndpointMiddlewareOptions);
    }
  };
};
function resolveBucketEndpointConfig(input) {
  var _a = input.bucketEndpoint, bucketEndpoint = _a === void 0 ? false : _a, _b = input.forcePathStyle, forcePathStyle = _b === void 0 ? false : _b, _c = input.useAccelerateEndpoint, useAccelerateEndpoint = _c === void 0 ? false : _c, _d = input.useDualstackEndpoint, useDualstackEndpoint = _d === void 0 ? false : _d, _e2 = input.useArnRegion, useArnRegion = _e2 === void 0 ? false : _e2;
  return tslib.exports.__assign(tslib.exports.__assign({}, input), {
    bucketEndpoint,
    forcePathStyle,
    useAccelerateEndpoint,
    useDualstackEndpoint,
    useArnRegion: typeof useArnRegion === "function" ? useArnRegion : function() {
      return Promise.resolve(useArnRegion);
    }
  });
}
function addExpectContinueMiddleware(options) {
  var _this = this;
  return function(next) {
    return function(args) {
      return tslib.exports.__awaiter(_this, void 0, void 0, function() {
        var request;
        return tslib.exports.__generator(this, function(_a) {
          request = args.request;
          if (HttpRequest.isInstance(request) && request.body && options.runtime === "node") {
            request.headers = tslib.exports.__assign(tslib.exports.__assign({}, request.headers), { Expect: "100-continue" });
          }
          return [2, next(tslib.exports.__assign(tslib.exports.__assign({}, args), { request }))];
        });
      });
    };
  };
}
var addExpectContinueMiddlewareOptions = {
  step: "build",
  tags: ["SET_EXPECT_HEADER", "EXPECT_HEADER"],
  name: "addExpectContinueMiddleware",
  override: true
};
var getAddExpectContinuePlugin = function(options) {
  return {
    applyToStack: function(clientStack) {
      clientStack.add(addExpectContinueMiddleware(options), addExpectContinueMiddlewareOptions);
    }
  };
};
function validateBucketNameMiddleware() {
  var _this = this;
  return function(next) {
    return function(args) {
      return tslib.exports.__awaiter(_this, void 0, void 0, function() {
        var Bucket2, err;
        return tslib.exports.__generator(this, function(_a) {
          Bucket2 = args.input.Bucket;
          if (typeof Bucket2 === "string" && !validate(Bucket2) && Bucket2.indexOf("/") >= 0) {
            err = new Error("Bucket name shouldn't contain '/', received '" + Bucket2 + "'");
            err.name = "InvalidBucketName";
            throw err;
          }
          return [2, next(tslib.exports.__assign({}, args))];
        });
      });
    };
  };
}
var validateBucketNameMiddlewareOptions = {
  step: "initialize",
  tags: ["VALIDATE_BUCKET_NAME"],
  name: "validateBucketNameMiddleware",
  override: true
};
var getValidateBucketNamePlugin = function(unused) {
  return {
    applyToStack: function(clientStack) {
      clientStack.add(validateBucketNameMiddleware(), validateBucketNameMiddlewareOptions);
    }
  };
};
var useRegionalEndpointMiddleware = function(config) {
  return function(next) {
    return function(args) {
      return tslib.exports.__awaiter(void 0, void 0, void 0, function() {
        var request, _a;
        return tslib.exports.__generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              request = args.request;
              if (!HttpRequest.isInstance(request) || config.isCustomEndpoint)
                return [2, next(tslib.exports.__assign({}, args))];
              if (!(request.hostname === "s3.amazonaws.com"))
                return [3, 1];
              request.hostname = "s3.us-east-1.amazonaws.com";
              return [3, 3];
            case 1:
              _a = "aws-global";
              return [4, config.region()];
            case 2:
              if (_a === _b.sent()) {
                request.hostname = "s3.amazonaws.com";
              }
              _b.label = 3;
            case 3:
              return [2, next(tslib.exports.__assign({}, args))];
          }
        });
      });
    };
  };
};
var useRegionalEndpointMiddlewareOptions = {
  step: "build",
  tags: ["USE_REGIONAL_ENDPOINT", "S3"],
  name: "useRegionalEndpointMiddleware",
  override: true
};
var getUseRegionalEndpointPlugin = function(config) {
  return {
    applyToStack: function(clientStack) {
      clientStack.add(useRegionalEndpointMiddleware(config), useRegionalEndpointMiddlewareOptions);
    }
  };
};
var throw200ExceptionsMiddleware = function(config) {
  return function(next) {
    return function(args) {
      return tslib.exports.__awaiter(void 0, void 0, void 0, function() {
        var result, response, statusCode, body, bodyBytes, bodyString, err;
        return tslib.exports.__generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              return [4, next(args)];
            case 1:
              result = _a.sent();
              response = result.response;
              if (!HttpResponse.isInstance(response))
                return [2, result];
              statusCode = response.statusCode, body = response.body;
              if (statusCode < 200 && statusCode >= 300)
                return [2, result];
              return [4, collectBody$1(body, config)];
            case 2:
              bodyBytes = _a.sent();
              return [4, collectBodyString$1(bodyBytes, config)];
            case 3:
              bodyString = _a.sent();
              if (bodyBytes.length === 0) {
                err = new Error("S3 aborted request");
                err.name = "InternalError";
                throw err;
              }
              if (bodyString && bodyString.match("<Error>")) {
                response.statusCode = 400;
              }
              response.body = bodyBytes;
              return [2, result];
          }
        });
      });
    };
  };
};
var collectBody$1 = function(streamBody, context) {
  if (streamBody === void 0) {
    streamBody = new Uint8Array();
  }
  if (streamBody instanceof Uint8Array) {
    return Promise.resolve(streamBody);
  }
  return context.streamCollector(streamBody) || Promise.resolve(new Uint8Array());
};
var collectBodyString$1 = function(streamBody, context) {
  return collectBody$1(streamBody, context).then(function(body) {
    return context.utf8Encoder(body);
  });
};
var throw200ExceptionsMiddlewareOptions = {
  relation: "after",
  toMiddleware: "deserializerMiddleware",
  tags: ["THROW_200_EXCEPTIONS", "S3"],
  name: "throw200ExceptionsMiddleware",
  override: true
};
var getThrow200ExceptionsPlugin = function(config) {
  return {
    applyToStack: function(clientStack) {
      clientStack.addRelativeTo(throw200ExceptionsMiddleware(config), throw200ExceptionsMiddlewareOptions);
    }
  };
};
var S3Client = function(_super) {
  __extends(S3Client2, _super);
  function S3Client2(configuration) {
    var _this = this;
    var _config_0 = __assign$4(__assign$4({}, ClientDefaultValues), configuration);
    var _config_1 = resolveRegionConfig(_config_0);
    var _config_2 = resolveEndpointsConfig(_config_1);
    var _config_3 = resolveAwsAuthConfig(_config_2);
    var _config_4 = resolveRetryConfig(_config_3);
    var _config_5 = resolveHostHeaderConfig(_config_4);
    var _config_6 = resolveBucketEndpointConfig(_config_5);
    var _config_7 = resolveUserAgentConfig(_config_6);
    var _config_8 = resolveEventStreamSerdeConfig(_config_7);
    _this = _super.call(this, _config_8) || this;
    _this.config = _config_8;
    _this.middlewareStack.use(getAwsAuthPlugin(_this.config));
    _this.middlewareStack.use(getRetryPlugin(_this.config));
    _this.middlewareStack.use(getContentLengthPlugin(_this.config));
    _this.middlewareStack.use(getHostHeaderPlugin(_this.config));
    _this.middlewareStack.use(getLoggerPlugin(_this.config));
    _this.middlewareStack.use(getValidateBucketNamePlugin(_this.config));
    _this.middlewareStack.use(getUseRegionalEndpointPlugin(_this.config));
    _this.middlewareStack.use(getAddExpectContinuePlugin(_this.config));
    _this.middlewareStack.use(getUserAgentPlugin(_this.config));
    return _this;
  }
  S3Client2.prototype.destroy = function() {
    _super.prototype.destroy.call(this);
  };
  return S3Client2;
}(Client);
var AbortIncompleteMultipartUpload;
(function(AbortIncompleteMultipartUpload2) {
  AbortIncompleteMultipartUpload2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(AbortIncompleteMultipartUpload || (AbortIncompleteMultipartUpload = {}));
var AbortMultipartUploadOutput;
(function(AbortMultipartUploadOutput2) {
  AbortMultipartUploadOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(AbortMultipartUploadOutput || (AbortMultipartUploadOutput = {}));
var AbortMultipartUploadRequest;
(function(AbortMultipartUploadRequest2) {
  AbortMultipartUploadRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(AbortMultipartUploadRequest || (AbortMultipartUploadRequest = {}));
var NoSuchUpload;
(function(NoSuchUpload2) {
  NoSuchUpload2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(NoSuchUpload || (NoSuchUpload = {}));
var AccelerateConfiguration;
(function(AccelerateConfiguration2) {
  AccelerateConfiguration2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(AccelerateConfiguration || (AccelerateConfiguration = {}));
var Grantee;
(function(Grantee2) {
  Grantee2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(Grantee || (Grantee = {}));
var Grant;
(function(Grant2) {
  Grant2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(Grant || (Grant = {}));
var Owner;
(function(Owner2) {
  Owner2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(Owner || (Owner = {}));
var AccessControlPolicy;
(function(AccessControlPolicy2) {
  AccessControlPolicy2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(AccessControlPolicy || (AccessControlPolicy = {}));
var AccessControlTranslation;
(function(AccessControlTranslation2) {
  AccessControlTranslation2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(AccessControlTranslation || (AccessControlTranslation = {}));
var CompleteMultipartUploadOutput;
(function(CompleteMultipartUploadOutput2) {
  CompleteMultipartUploadOutput2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.SSEKMSKeyId && { SSEKMSKeyId: SENSITIVE_STRING });
  };
})(CompleteMultipartUploadOutput || (CompleteMultipartUploadOutput = {}));
var CompletedPart;
(function(CompletedPart2) {
  CompletedPart2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(CompletedPart || (CompletedPart = {}));
var CompletedMultipartUpload;
(function(CompletedMultipartUpload2) {
  CompletedMultipartUpload2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(CompletedMultipartUpload || (CompletedMultipartUpload = {}));
var CompleteMultipartUploadRequest;
(function(CompleteMultipartUploadRequest2) {
  CompleteMultipartUploadRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(CompleteMultipartUploadRequest || (CompleteMultipartUploadRequest = {}));
var CopyObjectResult;
(function(CopyObjectResult2) {
  CopyObjectResult2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(CopyObjectResult || (CopyObjectResult = {}));
var CopyObjectOutput;
(function(CopyObjectOutput2) {
  CopyObjectOutput2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4(__assign$4({}, obj), obj.SSEKMSKeyId && { SSEKMSKeyId: SENSITIVE_STRING }), obj.SSEKMSEncryptionContext && { SSEKMSEncryptionContext: SENSITIVE_STRING });
  };
})(CopyObjectOutput || (CopyObjectOutput = {}));
var CopyObjectRequest;
(function(CopyObjectRequest2) {
  CopyObjectRequest2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4(__assign$4(__assign$4(__assign$4({}, obj), obj.SSECustomerKey && { SSECustomerKey: SENSITIVE_STRING }), obj.SSEKMSKeyId && { SSEKMSKeyId: SENSITIVE_STRING }), obj.SSEKMSEncryptionContext && { SSEKMSEncryptionContext: SENSITIVE_STRING }), obj.CopySourceSSECustomerKey && { CopySourceSSECustomerKey: SENSITIVE_STRING });
  };
})(CopyObjectRequest || (CopyObjectRequest = {}));
var ObjectNotInActiveTierError;
(function(ObjectNotInActiveTierError2) {
  ObjectNotInActiveTierError2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ObjectNotInActiveTierError || (ObjectNotInActiveTierError = {}));
var BucketAlreadyExists;
(function(BucketAlreadyExists2) {
  BucketAlreadyExists2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(BucketAlreadyExists || (BucketAlreadyExists = {}));
var BucketAlreadyOwnedByYou;
(function(BucketAlreadyOwnedByYou2) {
  BucketAlreadyOwnedByYou2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(BucketAlreadyOwnedByYou || (BucketAlreadyOwnedByYou = {}));
var CreateBucketOutput;
(function(CreateBucketOutput2) {
  CreateBucketOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(CreateBucketOutput || (CreateBucketOutput = {}));
var CreateBucketConfiguration;
(function(CreateBucketConfiguration2) {
  CreateBucketConfiguration2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(CreateBucketConfiguration || (CreateBucketConfiguration = {}));
var CreateBucketRequest;
(function(CreateBucketRequest2) {
  CreateBucketRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(CreateBucketRequest || (CreateBucketRequest = {}));
var CreateMultipartUploadOutput;
(function(CreateMultipartUploadOutput2) {
  CreateMultipartUploadOutput2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4(__assign$4({}, obj), obj.SSEKMSKeyId && { SSEKMSKeyId: SENSITIVE_STRING }), obj.SSEKMSEncryptionContext && { SSEKMSEncryptionContext: SENSITIVE_STRING });
  };
})(CreateMultipartUploadOutput || (CreateMultipartUploadOutput = {}));
var CreateMultipartUploadRequest;
(function(CreateMultipartUploadRequest2) {
  CreateMultipartUploadRequest2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4(__assign$4(__assign$4({}, obj), obj.SSECustomerKey && { SSECustomerKey: SENSITIVE_STRING }), obj.SSEKMSKeyId && { SSEKMSKeyId: SENSITIVE_STRING }), obj.SSEKMSEncryptionContext && { SSEKMSEncryptionContext: SENSITIVE_STRING });
  };
})(CreateMultipartUploadRequest || (CreateMultipartUploadRequest = {}));
var DeleteBucketRequest;
(function(DeleteBucketRequest2) {
  DeleteBucketRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(DeleteBucketRequest || (DeleteBucketRequest = {}));
var DeleteBucketAnalyticsConfigurationRequest;
(function(DeleteBucketAnalyticsConfigurationRequest2) {
  DeleteBucketAnalyticsConfigurationRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(DeleteBucketAnalyticsConfigurationRequest || (DeleteBucketAnalyticsConfigurationRequest = {}));
var DeleteBucketCorsRequest;
(function(DeleteBucketCorsRequest2) {
  DeleteBucketCorsRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(DeleteBucketCorsRequest || (DeleteBucketCorsRequest = {}));
var DeleteBucketEncryptionRequest;
(function(DeleteBucketEncryptionRequest2) {
  DeleteBucketEncryptionRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(DeleteBucketEncryptionRequest || (DeleteBucketEncryptionRequest = {}));
var DeleteBucketIntelligentTieringConfigurationRequest;
(function(DeleteBucketIntelligentTieringConfigurationRequest2) {
  DeleteBucketIntelligentTieringConfigurationRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(DeleteBucketIntelligentTieringConfigurationRequest || (DeleteBucketIntelligentTieringConfigurationRequest = {}));
var DeleteBucketInventoryConfigurationRequest;
(function(DeleteBucketInventoryConfigurationRequest2) {
  DeleteBucketInventoryConfigurationRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(DeleteBucketInventoryConfigurationRequest || (DeleteBucketInventoryConfigurationRequest = {}));
var DeleteBucketLifecycleRequest;
(function(DeleteBucketLifecycleRequest2) {
  DeleteBucketLifecycleRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(DeleteBucketLifecycleRequest || (DeleteBucketLifecycleRequest = {}));
var DeleteBucketMetricsConfigurationRequest;
(function(DeleteBucketMetricsConfigurationRequest2) {
  DeleteBucketMetricsConfigurationRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(DeleteBucketMetricsConfigurationRequest || (DeleteBucketMetricsConfigurationRequest = {}));
var DeleteBucketOwnershipControlsRequest;
(function(DeleteBucketOwnershipControlsRequest2) {
  DeleteBucketOwnershipControlsRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(DeleteBucketOwnershipControlsRequest || (DeleteBucketOwnershipControlsRequest = {}));
var DeleteBucketPolicyRequest;
(function(DeleteBucketPolicyRequest2) {
  DeleteBucketPolicyRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(DeleteBucketPolicyRequest || (DeleteBucketPolicyRequest = {}));
var DeleteBucketReplicationRequest;
(function(DeleteBucketReplicationRequest2) {
  DeleteBucketReplicationRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(DeleteBucketReplicationRequest || (DeleteBucketReplicationRequest = {}));
var DeleteBucketTaggingRequest;
(function(DeleteBucketTaggingRequest2) {
  DeleteBucketTaggingRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(DeleteBucketTaggingRequest || (DeleteBucketTaggingRequest = {}));
var DeleteBucketWebsiteRequest;
(function(DeleteBucketWebsiteRequest2) {
  DeleteBucketWebsiteRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(DeleteBucketWebsiteRequest || (DeleteBucketWebsiteRequest = {}));
var DeleteObjectOutput;
(function(DeleteObjectOutput2) {
  DeleteObjectOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(DeleteObjectOutput || (DeleteObjectOutput = {}));
var DeleteObjectRequest;
(function(DeleteObjectRequest2) {
  DeleteObjectRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(DeleteObjectRequest || (DeleteObjectRequest = {}));
var DeletedObject;
(function(DeletedObject2) {
  DeletedObject2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(DeletedObject || (DeletedObject = {}));
var _Error;
(function(_Error2) {
  _Error2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(_Error || (_Error = {}));
var DeleteObjectsOutput;
(function(DeleteObjectsOutput2) {
  DeleteObjectsOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(DeleteObjectsOutput || (DeleteObjectsOutput = {}));
var ObjectIdentifier;
(function(ObjectIdentifier2) {
  ObjectIdentifier2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ObjectIdentifier || (ObjectIdentifier = {}));
var Delete;
(function(Delete2) {
  Delete2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(Delete || (Delete = {}));
var DeleteObjectsRequest;
(function(DeleteObjectsRequest2) {
  DeleteObjectsRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(DeleteObjectsRequest || (DeleteObjectsRequest = {}));
var DeleteObjectTaggingOutput;
(function(DeleteObjectTaggingOutput2) {
  DeleteObjectTaggingOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(DeleteObjectTaggingOutput || (DeleteObjectTaggingOutput = {}));
var DeleteObjectTaggingRequest;
(function(DeleteObjectTaggingRequest2) {
  DeleteObjectTaggingRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(DeleteObjectTaggingRequest || (DeleteObjectTaggingRequest = {}));
var DeletePublicAccessBlockRequest;
(function(DeletePublicAccessBlockRequest2) {
  DeletePublicAccessBlockRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(DeletePublicAccessBlockRequest || (DeletePublicAccessBlockRequest = {}));
var GetBucketAccelerateConfigurationOutput;
(function(GetBucketAccelerateConfigurationOutput2) {
  GetBucketAccelerateConfigurationOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketAccelerateConfigurationOutput || (GetBucketAccelerateConfigurationOutput = {}));
var GetBucketAccelerateConfigurationRequest;
(function(GetBucketAccelerateConfigurationRequest2) {
  GetBucketAccelerateConfigurationRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketAccelerateConfigurationRequest || (GetBucketAccelerateConfigurationRequest = {}));
var GetBucketAclOutput;
(function(GetBucketAclOutput2) {
  GetBucketAclOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketAclOutput || (GetBucketAclOutput = {}));
var GetBucketAclRequest;
(function(GetBucketAclRequest2) {
  GetBucketAclRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketAclRequest || (GetBucketAclRequest = {}));
var Tag;
(function(Tag2) {
  Tag2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(Tag || (Tag = {}));
var AnalyticsAndOperator;
(function(AnalyticsAndOperator2) {
  AnalyticsAndOperator2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(AnalyticsAndOperator || (AnalyticsAndOperator = {}));
var AnalyticsFilter;
(function(AnalyticsFilter2) {
  AnalyticsFilter2.visit = function(value, visitor) {
    if (value.Prefix !== void 0)
      return visitor.Prefix(value.Prefix);
    if (value.Tag !== void 0)
      return visitor.Tag(value.Tag);
    if (value.And !== void 0)
      return visitor.And(value.And);
    return visitor._(value.$unknown[0], value.$unknown[1]);
  };
  AnalyticsFilter2.filterSensitiveLog = function(obj) {
    var _a;
    if (obj.Prefix !== void 0)
      return { Prefix: obj.Prefix };
    if (obj.Tag !== void 0)
      return { Tag: Tag.filterSensitiveLog(obj.Tag) };
    if (obj.And !== void 0)
      return { And: AnalyticsAndOperator.filterSensitiveLog(obj.And) };
    if (obj.$unknown !== void 0)
      return _a = {}, _a[obj.$unknown[0]] = "UNKNOWN", _a;
  };
})(AnalyticsFilter || (AnalyticsFilter = {}));
var AnalyticsS3BucketDestination;
(function(AnalyticsS3BucketDestination2) {
  AnalyticsS3BucketDestination2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(AnalyticsS3BucketDestination || (AnalyticsS3BucketDestination = {}));
var AnalyticsExportDestination;
(function(AnalyticsExportDestination2) {
  AnalyticsExportDestination2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(AnalyticsExportDestination || (AnalyticsExportDestination = {}));
var StorageClassAnalysisDataExport;
(function(StorageClassAnalysisDataExport2) {
  StorageClassAnalysisDataExport2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(StorageClassAnalysisDataExport || (StorageClassAnalysisDataExport = {}));
var StorageClassAnalysis;
(function(StorageClassAnalysis2) {
  StorageClassAnalysis2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(StorageClassAnalysis || (StorageClassAnalysis = {}));
var AnalyticsConfiguration;
(function(AnalyticsConfiguration2) {
  AnalyticsConfiguration2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.Filter && { Filter: AnalyticsFilter.filterSensitiveLog(obj.Filter) });
  };
})(AnalyticsConfiguration || (AnalyticsConfiguration = {}));
var GetBucketAnalyticsConfigurationOutput;
(function(GetBucketAnalyticsConfigurationOutput2) {
  GetBucketAnalyticsConfigurationOutput2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.AnalyticsConfiguration && {
      AnalyticsConfiguration: AnalyticsConfiguration.filterSensitiveLog(obj.AnalyticsConfiguration)
    });
  };
})(GetBucketAnalyticsConfigurationOutput || (GetBucketAnalyticsConfigurationOutput = {}));
var GetBucketAnalyticsConfigurationRequest;
(function(GetBucketAnalyticsConfigurationRequest2) {
  GetBucketAnalyticsConfigurationRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketAnalyticsConfigurationRequest || (GetBucketAnalyticsConfigurationRequest = {}));
var CORSRule;
(function(CORSRule2) {
  CORSRule2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(CORSRule || (CORSRule = {}));
var GetBucketCorsOutput;
(function(GetBucketCorsOutput2) {
  GetBucketCorsOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketCorsOutput || (GetBucketCorsOutput = {}));
var GetBucketCorsRequest;
(function(GetBucketCorsRequest2) {
  GetBucketCorsRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketCorsRequest || (GetBucketCorsRequest = {}));
var ServerSideEncryptionByDefault;
(function(ServerSideEncryptionByDefault2) {
  ServerSideEncryptionByDefault2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.KMSMasterKeyID && { KMSMasterKeyID: SENSITIVE_STRING });
  };
})(ServerSideEncryptionByDefault || (ServerSideEncryptionByDefault = {}));
var ServerSideEncryptionRule;
(function(ServerSideEncryptionRule2) {
  ServerSideEncryptionRule2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.ApplyServerSideEncryptionByDefault && {
      ApplyServerSideEncryptionByDefault: ServerSideEncryptionByDefault.filterSensitiveLog(obj.ApplyServerSideEncryptionByDefault)
    });
  };
})(ServerSideEncryptionRule || (ServerSideEncryptionRule = {}));
var ServerSideEncryptionConfiguration;
(function(ServerSideEncryptionConfiguration2) {
  ServerSideEncryptionConfiguration2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.Rules && { Rules: obj.Rules.map(function(item) {
      return ServerSideEncryptionRule.filterSensitiveLog(item);
    }) });
  };
})(ServerSideEncryptionConfiguration || (ServerSideEncryptionConfiguration = {}));
var GetBucketEncryptionOutput;
(function(GetBucketEncryptionOutput2) {
  GetBucketEncryptionOutput2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.ServerSideEncryptionConfiguration && {
      ServerSideEncryptionConfiguration: ServerSideEncryptionConfiguration.filterSensitiveLog(obj.ServerSideEncryptionConfiguration)
    });
  };
})(GetBucketEncryptionOutput || (GetBucketEncryptionOutput = {}));
var GetBucketEncryptionRequest;
(function(GetBucketEncryptionRequest2) {
  GetBucketEncryptionRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketEncryptionRequest || (GetBucketEncryptionRequest = {}));
var IntelligentTieringAndOperator;
(function(IntelligentTieringAndOperator2) {
  IntelligentTieringAndOperator2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(IntelligentTieringAndOperator || (IntelligentTieringAndOperator = {}));
var IntelligentTieringFilter;
(function(IntelligentTieringFilter2) {
  IntelligentTieringFilter2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(IntelligentTieringFilter || (IntelligentTieringFilter = {}));
var Tiering;
(function(Tiering2) {
  Tiering2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(Tiering || (Tiering = {}));
var IntelligentTieringConfiguration;
(function(IntelligentTieringConfiguration2) {
  IntelligentTieringConfiguration2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(IntelligentTieringConfiguration || (IntelligentTieringConfiguration = {}));
var GetBucketIntelligentTieringConfigurationOutput;
(function(GetBucketIntelligentTieringConfigurationOutput2) {
  GetBucketIntelligentTieringConfigurationOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketIntelligentTieringConfigurationOutput || (GetBucketIntelligentTieringConfigurationOutput = {}));
var GetBucketIntelligentTieringConfigurationRequest;
(function(GetBucketIntelligentTieringConfigurationRequest2) {
  GetBucketIntelligentTieringConfigurationRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketIntelligentTieringConfigurationRequest || (GetBucketIntelligentTieringConfigurationRequest = {}));
var SSEKMS;
(function(SSEKMS2) {
  SSEKMS2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.KeyId && { KeyId: SENSITIVE_STRING });
  };
})(SSEKMS || (SSEKMS = {}));
var SSES3;
(function(SSES32) {
  SSES32.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(SSES3 || (SSES3 = {}));
var InventoryEncryption;
(function(InventoryEncryption2) {
  InventoryEncryption2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.SSEKMS && { SSEKMS: SSEKMS.filterSensitiveLog(obj.SSEKMS) });
  };
})(InventoryEncryption || (InventoryEncryption = {}));
var InventoryS3BucketDestination;
(function(InventoryS3BucketDestination2) {
  InventoryS3BucketDestination2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.Encryption && { Encryption: InventoryEncryption.filterSensitiveLog(obj.Encryption) });
  };
})(InventoryS3BucketDestination || (InventoryS3BucketDestination = {}));
var InventoryDestination;
(function(InventoryDestination2) {
  InventoryDestination2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.S3BucketDestination && {
      S3BucketDestination: InventoryS3BucketDestination.filterSensitiveLog(obj.S3BucketDestination)
    });
  };
})(InventoryDestination || (InventoryDestination = {}));
var InventoryFilter;
(function(InventoryFilter2) {
  InventoryFilter2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(InventoryFilter || (InventoryFilter = {}));
var InventorySchedule;
(function(InventorySchedule2) {
  InventorySchedule2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(InventorySchedule || (InventorySchedule = {}));
var InventoryConfiguration;
(function(InventoryConfiguration2) {
  InventoryConfiguration2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.Destination && { Destination: InventoryDestination.filterSensitiveLog(obj.Destination) });
  };
})(InventoryConfiguration || (InventoryConfiguration = {}));
var GetBucketInventoryConfigurationOutput;
(function(GetBucketInventoryConfigurationOutput2) {
  GetBucketInventoryConfigurationOutput2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.InventoryConfiguration && {
      InventoryConfiguration: InventoryConfiguration.filterSensitiveLog(obj.InventoryConfiguration)
    });
  };
})(GetBucketInventoryConfigurationOutput || (GetBucketInventoryConfigurationOutput = {}));
var GetBucketInventoryConfigurationRequest;
(function(GetBucketInventoryConfigurationRequest2) {
  GetBucketInventoryConfigurationRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketInventoryConfigurationRequest || (GetBucketInventoryConfigurationRequest = {}));
var LifecycleExpiration;
(function(LifecycleExpiration2) {
  LifecycleExpiration2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(LifecycleExpiration || (LifecycleExpiration = {}));
var LifecycleRuleAndOperator;
(function(LifecycleRuleAndOperator2) {
  LifecycleRuleAndOperator2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(LifecycleRuleAndOperator || (LifecycleRuleAndOperator = {}));
var LifecycleRuleFilter;
(function(LifecycleRuleFilter2) {
  LifecycleRuleFilter2.visit = function(value, visitor) {
    if (value.Prefix !== void 0)
      return visitor.Prefix(value.Prefix);
    if (value.Tag !== void 0)
      return visitor.Tag(value.Tag);
    if (value.And !== void 0)
      return visitor.And(value.And);
    return visitor._(value.$unknown[0], value.$unknown[1]);
  };
  LifecycleRuleFilter2.filterSensitiveLog = function(obj) {
    var _a;
    if (obj.Prefix !== void 0)
      return { Prefix: obj.Prefix };
    if (obj.Tag !== void 0)
      return { Tag: Tag.filterSensitiveLog(obj.Tag) };
    if (obj.And !== void 0)
      return { And: LifecycleRuleAndOperator.filterSensitiveLog(obj.And) };
    if (obj.$unknown !== void 0)
      return _a = {}, _a[obj.$unknown[0]] = "UNKNOWN", _a;
  };
})(LifecycleRuleFilter || (LifecycleRuleFilter = {}));
var NoncurrentVersionExpiration;
(function(NoncurrentVersionExpiration2) {
  NoncurrentVersionExpiration2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(NoncurrentVersionExpiration || (NoncurrentVersionExpiration = {}));
var NoncurrentVersionTransition;
(function(NoncurrentVersionTransition2) {
  NoncurrentVersionTransition2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(NoncurrentVersionTransition || (NoncurrentVersionTransition = {}));
var Transition;
(function(Transition2) {
  Transition2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(Transition || (Transition = {}));
var LifecycleRule;
(function(LifecycleRule2) {
  LifecycleRule2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.Filter && { Filter: LifecycleRuleFilter.filterSensitiveLog(obj.Filter) });
  };
})(LifecycleRule || (LifecycleRule = {}));
var GetBucketLifecycleConfigurationOutput;
(function(GetBucketLifecycleConfigurationOutput2) {
  GetBucketLifecycleConfigurationOutput2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.Rules && { Rules: obj.Rules.map(function(item) {
      return LifecycleRule.filterSensitiveLog(item);
    }) });
  };
})(GetBucketLifecycleConfigurationOutput || (GetBucketLifecycleConfigurationOutput = {}));
var GetBucketLifecycleConfigurationRequest;
(function(GetBucketLifecycleConfigurationRequest2) {
  GetBucketLifecycleConfigurationRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketLifecycleConfigurationRequest || (GetBucketLifecycleConfigurationRequest = {}));
var GetBucketLocationOutput;
(function(GetBucketLocationOutput2) {
  GetBucketLocationOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketLocationOutput || (GetBucketLocationOutput = {}));
var GetBucketLocationRequest;
(function(GetBucketLocationRequest2) {
  GetBucketLocationRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketLocationRequest || (GetBucketLocationRequest = {}));
var TargetGrant;
(function(TargetGrant2) {
  TargetGrant2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(TargetGrant || (TargetGrant = {}));
var LoggingEnabled;
(function(LoggingEnabled2) {
  LoggingEnabled2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(LoggingEnabled || (LoggingEnabled = {}));
var GetBucketLoggingOutput;
(function(GetBucketLoggingOutput2) {
  GetBucketLoggingOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketLoggingOutput || (GetBucketLoggingOutput = {}));
var GetBucketLoggingRequest;
(function(GetBucketLoggingRequest2) {
  GetBucketLoggingRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketLoggingRequest || (GetBucketLoggingRequest = {}));
var MetricsAndOperator;
(function(MetricsAndOperator2) {
  MetricsAndOperator2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(MetricsAndOperator || (MetricsAndOperator = {}));
var MetricsFilter;
(function(MetricsFilter2) {
  MetricsFilter2.visit = function(value, visitor) {
    if (value.Prefix !== void 0)
      return visitor.Prefix(value.Prefix);
    if (value.Tag !== void 0)
      return visitor.Tag(value.Tag);
    if (value.And !== void 0)
      return visitor.And(value.And);
    return visitor._(value.$unknown[0], value.$unknown[1]);
  };
  MetricsFilter2.filterSensitiveLog = function(obj) {
    var _a;
    if (obj.Prefix !== void 0)
      return { Prefix: obj.Prefix };
    if (obj.Tag !== void 0)
      return { Tag: Tag.filterSensitiveLog(obj.Tag) };
    if (obj.And !== void 0)
      return { And: MetricsAndOperator.filterSensitiveLog(obj.And) };
    if (obj.$unknown !== void 0)
      return _a = {}, _a[obj.$unknown[0]] = "UNKNOWN", _a;
  };
})(MetricsFilter || (MetricsFilter = {}));
var MetricsConfiguration;
(function(MetricsConfiguration2) {
  MetricsConfiguration2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.Filter && { Filter: MetricsFilter.filterSensitiveLog(obj.Filter) });
  };
})(MetricsConfiguration || (MetricsConfiguration = {}));
var GetBucketMetricsConfigurationOutput;
(function(GetBucketMetricsConfigurationOutput2) {
  GetBucketMetricsConfigurationOutput2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.MetricsConfiguration && {
      MetricsConfiguration: MetricsConfiguration.filterSensitiveLog(obj.MetricsConfiguration)
    });
  };
})(GetBucketMetricsConfigurationOutput || (GetBucketMetricsConfigurationOutput = {}));
var GetBucketMetricsConfigurationRequest;
(function(GetBucketMetricsConfigurationRequest2) {
  GetBucketMetricsConfigurationRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketMetricsConfigurationRequest || (GetBucketMetricsConfigurationRequest = {}));
var GetBucketNotificationConfigurationRequest;
(function(GetBucketNotificationConfigurationRequest2) {
  GetBucketNotificationConfigurationRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketNotificationConfigurationRequest || (GetBucketNotificationConfigurationRequest = {}));
var FilterRule;
(function(FilterRule2) {
  FilterRule2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(FilterRule || (FilterRule = {}));
var S3KeyFilter;
(function(S3KeyFilter2) {
  S3KeyFilter2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(S3KeyFilter || (S3KeyFilter = {}));
var NotificationConfigurationFilter;
(function(NotificationConfigurationFilter2) {
  NotificationConfigurationFilter2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(NotificationConfigurationFilter || (NotificationConfigurationFilter = {}));
var LambdaFunctionConfiguration;
(function(LambdaFunctionConfiguration2) {
  LambdaFunctionConfiguration2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(LambdaFunctionConfiguration || (LambdaFunctionConfiguration = {}));
var QueueConfiguration;
(function(QueueConfiguration2) {
  QueueConfiguration2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(QueueConfiguration || (QueueConfiguration = {}));
var TopicConfiguration;
(function(TopicConfiguration2) {
  TopicConfiguration2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(TopicConfiguration || (TopicConfiguration = {}));
var NotificationConfiguration;
(function(NotificationConfiguration2) {
  NotificationConfiguration2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(NotificationConfiguration || (NotificationConfiguration = {}));
var OwnershipControlsRule;
(function(OwnershipControlsRule2) {
  OwnershipControlsRule2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(OwnershipControlsRule || (OwnershipControlsRule = {}));
var OwnershipControls;
(function(OwnershipControls2) {
  OwnershipControls2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(OwnershipControls || (OwnershipControls = {}));
var GetBucketOwnershipControlsOutput;
(function(GetBucketOwnershipControlsOutput2) {
  GetBucketOwnershipControlsOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketOwnershipControlsOutput || (GetBucketOwnershipControlsOutput = {}));
var GetBucketOwnershipControlsRequest;
(function(GetBucketOwnershipControlsRequest2) {
  GetBucketOwnershipControlsRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketOwnershipControlsRequest || (GetBucketOwnershipControlsRequest = {}));
var GetBucketPolicyOutput;
(function(GetBucketPolicyOutput2) {
  GetBucketPolicyOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketPolicyOutput || (GetBucketPolicyOutput = {}));
var GetBucketPolicyRequest;
(function(GetBucketPolicyRequest2) {
  GetBucketPolicyRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketPolicyRequest || (GetBucketPolicyRequest = {}));
var PolicyStatus;
(function(PolicyStatus2) {
  PolicyStatus2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(PolicyStatus || (PolicyStatus = {}));
var GetBucketPolicyStatusOutput;
(function(GetBucketPolicyStatusOutput2) {
  GetBucketPolicyStatusOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketPolicyStatusOutput || (GetBucketPolicyStatusOutput = {}));
var GetBucketPolicyStatusRequest;
(function(GetBucketPolicyStatusRequest2) {
  GetBucketPolicyStatusRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketPolicyStatusRequest || (GetBucketPolicyStatusRequest = {}));
var DeleteMarkerReplication;
(function(DeleteMarkerReplication2) {
  DeleteMarkerReplication2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(DeleteMarkerReplication || (DeleteMarkerReplication = {}));
var EncryptionConfiguration;
(function(EncryptionConfiguration2) {
  EncryptionConfiguration2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(EncryptionConfiguration || (EncryptionConfiguration = {}));
var ReplicationTimeValue;
(function(ReplicationTimeValue2) {
  ReplicationTimeValue2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ReplicationTimeValue || (ReplicationTimeValue = {}));
var Metrics;
(function(Metrics2) {
  Metrics2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(Metrics || (Metrics = {}));
var ReplicationTime;
(function(ReplicationTime2) {
  ReplicationTime2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ReplicationTime || (ReplicationTime = {}));
var Destination;
(function(Destination2) {
  Destination2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(Destination || (Destination = {}));
var ExistingObjectReplication;
(function(ExistingObjectReplication2) {
  ExistingObjectReplication2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ExistingObjectReplication || (ExistingObjectReplication = {}));
var ReplicationRuleAndOperator;
(function(ReplicationRuleAndOperator2) {
  ReplicationRuleAndOperator2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ReplicationRuleAndOperator || (ReplicationRuleAndOperator = {}));
var ReplicationRuleFilter;
(function(ReplicationRuleFilter2) {
  ReplicationRuleFilter2.visit = function(value, visitor) {
    if (value.Prefix !== void 0)
      return visitor.Prefix(value.Prefix);
    if (value.Tag !== void 0)
      return visitor.Tag(value.Tag);
    if (value.And !== void 0)
      return visitor.And(value.And);
    return visitor._(value.$unknown[0], value.$unknown[1]);
  };
  ReplicationRuleFilter2.filterSensitiveLog = function(obj) {
    var _a;
    if (obj.Prefix !== void 0)
      return { Prefix: obj.Prefix };
    if (obj.Tag !== void 0)
      return { Tag: Tag.filterSensitiveLog(obj.Tag) };
    if (obj.And !== void 0)
      return { And: ReplicationRuleAndOperator.filterSensitiveLog(obj.And) };
    if (obj.$unknown !== void 0)
      return _a = {}, _a[obj.$unknown[0]] = "UNKNOWN", _a;
  };
})(ReplicationRuleFilter || (ReplicationRuleFilter = {}));
var ReplicaModifications;
(function(ReplicaModifications2) {
  ReplicaModifications2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ReplicaModifications || (ReplicaModifications = {}));
var SseKmsEncryptedObjects;
(function(SseKmsEncryptedObjects2) {
  SseKmsEncryptedObjects2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(SseKmsEncryptedObjects || (SseKmsEncryptedObjects = {}));
var SourceSelectionCriteria;
(function(SourceSelectionCriteria2) {
  SourceSelectionCriteria2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(SourceSelectionCriteria || (SourceSelectionCriteria = {}));
var ReplicationRule;
(function(ReplicationRule2) {
  ReplicationRule2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.Filter && { Filter: ReplicationRuleFilter.filterSensitiveLog(obj.Filter) });
  };
})(ReplicationRule || (ReplicationRule = {}));
var ReplicationConfiguration;
(function(ReplicationConfiguration2) {
  ReplicationConfiguration2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.Rules && { Rules: obj.Rules.map(function(item) {
      return ReplicationRule.filterSensitiveLog(item);
    }) });
  };
})(ReplicationConfiguration || (ReplicationConfiguration = {}));
var GetBucketReplicationOutput;
(function(GetBucketReplicationOutput2) {
  GetBucketReplicationOutput2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.ReplicationConfiguration && {
      ReplicationConfiguration: ReplicationConfiguration.filterSensitiveLog(obj.ReplicationConfiguration)
    });
  };
})(GetBucketReplicationOutput || (GetBucketReplicationOutput = {}));
var GetBucketReplicationRequest;
(function(GetBucketReplicationRequest2) {
  GetBucketReplicationRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketReplicationRequest || (GetBucketReplicationRequest = {}));
var GetBucketRequestPaymentOutput;
(function(GetBucketRequestPaymentOutput2) {
  GetBucketRequestPaymentOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketRequestPaymentOutput || (GetBucketRequestPaymentOutput = {}));
var GetBucketRequestPaymentRequest;
(function(GetBucketRequestPaymentRequest2) {
  GetBucketRequestPaymentRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketRequestPaymentRequest || (GetBucketRequestPaymentRequest = {}));
var GetBucketTaggingOutput;
(function(GetBucketTaggingOutput2) {
  GetBucketTaggingOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketTaggingOutput || (GetBucketTaggingOutput = {}));
var GetBucketTaggingRequest;
(function(GetBucketTaggingRequest2) {
  GetBucketTaggingRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketTaggingRequest || (GetBucketTaggingRequest = {}));
var GetBucketVersioningOutput;
(function(GetBucketVersioningOutput2) {
  GetBucketVersioningOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketVersioningOutput || (GetBucketVersioningOutput = {}));
var GetBucketVersioningRequest;
(function(GetBucketVersioningRequest2) {
  GetBucketVersioningRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketVersioningRequest || (GetBucketVersioningRequest = {}));
var ErrorDocument;
(function(ErrorDocument2) {
  ErrorDocument2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ErrorDocument || (ErrorDocument = {}));
var IndexDocument;
(function(IndexDocument2) {
  IndexDocument2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(IndexDocument || (IndexDocument = {}));
var RedirectAllRequestsTo;
(function(RedirectAllRequestsTo2) {
  RedirectAllRequestsTo2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(RedirectAllRequestsTo || (RedirectAllRequestsTo = {}));
var Condition;
(function(Condition2) {
  Condition2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(Condition || (Condition = {}));
var Redirect;
(function(Redirect2) {
  Redirect2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(Redirect || (Redirect = {}));
var RoutingRule;
(function(RoutingRule2) {
  RoutingRule2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(RoutingRule || (RoutingRule = {}));
var GetBucketWebsiteOutput;
(function(GetBucketWebsiteOutput2) {
  GetBucketWebsiteOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketWebsiteOutput || (GetBucketWebsiteOutput = {}));
var GetBucketWebsiteRequest;
(function(GetBucketWebsiteRequest2) {
  GetBucketWebsiteRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetBucketWebsiteRequest || (GetBucketWebsiteRequest = {}));
var GetObjectOutput;
(function(GetObjectOutput2) {
  GetObjectOutput2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.SSEKMSKeyId && { SSEKMSKeyId: SENSITIVE_STRING });
  };
})(GetObjectOutput || (GetObjectOutput = {}));
var GetObjectRequest;
(function(GetObjectRequest2) {
  GetObjectRequest2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.SSECustomerKey && { SSECustomerKey: SENSITIVE_STRING });
  };
})(GetObjectRequest || (GetObjectRequest = {}));
var InvalidObjectState;
(function(InvalidObjectState2) {
  InvalidObjectState2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(InvalidObjectState || (InvalidObjectState = {}));
var NoSuchKey;
(function(NoSuchKey2) {
  NoSuchKey2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(NoSuchKey || (NoSuchKey = {}));
var GetObjectAclOutput;
(function(GetObjectAclOutput2) {
  GetObjectAclOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetObjectAclOutput || (GetObjectAclOutput = {}));
var GetObjectAclRequest;
(function(GetObjectAclRequest2) {
  GetObjectAclRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetObjectAclRequest || (GetObjectAclRequest = {}));
var ObjectLockLegalHold;
(function(ObjectLockLegalHold2) {
  ObjectLockLegalHold2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ObjectLockLegalHold || (ObjectLockLegalHold = {}));
var GetObjectLegalHoldOutput;
(function(GetObjectLegalHoldOutput2) {
  GetObjectLegalHoldOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetObjectLegalHoldOutput || (GetObjectLegalHoldOutput = {}));
var GetObjectLegalHoldRequest;
(function(GetObjectLegalHoldRequest2) {
  GetObjectLegalHoldRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetObjectLegalHoldRequest || (GetObjectLegalHoldRequest = {}));
var DefaultRetention;
(function(DefaultRetention2) {
  DefaultRetention2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(DefaultRetention || (DefaultRetention = {}));
var ObjectLockRule;
(function(ObjectLockRule2) {
  ObjectLockRule2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ObjectLockRule || (ObjectLockRule = {}));
var ObjectLockConfiguration;
(function(ObjectLockConfiguration2) {
  ObjectLockConfiguration2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ObjectLockConfiguration || (ObjectLockConfiguration = {}));
var GetObjectLockConfigurationOutput;
(function(GetObjectLockConfigurationOutput2) {
  GetObjectLockConfigurationOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetObjectLockConfigurationOutput || (GetObjectLockConfigurationOutput = {}));
var GetObjectLockConfigurationRequest;
(function(GetObjectLockConfigurationRequest2) {
  GetObjectLockConfigurationRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetObjectLockConfigurationRequest || (GetObjectLockConfigurationRequest = {}));
var ObjectLockRetention;
(function(ObjectLockRetention2) {
  ObjectLockRetention2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ObjectLockRetention || (ObjectLockRetention = {}));
var GetObjectRetentionOutput;
(function(GetObjectRetentionOutput2) {
  GetObjectRetentionOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetObjectRetentionOutput || (GetObjectRetentionOutput = {}));
var GetObjectRetentionRequest;
(function(GetObjectRetentionRequest2) {
  GetObjectRetentionRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetObjectRetentionRequest || (GetObjectRetentionRequest = {}));
var GetObjectTaggingOutput;
(function(GetObjectTaggingOutput2) {
  GetObjectTaggingOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetObjectTaggingOutput || (GetObjectTaggingOutput = {}));
var GetObjectTaggingRequest;
(function(GetObjectTaggingRequest2) {
  GetObjectTaggingRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetObjectTaggingRequest || (GetObjectTaggingRequest = {}));
var GetObjectTorrentOutput;
(function(GetObjectTorrentOutput2) {
  GetObjectTorrentOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetObjectTorrentOutput || (GetObjectTorrentOutput = {}));
var GetObjectTorrentRequest;
(function(GetObjectTorrentRequest2) {
  GetObjectTorrentRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetObjectTorrentRequest || (GetObjectTorrentRequest = {}));
var PublicAccessBlockConfiguration;
(function(PublicAccessBlockConfiguration2) {
  PublicAccessBlockConfiguration2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(PublicAccessBlockConfiguration || (PublicAccessBlockConfiguration = {}));
var GetPublicAccessBlockOutput;
(function(GetPublicAccessBlockOutput2) {
  GetPublicAccessBlockOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetPublicAccessBlockOutput || (GetPublicAccessBlockOutput = {}));
var GetPublicAccessBlockRequest;
(function(GetPublicAccessBlockRequest2) {
  GetPublicAccessBlockRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GetPublicAccessBlockRequest || (GetPublicAccessBlockRequest = {}));
var HeadBucketRequest;
(function(HeadBucketRequest2) {
  HeadBucketRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(HeadBucketRequest || (HeadBucketRequest = {}));
var NoSuchBucket;
(function(NoSuchBucket2) {
  NoSuchBucket2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(NoSuchBucket || (NoSuchBucket = {}));
var HeadObjectOutput;
(function(HeadObjectOutput2) {
  HeadObjectOutput2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.SSEKMSKeyId && { SSEKMSKeyId: SENSITIVE_STRING });
  };
})(HeadObjectOutput || (HeadObjectOutput = {}));
var HeadObjectRequest;
(function(HeadObjectRequest2) {
  HeadObjectRequest2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.SSECustomerKey && { SSECustomerKey: SENSITIVE_STRING });
  };
})(HeadObjectRequest || (HeadObjectRequest = {}));
var ListBucketAnalyticsConfigurationsOutput;
(function(ListBucketAnalyticsConfigurationsOutput2) {
  ListBucketAnalyticsConfigurationsOutput2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.AnalyticsConfigurationList && {
      AnalyticsConfigurationList: obj.AnalyticsConfigurationList.map(function(item) {
        return AnalyticsConfiguration.filterSensitiveLog(item);
      })
    });
  };
})(ListBucketAnalyticsConfigurationsOutput || (ListBucketAnalyticsConfigurationsOutput = {}));
var ListBucketAnalyticsConfigurationsRequest;
(function(ListBucketAnalyticsConfigurationsRequest2) {
  ListBucketAnalyticsConfigurationsRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ListBucketAnalyticsConfigurationsRequest || (ListBucketAnalyticsConfigurationsRequest = {}));
var ListBucketIntelligentTieringConfigurationsOutput;
(function(ListBucketIntelligentTieringConfigurationsOutput2) {
  ListBucketIntelligentTieringConfigurationsOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ListBucketIntelligentTieringConfigurationsOutput || (ListBucketIntelligentTieringConfigurationsOutput = {}));
var ListBucketIntelligentTieringConfigurationsRequest;
(function(ListBucketIntelligentTieringConfigurationsRequest2) {
  ListBucketIntelligentTieringConfigurationsRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ListBucketIntelligentTieringConfigurationsRequest || (ListBucketIntelligentTieringConfigurationsRequest = {}));
var ListBucketInventoryConfigurationsOutput;
(function(ListBucketInventoryConfigurationsOutput2) {
  ListBucketInventoryConfigurationsOutput2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.InventoryConfigurationList && {
      InventoryConfigurationList: obj.InventoryConfigurationList.map(function(item) {
        return InventoryConfiguration.filterSensitiveLog(item);
      })
    });
  };
})(ListBucketInventoryConfigurationsOutput || (ListBucketInventoryConfigurationsOutput = {}));
var ListBucketInventoryConfigurationsRequest;
(function(ListBucketInventoryConfigurationsRequest2) {
  ListBucketInventoryConfigurationsRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ListBucketInventoryConfigurationsRequest || (ListBucketInventoryConfigurationsRequest = {}));
var ListBucketMetricsConfigurationsOutput;
(function(ListBucketMetricsConfigurationsOutput2) {
  ListBucketMetricsConfigurationsOutput2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.MetricsConfigurationList && {
      MetricsConfigurationList: obj.MetricsConfigurationList.map(function(item) {
        return MetricsConfiguration.filterSensitiveLog(item);
      })
    });
  };
})(ListBucketMetricsConfigurationsOutput || (ListBucketMetricsConfigurationsOutput = {}));
var ListBucketMetricsConfigurationsRequest;
(function(ListBucketMetricsConfigurationsRequest2) {
  ListBucketMetricsConfigurationsRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ListBucketMetricsConfigurationsRequest || (ListBucketMetricsConfigurationsRequest = {}));
var Bucket;
(function(Bucket2) {
  Bucket2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(Bucket || (Bucket = {}));
var ListBucketsOutput;
(function(ListBucketsOutput2) {
  ListBucketsOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ListBucketsOutput || (ListBucketsOutput = {}));
var CommonPrefix;
(function(CommonPrefix2) {
  CommonPrefix2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(CommonPrefix || (CommonPrefix = {}));
var Initiator;
(function(Initiator2) {
  Initiator2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(Initiator || (Initiator = {}));
var MultipartUpload;
(function(MultipartUpload2) {
  MultipartUpload2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(MultipartUpload || (MultipartUpload = {}));
var ListMultipartUploadsOutput;
(function(ListMultipartUploadsOutput2) {
  ListMultipartUploadsOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ListMultipartUploadsOutput || (ListMultipartUploadsOutput = {}));
var ListMultipartUploadsRequest;
(function(ListMultipartUploadsRequest2) {
  ListMultipartUploadsRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ListMultipartUploadsRequest || (ListMultipartUploadsRequest = {}));
var _Object;
(function(_Object2) {
  _Object2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(_Object || (_Object = {}));
var ListObjectsOutput;
(function(ListObjectsOutput2) {
  ListObjectsOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ListObjectsOutput || (ListObjectsOutput = {}));
var ListObjectsRequest;
(function(ListObjectsRequest2) {
  ListObjectsRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ListObjectsRequest || (ListObjectsRequest = {}));
var ListObjectsV2Output;
(function(ListObjectsV2Output2) {
  ListObjectsV2Output2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ListObjectsV2Output || (ListObjectsV2Output = {}));
var ListObjectsV2Request;
(function(ListObjectsV2Request2) {
  ListObjectsV2Request2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ListObjectsV2Request || (ListObjectsV2Request = {}));
var DeleteMarkerEntry;
(function(DeleteMarkerEntry2) {
  DeleteMarkerEntry2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(DeleteMarkerEntry || (DeleteMarkerEntry = {}));
var ObjectVersion;
(function(ObjectVersion2) {
  ObjectVersion2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ObjectVersion || (ObjectVersion = {}));
var ListObjectVersionsOutput;
(function(ListObjectVersionsOutput2) {
  ListObjectVersionsOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ListObjectVersionsOutput || (ListObjectVersionsOutput = {}));
var ListObjectVersionsRequest;
(function(ListObjectVersionsRequest2) {
  ListObjectVersionsRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ListObjectVersionsRequest || (ListObjectVersionsRequest = {}));
var Part;
(function(Part2) {
  Part2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(Part || (Part = {}));
var ListPartsOutput;
(function(ListPartsOutput2) {
  ListPartsOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ListPartsOutput || (ListPartsOutput = {}));
var ListPartsRequest;
(function(ListPartsRequest2) {
  ListPartsRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ListPartsRequest || (ListPartsRequest = {}));
var PutBucketAccelerateConfigurationRequest;
(function(PutBucketAccelerateConfigurationRequest2) {
  PutBucketAccelerateConfigurationRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(PutBucketAccelerateConfigurationRequest || (PutBucketAccelerateConfigurationRequest = {}));
var PutBucketAclRequest;
(function(PutBucketAclRequest2) {
  PutBucketAclRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(PutBucketAclRequest || (PutBucketAclRequest = {}));
var PutBucketAnalyticsConfigurationRequest;
(function(PutBucketAnalyticsConfigurationRequest2) {
  PutBucketAnalyticsConfigurationRequest2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.AnalyticsConfiguration && {
      AnalyticsConfiguration: AnalyticsConfiguration.filterSensitiveLog(obj.AnalyticsConfiguration)
    });
  };
})(PutBucketAnalyticsConfigurationRequest || (PutBucketAnalyticsConfigurationRequest = {}));
var CORSConfiguration;
(function(CORSConfiguration2) {
  CORSConfiguration2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(CORSConfiguration || (CORSConfiguration = {}));
var PutBucketCorsRequest;
(function(PutBucketCorsRequest2) {
  PutBucketCorsRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(PutBucketCorsRequest || (PutBucketCorsRequest = {}));
var PutBucketEncryptionRequest;
(function(PutBucketEncryptionRequest2) {
  PutBucketEncryptionRequest2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.ServerSideEncryptionConfiguration && {
      ServerSideEncryptionConfiguration: ServerSideEncryptionConfiguration.filterSensitiveLog(obj.ServerSideEncryptionConfiguration)
    });
  };
})(PutBucketEncryptionRequest || (PutBucketEncryptionRequest = {}));
var PutBucketIntelligentTieringConfigurationRequest;
(function(PutBucketIntelligentTieringConfigurationRequest2) {
  PutBucketIntelligentTieringConfigurationRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(PutBucketIntelligentTieringConfigurationRequest || (PutBucketIntelligentTieringConfigurationRequest = {}));
var PutBucketInventoryConfigurationRequest;
(function(PutBucketInventoryConfigurationRequest2) {
  PutBucketInventoryConfigurationRequest2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.InventoryConfiguration && {
      InventoryConfiguration: InventoryConfiguration.filterSensitiveLog(obj.InventoryConfiguration)
    });
  };
})(PutBucketInventoryConfigurationRequest || (PutBucketInventoryConfigurationRequest = {}));
var BucketLifecycleConfiguration;
(function(BucketLifecycleConfiguration2) {
  BucketLifecycleConfiguration2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.Rules && { Rules: obj.Rules.map(function(item) {
      return LifecycleRule.filterSensitiveLog(item);
    }) });
  };
})(BucketLifecycleConfiguration || (BucketLifecycleConfiguration = {}));
var PutBucketLifecycleConfigurationRequest;
(function(PutBucketLifecycleConfigurationRequest2) {
  PutBucketLifecycleConfigurationRequest2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.LifecycleConfiguration && {
      LifecycleConfiguration: BucketLifecycleConfiguration.filterSensitiveLog(obj.LifecycleConfiguration)
    });
  };
})(PutBucketLifecycleConfigurationRequest || (PutBucketLifecycleConfigurationRequest = {}));
var BucketLoggingStatus;
(function(BucketLoggingStatus2) {
  BucketLoggingStatus2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(BucketLoggingStatus || (BucketLoggingStatus = {}));
var PutBucketLoggingRequest;
(function(PutBucketLoggingRequest2) {
  PutBucketLoggingRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(PutBucketLoggingRequest || (PutBucketLoggingRequest = {}));
var PutBucketMetricsConfigurationRequest;
(function(PutBucketMetricsConfigurationRequest2) {
  PutBucketMetricsConfigurationRequest2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.MetricsConfiguration && {
      MetricsConfiguration: MetricsConfiguration.filterSensitiveLog(obj.MetricsConfiguration)
    });
  };
})(PutBucketMetricsConfigurationRequest || (PutBucketMetricsConfigurationRequest = {}));
var PutBucketNotificationConfigurationRequest;
(function(PutBucketNotificationConfigurationRequest2) {
  PutBucketNotificationConfigurationRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(PutBucketNotificationConfigurationRequest || (PutBucketNotificationConfigurationRequest = {}));
var PutBucketOwnershipControlsRequest;
(function(PutBucketOwnershipControlsRequest2) {
  PutBucketOwnershipControlsRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(PutBucketOwnershipControlsRequest || (PutBucketOwnershipControlsRequest = {}));
var PutBucketPolicyRequest;
(function(PutBucketPolicyRequest2) {
  PutBucketPolicyRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(PutBucketPolicyRequest || (PutBucketPolicyRequest = {}));
var PutBucketReplicationRequest;
(function(PutBucketReplicationRequest2) {
  PutBucketReplicationRequest2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.ReplicationConfiguration && {
      ReplicationConfiguration: ReplicationConfiguration.filterSensitiveLog(obj.ReplicationConfiguration)
    });
  };
})(PutBucketReplicationRequest || (PutBucketReplicationRequest = {}));
var RequestPaymentConfiguration;
(function(RequestPaymentConfiguration2) {
  RequestPaymentConfiguration2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(RequestPaymentConfiguration || (RequestPaymentConfiguration = {}));
var PutBucketRequestPaymentRequest;
(function(PutBucketRequestPaymentRequest2) {
  PutBucketRequestPaymentRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(PutBucketRequestPaymentRequest || (PutBucketRequestPaymentRequest = {}));
var Tagging;
(function(Tagging2) {
  Tagging2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(Tagging || (Tagging = {}));
var PutBucketTaggingRequest;
(function(PutBucketTaggingRequest2) {
  PutBucketTaggingRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(PutBucketTaggingRequest || (PutBucketTaggingRequest = {}));
var VersioningConfiguration;
(function(VersioningConfiguration2) {
  VersioningConfiguration2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(VersioningConfiguration || (VersioningConfiguration = {}));
var PutBucketVersioningRequest;
(function(PutBucketVersioningRequest2) {
  PutBucketVersioningRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(PutBucketVersioningRequest || (PutBucketVersioningRequest = {}));
var WebsiteConfiguration;
(function(WebsiteConfiguration2) {
  WebsiteConfiguration2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(WebsiteConfiguration || (WebsiteConfiguration = {}));
var PutBucketWebsiteRequest;
(function(PutBucketWebsiteRequest2) {
  PutBucketWebsiteRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(PutBucketWebsiteRequest || (PutBucketWebsiteRequest = {}));
var PutObjectOutput;
(function(PutObjectOutput2) {
  PutObjectOutput2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4(__assign$4({}, obj), obj.SSEKMSKeyId && { SSEKMSKeyId: SENSITIVE_STRING }), obj.SSEKMSEncryptionContext && { SSEKMSEncryptionContext: SENSITIVE_STRING });
  };
})(PutObjectOutput || (PutObjectOutput = {}));
var PutObjectRequest;
(function(PutObjectRequest2) {
  PutObjectRequest2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4(__assign$4(__assign$4({}, obj), obj.SSECustomerKey && { SSECustomerKey: SENSITIVE_STRING }), obj.SSEKMSKeyId && { SSEKMSKeyId: SENSITIVE_STRING }), obj.SSEKMSEncryptionContext && { SSEKMSEncryptionContext: SENSITIVE_STRING });
  };
})(PutObjectRequest || (PutObjectRequest = {}));
var PutObjectAclOutput;
(function(PutObjectAclOutput2) {
  PutObjectAclOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(PutObjectAclOutput || (PutObjectAclOutput = {}));
var PutObjectAclRequest;
(function(PutObjectAclRequest2) {
  PutObjectAclRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(PutObjectAclRequest || (PutObjectAclRequest = {}));
var PutObjectLegalHoldOutput;
(function(PutObjectLegalHoldOutput2) {
  PutObjectLegalHoldOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(PutObjectLegalHoldOutput || (PutObjectLegalHoldOutput = {}));
var PutObjectLegalHoldRequest;
(function(PutObjectLegalHoldRequest2) {
  PutObjectLegalHoldRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(PutObjectLegalHoldRequest || (PutObjectLegalHoldRequest = {}));
var PutObjectLockConfigurationOutput;
(function(PutObjectLockConfigurationOutput2) {
  PutObjectLockConfigurationOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(PutObjectLockConfigurationOutput || (PutObjectLockConfigurationOutput = {}));
var PutObjectLockConfigurationRequest;
(function(PutObjectLockConfigurationRequest2) {
  PutObjectLockConfigurationRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(PutObjectLockConfigurationRequest || (PutObjectLockConfigurationRequest = {}));
var PutObjectRetentionOutput;
(function(PutObjectRetentionOutput2) {
  PutObjectRetentionOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(PutObjectRetentionOutput || (PutObjectRetentionOutput = {}));
var PutObjectRetentionRequest;
(function(PutObjectRetentionRequest2) {
  PutObjectRetentionRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(PutObjectRetentionRequest || (PutObjectRetentionRequest = {}));
var PutObjectTaggingOutput;
(function(PutObjectTaggingOutput2) {
  PutObjectTaggingOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(PutObjectTaggingOutput || (PutObjectTaggingOutput = {}));
var PutObjectTaggingRequest;
(function(PutObjectTaggingRequest2) {
  PutObjectTaggingRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(PutObjectTaggingRequest || (PutObjectTaggingRequest = {}));
var PutPublicAccessBlockRequest;
(function(PutPublicAccessBlockRequest2) {
  PutPublicAccessBlockRequest2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(PutPublicAccessBlockRequest || (PutPublicAccessBlockRequest = {}));
var ObjectAlreadyInActiveTierError;
(function(ObjectAlreadyInActiveTierError2) {
  ObjectAlreadyInActiveTierError2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ObjectAlreadyInActiveTierError || (ObjectAlreadyInActiveTierError = {}));
var RestoreObjectOutput;
(function(RestoreObjectOutput2) {
  RestoreObjectOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(RestoreObjectOutput || (RestoreObjectOutput = {}));
var GlacierJobParameters;
(function(GlacierJobParameters2) {
  GlacierJobParameters2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(GlacierJobParameters || (GlacierJobParameters = {}));
var Encryption;
(function(Encryption2) {
  Encryption2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.KMSKeyId && { KMSKeyId: SENSITIVE_STRING });
  };
})(Encryption || (Encryption = {}));
function escapeAttribute(value) {
  return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
var XmlNode = function() {
  function XmlNode2(name2, children) {
    if (children === void 0) {
      children = [];
    }
    this.name = name2;
    this.children = children;
    this.attributes = {};
  }
  XmlNode2.prototype.withName = function(name2) {
    this.name = name2;
    return this;
  };
  XmlNode2.prototype.addAttribute = function(name2, value) {
    this.attributes[name2] = value;
    return this;
  };
  XmlNode2.prototype.addChildNode = function(child) {
    this.children.push(child);
    return this;
  };
  XmlNode2.prototype.removeAttribute = function(name2) {
    delete this.attributes[name2];
    return this;
  };
  XmlNode2.prototype.toString = function() {
    var e_1, _a;
    var hasChildren = Boolean(this.children.length);
    var xmlText = "<" + this.name;
    var attributes = this.attributes;
    try {
      for (var _b = tslib.exports.__values(Object.keys(attributes)), _c = _b.next(); !_c.done; _c = _b.next()) {
        var attributeName = _c.value;
        var attribute = attributes[attributeName];
        if (typeof attribute !== "undefined" && attribute !== null) {
          xmlText += " " + attributeName + '="' + escapeAttribute("" + attribute) + '"';
        }
      }
    } catch (e_1_1) {
      e_1 = { error: e_1_1 };
    } finally {
      try {
        if (_c && !_c.done && (_a = _b.return))
          _a.call(_b);
      } finally {
        if (e_1)
          throw e_1.error;
      }
    }
    return xmlText += !hasChildren ? "/>" : ">" + this.children.map(function(c) {
      return c.toString();
    }).join("") + "</" + this.name + ">";
  };
  return XmlNode2;
}();
function escapeElement(value) {
  return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
var XmlText = function() {
  function XmlText2(value) {
    this.value = value;
  }
  XmlText2.prototype.toString = function() {
    return escapeElement("" + this.value);
  };
  return XmlText2;
}();
var parser = {};
var node2json = {};
var util$4 = {};
(function(exports) {
  const nameStartChar = ":A-Za-z_\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD";
  const nameChar = nameStartChar + "\\-.\\d\\u00B7\\u0300-\\u036F\\u203F-\\u2040";
  const nameRegexp = "[" + nameStartChar + "][" + nameChar + "]*";
  const regexName = new RegExp("^" + nameRegexp + "$");
  const getAllMatches = function(string, regex) {
    const matches = [];
    let match = regex.exec(string);
    while (match) {
      const allmatches = [];
      const len = match.length;
      for (let index = 0; index < len; index++) {
        allmatches.push(match[index]);
      }
      matches.push(allmatches);
      match = regex.exec(string);
    }
    return matches;
  };
  const isName = function(string) {
    const match = regexName.exec(string);
    return !(match === null || typeof match === "undefined");
  };
  exports.isExist = function(v) {
    return typeof v !== "undefined";
  };
  exports.isEmptyObject = function(obj) {
    return Object.keys(obj).length === 0;
  };
  exports.merge = function(target, a, arrayMode) {
    if (a) {
      const keys = Object.keys(a);
      const len = keys.length;
      for (let i = 0; i < len; i++) {
        if (arrayMode === "strict") {
          target[keys[i]] = [a[keys[i]]];
        } else {
          target[keys[i]] = a[keys[i]];
        }
      }
    }
  };
  exports.getValue = function(v) {
    if (exports.isExist(v)) {
      return v;
    } else {
      return "";
    }
  };
  exports.buildOptions = function(options, defaultOptions2, props2) {
    var newOptions = {};
    if (!options) {
      return defaultOptions2;
    }
    for (let i = 0; i < props2.length; i++) {
      if (options[props2[i]] !== void 0) {
        newOptions[props2[i]] = options[props2[i]];
      } else {
        newOptions[props2[i]] = defaultOptions2[props2[i]];
      }
    }
    return newOptions;
  };
  exports.isTagNameInArrayMode = function(tagName, arrayMode, parentTagName) {
    if (arrayMode === false) {
      return false;
    } else if (arrayMode instanceof RegExp) {
      return arrayMode.test(tagName);
    } else if (typeof arrayMode === "function") {
      return !!arrayMode(tagName, parentTagName);
    }
    return arrayMode === "strict";
  };
  exports.isName = isName;
  exports.getAllMatches = getAllMatches;
  exports.nameRegexp = nameRegexp;
})(util$4);
const util$3 = util$4;
const convertToJson = function(node, options, parentTagName) {
  const jObj = {};
  if ((!node.child || util$3.isEmptyObject(node.child)) && (!node.attrsMap || util$3.isEmptyObject(node.attrsMap))) {
    return util$3.isExist(node.val) ? node.val : "";
  }
  if (util$3.isExist(node.val) && !(typeof node.val === "string" && (node.val === "" || node.val === options.cdataPositionChar))) {
    const asArray = util$3.isTagNameInArrayMode(node.tagname, options.arrayMode, parentTagName);
    jObj[options.textNodeName] = asArray ? [node.val] : node.val;
  }
  util$3.merge(jObj, node.attrsMap, options.arrayMode);
  const keys = Object.keys(node.child);
  for (let index = 0; index < keys.length; index++) {
    const tagName = keys[index];
    if (node.child[tagName] && node.child[tagName].length > 1) {
      jObj[tagName] = [];
      for (let tag in node.child[tagName]) {
        if (node.child[tagName].hasOwnProperty(tag)) {
          jObj[tagName].push(convertToJson(node.child[tagName][tag], options, tagName));
        }
      }
    } else {
      const result = convertToJson(node.child[tagName][0], options, tagName);
      const asArray = options.arrayMode === true && typeof result === "object" || util$3.isTagNameInArrayMode(tagName, options.arrayMode, parentTagName);
      jObj[tagName] = asArray ? [result] : result;
    }
  }
  return jObj;
};
node2json.convertToJson = convertToJson;
var xmlstr2xmlnode = {};
var xmlNode$1 = function(tagname, parent, val) {
  this.tagname = tagname;
  this.parent = parent;
  this.child = {};
  this.attrsMap = {};
  this.val = val;
  this.addChild = function(child) {
    if (Array.isArray(this.child[child.tagname])) {
      this.child[child.tagname].push(child);
    } else {
      this.child[child.tagname] = [child];
    }
  };
};
const hexRegex = /0x[a-zA-Z0-9]+/;
const numRegex = /^([\-\+])?(0*)(\.[0-9]+(e\-?[0-9]+)?|[0-9]+(\.[0-9]+(e\-?[0-9]+)?)?)$/;
const consider = {
  hex: true,
  leadingZeros: true,
  decimalPoint: "."
};
function toNumber$1(str, options = {}) {
  options = Object.assign({}, consider, options);
  if (!str || typeof str !== "string")
    return str;
  let trimmedStr = str.trim();
  if (options.skipLike !== void 0 && options.skipLike.test(trimmedStr))
    return str;
  else if (options.hex && hexRegex.test(trimmedStr)) {
    return Number.parseInt(trimmedStr, 16);
  } else {
    const match = numRegex.exec(trimmedStr);
    if (match) {
      match[1];
      const leadingZeros = match[2];
      const num = match[3];
      match[4] || match[6];
      if (leadingZeros.length === 1 && num[0] === ".")
        return Number(str);
      else if (!options.leadingZeros && leadingZeros.length > 0)
        return str;
      else
        return Number(trimmedStr);
    } else {
      return str;
    }
  }
}
var strnum = toNumber$1;
const util$2 = util$4;
const buildOptions$3 = util$4.buildOptions;
const xmlNode = xmlNode$1;
const toNumber = strnum;
"<((!\\[CDATA\\[([\\s\\S]*?)(]]>))|((NAME:)?(NAME))([^>]*)>|((\\/)(NAME)\\s*>))([^<]*)".replace(/NAME/g, util$2.nameRegexp);
if (!Number.parseInt && window.parseInt) {
  Number.parseInt = window.parseInt;
}
if (!Number.parseFloat && window.parseFloat) {
  Number.parseFloat = window.parseFloat;
}
const defaultOptions$2 = {
  attributeNamePrefix: "@_",
  attrNodeName: false,
  textNodeName: "#text",
  ignoreAttributes: true,
  ignoreNameSpace: false,
  allowBooleanAttributes: false,
  parseNodeValue: true,
  parseAttributeValue: false,
  arrayMode: false,
  trimValues: true,
  cdataTagName: false,
  cdataPositionChar: "\\c",
  numParseOptions: {
    hex: true,
    leadingZeros: true
  },
  tagValueProcessor: function(a, tagName) {
    return a;
  },
  attrValueProcessor: function(a, attrName) {
    return a;
  },
  stopNodes: []
};
xmlstr2xmlnode.defaultOptions = defaultOptions$2;
const props$2 = [
  "attributeNamePrefix",
  "attrNodeName",
  "textNodeName",
  "ignoreAttributes",
  "ignoreNameSpace",
  "allowBooleanAttributes",
  "parseNodeValue",
  "parseAttributeValue",
  "arrayMode",
  "trimValues",
  "cdataTagName",
  "cdataPositionChar",
  "tagValueProcessor",
  "attrValueProcessor",
  "parseTrueNumberOnly",
  "numParseOptions",
  "stopNodes"
];
xmlstr2xmlnode.props = props$2;
function processTagValue(tagName, val, options) {
  if (val) {
    if (options.trimValues) {
      val = val.trim();
    }
    val = options.tagValueProcessor(val, tagName);
    val = parseValue(val, options.parseNodeValue, options.numParseOptions);
  }
  return val;
}
function resolveNameSpace(tagname, options) {
  if (options.ignoreNameSpace) {
    const tags = tagname.split(":");
    const prefix = tagname.charAt(0) === "/" ? "/" : "";
    if (tags[0] === "xmlns") {
      return "";
    }
    if (tags.length === 2) {
      tagname = prefix + tags[1];
    }
  }
  return tagname;
}
function parseValue(val, shouldParse, options) {
  if (shouldParse && typeof val === "string") {
    const newval = val.trim();
    if (newval === "true")
      return true;
    else if (newval === "false")
      return false;
    else
      return toNumber(val, options);
  } else {
    if (util$2.isExist(val)) {
      return val;
    } else {
      return "";
    }
  }
}
const attrsRegx = new RegExp(`([^\\s=]+)\\s*(=\\s*(['"])(.*?)\\3)?`, "g");
function buildAttributesMap(attrStr, options) {
  if (!options.ignoreAttributes && typeof attrStr === "string") {
    attrStr = attrStr.replace(/\r?\n/g, " ");
    const matches = util$2.getAllMatches(attrStr, attrsRegx);
    const len = matches.length;
    const attrs = {};
    for (let i = 0; i < len; i++) {
      const attrName = resolveNameSpace(matches[i][1], options);
      if (attrName.length) {
        if (matches[i][4] !== void 0) {
          if (options.trimValues) {
            matches[i][4] = matches[i][4].trim();
          }
          matches[i][4] = options.attrValueProcessor(matches[i][4], attrName);
          attrs[options.attributeNamePrefix + attrName] = parseValue(
            matches[i][4],
            options.parseAttributeValue,
            options.numParseOptions
          );
        } else if (options.allowBooleanAttributes) {
          attrs[options.attributeNamePrefix + attrName] = true;
        }
      }
    }
    if (!Object.keys(attrs).length) {
      return;
    }
    if (options.attrNodeName) {
      const attrCollection = {};
      attrCollection[options.attrNodeName] = attrs;
      return attrCollection;
    }
    return attrs;
  }
}
const getTraversalObj = function(xmlData, options) {
  xmlData = xmlData.replace(/\r\n?/g, "\n");
  options = buildOptions$3(options, defaultOptions$2, props$2);
  const xmlObj = new xmlNode("!xml");
  let currentNode = xmlObj;
  let textData = "";
  for (let i = 0; i < xmlData.length; i++) {
    const ch = xmlData[i];
    if (ch === "<") {
      if (xmlData[i + 1] === "/") {
        const closeIndex = findClosingIndex(xmlData, ">", i, "Closing Tag is not closed.");
        let tagName = xmlData.substring(i + 2, closeIndex).trim();
        if (options.ignoreNameSpace) {
          const colonIndex = tagName.indexOf(":");
          if (colonIndex !== -1) {
            tagName = tagName.substr(colonIndex + 1);
          }
        }
        if (currentNode) {
          if (currentNode.val) {
            currentNode.val = util$2.getValue(currentNode.val) + "" + processTagValue(tagName, textData, options);
          } else {
            currentNode.val = processTagValue(tagName, textData, options);
          }
        }
        if (options.stopNodes.length && options.stopNodes.includes(currentNode.tagname)) {
          currentNode.child = [];
          if (currentNode.attrsMap == void 0) {
            currentNode.attrsMap = {};
          }
          currentNode.val = xmlData.substr(currentNode.startIndex + 1, i - currentNode.startIndex - 1);
        }
        currentNode = currentNode.parent;
        textData = "";
        i = closeIndex;
      } else if (xmlData[i + 1] === "?") {
        i = findClosingIndex(xmlData, "?>", i, "Pi Tag is not closed.");
      } else if (xmlData.substr(i + 1, 3) === "!--") {
        i = findClosingIndex(xmlData, "-->", i, "Comment is not closed.");
      } else if (xmlData.substr(i + 1, 2) === "!D") {
        const closeIndex = findClosingIndex(xmlData, ">", i, "DOCTYPE is not closed.");
        const tagExp = xmlData.substring(i, closeIndex);
        if (tagExp.indexOf("[") >= 0) {
          i = xmlData.indexOf("]>", i) + 1;
        } else {
          i = closeIndex;
        }
      } else if (xmlData.substr(i + 1, 2) === "![") {
        const closeIndex = findClosingIndex(xmlData, "]]>", i, "CDATA is not closed.") - 2;
        const tagExp = xmlData.substring(i + 9, closeIndex);
        if (textData) {
          currentNode.val = util$2.getValue(currentNode.val) + "" + processTagValue(currentNode.tagname, textData, options);
          textData = "";
        }
        if (options.cdataTagName) {
          const childNode = new xmlNode(options.cdataTagName, currentNode, tagExp);
          currentNode.addChild(childNode);
          currentNode.val = util$2.getValue(currentNode.val) + options.cdataPositionChar;
          if (tagExp) {
            childNode.val = tagExp;
          }
        } else {
          currentNode.val = (currentNode.val || "") + (tagExp || "");
        }
        i = closeIndex + 2;
      } else {
        const result = closingIndexForOpeningTag(xmlData, i + 1);
        let tagExp = result.data;
        const closeIndex = result.index;
        const separatorIndex = tagExp.indexOf(" ");
        let tagName = tagExp;
        let shouldBuildAttributesMap = true;
        if (separatorIndex !== -1) {
          tagName = tagExp.substr(0, separatorIndex).replace(/\s\s*$/, "");
          tagExp = tagExp.substr(separatorIndex + 1);
        }
        if (options.ignoreNameSpace) {
          const colonIndex = tagName.indexOf(":");
          if (colonIndex !== -1) {
            tagName = tagName.substr(colonIndex + 1);
            shouldBuildAttributesMap = tagName !== result.data.substr(colonIndex + 1);
          }
        }
        if (currentNode && textData) {
          if (currentNode.tagname !== "!xml") {
            currentNode.val = util$2.getValue(currentNode.val) + "" + processTagValue(currentNode.tagname, textData, options);
          }
        }
        if (tagExp.length > 0 && tagExp.lastIndexOf("/") === tagExp.length - 1) {
          if (tagName[tagName.length - 1] === "/") {
            tagName = tagName.substr(0, tagName.length - 1);
            tagExp = tagName;
          } else {
            tagExp = tagExp.substr(0, tagExp.length - 1);
          }
          const childNode = new xmlNode(tagName, currentNode, "");
          if (tagName !== tagExp) {
            childNode.attrsMap = buildAttributesMap(tagExp, options);
          }
          currentNode.addChild(childNode);
        } else {
          const childNode = new xmlNode(tagName, currentNode);
          if (options.stopNodes.length && options.stopNodes.includes(childNode.tagname)) {
            childNode.startIndex = closeIndex;
          }
          if (tagName !== tagExp && shouldBuildAttributesMap) {
            childNode.attrsMap = buildAttributesMap(tagExp, options);
          }
          currentNode.addChild(childNode);
          currentNode = childNode;
        }
        textData = "";
        i = closeIndex;
      }
    } else {
      textData += xmlData[i];
    }
  }
  return xmlObj;
};
function closingIndexForOpeningTag(data, i) {
  let attrBoundary;
  let tagExp = "";
  for (let index = i; index < data.length; index++) {
    let ch = data[index];
    if (attrBoundary) {
      if (ch === attrBoundary)
        attrBoundary = "";
    } else if (ch === '"' || ch === "'") {
      attrBoundary = ch;
    } else if (ch === ">") {
      return {
        data: tagExp,
        index
      };
    } else if (ch === "	") {
      ch = " ";
    }
    tagExp += ch;
  }
}
function findClosingIndex(xmlData, str, i, errMsg) {
  const closingIndex = xmlData.indexOf(str, i);
  if (closingIndex === -1) {
    throw new Error(errMsg);
  } else {
    return closingIndex + str.length - 1;
  }
}
xmlstr2xmlnode.getTraversalObj = getTraversalObj;
var validator = {};
const util$1 = util$4;
const defaultOptions$1 = {
  allowBooleanAttributes: false
};
const props$1 = ["allowBooleanAttributes"];
validator.validate = function(xmlData, options) {
  options = util$1.buildOptions(options, defaultOptions$1, props$1);
  const tags = [];
  let tagFound = false;
  let reachedRoot = false;
  if (xmlData[0] === "\uFEFF") {
    xmlData = xmlData.substr(1);
  }
  for (let i = 0; i < xmlData.length; i++) {
    if (xmlData[i] === "<" && xmlData[i + 1] === "?") {
      i += 2;
      i = readPI(xmlData, i);
      if (i.err)
        return i;
    } else if (xmlData[i] === "<") {
      i++;
      if (xmlData[i] === "!") {
        i = readCommentAndCDATA(xmlData, i);
        continue;
      } else {
        let closingTag = false;
        if (xmlData[i] === "/") {
          closingTag = true;
          i++;
        }
        let tagName = "";
        for (; i < xmlData.length && xmlData[i] !== ">" && xmlData[i] !== " " && xmlData[i] !== "	" && xmlData[i] !== "\n" && xmlData[i] !== "\r"; i++) {
          tagName += xmlData[i];
        }
        tagName = tagName.trim();
        if (tagName[tagName.length - 1] === "/") {
          tagName = tagName.substring(0, tagName.length - 1);
          i--;
        }
        if (!validateTagName(tagName)) {
          let msg;
          if (tagName.trim().length === 0) {
            msg = "There is an unnecessary space between tag name and backward slash '</ ..'.";
          } else {
            msg = "Tag '" + tagName + "' is an invalid name.";
          }
          return getErrorObject("InvalidTag", msg, getLineNumberForPosition(xmlData, i));
        }
        const result = readAttributeStr(xmlData, i);
        if (result === false) {
          return getErrorObject("InvalidAttr", "Attributes for '" + tagName + "' have open quote.", getLineNumberForPosition(xmlData, i));
        }
        let attrStr = result.value;
        i = result.index;
        if (attrStr[attrStr.length - 1] === "/") {
          attrStr = attrStr.substring(0, attrStr.length - 1);
          const isValid = validateAttributeString(attrStr, options);
          if (isValid === true) {
            tagFound = true;
          } else {
            return getErrorObject(isValid.err.code, isValid.err.msg, getLineNumberForPosition(xmlData, i - attrStr.length + isValid.err.line));
          }
        } else if (closingTag) {
          if (!result.tagClosed) {
            return getErrorObject("InvalidTag", "Closing tag '" + tagName + "' doesn't have proper closing.", getLineNumberForPosition(xmlData, i));
          } else if (attrStr.trim().length > 0) {
            return getErrorObject("InvalidTag", "Closing tag '" + tagName + "' can't have attributes or invalid starting.", getLineNumberForPosition(xmlData, i));
          } else {
            const otg = tags.pop();
            if (tagName !== otg) {
              return getErrorObject("InvalidTag", "Closing tag '" + otg + "' is expected inplace of '" + tagName + "'.", getLineNumberForPosition(xmlData, i));
            }
            if (tags.length == 0) {
              reachedRoot = true;
            }
          }
        } else {
          const isValid = validateAttributeString(attrStr, options);
          if (isValid !== true) {
            return getErrorObject(isValid.err.code, isValid.err.msg, getLineNumberForPosition(xmlData, i - attrStr.length + isValid.err.line));
          }
          if (reachedRoot === true) {
            return getErrorObject("InvalidXml", "Multiple possible root nodes found.", getLineNumberForPosition(xmlData, i));
          } else {
            tags.push(tagName);
          }
          tagFound = true;
        }
        for (i++; i < xmlData.length; i++) {
          if (xmlData[i] === "<") {
            if (xmlData[i + 1] === "!") {
              i++;
              i = readCommentAndCDATA(xmlData, i);
              continue;
            } else if (xmlData[i + 1] === "?") {
              i = readPI(xmlData, ++i);
              if (i.err)
                return i;
            } else {
              break;
            }
          } else if (xmlData[i] === "&") {
            const afterAmp = validateAmpersand(xmlData, i);
            if (afterAmp == -1)
              return getErrorObject("InvalidChar", "char '&' is not expected.", getLineNumberForPosition(xmlData, i));
            i = afterAmp;
          }
        }
        if (xmlData[i] === "<") {
          i--;
        }
      }
    } else {
      if (xmlData[i] === " " || xmlData[i] === "	" || xmlData[i] === "\n" || xmlData[i] === "\r") {
        continue;
      }
      return getErrorObject("InvalidChar", "char '" + xmlData[i] + "' is not expected.", getLineNumberForPosition(xmlData, i));
    }
  }
  if (!tagFound) {
    return getErrorObject("InvalidXml", "Start tag expected.", 1);
  } else if (tags.length > 0) {
    return getErrorObject("InvalidXml", "Invalid '" + JSON.stringify(tags, null, 4).replace(/\r?\n/g, "") + "' found.", 1);
  }
  return true;
};
function readPI(xmlData, i) {
  var start = i;
  for (; i < xmlData.length; i++) {
    if (xmlData[i] == "?" || xmlData[i] == " ") {
      var tagname = xmlData.substr(start, i - start);
      if (i > 5 && tagname === "xml") {
        return getErrorObject("InvalidXml", "XML declaration allowed only at the start of the document.", getLineNumberForPosition(xmlData, i));
      } else if (xmlData[i] == "?" && xmlData[i + 1] == ">") {
        i++;
        break;
      } else {
        continue;
      }
    }
  }
  return i;
}
function readCommentAndCDATA(xmlData, i) {
  if (xmlData.length > i + 5 && xmlData[i + 1] === "-" && xmlData[i + 2] === "-") {
    for (i += 3; i < xmlData.length; i++) {
      if (xmlData[i] === "-" && xmlData[i + 1] === "-" && xmlData[i + 2] === ">") {
        i += 2;
        break;
      }
    }
  } else if (xmlData.length > i + 8 && xmlData[i + 1] === "D" && xmlData[i + 2] === "O" && xmlData[i + 3] === "C" && xmlData[i + 4] === "T" && xmlData[i + 5] === "Y" && xmlData[i + 6] === "P" && xmlData[i + 7] === "E") {
    let angleBracketsCount = 1;
    for (i += 8; i < xmlData.length; i++) {
      if (xmlData[i] === "<") {
        angleBracketsCount++;
      } else if (xmlData[i] === ">") {
        angleBracketsCount--;
        if (angleBracketsCount === 0) {
          break;
        }
      }
    }
  } else if (xmlData.length > i + 9 && xmlData[i + 1] === "[" && xmlData[i + 2] === "C" && xmlData[i + 3] === "D" && xmlData[i + 4] === "A" && xmlData[i + 5] === "T" && xmlData[i + 6] === "A" && xmlData[i + 7] === "[") {
    for (i += 8; i < xmlData.length; i++) {
      if (xmlData[i] === "]" && xmlData[i + 1] === "]" && xmlData[i + 2] === ">") {
        i += 2;
        break;
      }
    }
  }
  return i;
}
var doubleQuote = '"';
var singleQuote = "'";
function readAttributeStr(xmlData, i) {
  let attrStr = "";
  let startChar = "";
  let tagClosed = false;
  for (; i < xmlData.length; i++) {
    if (xmlData[i] === doubleQuote || xmlData[i] === singleQuote) {
      if (startChar === "") {
        startChar = xmlData[i];
      } else if (startChar !== xmlData[i]) {
        continue;
      } else {
        startChar = "";
      }
    } else if (xmlData[i] === ">") {
      if (startChar === "") {
        tagClosed = true;
        break;
      }
    }
    attrStr += xmlData[i];
  }
  if (startChar !== "") {
    return false;
  }
  return {
    value: attrStr,
    index: i,
    tagClosed
  };
}
const validAttrStrRegxp = new RegExp(`(\\s*)([^\\s=]+)(\\s*=)?(\\s*(['"])(([\\s\\S])*?)\\5)?`, "g");
function validateAttributeString(attrStr, options) {
  const matches = util$1.getAllMatches(attrStr, validAttrStrRegxp);
  const attrNames = {};
  for (let i = 0; i < matches.length; i++) {
    if (matches[i][1].length === 0) {
      return getErrorObject("InvalidAttr", "Attribute '" + matches[i][2] + "' has no space in starting.", getPositionFromMatch(attrStr, matches[i][0]));
    } else if (matches[i][3] === void 0 && !options.allowBooleanAttributes) {
      return getErrorObject("InvalidAttr", "boolean attribute '" + matches[i][2] + "' is not allowed.", getPositionFromMatch(attrStr, matches[i][0]));
    }
    const attrName = matches[i][2];
    if (!validateAttrName(attrName)) {
      return getErrorObject("InvalidAttr", "Attribute '" + attrName + "' is an invalid name.", getPositionFromMatch(attrStr, matches[i][0]));
    }
    if (!attrNames.hasOwnProperty(attrName)) {
      attrNames[attrName] = 1;
    } else {
      return getErrorObject("InvalidAttr", "Attribute '" + attrName + "' is repeated.", getPositionFromMatch(attrStr, matches[i][0]));
    }
  }
  return true;
}
function validateNumberAmpersand(xmlData, i) {
  let re = /\d/;
  if (xmlData[i] === "x") {
    i++;
    re = /[\da-fA-F]/;
  }
  for (; i < xmlData.length; i++) {
    if (xmlData[i] === ";")
      return i;
    if (!xmlData[i].match(re))
      break;
  }
  return -1;
}
function validateAmpersand(xmlData, i) {
  i++;
  if (xmlData[i] === ";")
    return -1;
  if (xmlData[i] === "#") {
    i++;
    return validateNumberAmpersand(xmlData, i);
  }
  let count = 0;
  for (; i < xmlData.length; i++, count++) {
    if (xmlData[i].match(/\w/) && count < 20)
      continue;
    if (xmlData[i] === ";")
      break;
    return -1;
  }
  return i;
}
function getErrorObject(code, message, lineNumber) {
  return {
    err: {
      code,
      msg: message,
      line: lineNumber
    }
  };
}
function validateAttrName(attrName) {
  return util$1.isName(attrName);
}
function validateTagName(tagname) {
  return util$1.isName(tagname);
}
function getLineNumberForPosition(xmlData, index) {
  var lines = xmlData.substring(0, index).split(/\r?\n/);
  return lines.length;
}
function getPositionFromMatch(attrStr, match) {
  return attrStr.indexOf(match) + match.length;
}
var nimndata = {};
const char = function(a) {
  return String.fromCharCode(a);
};
const chars = {
  nilChar: char(176),
  missingChar: char(201),
  nilPremitive: char(175),
  missingPremitive: char(200),
  emptyChar: char(178),
  emptyValue: char(177),
  boundryChar: char(179),
  objStart: char(198),
  arrStart: char(204),
  arrayEnd: char(185)
};
const charsArr = [
  chars.nilChar,
  chars.nilPremitive,
  chars.missingChar,
  chars.missingPremitive,
  chars.boundryChar,
  chars.emptyChar,
  chars.emptyValue,
  chars.arrayEnd,
  chars.objStart,
  chars.arrStart
];
const _e = function(node, e_schema, options) {
  if (typeof e_schema === "string") {
    if (node && node[0] && node[0].val !== void 0) {
      return getValue(node[0].val);
    } else {
      return getValue(node);
    }
  } else {
    const hasValidData = hasData(node);
    if (hasValidData === true) {
      let str = "";
      if (Array.isArray(e_schema)) {
        str += chars.arrStart;
        const itemSchema = e_schema[0];
        const arr_len = node.length;
        if (typeof itemSchema === "string") {
          for (let arr_i = 0; arr_i < arr_len; arr_i++) {
            const r = getValue(node[arr_i].val);
            str = processValue(str, r);
          }
        } else {
          for (let arr_i = 0; arr_i < arr_len; arr_i++) {
            const r = _e(node[arr_i], itemSchema, options);
            str = processValue(str, r);
          }
        }
        str += chars.arrayEnd;
      } else {
        str += chars.objStart;
        const keys = Object.keys(e_schema);
        if (Array.isArray(node)) {
          node = node[0];
        }
        for (let i in keys) {
          const key = keys[i];
          let r;
          if (!options.ignoreAttributes && node.attrsMap && node.attrsMap[key]) {
            r = _e(node.attrsMap[key], e_schema[key], options);
          } else if (key === options.textNodeName) {
            r = _e(node.val, e_schema[key], options);
          } else {
            r = _e(node.child[key], e_schema[key], options);
          }
          str = processValue(str, r);
        }
      }
      return str;
    } else {
      return hasValidData;
    }
  }
};
const getValue = function(a) {
  switch (a) {
    case void 0:
      return chars.missingPremitive;
    case null:
      return chars.nilPremitive;
    case "":
      return chars.emptyValue;
    default:
      return a;
  }
};
const processValue = function(str, r) {
  if (!isAppChar(r[0]) && !isAppChar(str[str.length - 1])) {
    str += chars.boundryChar;
  }
  return str + r;
};
const isAppChar = function(ch) {
  return charsArr.indexOf(ch) !== -1;
};
function hasData(jObj) {
  if (jObj === void 0) {
    return chars.missingChar;
  } else if (jObj === null) {
    return chars.nilChar;
  } else if (jObj.child && Object.keys(jObj.child).length === 0 && (!jObj.attrsMap || Object.keys(jObj.attrsMap).length === 0)) {
    return chars.emptyChar;
  } else {
    return true;
  }
}
const x2j$1 = xmlstr2xmlnode;
const buildOptions$2 = util$4.buildOptions;
const convert2nimn = function(node, e_schema, options) {
  options = buildOptions$2(options, x2j$1.defaultOptions, x2j$1.props);
  return _e(node, e_schema, options);
};
nimndata.convert2nimn = convert2nimn;
var node2json_str = {};
const util = util$4;
const buildOptions$1 = util$4.buildOptions;
const x2j = xmlstr2xmlnode;
const convertToJsonString = function(node, options) {
  options = buildOptions$1(options, x2j.defaultOptions, x2j.props);
  options.indentBy = options.indentBy || "";
  return _cToJsonStr(node, options);
};
const _cToJsonStr = function(node, options, level) {
  let jObj = "{";
  const keys = Object.keys(node.child);
  for (let index = 0; index < keys.length; index++) {
    var tagname = keys[index];
    if (node.child[tagname] && node.child[tagname].length > 1) {
      jObj += '"' + tagname + '" : [ ';
      for (var tag in node.child[tagname]) {
        jObj += _cToJsonStr(node.child[tagname][tag], options) + " , ";
      }
      jObj = jObj.substr(0, jObj.length - 1) + " ] ";
    } else {
      jObj += '"' + tagname + '" : ' + _cToJsonStr(node.child[tagname][0], options) + " ,";
    }
  }
  util.merge(jObj, node.attrsMap);
  if (util.isEmptyObject(jObj)) {
    return util.isExist(node.val) ? node.val : "";
  } else {
    if (util.isExist(node.val)) {
      if (!(typeof node.val === "string" && (node.val === "" || node.val === options.cdataPositionChar))) {
        jObj += '"' + options.textNodeName + '" : ' + stringval(node.val);
      }
    }
  }
  if (jObj[jObj.length - 1] === ",") {
    jObj = jObj.substr(0, jObj.length - 2);
  }
  return jObj + "}";
};
function stringval(v) {
  if (v === true || v === false || !isNaN(v)) {
    return v;
  } else {
    return '"' + v + '"';
  }
}
node2json_str.convertToJsonString = convertToJsonString;
const buildOptions = util$4.buildOptions;
const defaultOptions = {
  attributeNamePrefix: "@_",
  attrNodeName: false,
  textNodeName: "#text",
  ignoreAttributes: true,
  cdataTagName: false,
  cdataPositionChar: "\\c",
  format: false,
  indentBy: "  ",
  supressEmptyNode: false,
  tagValueProcessor: function(a) {
    return a;
  },
  attrValueProcessor: function(a) {
    return a;
  }
};
const props = [
  "attributeNamePrefix",
  "attrNodeName",
  "textNodeName",
  "ignoreAttributes",
  "cdataTagName",
  "cdataPositionChar",
  "format",
  "indentBy",
  "supressEmptyNode",
  "tagValueProcessor",
  "attrValueProcessor"
];
function Parser(options) {
  this.options = buildOptions(options, defaultOptions, props);
  if (this.options.ignoreAttributes || this.options.attrNodeName) {
    this.isAttribute = function() {
      return false;
    };
  } else {
    this.attrPrefixLen = this.options.attributeNamePrefix.length;
    this.isAttribute = isAttribute;
  }
  if (this.options.cdataTagName) {
    this.isCDATA = isCDATA;
  } else {
    this.isCDATA = function() {
      return false;
    };
  }
  this.replaceCDATAstr = replaceCDATAstr;
  this.replaceCDATAarr = replaceCDATAarr;
  if (this.options.format) {
    this.indentate = indentate;
    this.tagEndChar = ">\n";
    this.newLine = "\n";
  } else {
    this.indentate = function() {
      return "";
    };
    this.tagEndChar = ">";
    this.newLine = "";
  }
  if (this.options.supressEmptyNode) {
    this.buildTextNode = buildEmptyTextNode;
    this.buildObjNode = buildEmptyObjNode;
  } else {
    this.buildTextNode = buildTextValNode;
    this.buildObjNode = buildObjectNode;
  }
  this.buildTextValNode = buildTextValNode;
  this.buildObjectNode = buildObjectNode;
}
Parser.prototype.parse = function(jObj) {
  return this.j2x(jObj, 0).val;
};
Parser.prototype.j2x = function(jObj, level) {
  let attrStr = "";
  let val = "";
  const keys = Object.keys(jObj);
  const len = keys.length;
  for (let i = 0; i < len; i++) {
    const key = keys[i];
    if (typeof jObj[key] === "undefined")
      ;
    else if (jObj[key] === null) {
      val += this.indentate(level) + "<" + key + "/" + this.tagEndChar;
    } else if (jObj[key] instanceof Date) {
      val += this.buildTextNode(jObj[key], key, "", level);
    } else if (typeof jObj[key] !== "object") {
      const attr = this.isAttribute(key);
      if (attr) {
        attrStr += " " + attr + '="' + this.options.attrValueProcessor("" + jObj[key]) + '"';
      } else if (this.isCDATA(key)) {
        if (jObj[this.options.textNodeName]) {
          val += this.replaceCDATAstr(jObj[this.options.textNodeName], jObj[key]);
        } else {
          val += this.replaceCDATAstr("", jObj[key]);
        }
      } else {
        if (key === this.options.textNodeName) {
          if (jObj[this.options.cdataTagName])
            ;
          else {
            val += this.options.tagValueProcessor("" + jObj[key]);
          }
        } else {
          val += this.buildTextNode(jObj[key], key, "", level);
        }
      }
    } else if (Array.isArray(jObj[key])) {
      if (this.isCDATA(key)) {
        val += this.indentate(level);
        if (jObj[this.options.textNodeName]) {
          val += this.replaceCDATAarr(jObj[this.options.textNodeName], jObj[key]);
        } else {
          val += this.replaceCDATAarr("", jObj[key]);
        }
      } else {
        const arrLen = jObj[key].length;
        for (let j = 0; j < arrLen; j++) {
          const item = jObj[key][j];
          if (typeof item === "undefined")
            ;
          else if (item === null) {
            val += this.indentate(level) + "<" + key + "/" + this.tagEndChar;
          } else if (typeof item === "object") {
            const result = this.j2x(item, level + 1);
            val += this.buildObjNode(result.val, key, result.attrStr, level);
          } else {
            val += this.buildTextNode(item, key, "", level);
          }
        }
      }
    } else {
      if (this.options.attrNodeName && key === this.options.attrNodeName) {
        const Ks = Object.keys(jObj[key]);
        const L = Ks.length;
        for (let j = 0; j < L; j++) {
          attrStr += " " + Ks[j] + '="' + this.options.attrValueProcessor("" + jObj[key][Ks[j]]) + '"';
        }
      } else {
        const result = this.j2x(jObj[key], level + 1);
        val += this.buildObjNode(result.val, key, result.attrStr, level);
      }
    }
  }
  return { attrStr, val };
};
function replaceCDATAstr(str, cdata) {
  str = this.options.tagValueProcessor("" + str);
  if (this.options.cdataPositionChar === "" || str === "") {
    return str + "<![CDATA[" + cdata + "]]" + this.tagEndChar;
  } else {
    return str.replace(this.options.cdataPositionChar, "<![CDATA[" + cdata + "]]" + this.tagEndChar);
  }
}
function replaceCDATAarr(str, cdata) {
  str = this.options.tagValueProcessor("" + str);
  if (this.options.cdataPositionChar === "" || str === "") {
    return str + "<![CDATA[" + cdata.join("]]><![CDATA[") + "]]" + this.tagEndChar;
  } else {
    for (let v in cdata) {
      str = str.replace(this.options.cdataPositionChar, "<![CDATA[" + cdata[v] + "]]>");
    }
    return str + this.newLine;
  }
}
function buildObjectNode(val, key, attrStr, level) {
  if (attrStr && !val.includes("<")) {
    return this.indentate(level) + "<" + key + attrStr + ">" + val + "</" + key + this.tagEndChar;
  } else {
    return this.indentate(level) + "<" + key + attrStr + this.tagEndChar + val + this.indentate(level) + "</" + key + this.tagEndChar;
  }
}
function buildEmptyObjNode(val, key, attrStr, level) {
  if (val !== "") {
    return this.buildObjectNode(val, key, attrStr, level);
  } else {
    return this.indentate(level) + "<" + key + attrStr + "/" + this.tagEndChar;
  }
}
function buildTextValNode(val, key, attrStr, level) {
  return this.indentate(level) + "<" + key + attrStr + ">" + this.options.tagValueProcessor(val) + "</" + key + this.tagEndChar;
}
function buildEmptyTextNode(val, key, attrStr, level) {
  if (val !== "") {
    return this.buildTextValNode(val, key, attrStr, level);
  } else {
    return this.indentate(level) + "<" + key + attrStr + "/" + this.tagEndChar;
  }
}
function indentate(level) {
  return this.options.indentBy.repeat(level);
}
function isAttribute(name2) {
  if (name2.startsWith(this.options.attributeNamePrefix)) {
    return name2.substr(this.attrPrefixLen);
  } else {
    return false;
  }
}
function isCDATA(name2) {
  return name2 === this.options.cdataTagName;
}
var json2xml = Parser;
(function(exports) {
  const nodeToJson = node2json;
  const xmlToNodeobj = xmlstr2xmlnode;
  const x2xmlnode = xmlstr2xmlnode;
  const buildOptions2 = util$4.buildOptions;
  const validator$1 = validator;
  exports.parse = function(xmlData, givenOptions = {}, validationOption) {
    if (validationOption) {
      if (validationOption === true)
        validationOption = {};
      const result = validator$1.validate(xmlData, validationOption);
      if (result !== true) {
        throw Error(result.err.msg);
      }
    }
    if (givenOptions.parseTrueNumberOnly && givenOptions.parseNodeValue !== false && !givenOptions.numParseOptions) {
      givenOptions.numParseOptions = {
        leadingZeros: false
      };
    }
    let options = buildOptions2(givenOptions, x2xmlnode.defaultOptions, x2xmlnode.props);
    const traversableObj = xmlToNodeobj.getTraversalObj(xmlData, options);
    return nodeToJson.convertToJson(traversableObj, options);
  };
  exports.convertTonimn = nimndata.convert2nimn;
  exports.getTraversalObj = xmlToNodeobj.getTraversalObj;
  exports.convertToJson = nodeToJson.convertToJson;
  exports.convertToJsonString = node2json_str.convertToJsonString;
  exports.validate = validator$1.validate;
  exports.j2xParser = json2xml;
  exports.parseToNimn = function(xmlData, schema, options) {
    return exports.convertTonimn(exports.getTraversalObj(xmlData, options), schema, options);
  };
})(parser);
var serializeAws_restXmlAbortMultipartUploadCommand = function(input, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var headers, resolvedPath, labelValue, labelValue, query, body, _a, hostname, _b, protocol, port;
    return __generator$3(this, function(_c) {
      switch (_c.label) {
        case 0:
          headers = __assign$4(__assign$4({}, isSerializableHeaderValue(input.RequestPayer) && { "x-amz-request-payer": input.RequestPayer }), isSerializableHeaderValue(input.ExpectedBucketOwner) && {
            "x-amz-expected-bucket-owner": input.ExpectedBucketOwner
          });
          resolvedPath = "/{Bucket}/{Key+}";
          if (input.Bucket !== void 0) {
            labelValue = input.Bucket;
            if (labelValue.length <= 0) {
              throw new Error("Empty value provided for input HTTP label: Bucket.");
            }
            resolvedPath = resolvedPath.replace("{Bucket}", extendedEncodeURIComponent(labelValue));
          } else {
            throw new Error("No value provided for input HTTP label: Bucket.");
          }
          if (input.Key !== void 0) {
            labelValue = input.Key;
            if (labelValue.length <= 0) {
              throw new Error("Empty value provided for input HTTP label: Key.");
            }
            resolvedPath = resolvedPath.replace("{Key+}", labelValue.split("/").map(function(segment) {
              return extendedEncodeURIComponent(segment);
            }).join("/"));
          } else {
            throw new Error("No value provided for input HTTP label: Key.");
          }
          query = __assign$4({ "x-id": "AbortMultipartUpload" }, input.UploadId !== void 0 && { uploadId: input.UploadId });
          return [4, context.endpoint()];
        case 1:
          _a = _c.sent(), hostname = _a.hostname, _b = _a.protocol, protocol = _b === void 0 ? "https" : _b, port = _a.port;
          return [2, new HttpRequest({
            protocol,
            hostname,
            port,
            method: "DELETE",
            headers,
            path: resolvedPath,
            query,
            body
          })];
      }
    });
  });
};
var serializeAws_restXmlCompleteMultipartUploadCommand = function(input, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var headers, resolvedPath, labelValue, labelValue, query, body, contents, _a, hostname, _b, protocol, port;
    return __generator$3(this, function(_c) {
      switch (_c.label) {
        case 0:
          headers = __assign$4(__assign$4({ "content-type": "application/xml" }, isSerializableHeaderValue(input.RequestPayer) && { "x-amz-request-payer": input.RequestPayer }), isSerializableHeaderValue(input.ExpectedBucketOwner) && {
            "x-amz-expected-bucket-owner": input.ExpectedBucketOwner
          });
          resolvedPath = "/{Bucket}/{Key+}";
          if (input.Bucket !== void 0) {
            labelValue = input.Bucket;
            if (labelValue.length <= 0) {
              throw new Error("Empty value provided for input HTTP label: Bucket.");
            }
            resolvedPath = resolvedPath.replace("{Bucket}", extendedEncodeURIComponent(labelValue));
          } else {
            throw new Error("No value provided for input HTTP label: Bucket.");
          }
          if (input.Key !== void 0) {
            labelValue = input.Key;
            if (labelValue.length <= 0) {
              throw new Error("Empty value provided for input HTTP label: Key.");
            }
            resolvedPath = resolvedPath.replace("{Key+}", labelValue.split("/").map(function(segment) {
              return extendedEncodeURIComponent(segment);
            }).join("/"));
          } else {
            throw new Error("No value provided for input HTTP label: Key.");
          }
          query = __assign$4({}, input.UploadId !== void 0 && { uploadId: input.UploadId });
          if (input.MultipartUpload !== void 0) {
            contents = serializeAws_restXmlCompletedMultipartUpload(input.MultipartUpload);
            body = '<?xml version="1.0" encoding="UTF-8"?>';
            contents.addAttribute("xmlns", "http://s3.amazonaws.com/doc/2006-03-01/");
            body += contents.toString();
          }
          return [4, context.endpoint()];
        case 1:
          _a = _c.sent(), hostname = _a.hostname, _b = _a.protocol, protocol = _b === void 0 ? "https" : _b, port = _a.port;
          return [2, new HttpRequest({
            protocol,
            hostname,
            port,
            method: "POST",
            headers,
            path: resolvedPath,
            query,
            body
          })];
      }
    });
  });
};
var serializeAws_restXmlCopyObjectCommand = function(input, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var headers, resolvedPath, labelValue, labelValue, query, body, _a, hostname, _b, protocol, port;
    return __generator$3(this, function(_c) {
      switch (_c.label) {
        case 0:
          headers = __assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4({}, isSerializableHeaderValue(input.ACL) && { "x-amz-acl": input.ACL }), isSerializableHeaderValue(input.CacheControl) && { "cache-control": input.CacheControl }), isSerializableHeaderValue(input.ContentDisposition) && { "content-disposition": input.ContentDisposition }), isSerializableHeaderValue(input.ContentEncoding) && { "content-encoding": input.ContentEncoding }), isSerializableHeaderValue(input.ContentLanguage) && { "content-language": input.ContentLanguage }), isSerializableHeaderValue(input.ContentType) && { "content-type": input.ContentType }), isSerializableHeaderValue(input.CopySource) && { "x-amz-copy-source": input.CopySource }), isSerializableHeaderValue(input.CopySourceIfMatch) && {
            "x-amz-copy-source-if-match": input.CopySourceIfMatch
          }), isSerializableHeaderValue(input.CopySourceIfModifiedSince) && {
            "x-amz-copy-source-if-modified-since": dateToUtcString(input.CopySourceIfModifiedSince).toString()
          }), isSerializableHeaderValue(input.CopySourceIfNoneMatch) && {
            "x-amz-copy-source-if-none-match": input.CopySourceIfNoneMatch
          }), isSerializableHeaderValue(input.CopySourceIfUnmodifiedSince) && {
            "x-amz-copy-source-if-unmodified-since": dateToUtcString(input.CopySourceIfUnmodifiedSince).toString()
          }), isSerializableHeaderValue(input.Expires) && { expires: dateToUtcString(input.Expires).toString() }), isSerializableHeaderValue(input.GrantFullControl) && { "x-amz-grant-full-control": input.GrantFullControl }), isSerializableHeaderValue(input.GrantRead) && { "x-amz-grant-read": input.GrantRead }), isSerializableHeaderValue(input.GrantReadACP) && { "x-amz-grant-read-acp": input.GrantReadACP }), isSerializableHeaderValue(input.GrantWriteACP) && { "x-amz-grant-write-acp": input.GrantWriteACP }), isSerializableHeaderValue(input.MetadataDirective) && { "x-amz-metadata-directive": input.MetadataDirective }), isSerializableHeaderValue(input.TaggingDirective) && { "x-amz-tagging-directive": input.TaggingDirective }), isSerializableHeaderValue(input.ServerSideEncryption) && {
            "x-amz-server-side-encryption": input.ServerSideEncryption
          }), isSerializableHeaderValue(input.StorageClass) && { "x-amz-storage-class": input.StorageClass }), isSerializableHeaderValue(input.WebsiteRedirectLocation) && {
            "x-amz-website-redirect-location": input.WebsiteRedirectLocation
          }), isSerializableHeaderValue(input.SSECustomerAlgorithm) && {
            "x-amz-server-side-encryption-customer-algorithm": input.SSECustomerAlgorithm
          }), isSerializableHeaderValue(input.SSECustomerKey) && {
            "x-amz-server-side-encryption-customer-key": input.SSECustomerKey
          }), isSerializableHeaderValue(input.SSECustomerKeyMD5) && {
            "x-amz-server-side-encryption-customer-key-md5": input.SSECustomerKeyMD5
          }), isSerializableHeaderValue(input.SSEKMSKeyId) && {
            "x-amz-server-side-encryption-aws-kms-key-id": input.SSEKMSKeyId
          }), isSerializableHeaderValue(input.SSEKMSEncryptionContext) && {
            "x-amz-server-side-encryption-context": input.SSEKMSEncryptionContext
          }), isSerializableHeaderValue(input.BucketKeyEnabled) && {
            "x-amz-server-side-encryption-bucket-key-enabled": input.BucketKeyEnabled.toString()
          }), isSerializableHeaderValue(input.CopySourceSSECustomerAlgorithm) && {
            "x-amz-copy-source-server-side-encryption-customer-algorithm": input.CopySourceSSECustomerAlgorithm
          }), isSerializableHeaderValue(input.CopySourceSSECustomerKey) && {
            "x-amz-copy-source-server-side-encryption-customer-key": input.CopySourceSSECustomerKey
          }), isSerializableHeaderValue(input.CopySourceSSECustomerKeyMD5) && {
            "x-amz-copy-source-server-side-encryption-customer-key-md5": input.CopySourceSSECustomerKeyMD5
          }), isSerializableHeaderValue(input.RequestPayer) && { "x-amz-request-payer": input.RequestPayer }), isSerializableHeaderValue(input.Tagging) && { "x-amz-tagging": input.Tagging }), isSerializableHeaderValue(input.ObjectLockMode) && { "x-amz-object-lock-mode": input.ObjectLockMode }), isSerializableHeaderValue(input.ObjectLockRetainUntilDate) && {
            "x-amz-object-lock-retain-until-date": (input.ObjectLockRetainUntilDate.toISOString().split(".")[0] + "Z").toString()
          }), isSerializableHeaderValue(input.ObjectLockLegalHoldStatus) && {
            "x-amz-object-lock-legal-hold": input.ObjectLockLegalHoldStatus
          }), isSerializableHeaderValue(input.ExpectedBucketOwner) && {
            "x-amz-expected-bucket-owner": input.ExpectedBucketOwner
          }), isSerializableHeaderValue(input.ExpectedSourceBucketOwner) && {
            "x-amz-source-expected-bucket-owner": input.ExpectedSourceBucketOwner
          }), input.Metadata !== void 0 && Object.keys(input.Metadata).reduce(function(acc, suffix) {
            var _a2;
            return __assign$4(__assign$4({}, acc), (_a2 = {}, _a2["x-amz-meta-" + suffix.toLowerCase()] = input.Metadata[suffix], _a2));
          }, {}));
          resolvedPath = "/{Bucket}/{Key+}";
          if (input.Bucket !== void 0) {
            labelValue = input.Bucket;
            if (labelValue.length <= 0) {
              throw new Error("Empty value provided for input HTTP label: Bucket.");
            }
            resolvedPath = resolvedPath.replace("{Bucket}", extendedEncodeURIComponent(labelValue));
          } else {
            throw new Error("No value provided for input HTTP label: Bucket.");
          }
          if (input.Key !== void 0) {
            labelValue = input.Key;
            if (labelValue.length <= 0) {
              throw new Error("Empty value provided for input HTTP label: Key.");
            }
            resolvedPath = resolvedPath.replace("{Key+}", labelValue.split("/").map(function(segment) {
              return extendedEncodeURIComponent(segment);
            }).join("/"));
          } else {
            throw new Error("No value provided for input HTTP label: Key.");
          }
          query = {
            "x-id": "CopyObject"
          };
          return [4, context.endpoint()];
        case 1:
          _a = _c.sent(), hostname = _a.hostname, _b = _a.protocol, protocol = _b === void 0 ? "https" : _b, port = _a.port;
          return [2, new HttpRequest({
            protocol,
            hostname,
            port,
            method: "PUT",
            headers,
            path: resolvedPath,
            query,
            body
          })];
      }
    });
  });
};
var serializeAws_restXmlCreateMultipartUploadCommand = function(input, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var headers, resolvedPath, labelValue, labelValue, query, body, _a, hostname, _b, protocol, port;
    return __generator$3(this, function(_c) {
      switch (_c.label) {
        case 0:
          headers = __assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4({}, isSerializableHeaderValue(input.ACL) && { "x-amz-acl": input.ACL }), isSerializableHeaderValue(input.CacheControl) && { "cache-control": input.CacheControl }), isSerializableHeaderValue(input.ContentDisposition) && { "content-disposition": input.ContentDisposition }), isSerializableHeaderValue(input.ContentEncoding) && { "content-encoding": input.ContentEncoding }), isSerializableHeaderValue(input.ContentLanguage) && { "content-language": input.ContentLanguage }), isSerializableHeaderValue(input.ContentType) && { "content-type": input.ContentType }), isSerializableHeaderValue(input.Expires) && { expires: dateToUtcString(input.Expires).toString() }), isSerializableHeaderValue(input.GrantFullControl) && { "x-amz-grant-full-control": input.GrantFullControl }), isSerializableHeaderValue(input.GrantRead) && { "x-amz-grant-read": input.GrantRead }), isSerializableHeaderValue(input.GrantReadACP) && { "x-amz-grant-read-acp": input.GrantReadACP }), isSerializableHeaderValue(input.GrantWriteACP) && { "x-amz-grant-write-acp": input.GrantWriteACP }), isSerializableHeaderValue(input.ServerSideEncryption) && {
            "x-amz-server-side-encryption": input.ServerSideEncryption
          }), isSerializableHeaderValue(input.StorageClass) && { "x-amz-storage-class": input.StorageClass }), isSerializableHeaderValue(input.WebsiteRedirectLocation) && {
            "x-amz-website-redirect-location": input.WebsiteRedirectLocation
          }), isSerializableHeaderValue(input.SSECustomerAlgorithm) && {
            "x-amz-server-side-encryption-customer-algorithm": input.SSECustomerAlgorithm
          }), isSerializableHeaderValue(input.SSECustomerKey) && {
            "x-amz-server-side-encryption-customer-key": input.SSECustomerKey
          }), isSerializableHeaderValue(input.SSECustomerKeyMD5) && {
            "x-amz-server-side-encryption-customer-key-md5": input.SSECustomerKeyMD5
          }), isSerializableHeaderValue(input.SSEKMSKeyId) && {
            "x-amz-server-side-encryption-aws-kms-key-id": input.SSEKMSKeyId
          }), isSerializableHeaderValue(input.SSEKMSEncryptionContext) && {
            "x-amz-server-side-encryption-context": input.SSEKMSEncryptionContext
          }), isSerializableHeaderValue(input.BucketKeyEnabled) && {
            "x-amz-server-side-encryption-bucket-key-enabled": input.BucketKeyEnabled.toString()
          }), isSerializableHeaderValue(input.RequestPayer) && { "x-amz-request-payer": input.RequestPayer }), isSerializableHeaderValue(input.Tagging) && { "x-amz-tagging": input.Tagging }), isSerializableHeaderValue(input.ObjectLockMode) && { "x-amz-object-lock-mode": input.ObjectLockMode }), isSerializableHeaderValue(input.ObjectLockRetainUntilDate) && {
            "x-amz-object-lock-retain-until-date": (input.ObjectLockRetainUntilDate.toISOString().split(".")[0] + "Z").toString()
          }), isSerializableHeaderValue(input.ObjectLockLegalHoldStatus) && {
            "x-amz-object-lock-legal-hold": input.ObjectLockLegalHoldStatus
          }), isSerializableHeaderValue(input.ExpectedBucketOwner) && {
            "x-amz-expected-bucket-owner": input.ExpectedBucketOwner
          }), input.Metadata !== void 0 && Object.keys(input.Metadata).reduce(function(acc, suffix) {
            var _a2;
            return __assign$4(__assign$4({}, acc), (_a2 = {}, _a2["x-amz-meta-" + suffix.toLowerCase()] = input.Metadata[suffix], _a2));
          }, {}));
          resolvedPath = "/{Bucket}/{Key+}";
          if (input.Bucket !== void 0) {
            labelValue = input.Bucket;
            if (labelValue.length <= 0) {
              throw new Error("Empty value provided for input HTTP label: Bucket.");
            }
            resolvedPath = resolvedPath.replace("{Bucket}", extendedEncodeURIComponent(labelValue));
          } else {
            throw new Error("No value provided for input HTTP label: Bucket.");
          }
          if (input.Key !== void 0) {
            labelValue = input.Key;
            if (labelValue.length <= 0) {
              throw new Error("Empty value provided for input HTTP label: Key.");
            }
            resolvedPath = resolvedPath.replace("{Key+}", labelValue.split("/").map(function(segment) {
              return extendedEncodeURIComponent(segment);
            }).join("/"));
          } else {
            throw new Error("No value provided for input HTTP label: Key.");
          }
          query = {
            uploads: ""
          };
          return [4, context.endpoint()];
        case 1:
          _a = _c.sent(), hostname = _a.hostname, _b = _a.protocol, protocol = _b === void 0 ? "https" : _b, port = _a.port;
          return [2, new HttpRequest({
            protocol,
            hostname,
            port,
            method: "POST",
            headers,
            path: resolvedPath,
            query,
            body
          })];
      }
    });
  });
};
var serializeAws_restXmlDeleteObjectCommand = function(input, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var headers, resolvedPath, labelValue, labelValue, query, body, _a, hostname, _b, protocol, port;
    return __generator$3(this, function(_c) {
      switch (_c.label) {
        case 0:
          headers = __assign$4(__assign$4(__assign$4(__assign$4({}, isSerializableHeaderValue(input.MFA) && { "x-amz-mfa": input.MFA }), isSerializableHeaderValue(input.RequestPayer) && { "x-amz-request-payer": input.RequestPayer }), isSerializableHeaderValue(input.BypassGovernanceRetention) && {
            "x-amz-bypass-governance-retention": input.BypassGovernanceRetention.toString()
          }), isSerializableHeaderValue(input.ExpectedBucketOwner) && {
            "x-amz-expected-bucket-owner": input.ExpectedBucketOwner
          });
          resolvedPath = "/{Bucket}/{Key+}";
          if (input.Bucket !== void 0) {
            labelValue = input.Bucket;
            if (labelValue.length <= 0) {
              throw new Error("Empty value provided for input HTTP label: Bucket.");
            }
            resolvedPath = resolvedPath.replace("{Bucket}", extendedEncodeURIComponent(labelValue));
          } else {
            throw new Error("No value provided for input HTTP label: Bucket.");
          }
          if (input.Key !== void 0) {
            labelValue = input.Key;
            if (labelValue.length <= 0) {
              throw new Error("Empty value provided for input HTTP label: Key.");
            }
            resolvedPath = resolvedPath.replace("{Key+}", labelValue.split("/").map(function(segment) {
              return extendedEncodeURIComponent(segment);
            }).join("/"));
          } else {
            throw new Error("No value provided for input HTTP label: Key.");
          }
          query = __assign$4({ "x-id": "DeleteObject" }, input.VersionId !== void 0 && { versionId: input.VersionId });
          return [4, context.endpoint()];
        case 1:
          _a = _c.sent(), hostname = _a.hostname, _b = _a.protocol, protocol = _b === void 0 ? "https" : _b, port = _a.port;
          return [2, new HttpRequest({
            protocol,
            hostname,
            port,
            method: "DELETE",
            headers,
            path: resolvedPath,
            query,
            body
          })];
      }
    });
  });
};
var serializeAws_restXmlGetObjectCommand = function(input, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var headers, resolvedPath, labelValue, labelValue, query, body, _a, hostname, _b, protocol, port;
    return __generator$3(this, function(_c) {
      switch (_c.label) {
        case 0:
          headers = __assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4({}, isSerializableHeaderValue(input.IfMatch) && { "if-match": input.IfMatch }), isSerializableHeaderValue(input.IfModifiedSince) && {
            "if-modified-since": dateToUtcString(input.IfModifiedSince).toString()
          }), isSerializableHeaderValue(input.IfNoneMatch) && { "if-none-match": input.IfNoneMatch }), isSerializableHeaderValue(input.IfUnmodifiedSince) && {
            "if-unmodified-since": dateToUtcString(input.IfUnmodifiedSince).toString()
          }), isSerializableHeaderValue(input.Range) && { range: input.Range }), isSerializableHeaderValue(input.SSECustomerAlgorithm) && {
            "x-amz-server-side-encryption-customer-algorithm": input.SSECustomerAlgorithm
          }), isSerializableHeaderValue(input.SSECustomerKey) && {
            "x-amz-server-side-encryption-customer-key": input.SSECustomerKey
          }), isSerializableHeaderValue(input.SSECustomerKeyMD5) && {
            "x-amz-server-side-encryption-customer-key-md5": input.SSECustomerKeyMD5
          }), isSerializableHeaderValue(input.RequestPayer) && { "x-amz-request-payer": input.RequestPayer }), isSerializableHeaderValue(input.ExpectedBucketOwner) && {
            "x-amz-expected-bucket-owner": input.ExpectedBucketOwner
          });
          resolvedPath = "/{Bucket}/{Key+}";
          if (input.Bucket !== void 0) {
            labelValue = input.Bucket;
            if (labelValue.length <= 0) {
              throw new Error("Empty value provided for input HTTP label: Bucket.");
            }
            resolvedPath = resolvedPath.replace("{Bucket}", extendedEncodeURIComponent(labelValue));
          } else {
            throw new Error("No value provided for input HTTP label: Bucket.");
          }
          if (input.Key !== void 0) {
            labelValue = input.Key;
            if (labelValue.length <= 0) {
              throw new Error("Empty value provided for input HTTP label: Key.");
            }
            resolvedPath = resolvedPath.replace("{Key+}", labelValue.split("/").map(function(segment) {
              return extendedEncodeURIComponent(segment);
            }).join("/"));
          } else {
            throw new Error("No value provided for input HTTP label: Key.");
          }
          query = __assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4({ "x-id": "GetObject" }, input.ResponseCacheControl !== void 0 && { "response-cache-control": input.ResponseCacheControl }), input.ResponseContentDisposition !== void 0 && {
            "response-content-disposition": input.ResponseContentDisposition
          }), input.ResponseContentEncoding !== void 0 && { "response-content-encoding": input.ResponseContentEncoding }), input.ResponseContentLanguage !== void 0 && { "response-content-language": input.ResponseContentLanguage }), input.ResponseContentType !== void 0 && { "response-content-type": input.ResponseContentType }), input.ResponseExpires !== void 0 && {
            "response-expires": (input.ResponseExpires.toISOString().split(".")[0] + "Z").toString()
          }), input.VersionId !== void 0 && { versionId: input.VersionId }), input.PartNumber !== void 0 && { partNumber: input.PartNumber.toString() });
          return [4, context.endpoint()];
        case 1:
          _a = _c.sent(), hostname = _a.hostname, _b = _a.protocol, protocol = _b === void 0 ? "https" : _b, port = _a.port;
          return [2, new HttpRequest({
            protocol,
            hostname,
            port,
            method: "GET",
            headers,
            path: resolvedPath,
            query,
            body
          })];
      }
    });
  });
};
var serializeAws_restXmlListObjectsCommand = function(input, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var headers, resolvedPath, labelValue, query, body, _a, hostname, _b, protocol, port;
    return __generator$3(this, function(_c) {
      switch (_c.label) {
        case 0:
          headers = __assign$4(__assign$4({}, isSerializableHeaderValue(input.RequestPayer) && { "x-amz-request-payer": input.RequestPayer }), isSerializableHeaderValue(input.ExpectedBucketOwner) && {
            "x-amz-expected-bucket-owner": input.ExpectedBucketOwner
          });
          resolvedPath = "/{Bucket}";
          if (input.Bucket !== void 0) {
            labelValue = input.Bucket;
            if (labelValue.length <= 0) {
              throw new Error("Empty value provided for input HTTP label: Bucket.");
            }
            resolvedPath = resolvedPath.replace("{Bucket}", extendedEncodeURIComponent(labelValue));
          } else {
            throw new Error("No value provided for input HTTP label: Bucket.");
          }
          query = __assign$4(__assign$4(__assign$4(__assign$4(__assign$4({}, input.Delimiter !== void 0 && { delimiter: input.Delimiter }), input.EncodingType !== void 0 && { "encoding-type": input.EncodingType }), input.Marker !== void 0 && { marker: input.Marker }), input.MaxKeys !== void 0 && { "max-keys": input.MaxKeys.toString() }), input.Prefix !== void 0 && { prefix: input.Prefix });
          return [4, context.endpoint()];
        case 1:
          _a = _c.sent(), hostname = _a.hostname, _b = _a.protocol, protocol = _b === void 0 ? "https" : _b, port = _a.port;
          return [2, new HttpRequest({
            protocol,
            hostname,
            port,
            method: "GET",
            headers,
            path: resolvedPath,
            query,
            body
          })];
      }
    });
  });
};
var serializeAws_restXmlListPartsCommand = function(input, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var headers, resolvedPath, labelValue, labelValue, query, body, _a, hostname, _b, protocol, port;
    return __generator$3(this, function(_c) {
      switch (_c.label) {
        case 0:
          headers = __assign$4(__assign$4({}, isSerializableHeaderValue(input.RequestPayer) && { "x-amz-request-payer": input.RequestPayer }), isSerializableHeaderValue(input.ExpectedBucketOwner) && {
            "x-amz-expected-bucket-owner": input.ExpectedBucketOwner
          });
          resolvedPath = "/{Bucket}/{Key+}";
          if (input.Bucket !== void 0) {
            labelValue = input.Bucket;
            if (labelValue.length <= 0) {
              throw new Error("Empty value provided for input HTTP label: Bucket.");
            }
            resolvedPath = resolvedPath.replace("{Bucket}", extendedEncodeURIComponent(labelValue));
          } else {
            throw new Error("No value provided for input HTTP label: Bucket.");
          }
          if (input.Key !== void 0) {
            labelValue = input.Key;
            if (labelValue.length <= 0) {
              throw new Error("Empty value provided for input HTTP label: Key.");
            }
            resolvedPath = resolvedPath.replace("{Key+}", labelValue.split("/").map(function(segment) {
              return extendedEncodeURIComponent(segment);
            }).join("/"));
          } else {
            throw new Error("No value provided for input HTTP label: Key.");
          }
          query = __assign$4(__assign$4(__assign$4({ "x-id": "ListParts" }, input.MaxParts !== void 0 && { "max-parts": input.MaxParts.toString() }), input.PartNumberMarker !== void 0 && { "part-number-marker": input.PartNumberMarker }), input.UploadId !== void 0 && { uploadId: input.UploadId });
          return [4, context.endpoint()];
        case 1:
          _a = _c.sent(), hostname = _a.hostname, _b = _a.protocol, protocol = _b === void 0 ? "https" : _b, port = _a.port;
          return [2, new HttpRequest({
            protocol,
            hostname,
            port,
            method: "GET",
            headers,
            path: resolvedPath,
            query,
            body
          })];
      }
    });
  });
};
var serializeAws_restXmlPutObjectCommand = function(input, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var headers, resolvedPath, labelValue, labelValue, query, body, contents, _a, hostname, _b, protocol, port;
    return __generator$3(this, function(_c) {
      switch (_c.label) {
        case 0:
          headers = __assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4({ "content-type": "application/octet-stream" }, isSerializableHeaderValue(input.ACL) && { "x-amz-acl": input.ACL }), isSerializableHeaderValue(input.CacheControl) && { "cache-control": input.CacheControl }), isSerializableHeaderValue(input.ContentDisposition) && { "content-disposition": input.ContentDisposition }), isSerializableHeaderValue(input.ContentEncoding) && { "content-encoding": input.ContentEncoding }), isSerializableHeaderValue(input.ContentLanguage) && { "content-language": input.ContentLanguage }), isSerializableHeaderValue(input.ContentLength) && { "content-length": input.ContentLength.toString() }), isSerializableHeaderValue(input.ContentMD5) && { "content-md5": input.ContentMD5 }), isSerializableHeaderValue(input.ContentType) && { "content-type": input.ContentType }), isSerializableHeaderValue(input.Expires) && { expires: dateToUtcString(input.Expires).toString() }), isSerializableHeaderValue(input.GrantFullControl) && { "x-amz-grant-full-control": input.GrantFullControl }), isSerializableHeaderValue(input.GrantRead) && { "x-amz-grant-read": input.GrantRead }), isSerializableHeaderValue(input.GrantReadACP) && { "x-amz-grant-read-acp": input.GrantReadACP }), isSerializableHeaderValue(input.GrantWriteACP) && { "x-amz-grant-write-acp": input.GrantWriteACP }), isSerializableHeaderValue(input.ServerSideEncryption) && {
            "x-amz-server-side-encryption": input.ServerSideEncryption
          }), isSerializableHeaderValue(input.StorageClass) && { "x-amz-storage-class": input.StorageClass }), isSerializableHeaderValue(input.WebsiteRedirectLocation) && {
            "x-amz-website-redirect-location": input.WebsiteRedirectLocation
          }), isSerializableHeaderValue(input.SSECustomerAlgorithm) && {
            "x-amz-server-side-encryption-customer-algorithm": input.SSECustomerAlgorithm
          }), isSerializableHeaderValue(input.SSECustomerKey) && {
            "x-amz-server-side-encryption-customer-key": input.SSECustomerKey
          }), isSerializableHeaderValue(input.SSECustomerKeyMD5) && {
            "x-amz-server-side-encryption-customer-key-md5": input.SSECustomerKeyMD5
          }), isSerializableHeaderValue(input.SSEKMSKeyId) && {
            "x-amz-server-side-encryption-aws-kms-key-id": input.SSEKMSKeyId
          }), isSerializableHeaderValue(input.SSEKMSEncryptionContext) && {
            "x-amz-server-side-encryption-context": input.SSEKMSEncryptionContext
          }), isSerializableHeaderValue(input.BucketKeyEnabled) && {
            "x-amz-server-side-encryption-bucket-key-enabled": input.BucketKeyEnabled.toString()
          }), isSerializableHeaderValue(input.RequestPayer) && { "x-amz-request-payer": input.RequestPayer }), isSerializableHeaderValue(input.Tagging) && { "x-amz-tagging": input.Tagging }), isSerializableHeaderValue(input.ObjectLockMode) && { "x-amz-object-lock-mode": input.ObjectLockMode }), isSerializableHeaderValue(input.ObjectLockRetainUntilDate) && {
            "x-amz-object-lock-retain-until-date": (input.ObjectLockRetainUntilDate.toISOString().split(".")[0] + "Z").toString()
          }), isSerializableHeaderValue(input.ObjectLockLegalHoldStatus) && {
            "x-amz-object-lock-legal-hold": input.ObjectLockLegalHoldStatus
          }), isSerializableHeaderValue(input.ExpectedBucketOwner) && {
            "x-amz-expected-bucket-owner": input.ExpectedBucketOwner
          }), input.Metadata !== void 0 && Object.keys(input.Metadata).reduce(function(acc, suffix) {
            var _a2;
            return __assign$4(__assign$4({}, acc), (_a2 = {}, _a2["x-amz-meta-" + suffix.toLowerCase()] = input.Metadata[suffix], _a2));
          }, {}));
          resolvedPath = "/{Bucket}/{Key+}";
          if (input.Bucket !== void 0) {
            labelValue = input.Bucket;
            if (labelValue.length <= 0) {
              throw new Error("Empty value provided for input HTTP label: Bucket.");
            }
            resolvedPath = resolvedPath.replace("{Bucket}", extendedEncodeURIComponent(labelValue));
          } else {
            throw new Error("No value provided for input HTTP label: Bucket.");
          }
          if (input.Key !== void 0) {
            labelValue = input.Key;
            if (labelValue.length <= 0) {
              throw new Error("Empty value provided for input HTTP label: Key.");
            }
            resolvedPath = resolvedPath.replace("{Key+}", labelValue.split("/").map(function(segment) {
              return extendedEncodeURIComponent(segment);
            }).join("/"));
          } else {
            throw new Error("No value provided for input HTTP label: Key.");
          }
          query = {
            "x-id": "PutObject"
          };
          if (input.Body !== void 0) {
            contents = input.Body;
            body = contents;
          }
          return [4, context.endpoint()];
        case 1:
          _a = _c.sent(), hostname = _a.hostname, _b = _a.protocol, protocol = _b === void 0 ? "https" : _b, port = _a.port;
          return [2, new HttpRequest({
            protocol,
            hostname,
            port,
            method: "PUT",
            headers,
            path: resolvedPath,
            query,
            body
          })];
      }
    });
  });
};
var serializeAws_restXmlUploadPartCommand = function(input, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var headers, resolvedPath, labelValue, labelValue, query, body, contents, _a, hostname, _b, protocol, port;
    return __generator$3(this, function(_c) {
      switch (_c.label) {
        case 0:
          headers = __assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4(__assign$4({ "content-type": "application/octet-stream" }, isSerializableHeaderValue(input.ContentLength) && { "content-length": input.ContentLength.toString() }), isSerializableHeaderValue(input.ContentMD5) && { "content-md5": input.ContentMD5 }), isSerializableHeaderValue(input.SSECustomerAlgorithm) && {
            "x-amz-server-side-encryption-customer-algorithm": input.SSECustomerAlgorithm
          }), isSerializableHeaderValue(input.SSECustomerKey) && {
            "x-amz-server-side-encryption-customer-key": input.SSECustomerKey
          }), isSerializableHeaderValue(input.SSECustomerKeyMD5) && {
            "x-amz-server-side-encryption-customer-key-md5": input.SSECustomerKeyMD5
          }), isSerializableHeaderValue(input.RequestPayer) && { "x-amz-request-payer": input.RequestPayer }), isSerializableHeaderValue(input.ExpectedBucketOwner) && {
            "x-amz-expected-bucket-owner": input.ExpectedBucketOwner
          });
          resolvedPath = "/{Bucket}/{Key+}";
          if (input.Bucket !== void 0) {
            labelValue = input.Bucket;
            if (labelValue.length <= 0) {
              throw new Error("Empty value provided for input HTTP label: Bucket.");
            }
            resolvedPath = resolvedPath.replace("{Bucket}", extendedEncodeURIComponent(labelValue));
          } else {
            throw new Error("No value provided for input HTTP label: Bucket.");
          }
          if (input.Key !== void 0) {
            labelValue = input.Key;
            if (labelValue.length <= 0) {
              throw new Error("Empty value provided for input HTTP label: Key.");
            }
            resolvedPath = resolvedPath.replace("{Key+}", labelValue.split("/").map(function(segment) {
              return extendedEncodeURIComponent(segment);
            }).join("/"));
          } else {
            throw new Error("No value provided for input HTTP label: Key.");
          }
          query = __assign$4(__assign$4({ "x-id": "UploadPart" }, input.PartNumber !== void 0 && { partNumber: input.PartNumber.toString() }), input.UploadId !== void 0 && { uploadId: input.UploadId });
          if (input.Body !== void 0) {
            contents = input.Body;
            body = contents;
          }
          return [4, context.endpoint()];
        case 1:
          _a = _c.sent(), hostname = _a.hostname, _b = _a.protocol, protocol = _b === void 0 ? "https" : _b, port = _a.port;
          return [2, new HttpRequest({
            protocol,
            hostname,
            port,
            method: "PUT",
            headers,
            path: resolvedPath,
            query,
            body
          })];
      }
    });
  });
};
var deserializeAws_restXmlAbortMultipartUploadCommand = function(output, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var contents;
    return __generator$3(this, function(_a) {
      switch (_a.label) {
        case 0:
          if (output.statusCode !== 204 && output.statusCode >= 300) {
            return [2, deserializeAws_restXmlAbortMultipartUploadCommandError(output, context)];
          }
          contents = {
            $metadata: deserializeMetadata(output),
            RequestCharged: void 0
          };
          if (output.headers["x-amz-request-charged"] !== void 0) {
            contents.RequestCharged = output.headers["x-amz-request-charged"];
          }
          return [4, collectBody(output.body, context)];
        case 1:
          _a.sent();
          return [2, Promise.resolve(contents)];
      }
    });
  });
};
var deserializeAws_restXmlAbortMultipartUploadCommandError = function(output, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var parsedOutput, _a, response, errorCode, _b, _c, parsedBody, message;
    var _d;
    return __generator$3(this, function(_e2) {
      switch (_e2.label) {
        case 0:
          _a = [__assign$4({}, output)];
          _d = {};
          return [4, parseBody(output.body, context)];
        case 1:
          parsedOutput = __assign$4.apply(void 0, _a.concat([(_d.body = _e2.sent(), _d)]));
          errorCode = "UnknownError";
          errorCode = loadRestXmlErrorCode(output, parsedOutput.body);
          _b = errorCode;
          switch (_b) {
            case "NoSuchUpload":
              return [3, 2];
            case "com.amazonaws.s3#NoSuchUpload":
              return [3, 2];
          }
          return [3, 4];
        case 2:
          _c = [{}];
          return [4, deserializeAws_restXmlNoSuchUploadResponse(parsedOutput)];
        case 3:
          response = __assign$4.apply(void 0, [__assign$4.apply(void 0, _c.concat([_e2.sent()])), { name: errorCode, $metadata: deserializeMetadata(output) }]);
          return [3, 5];
        case 4:
          parsedBody = parsedOutput.body;
          errorCode = parsedBody.code || parsedBody.Code || errorCode;
          response = __assign$4(__assign$4({}, parsedBody), { name: "" + errorCode, message: parsedBody.message || parsedBody.Message || errorCode, $fault: "client", $metadata: deserializeMetadata(output) });
          _e2.label = 5;
        case 5:
          message = response.message || response.Message || errorCode;
          response.message = message;
          delete response.Message;
          return [2, Promise.reject(Object.assign(new Error(message), response))];
      }
    });
  });
};
var deserializeAws_restXmlCompleteMultipartUploadCommand = function(output, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var contents, data;
    return __generator$3(this, function(_a) {
      switch (_a.label) {
        case 0:
          if (output.statusCode !== 200 && output.statusCode >= 300) {
            return [2, deserializeAws_restXmlCompleteMultipartUploadCommandError(output, context)];
          }
          contents = {
            $metadata: deserializeMetadata(output),
            Bucket: void 0,
            BucketKeyEnabled: void 0,
            ETag: void 0,
            Expiration: void 0,
            Key: void 0,
            Location: void 0,
            RequestCharged: void 0,
            SSEKMSKeyId: void 0,
            ServerSideEncryption: void 0,
            VersionId: void 0
          };
          if (output.headers["x-amz-expiration"] !== void 0) {
            contents.Expiration = output.headers["x-amz-expiration"];
          }
          if (output.headers["x-amz-server-side-encryption"] !== void 0) {
            contents.ServerSideEncryption = output.headers["x-amz-server-side-encryption"];
          }
          if (output.headers["x-amz-version-id"] !== void 0) {
            contents.VersionId = output.headers["x-amz-version-id"];
          }
          if (output.headers["x-amz-server-side-encryption-aws-kms-key-id"] !== void 0) {
            contents.SSEKMSKeyId = output.headers["x-amz-server-side-encryption-aws-kms-key-id"];
          }
          if (output.headers["x-amz-server-side-encryption-bucket-key-enabled"] !== void 0) {
            contents.BucketKeyEnabled = output.headers["x-amz-server-side-encryption-bucket-key-enabled"] === "true";
          }
          if (output.headers["x-amz-request-charged"] !== void 0) {
            contents.RequestCharged = output.headers["x-amz-request-charged"];
          }
          return [4, parseBody(output.body, context)];
        case 1:
          data = _a.sent();
          if (data["Bucket"] !== void 0) {
            contents.Bucket = data["Bucket"];
          }
          if (data["ETag"] !== void 0) {
            contents.ETag = data["ETag"];
          }
          if (data["Key"] !== void 0) {
            contents.Key = data["Key"];
          }
          if (data["Location"] !== void 0) {
            contents.Location = data["Location"];
          }
          return [2, Promise.resolve(contents)];
      }
    });
  });
};
var deserializeAws_restXmlCompleteMultipartUploadCommandError = function(output, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var parsedOutput, _a, response, errorCode, parsedBody, message;
    var _b;
    return __generator$3(this, function(_c) {
      switch (_c.label) {
        case 0:
          _a = [__assign$4({}, output)];
          _b = {};
          return [4, parseBody(output.body, context)];
        case 1:
          parsedOutput = __assign$4.apply(void 0, _a.concat([(_b.body = _c.sent(), _b)]));
          errorCode = "UnknownError";
          errorCode = loadRestXmlErrorCode(output, parsedOutput.body);
          switch (errorCode) {
            default:
              parsedBody = parsedOutput.body;
              errorCode = parsedBody.code || parsedBody.Code || errorCode;
              response = __assign$4(__assign$4({}, parsedBody), { name: "" + errorCode, message: parsedBody.message || parsedBody.Message || errorCode, $fault: "client", $metadata: deserializeMetadata(output) });
          }
          message = response.message || response.Message || errorCode;
          response.message = message;
          delete response.Message;
          return [2, Promise.reject(Object.assign(new Error(message), response))];
      }
    });
  });
};
var deserializeAws_restXmlCopyObjectCommand = function(output, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var contents, data;
    return __generator$3(this, function(_a) {
      switch (_a.label) {
        case 0:
          if (output.statusCode !== 200 && output.statusCode >= 300) {
            return [2, deserializeAws_restXmlCopyObjectCommandError(output, context)];
          }
          contents = {
            $metadata: deserializeMetadata(output),
            BucketKeyEnabled: void 0,
            CopyObjectResult: void 0,
            CopySourceVersionId: void 0,
            Expiration: void 0,
            RequestCharged: void 0,
            SSECustomerAlgorithm: void 0,
            SSECustomerKeyMD5: void 0,
            SSEKMSEncryptionContext: void 0,
            SSEKMSKeyId: void 0,
            ServerSideEncryption: void 0,
            VersionId: void 0
          };
          if (output.headers["x-amz-expiration"] !== void 0) {
            contents.Expiration = output.headers["x-amz-expiration"];
          }
          if (output.headers["x-amz-copy-source-version-id"] !== void 0) {
            contents.CopySourceVersionId = output.headers["x-amz-copy-source-version-id"];
          }
          if (output.headers["x-amz-version-id"] !== void 0) {
            contents.VersionId = output.headers["x-amz-version-id"];
          }
          if (output.headers["x-amz-server-side-encryption"] !== void 0) {
            contents.ServerSideEncryption = output.headers["x-amz-server-side-encryption"];
          }
          if (output.headers["x-amz-server-side-encryption-customer-algorithm"] !== void 0) {
            contents.SSECustomerAlgorithm = output.headers["x-amz-server-side-encryption-customer-algorithm"];
          }
          if (output.headers["x-amz-server-side-encryption-customer-key-md5"] !== void 0) {
            contents.SSECustomerKeyMD5 = output.headers["x-amz-server-side-encryption-customer-key-md5"];
          }
          if (output.headers["x-amz-server-side-encryption-aws-kms-key-id"] !== void 0) {
            contents.SSEKMSKeyId = output.headers["x-amz-server-side-encryption-aws-kms-key-id"];
          }
          if (output.headers["x-amz-server-side-encryption-context"] !== void 0) {
            contents.SSEKMSEncryptionContext = output.headers["x-amz-server-side-encryption-context"];
          }
          if (output.headers["x-amz-server-side-encryption-bucket-key-enabled"] !== void 0) {
            contents.BucketKeyEnabled = output.headers["x-amz-server-side-encryption-bucket-key-enabled"] === "true";
          }
          if (output.headers["x-amz-request-charged"] !== void 0) {
            contents.RequestCharged = output.headers["x-amz-request-charged"];
          }
          return [4, parseBody(output.body, context)];
        case 1:
          data = _a.sent();
          contents.CopyObjectResult = deserializeAws_restXmlCopyObjectResult(data);
          return [2, Promise.resolve(contents)];
      }
    });
  });
};
var deserializeAws_restXmlCopyObjectCommandError = function(output, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var parsedOutput, _a, response, errorCode, _b, _c, parsedBody, message;
    var _d;
    return __generator$3(this, function(_e2) {
      switch (_e2.label) {
        case 0:
          _a = [__assign$4({}, output)];
          _d = {};
          return [4, parseBody(output.body, context)];
        case 1:
          parsedOutput = __assign$4.apply(void 0, _a.concat([(_d.body = _e2.sent(), _d)]));
          errorCode = "UnknownError";
          errorCode = loadRestXmlErrorCode(output, parsedOutput.body);
          _b = errorCode;
          switch (_b) {
            case "ObjectNotInActiveTierError":
              return [3, 2];
            case "com.amazonaws.s3#ObjectNotInActiveTierError":
              return [3, 2];
          }
          return [3, 4];
        case 2:
          _c = [{}];
          return [4, deserializeAws_restXmlObjectNotInActiveTierErrorResponse(parsedOutput)];
        case 3:
          response = __assign$4.apply(void 0, [__assign$4.apply(void 0, _c.concat([_e2.sent()])), { name: errorCode, $metadata: deserializeMetadata(output) }]);
          return [3, 5];
        case 4:
          parsedBody = parsedOutput.body;
          errorCode = parsedBody.code || parsedBody.Code || errorCode;
          response = __assign$4(__assign$4({}, parsedBody), { name: "" + errorCode, message: parsedBody.message || parsedBody.Message || errorCode, $fault: "client", $metadata: deserializeMetadata(output) });
          _e2.label = 5;
        case 5:
          message = response.message || response.Message || errorCode;
          response.message = message;
          delete response.Message;
          return [2, Promise.reject(Object.assign(new Error(message), response))];
      }
    });
  });
};
var deserializeAws_restXmlCreateMultipartUploadCommand = function(output, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var contents, data;
    return __generator$3(this, function(_a) {
      switch (_a.label) {
        case 0:
          if (output.statusCode !== 200 && output.statusCode >= 300) {
            return [2, deserializeAws_restXmlCreateMultipartUploadCommandError(output, context)];
          }
          contents = {
            $metadata: deserializeMetadata(output),
            AbortDate: void 0,
            AbortRuleId: void 0,
            Bucket: void 0,
            BucketKeyEnabled: void 0,
            Key: void 0,
            RequestCharged: void 0,
            SSECustomerAlgorithm: void 0,
            SSECustomerKeyMD5: void 0,
            SSEKMSEncryptionContext: void 0,
            SSEKMSKeyId: void 0,
            ServerSideEncryption: void 0,
            UploadId: void 0
          };
          if (output.headers["x-amz-abort-date"] !== void 0) {
            contents.AbortDate = new Date(output.headers["x-amz-abort-date"]);
          }
          if (output.headers["x-amz-abort-rule-id"] !== void 0) {
            contents.AbortRuleId = output.headers["x-amz-abort-rule-id"];
          }
          if (output.headers["x-amz-server-side-encryption"] !== void 0) {
            contents.ServerSideEncryption = output.headers["x-amz-server-side-encryption"];
          }
          if (output.headers["x-amz-server-side-encryption-customer-algorithm"] !== void 0) {
            contents.SSECustomerAlgorithm = output.headers["x-amz-server-side-encryption-customer-algorithm"];
          }
          if (output.headers["x-amz-server-side-encryption-customer-key-md5"] !== void 0) {
            contents.SSECustomerKeyMD5 = output.headers["x-amz-server-side-encryption-customer-key-md5"];
          }
          if (output.headers["x-amz-server-side-encryption-aws-kms-key-id"] !== void 0) {
            contents.SSEKMSKeyId = output.headers["x-amz-server-side-encryption-aws-kms-key-id"];
          }
          if (output.headers["x-amz-server-side-encryption-context"] !== void 0) {
            contents.SSEKMSEncryptionContext = output.headers["x-amz-server-side-encryption-context"];
          }
          if (output.headers["x-amz-server-side-encryption-bucket-key-enabled"] !== void 0) {
            contents.BucketKeyEnabled = output.headers["x-amz-server-side-encryption-bucket-key-enabled"] === "true";
          }
          if (output.headers["x-amz-request-charged"] !== void 0) {
            contents.RequestCharged = output.headers["x-amz-request-charged"];
          }
          return [4, parseBody(output.body, context)];
        case 1:
          data = _a.sent();
          if (data["Bucket"] !== void 0) {
            contents.Bucket = data["Bucket"];
          }
          if (data["Key"] !== void 0) {
            contents.Key = data["Key"];
          }
          if (data["UploadId"] !== void 0) {
            contents.UploadId = data["UploadId"];
          }
          return [2, Promise.resolve(contents)];
      }
    });
  });
};
var deserializeAws_restXmlCreateMultipartUploadCommandError = function(output, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var parsedOutput, _a, response, errorCode, parsedBody, message;
    var _b;
    return __generator$3(this, function(_c) {
      switch (_c.label) {
        case 0:
          _a = [__assign$4({}, output)];
          _b = {};
          return [4, parseBody(output.body, context)];
        case 1:
          parsedOutput = __assign$4.apply(void 0, _a.concat([(_b.body = _c.sent(), _b)]));
          errorCode = "UnknownError";
          errorCode = loadRestXmlErrorCode(output, parsedOutput.body);
          switch (errorCode) {
            default:
              parsedBody = parsedOutput.body;
              errorCode = parsedBody.code || parsedBody.Code || errorCode;
              response = __assign$4(__assign$4({}, parsedBody), { name: "" + errorCode, message: parsedBody.message || parsedBody.Message || errorCode, $fault: "client", $metadata: deserializeMetadata(output) });
          }
          message = response.message || response.Message || errorCode;
          response.message = message;
          delete response.Message;
          return [2, Promise.reject(Object.assign(new Error(message), response))];
      }
    });
  });
};
var deserializeAws_restXmlDeleteObjectCommand = function(output, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var contents;
    return __generator$3(this, function(_a) {
      switch (_a.label) {
        case 0:
          if (output.statusCode !== 204 && output.statusCode >= 300) {
            return [2, deserializeAws_restXmlDeleteObjectCommandError(output, context)];
          }
          contents = {
            $metadata: deserializeMetadata(output),
            DeleteMarker: void 0,
            RequestCharged: void 0,
            VersionId: void 0
          };
          if (output.headers["x-amz-delete-marker"] !== void 0) {
            contents.DeleteMarker = output.headers["x-amz-delete-marker"] === "true";
          }
          if (output.headers["x-amz-version-id"] !== void 0) {
            contents.VersionId = output.headers["x-amz-version-id"];
          }
          if (output.headers["x-amz-request-charged"] !== void 0) {
            contents.RequestCharged = output.headers["x-amz-request-charged"];
          }
          return [4, collectBody(output.body, context)];
        case 1:
          _a.sent();
          return [2, Promise.resolve(contents)];
      }
    });
  });
};
var deserializeAws_restXmlDeleteObjectCommandError = function(output, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var parsedOutput, _a, response, errorCode, parsedBody, message;
    var _b;
    return __generator$3(this, function(_c) {
      switch (_c.label) {
        case 0:
          _a = [__assign$4({}, output)];
          _b = {};
          return [4, parseBody(output.body, context)];
        case 1:
          parsedOutput = __assign$4.apply(void 0, _a.concat([(_b.body = _c.sent(), _b)]));
          errorCode = "UnknownError";
          errorCode = loadRestXmlErrorCode(output, parsedOutput.body);
          switch (errorCode) {
            default:
              parsedBody = parsedOutput.body;
              errorCode = parsedBody.code || parsedBody.Code || errorCode;
              response = __assign$4(__assign$4({}, parsedBody), { name: "" + errorCode, message: parsedBody.message || parsedBody.Message || errorCode, $fault: "client", $metadata: deserializeMetadata(output) });
          }
          message = response.message || response.Message || errorCode;
          response.message = message;
          delete response.Message;
          return [2, Promise.reject(Object.assign(new Error(message), response))];
      }
    });
  });
};
var deserializeAws_restXmlGetObjectCommand = function(output, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var contents, data;
    return __generator$3(this, function(_a) {
      if (output.statusCode !== 200 && output.statusCode >= 300) {
        return [2, deserializeAws_restXmlGetObjectCommandError(output, context)];
      }
      contents = {
        $metadata: deserializeMetadata(output),
        AcceptRanges: void 0,
        Body: void 0,
        BucketKeyEnabled: void 0,
        CacheControl: void 0,
        ContentDisposition: void 0,
        ContentEncoding: void 0,
        ContentLanguage: void 0,
        ContentLength: void 0,
        ContentRange: void 0,
        ContentType: void 0,
        DeleteMarker: void 0,
        ETag: void 0,
        Expiration: void 0,
        Expires: void 0,
        LastModified: void 0,
        Metadata: void 0,
        MissingMeta: void 0,
        ObjectLockLegalHoldStatus: void 0,
        ObjectLockMode: void 0,
        ObjectLockRetainUntilDate: void 0,
        PartsCount: void 0,
        ReplicationStatus: void 0,
        RequestCharged: void 0,
        Restore: void 0,
        SSECustomerAlgorithm: void 0,
        SSECustomerKeyMD5: void 0,
        SSEKMSKeyId: void 0,
        ServerSideEncryption: void 0,
        StorageClass: void 0,
        TagCount: void 0,
        VersionId: void 0,
        WebsiteRedirectLocation: void 0
      };
      if (output.headers["x-amz-delete-marker"] !== void 0) {
        contents.DeleteMarker = output.headers["x-amz-delete-marker"] === "true";
      }
      if (output.headers["accept-ranges"] !== void 0) {
        contents.AcceptRanges = output.headers["accept-ranges"];
      }
      if (output.headers["x-amz-expiration"] !== void 0) {
        contents.Expiration = output.headers["x-amz-expiration"];
      }
      if (output.headers["x-amz-restore"] !== void 0) {
        contents.Restore = output.headers["x-amz-restore"];
      }
      if (output.headers["last-modified"] !== void 0) {
        contents.LastModified = new Date(output.headers["last-modified"]);
      }
      if (output.headers["content-length"] !== void 0) {
        contents.ContentLength = parseInt(output.headers["content-length"], 10);
      }
      if (output.headers["etag"] !== void 0) {
        contents.ETag = output.headers["etag"];
      }
      if (output.headers["x-amz-missing-meta"] !== void 0) {
        contents.MissingMeta = parseInt(output.headers["x-amz-missing-meta"], 10);
      }
      if (output.headers["x-amz-version-id"] !== void 0) {
        contents.VersionId = output.headers["x-amz-version-id"];
      }
      if (output.headers["cache-control"] !== void 0) {
        contents.CacheControl = output.headers["cache-control"];
      }
      if (output.headers["content-disposition"] !== void 0) {
        contents.ContentDisposition = output.headers["content-disposition"];
      }
      if (output.headers["content-encoding"] !== void 0) {
        contents.ContentEncoding = output.headers["content-encoding"];
      }
      if (output.headers["content-language"] !== void 0) {
        contents.ContentLanguage = output.headers["content-language"];
      }
      if (output.headers["content-range"] !== void 0) {
        contents.ContentRange = output.headers["content-range"];
      }
      if (output.headers["content-type"] !== void 0) {
        contents.ContentType = output.headers["content-type"];
      }
      if (output.headers["expires"] !== void 0) {
        contents.Expires = new Date(output.headers["expires"]);
      }
      if (output.headers["x-amz-website-redirect-location"] !== void 0) {
        contents.WebsiteRedirectLocation = output.headers["x-amz-website-redirect-location"];
      }
      if (output.headers["x-amz-server-side-encryption"] !== void 0) {
        contents.ServerSideEncryption = output.headers["x-amz-server-side-encryption"];
      }
      if (output.headers["x-amz-server-side-encryption-customer-algorithm"] !== void 0) {
        contents.SSECustomerAlgorithm = output.headers["x-amz-server-side-encryption-customer-algorithm"];
      }
      if (output.headers["x-amz-server-side-encryption-customer-key-md5"] !== void 0) {
        contents.SSECustomerKeyMD5 = output.headers["x-amz-server-side-encryption-customer-key-md5"];
      }
      if (output.headers["x-amz-server-side-encryption-aws-kms-key-id"] !== void 0) {
        contents.SSEKMSKeyId = output.headers["x-amz-server-side-encryption-aws-kms-key-id"];
      }
      if (output.headers["x-amz-server-side-encryption-bucket-key-enabled"] !== void 0) {
        contents.BucketKeyEnabled = output.headers["x-amz-server-side-encryption-bucket-key-enabled"] === "true";
      }
      if (output.headers["x-amz-storage-class"] !== void 0) {
        contents.StorageClass = output.headers["x-amz-storage-class"];
      }
      if (output.headers["x-amz-request-charged"] !== void 0) {
        contents.RequestCharged = output.headers["x-amz-request-charged"];
      }
      if (output.headers["x-amz-replication-status"] !== void 0) {
        contents.ReplicationStatus = output.headers["x-amz-replication-status"];
      }
      if (output.headers["x-amz-mp-parts-count"] !== void 0) {
        contents.PartsCount = parseInt(output.headers["x-amz-mp-parts-count"], 10);
      }
      if (output.headers["x-amz-tagging-count"] !== void 0) {
        contents.TagCount = parseInt(output.headers["x-amz-tagging-count"], 10);
      }
      if (output.headers["x-amz-object-lock-mode"] !== void 0) {
        contents.ObjectLockMode = output.headers["x-amz-object-lock-mode"];
      }
      if (output.headers["x-amz-object-lock-retain-until-date"] !== void 0) {
        contents.ObjectLockRetainUntilDate = new Date(output.headers["x-amz-object-lock-retain-until-date"]);
      }
      if (output.headers["x-amz-object-lock-legal-hold"] !== void 0) {
        contents.ObjectLockLegalHoldStatus = output.headers["x-amz-object-lock-legal-hold"];
      }
      Object.keys(output.headers).forEach(function(header) {
        if (contents.Metadata === void 0) {
          contents.Metadata = {};
        }
        if (header.startsWith("x-amz-meta-")) {
          contents.Metadata[header.substring(11)] = output.headers[header];
        }
      });
      data = output.body;
      contents.Body = data;
      return [2, Promise.resolve(contents)];
    });
  });
};
var deserializeAws_restXmlGetObjectCommandError = function(output, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var parsedOutput, _a, response, errorCode, _b, _c, _d, parsedBody, message;
    var _e2;
    return __generator$3(this, function(_f) {
      switch (_f.label) {
        case 0:
          _a = [__assign$4({}, output)];
          _e2 = {};
          return [4, parseBody(output.body, context)];
        case 1:
          parsedOutput = __assign$4.apply(void 0, _a.concat([(_e2.body = _f.sent(), _e2)]));
          errorCode = "UnknownError";
          errorCode = loadRestXmlErrorCode(output, parsedOutput.body);
          _b = errorCode;
          switch (_b) {
            case "InvalidObjectState":
              return [3, 2];
            case "com.amazonaws.s3#InvalidObjectState":
              return [3, 2];
            case "NoSuchKey":
              return [3, 4];
            case "com.amazonaws.s3#NoSuchKey":
              return [3, 4];
          }
          return [3, 6];
        case 2:
          _c = [{}];
          return [4, deserializeAws_restXmlInvalidObjectStateResponse(parsedOutput)];
        case 3:
          response = __assign$4.apply(void 0, [__assign$4.apply(void 0, _c.concat([_f.sent()])), { name: errorCode, $metadata: deserializeMetadata(output) }]);
          return [3, 7];
        case 4:
          _d = [{}];
          return [4, deserializeAws_restXmlNoSuchKeyResponse(parsedOutput)];
        case 5:
          response = __assign$4.apply(void 0, [__assign$4.apply(void 0, _d.concat([_f.sent()])), { name: errorCode, $metadata: deserializeMetadata(output) }]);
          return [3, 7];
        case 6:
          parsedBody = parsedOutput.body;
          errorCode = parsedBody.code || parsedBody.Code || errorCode;
          response = __assign$4(__assign$4({}, parsedBody), { name: "" + errorCode, message: parsedBody.message || parsedBody.Message || errorCode, $fault: "client", $metadata: deserializeMetadata(output) });
          _f.label = 7;
        case 7:
          message = response.message || response.Message || errorCode;
          response.message = message;
          delete response.Message;
          return [2, Promise.reject(Object.assign(new Error(message), response))];
      }
    });
  });
};
var deserializeAws_restXmlListObjectsCommand = function(output, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var contents, data;
    return __generator$3(this, function(_a) {
      switch (_a.label) {
        case 0:
          if (output.statusCode !== 200 && output.statusCode >= 300) {
            return [2, deserializeAws_restXmlListObjectsCommandError(output, context)];
          }
          contents = {
            $metadata: deserializeMetadata(output),
            CommonPrefixes: void 0,
            Contents: void 0,
            Delimiter: void 0,
            EncodingType: void 0,
            IsTruncated: void 0,
            Marker: void 0,
            MaxKeys: void 0,
            Name: void 0,
            NextMarker: void 0,
            Prefix: void 0
          };
          return [4, parseBody(output.body, context)];
        case 1:
          data = _a.sent();
          if (data.CommonPrefixes === "") {
            contents.CommonPrefixes = [];
          }
          if (data["CommonPrefixes"] !== void 0) {
            contents.CommonPrefixes = deserializeAws_restXmlCommonPrefixList(getArrayIfSingleItem(data["CommonPrefixes"]));
          }
          if (data.Contents === "") {
            contents.Contents = [];
          }
          if (data["Contents"] !== void 0) {
            contents.Contents = deserializeAws_restXmlObjectList(getArrayIfSingleItem(data["Contents"]));
          }
          if (data["Delimiter"] !== void 0) {
            contents.Delimiter = data["Delimiter"];
          }
          if (data["EncodingType"] !== void 0) {
            contents.EncodingType = data["EncodingType"];
          }
          if (data["IsTruncated"] !== void 0) {
            contents.IsTruncated = data["IsTruncated"] == "true";
          }
          if (data["Marker"] !== void 0) {
            contents.Marker = data["Marker"];
          }
          if (data["MaxKeys"] !== void 0) {
            contents.MaxKeys = parseInt(data["MaxKeys"]);
          }
          if (data["Name"] !== void 0) {
            contents.Name = data["Name"];
          }
          if (data["NextMarker"] !== void 0) {
            contents.NextMarker = data["NextMarker"];
          }
          if (data["Prefix"] !== void 0) {
            contents.Prefix = data["Prefix"];
          }
          return [2, Promise.resolve(contents)];
      }
    });
  });
};
var deserializeAws_restXmlListObjectsCommandError = function(output, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var parsedOutput, _a, response, errorCode, _b, _c, parsedBody, message;
    var _d;
    return __generator$3(this, function(_e2) {
      switch (_e2.label) {
        case 0:
          _a = [__assign$4({}, output)];
          _d = {};
          return [4, parseBody(output.body, context)];
        case 1:
          parsedOutput = __assign$4.apply(void 0, _a.concat([(_d.body = _e2.sent(), _d)]));
          errorCode = "UnknownError";
          errorCode = loadRestXmlErrorCode(output, parsedOutput.body);
          _b = errorCode;
          switch (_b) {
            case "NoSuchBucket":
              return [3, 2];
            case "com.amazonaws.s3#NoSuchBucket":
              return [3, 2];
          }
          return [3, 4];
        case 2:
          _c = [{}];
          return [4, deserializeAws_restXmlNoSuchBucketResponse(parsedOutput)];
        case 3:
          response = __assign$4.apply(void 0, [__assign$4.apply(void 0, _c.concat([_e2.sent()])), { name: errorCode, $metadata: deserializeMetadata(output) }]);
          return [3, 5];
        case 4:
          parsedBody = parsedOutput.body;
          errorCode = parsedBody.code || parsedBody.Code || errorCode;
          response = __assign$4(__assign$4({}, parsedBody), { name: "" + errorCode, message: parsedBody.message || parsedBody.Message || errorCode, $fault: "client", $metadata: deserializeMetadata(output) });
          _e2.label = 5;
        case 5:
          message = response.message || response.Message || errorCode;
          response.message = message;
          delete response.Message;
          return [2, Promise.reject(Object.assign(new Error(message), response))];
      }
    });
  });
};
var deserializeAws_restXmlListPartsCommand = function(output, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var contents, data;
    return __generator$3(this, function(_a) {
      switch (_a.label) {
        case 0:
          if (output.statusCode !== 200 && output.statusCode >= 300) {
            return [2, deserializeAws_restXmlListPartsCommandError(output, context)];
          }
          contents = {
            $metadata: deserializeMetadata(output),
            AbortDate: void 0,
            AbortRuleId: void 0,
            Bucket: void 0,
            Initiator: void 0,
            IsTruncated: void 0,
            Key: void 0,
            MaxParts: void 0,
            NextPartNumberMarker: void 0,
            Owner: void 0,
            PartNumberMarker: void 0,
            Parts: void 0,
            RequestCharged: void 0,
            StorageClass: void 0,
            UploadId: void 0
          };
          if (output.headers["x-amz-abort-date"] !== void 0) {
            contents.AbortDate = new Date(output.headers["x-amz-abort-date"]);
          }
          if (output.headers["x-amz-abort-rule-id"] !== void 0) {
            contents.AbortRuleId = output.headers["x-amz-abort-rule-id"];
          }
          if (output.headers["x-amz-request-charged"] !== void 0) {
            contents.RequestCharged = output.headers["x-amz-request-charged"];
          }
          return [4, parseBody(output.body, context)];
        case 1:
          data = _a.sent();
          if (data["Bucket"] !== void 0) {
            contents.Bucket = data["Bucket"];
          }
          if (data["Initiator"] !== void 0) {
            contents.Initiator = deserializeAws_restXmlInitiator(data["Initiator"]);
          }
          if (data["IsTruncated"] !== void 0) {
            contents.IsTruncated = data["IsTruncated"] == "true";
          }
          if (data["Key"] !== void 0) {
            contents.Key = data["Key"];
          }
          if (data["MaxParts"] !== void 0) {
            contents.MaxParts = parseInt(data["MaxParts"]);
          }
          if (data["NextPartNumberMarker"] !== void 0) {
            contents.NextPartNumberMarker = data["NextPartNumberMarker"];
          }
          if (data["Owner"] !== void 0) {
            contents.Owner = deserializeAws_restXmlOwner(data["Owner"]);
          }
          if (data["PartNumberMarker"] !== void 0) {
            contents.PartNumberMarker = data["PartNumberMarker"];
          }
          if (data.Part === "") {
            contents.Parts = [];
          }
          if (data["Part"] !== void 0) {
            contents.Parts = deserializeAws_restXmlParts(getArrayIfSingleItem(data["Part"]));
          }
          if (data["StorageClass"] !== void 0) {
            contents.StorageClass = data["StorageClass"];
          }
          if (data["UploadId"] !== void 0) {
            contents.UploadId = data["UploadId"];
          }
          return [2, Promise.resolve(contents)];
      }
    });
  });
};
var deserializeAws_restXmlListPartsCommandError = function(output, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var parsedOutput, _a, response, errorCode, parsedBody, message;
    var _b;
    return __generator$3(this, function(_c) {
      switch (_c.label) {
        case 0:
          _a = [__assign$4({}, output)];
          _b = {};
          return [4, parseBody(output.body, context)];
        case 1:
          parsedOutput = __assign$4.apply(void 0, _a.concat([(_b.body = _c.sent(), _b)]));
          errorCode = "UnknownError";
          errorCode = loadRestXmlErrorCode(output, parsedOutput.body);
          switch (errorCode) {
            default:
              parsedBody = parsedOutput.body;
              errorCode = parsedBody.code || parsedBody.Code || errorCode;
              response = __assign$4(__assign$4({}, parsedBody), { name: "" + errorCode, message: parsedBody.message || parsedBody.Message || errorCode, $fault: "client", $metadata: deserializeMetadata(output) });
          }
          message = response.message || response.Message || errorCode;
          response.message = message;
          delete response.Message;
          return [2, Promise.reject(Object.assign(new Error(message), response))];
      }
    });
  });
};
var deserializeAws_restXmlPutObjectCommand = function(output, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var contents;
    return __generator$3(this, function(_a) {
      switch (_a.label) {
        case 0:
          if (output.statusCode !== 200 && output.statusCode >= 300) {
            return [2, deserializeAws_restXmlPutObjectCommandError(output, context)];
          }
          contents = {
            $metadata: deserializeMetadata(output),
            BucketKeyEnabled: void 0,
            ETag: void 0,
            Expiration: void 0,
            RequestCharged: void 0,
            SSECustomerAlgorithm: void 0,
            SSECustomerKeyMD5: void 0,
            SSEKMSEncryptionContext: void 0,
            SSEKMSKeyId: void 0,
            ServerSideEncryption: void 0,
            VersionId: void 0
          };
          if (output.headers["x-amz-expiration"] !== void 0) {
            contents.Expiration = output.headers["x-amz-expiration"];
          }
          if (output.headers["etag"] !== void 0) {
            contents.ETag = output.headers["etag"];
          }
          if (output.headers["x-amz-server-side-encryption"] !== void 0) {
            contents.ServerSideEncryption = output.headers["x-amz-server-side-encryption"];
          }
          if (output.headers["x-amz-version-id"] !== void 0) {
            contents.VersionId = output.headers["x-amz-version-id"];
          }
          if (output.headers["x-amz-server-side-encryption-customer-algorithm"] !== void 0) {
            contents.SSECustomerAlgorithm = output.headers["x-amz-server-side-encryption-customer-algorithm"];
          }
          if (output.headers["x-amz-server-side-encryption-customer-key-md5"] !== void 0) {
            contents.SSECustomerKeyMD5 = output.headers["x-amz-server-side-encryption-customer-key-md5"];
          }
          if (output.headers["x-amz-server-side-encryption-aws-kms-key-id"] !== void 0) {
            contents.SSEKMSKeyId = output.headers["x-amz-server-side-encryption-aws-kms-key-id"];
          }
          if (output.headers["x-amz-server-side-encryption-context"] !== void 0) {
            contents.SSEKMSEncryptionContext = output.headers["x-amz-server-side-encryption-context"];
          }
          if (output.headers["x-amz-server-side-encryption-bucket-key-enabled"] !== void 0) {
            contents.BucketKeyEnabled = output.headers["x-amz-server-side-encryption-bucket-key-enabled"] === "true";
          }
          if (output.headers["x-amz-request-charged"] !== void 0) {
            contents.RequestCharged = output.headers["x-amz-request-charged"];
          }
          return [4, collectBody(output.body, context)];
        case 1:
          _a.sent();
          return [2, Promise.resolve(contents)];
      }
    });
  });
};
var deserializeAws_restXmlPutObjectCommandError = function(output, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var parsedOutput, _a, response, errorCode, parsedBody, message;
    var _b;
    return __generator$3(this, function(_c) {
      switch (_c.label) {
        case 0:
          _a = [__assign$4({}, output)];
          _b = {};
          return [4, parseBody(output.body, context)];
        case 1:
          parsedOutput = __assign$4.apply(void 0, _a.concat([(_b.body = _c.sent(), _b)]));
          errorCode = "UnknownError";
          errorCode = loadRestXmlErrorCode(output, parsedOutput.body);
          switch (errorCode) {
            default:
              parsedBody = parsedOutput.body;
              errorCode = parsedBody.code || parsedBody.Code || errorCode;
              response = __assign$4(__assign$4({}, parsedBody), { name: "" + errorCode, message: parsedBody.message || parsedBody.Message || errorCode, $fault: "client", $metadata: deserializeMetadata(output) });
          }
          message = response.message || response.Message || errorCode;
          response.message = message;
          delete response.Message;
          return [2, Promise.reject(Object.assign(new Error(message), response))];
      }
    });
  });
};
var deserializeAws_restXmlUploadPartCommand = function(output, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var contents;
    return __generator$3(this, function(_a) {
      switch (_a.label) {
        case 0:
          if (output.statusCode !== 200 && output.statusCode >= 300) {
            return [2, deserializeAws_restXmlUploadPartCommandError(output, context)];
          }
          contents = {
            $metadata: deserializeMetadata(output),
            BucketKeyEnabled: void 0,
            ETag: void 0,
            RequestCharged: void 0,
            SSECustomerAlgorithm: void 0,
            SSECustomerKeyMD5: void 0,
            SSEKMSKeyId: void 0,
            ServerSideEncryption: void 0
          };
          if (output.headers["x-amz-server-side-encryption"] !== void 0) {
            contents.ServerSideEncryption = output.headers["x-amz-server-side-encryption"];
          }
          if (output.headers["etag"] !== void 0) {
            contents.ETag = output.headers["etag"];
          }
          if (output.headers["x-amz-server-side-encryption-customer-algorithm"] !== void 0) {
            contents.SSECustomerAlgorithm = output.headers["x-amz-server-side-encryption-customer-algorithm"];
          }
          if (output.headers["x-amz-server-side-encryption-customer-key-md5"] !== void 0) {
            contents.SSECustomerKeyMD5 = output.headers["x-amz-server-side-encryption-customer-key-md5"];
          }
          if (output.headers["x-amz-server-side-encryption-aws-kms-key-id"] !== void 0) {
            contents.SSEKMSKeyId = output.headers["x-amz-server-side-encryption-aws-kms-key-id"];
          }
          if (output.headers["x-amz-server-side-encryption-bucket-key-enabled"] !== void 0) {
            contents.BucketKeyEnabled = output.headers["x-amz-server-side-encryption-bucket-key-enabled"] === "true";
          }
          if (output.headers["x-amz-request-charged"] !== void 0) {
            contents.RequestCharged = output.headers["x-amz-request-charged"];
          }
          return [4, collectBody(output.body, context)];
        case 1:
          _a.sent();
          return [2, Promise.resolve(contents)];
      }
    });
  });
};
var deserializeAws_restXmlUploadPartCommandError = function(output, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var parsedOutput, _a, response, errorCode, parsedBody, message;
    var _b;
    return __generator$3(this, function(_c) {
      switch (_c.label) {
        case 0:
          _a = [__assign$4({}, output)];
          _b = {};
          return [4, parseBody(output.body, context)];
        case 1:
          parsedOutput = __assign$4.apply(void 0, _a.concat([(_b.body = _c.sent(), _b)]));
          errorCode = "UnknownError";
          errorCode = loadRestXmlErrorCode(output, parsedOutput.body);
          switch (errorCode) {
            default:
              parsedBody = parsedOutput.body;
              errorCode = parsedBody.code || parsedBody.Code || errorCode;
              response = __assign$4(__assign$4({}, parsedBody), { name: "" + errorCode, message: parsedBody.message || parsedBody.Message || errorCode, $fault: "client", $metadata: deserializeMetadata(output) });
          }
          message = response.message || response.Message || errorCode;
          response.message = message;
          delete response.Message;
          return [2, Promise.reject(Object.assign(new Error(message), response))];
      }
    });
  });
};
var deserializeAws_restXmlInvalidObjectStateResponse = function(parsedOutput, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var contents, data;
    return __generator$3(this, function(_a) {
      contents = {
        name: "InvalidObjectState",
        $fault: "client",
        $metadata: deserializeMetadata(parsedOutput),
        AccessTier: void 0,
        StorageClass: void 0
      };
      data = parsedOutput.body;
      if (data["AccessTier"] !== void 0) {
        contents.AccessTier = data["AccessTier"];
      }
      if (data["StorageClass"] !== void 0) {
        contents.StorageClass = data["StorageClass"];
      }
      return [2, contents];
    });
  });
};
var deserializeAws_restXmlNoSuchBucketResponse = function(parsedOutput, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var contents;
    return __generator$3(this, function(_a) {
      contents = {
        name: "NoSuchBucket",
        $fault: "client",
        $metadata: deserializeMetadata(parsedOutput)
      };
      parsedOutput.body;
      return [2, contents];
    });
  });
};
var deserializeAws_restXmlNoSuchKeyResponse = function(parsedOutput, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var contents;
    return __generator$3(this, function(_a) {
      contents = {
        name: "NoSuchKey",
        $fault: "client",
        $metadata: deserializeMetadata(parsedOutput)
      };
      parsedOutput.body;
      return [2, contents];
    });
  });
};
var deserializeAws_restXmlNoSuchUploadResponse = function(parsedOutput, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var contents;
    return __generator$3(this, function(_a) {
      contents = {
        name: "NoSuchUpload",
        $fault: "client",
        $metadata: deserializeMetadata(parsedOutput)
      };
      parsedOutput.body;
      return [2, contents];
    });
  });
};
var deserializeAws_restXmlObjectNotInActiveTierErrorResponse = function(parsedOutput, context) {
  return __awaiter$3(void 0, void 0, void 0, function() {
    var contents;
    return __generator$3(this, function(_a) {
      contents = {
        name: "ObjectNotInActiveTierError",
        $fault: "client",
        $metadata: deserializeMetadata(parsedOutput)
      };
      parsedOutput.body;
      return [2, contents];
    });
  });
};
var serializeAws_restXmlCompletedMultipartUpload = function(input, context) {
  var bodyNode = new XmlNode("CompletedMultipartUpload");
  if (input.Parts !== void 0 && input.Parts !== null) {
    var nodes = serializeAws_restXmlCompletedPartList(input.Parts);
    nodes.map(function(node) {
      node = node.withName("Part");
      bodyNode.addChildNode(node);
    });
  }
  return bodyNode;
};
var serializeAws_restXmlCompletedPart = function(input, context) {
  var bodyNode = new XmlNode("CompletedPart");
  if (input.ETag !== void 0 && input.ETag !== null) {
    var node = new XmlNode("ETag").addChildNode(new XmlText(input.ETag)).withName("ETag");
    bodyNode.addChildNode(node);
  }
  if (input.PartNumber !== void 0 && input.PartNumber !== null) {
    var node = new XmlNode("PartNumber").addChildNode(new XmlText(String(input.PartNumber))).withName("PartNumber");
    bodyNode.addChildNode(node);
  }
  return bodyNode;
};
var serializeAws_restXmlCompletedPartList = function(input, context) {
  return input.filter(function(e) {
    return e != null;
  }).map(function(entry) {
    if (entry === null) {
      return null;
    }
    var node = serializeAws_restXmlCompletedPart(entry);
    return node.withName("member");
  });
};
var deserializeAws_restXmlCommonPrefix = function(output, context) {
  var contents = {
    Prefix: void 0
  };
  if (output["Prefix"] !== void 0) {
    contents.Prefix = output["Prefix"];
  }
  return contents;
};
var deserializeAws_restXmlCommonPrefixList = function(output, context) {
  return (output || []).filter(function(e) {
    return e != null;
  }).map(function(entry) {
    if (entry === null) {
      return null;
    }
    return deserializeAws_restXmlCommonPrefix(entry);
  });
};
var deserializeAws_restXmlCopyObjectResult = function(output, context) {
  var contents = {
    ETag: void 0,
    LastModified: void 0
  };
  if (output["ETag"] !== void 0) {
    contents.ETag = output["ETag"];
  }
  if (output["LastModified"] !== void 0) {
    contents.LastModified = new Date(output["LastModified"]);
  }
  return contents;
};
var deserializeAws_restXmlInitiator = function(output, context) {
  var contents = {
    ID: void 0,
    DisplayName: void 0
  };
  if (output["ID"] !== void 0) {
    contents.ID = output["ID"];
  }
  if (output["DisplayName"] !== void 0) {
    contents.DisplayName = output["DisplayName"];
  }
  return contents;
};
var deserializeAws_restXml_Object = function(output, context) {
  var contents = {
    Key: void 0,
    LastModified: void 0,
    ETag: void 0,
    Size: void 0,
    StorageClass: void 0,
    Owner: void 0
  };
  if (output["Key"] !== void 0) {
    contents.Key = output["Key"];
  }
  if (output["LastModified"] !== void 0) {
    contents.LastModified = new Date(output["LastModified"]);
  }
  if (output["ETag"] !== void 0) {
    contents.ETag = output["ETag"];
  }
  if (output["Size"] !== void 0) {
    contents.Size = parseInt(output["Size"]);
  }
  if (output["StorageClass"] !== void 0) {
    contents.StorageClass = output["StorageClass"];
  }
  if (output["Owner"] !== void 0) {
    contents.Owner = deserializeAws_restXmlOwner(output["Owner"]);
  }
  return contents;
};
var deserializeAws_restXmlObjectList = function(output, context) {
  return (output || []).filter(function(e) {
    return e != null;
  }).map(function(entry) {
    if (entry === null) {
      return null;
    }
    return deserializeAws_restXml_Object(entry);
  });
};
var deserializeAws_restXmlOwner = function(output, context) {
  var contents = {
    DisplayName: void 0,
    ID: void 0
  };
  if (output["DisplayName"] !== void 0) {
    contents.DisplayName = output["DisplayName"];
  }
  if (output["ID"] !== void 0) {
    contents.ID = output["ID"];
  }
  return contents;
};
var deserializeAws_restXmlPart = function(output, context) {
  var contents = {
    PartNumber: void 0,
    LastModified: void 0,
    ETag: void 0,
    Size: void 0
  };
  if (output["PartNumber"] !== void 0) {
    contents.PartNumber = parseInt(output["PartNumber"]);
  }
  if (output["LastModified"] !== void 0) {
    contents.LastModified = new Date(output["LastModified"]);
  }
  if (output["ETag"] !== void 0) {
    contents.ETag = output["ETag"];
  }
  if (output["Size"] !== void 0) {
    contents.Size = parseInt(output["Size"]);
  }
  return contents;
};
var deserializeAws_restXmlParts = function(output, context) {
  return (output || []).filter(function(e) {
    return e != null;
  }).map(function(entry) {
    if (entry === null) {
      return null;
    }
    return deserializeAws_restXmlPart(entry);
  });
};
var deserializeMetadata = function(output) {
  var _a;
  return {
    httpStatusCode: output.statusCode,
    requestId: (_a = output.headers["x-amzn-requestid"]) !== null && _a !== void 0 ? _a : output.headers["x-amzn-request-id"],
    extendedRequestId: output.headers["x-amz-id-2"],
    cfId: output.headers["x-amz-cf-id"]
  };
};
var collectBody = function(streamBody, context) {
  if (streamBody === void 0) {
    streamBody = new Uint8Array();
  }
  if (streamBody instanceof Uint8Array) {
    return Promise.resolve(streamBody);
  }
  return context.streamCollector(streamBody) || Promise.resolve(new Uint8Array());
};
var collectBodyString = function(streamBody, context) {
  return collectBody(streamBody, context).then(function(body) {
    return context.utf8Encoder(body);
  });
};
var isSerializableHeaderValue = function(value) {
  return value !== void 0 && value !== null && value !== "" && (!Object.getOwnPropertyNames(value).includes("length") || value.length != 0) && (!Object.getOwnPropertyNames(value).includes("size") || value.size != 0);
};
var decodeEscapedXML = function(str) {
  return str.replace(/&amp;/g, "&").replace(/&apos;/g, "'").replace(/&quot;/g, '"').replace(/&gt;/g, ">").replace(/&lt;/g, "<");
};
var parseBody = function(streamBody, context) {
  return collectBodyString(streamBody, context).then(function(encoded) {
    if (encoded.length) {
      var parsedObj = parser.parse(encoded, {
        attributeNamePrefix: "",
        ignoreAttributes: false,
        parseNodeValue: false,
        tagValueProcessor: function(val, tagName) {
          return decodeEscapedXML(val);
        }
      });
      var textNodeName = "#text";
      var key = Object.keys(parsedObj)[0];
      var parsedObjToReturn = parsedObj[key];
      if (parsedObjToReturn[textNodeName]) {
        parsedObjToReturn[key] = parsedObjToReturn[textNodeName];
        delete parsedObjToReturn[textNodeName];
      }
      return getValueFromTextNode(parsedObjToReturn);
    }
    return {};
  });
};
var loadRestXmlErrorCode = function(output, data) {
  if (data.Code !== void 0) {
    return data.Code;
  }
  if (output.statusCode == 404) {
    return "NotFound";
  }
  return "";
};
var AbortMultipartUploadCommand = function(_super) {
  __extends(AbortMultipartUploadCommand2, _super);
  function AbortMultipartUploadCommand2(input) {
    var _this = _super.call(this) || this;
    _this.input = input;
    return _this;
  }
  AbortMultipartUploadCommand2.prototype.resolveMiddleware = function(clientStack, configuration, options) {
    this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
    this.middlewareStack.use(getBucketEndpointPlugin(configuration));
    var stack = clientStack.concat(this.middlewareStack);
    var logger2 = configuration.logger;
    var clientName = "S3Client";
    var commandName = "AbortMultipartUploadCommand";
    var handlerExecutionContext = {
      logger: logger2,
      clientName,
      commandName,
      inputFilterSensitiveLog: AbortMultipartUploadRequest.filterSensitiveLog,
      outputFilterSensitiveLog: AbortMultipartUploadOutput.filterSensitiveLog
    };
    var requestHandler = configuration.requestHandler;
    return stack.resolve(function(request) {
      return requestHandler.handle(request.request, options || {});
    }, handlerExecutionContext);
  };
  AbortMultipartUploadCommand2.prototype.serialize = function(input, context) {
    return serializeAws_restXmlAbortMultipartUploadCommand(input, context);
  };
  AbortMultipartUploadCommand2.prototype.deserialize = function(output, context) {
    return deserializeAws_restXmlAbortMultipartUploadCommand(output, context);
  };
  return AbortMultipartUploadCommand2;
}(Command);
var CompleteMultipartUploadCommand = function(_super) {
  __extends(CompleteMultipartUploadCommand2, _super);
  function CompleteMultipartUploadCommand2(input) {
    var _this = _super.call(this) || this;
    _this.input = input;
    return _this;
  }
  CompleteMultipartUploadCommand2.prototype.resolveMiddleware = function(clientStack, configuration, options) {
    this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
    this.middlewareStack.use(getThrow200ExceptionsPlugin(configuration));
    this.middlewareStack.use(getBucketEndpointPlugin(configuration));
    var stack = clientStack.concat(this.middlewareStack);
    var logger2 = configuration.logger;
    var clientName = "S3Client";
    var commandName = "CompleteMultipartUploadCommand";
    var handlerExecutionContext = {
      logger: logger2,
      clientName,
      commandName,
      inputFilterSensitiveLog: CompleteMultipartUploadRequest.filterSensitiveLog,
      outputFilterSensitiveLog: CompleteMultipartUploadOutput.filterSensitiveLog
    };
    var requestHandler = configuration.requestHandler;
    return stack.resolve(function(request) {
      return requestHandler.handle(request.request, options || {});
    }, handlerExecutionContext);
  };
  CompleteMultipartUploadCommand2.prototype.serialize = function(input, context) {
    return serializeAws_restXmlCompleteMultipartUploadCommand(input, context);
  };
  CompleteMultipartUploadCommand2.prototype.deserialize = function(output, context) {
    return deserializeAws_restXmlCompleteMultipartUploadCommand(output, context);
  };
  return CompleteMultipartUploadCommand2;
}(Command);
function ssecMiddleware(options) {
  var _this = this;
  return function(next) {
    return function(args) {
      return tslib.exports.__awaiter(_this, void 0, void 0, function() {
        var input, properties, properties_1, properties_1_1, prop, value, valueView, encoded, hash, _a, _b, _c, _d, e_1_1;
        var e_1, _e2, _f;
        return tslib.exports.__generator(this, function(_g) {
          switch (_g.label) {
            case 0:
              input = tslib.exports.__assign({}, args.input);
              properties = [
                {
                  target: "SSECustomerKey",
                  hash: "SSECustomerKeyMD5"
                },
                {
                  target: "CopySourceSSECustomerKey",
                  hash: "CopySourceSSECustomerKeyMD5"
                }
              ];
              _g.label = 1;
            case 1:
              _g.trys.push([1, 6, 7, 8]);
              properties_1 = tslib.exports.__values(properties), properties_1_1 = properties_1.next();
              _g.label = 2;
            case 2:
              if (!!properties_1_1.done)
                return [3, 5];
              prop = properties_1_1.value;
              value = input[prop.target];
              if (!value)
                return [3, 4];
              valueView = ArrayBuffer.isView(value) ? new Uint8Array(value.buffer, value.byteOffset, value.byteLength) : typeof value === "string" ? options.utf8Decoder(value) : new Uint8Array(value);
              encoded = options.base64Encoder(valueView);
              hash = new options.md5();
              hash.update(valueView);
              _a = [tslib.exports.__assign({}, input)];
              _f = {}, _f[prop.target] = encoded;
              _b = prop.hash;
              _d = (_c = options).base64Encoder;
              return [4, hash.digest()];
            case 3:
              input = tslib.exports.__assign.apply(void 0, _a.concat([(_f[_b] = _d.apply(_c, [_g.sent()]), _f)]));
              _g.label = 4;
            case 4:
              properties_1_1 = properties_1.next();
              return [3, 2];
            case 5:
              return [3, 8];
            case 6:
              e_1_1 = _g.sent();
              e_1 = { error: e_1_1 };
              return [3, 8];
            case 7:
              try {
                if (properties_1_1 && !properties_1_1.done && (_e2 = properties_1.return))
                  _e2.call(properties_1);
              } finally {
                if (e_1)
                  throw e_1.error;
              }
              return [7];
            case 8:
              return [2, next(tslib.exports.__assign(tslib.exports.__assign({}, args), { input }))];
          }
        });
      });
    };
  };
}
var ssecMiddlewareOptions = {
  name: "ssecMiddleware",
  step: "initialize",
  tags: ["SSE"],
  override: true
};
var getSsecPlugin = function(config) {
  return {
    applyToStack: function(clientStack) {
      clientStack.add(ssecMiddleware(config), ssecMiddlewareOptions);
    }
  };
};
var CopyObjectCommand = function(_super) {
  __extends(CopyObjectCommand2, _super);
  function CopyObjectCommand2(input) {
    var _this = _super.call(this) || this;
    _this.input = input;
    return _this;
  }
  CopyObjectCommand2.prototype.resolveMiddleware = function(clientStack, configuration, options) {
    this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
    this.middlewareStack.use(getThrow200ExceptionsPlugin(configuration));
    this.middlewareStack.use(getSsecPlugin(configuration));
    this.middlewareStack.use(getBucketEndpointPlugin(configuration));
    var stack = clientStack.concat(this.middlewareStack);
    var logger2 = configuration.logger;
    var clientName = "S3Client";
    var commandName = "CopyObjectCommand";
    var handlerExecutionContext = {
      logger: logger2,
      clientName,
      commandName,
      inputFilterSensitiveLog: CopyObjectRequest.filterSensitiveLog,
      outputFilterSensitiveLog: CopyObjectOutput.filterSensitiveLog
    };
    var requestHandler = configuration.requestHandler;
    return stack.resolve(function(request) {
      return requestHandler.handle(request.request, options || {});
    }, handlerExecutionContext);
  };
  CopyObjectCommand2.prototype.serialize = function(input, context) {
    return serializeAws_restXmlCopyObjectCommand(input, context);
  };
  CopyObjectCommand2.prototype.deserialize = function(output, context) {
    return deserializeAws_restXmlCopyObjectCommand(output, context);
  };
  return CopyObjectCommand2;
}(Command);
var CreateMultipartUploadCommand = function(_super) {
  __extends(CreateMultipartUploadCommand2, _super);
  function CreateMultipartUploadCommand2(input) {
    var _this = _super.call(this) || this;
    _this.input = input;
    return _this;
  }
  CreateMultipartUploadCommand2.prototype.resolveMiddleware = function(clientStack, configuration, options) {
    this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
    this.middlewareStack.use(getSsecPlugin(configuration));
    this.middlewareStack.use(getBucketEndpointPlugin(configuration));
    var stack = clientStack.concat(this.middlewareStack);
    var logger2 = configuration.logger;
    var clientName = "S3Client";
    var commandName = "CreateMultipartUploadCommand";
    var handlerExecutionContext = {
      logger: logger2,
      clientName,
      commandName,
      inputFilterSensitiveLog: CreateMultipartUploadRequest.filterSensitiveLog,
      outputFilterSensitiveLog: CreateMultipartUploadOutput.filterSensitiveLog
    };
    var requestHandler = configuration.requestHandler;
    return stack.resolve(function(request) {
      return requestHandler.handle(request.request, options || {});
    }, handlerExecutionContext);
  };
  CreateMultipartUploadCommand2.prototype.serialize = function(input, context) {
    return serializeAws_restXmlCreateMultipartUploadCommand(input, context);
  };
  CreateMultipartUploadCommand2.prototype.deserialize = function(output, context) {
    return deserializeAws_restXmlCreateMultipartUploadCommand(output, context);
  };
  return CreateMultipartUploadCommand2;
}(Command);
var DeleteObjectCommand = function(_super) {
  __extends(DeleteObjectCommand2, _super);
  function DeleteObjectCommand2(input) {
    var _this = _super.call(this) || this;
    _this.input = input;
    return _this;
  }
  DeleteObjectCommand2.prototype.resolveMiddleware = function(clientStack, configuration, options) {
    this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
    this.middlewareStack.use(getBucketEndpointPlugin(configuration));
    var stack = clientStack.concat(this.middlewareStack);
    var logger2 = configuration.logger;
    var clientName = "S3Client";
    var commandName = "DeleteObjectCommand";
    var handlerExecutionContext = {
      logger: logger2,
      clientName,
      commandName,
      inputFilterSensitiveLog: DeleteObjectRequest.filterSensitiveLog,
      outputFilterSensitiveLog: DeleteObjectOutput.filterSensitiveLog
    };
    var requestHandler = configuration.requestHandler;
    return stack.resolve(function(request) {
      return requestHandler.handle(request.request, options || {});
    }, handlerExecutionContext);
  };
  DeleteObjectCommand2.prototype.serialize = function(input, context) {
    return serializeAws_restXmlDeleteObjectCommand(input, context);
  };
  DeleteObjectCommand2.prototype.deserialize = function(output, context) {
    return deserializeAws_restXmlDeleteObjectCommand(output, context);
  };
  return DeleteObjectCommand2;
}(Command);
var GetObjectCommand = function(_super) {
  __extends(GetObjectCommand2, _super);
  function GetObjectCommand2(input) {
    var _this = _super.call(this) || this;
    _this.input = input;
    return _this;
  }
  GetObjectCommand2.prototype.resolveMiddleware = function(clientStack, configuration, options) {
    this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
    this.middlewareStack.use(getSsecPlugin(configuration));
    this.middlewareStack.use(getBucketEndpointPlugin(configuration));
    var stack = clientStack.concat(this.middlewareStack);
    var logger2 = configuration.logger;
    var clientName = "S3Client";
    var commandName = "GetObjectCommand";
    var handlerExecutionContext = {
      logger: logger2,
      clientName,
      commandName,
      inputFilterSensitiveLog: GetObjectRequest.filterSensitiveLog,
      outputFilterSensitiveLog: GetObjectOutput.filterSensitiveLog
    };
    var requestHandler = configuration.requestHandler;
    return stack.resolve(function(request) {
      return requestHandler.handle(request.request, options || {});
    }, handlerExecutionContext);
  };
  GetObjectCommand2.prototype.serialize = function(input, context) {
    return serializeAws_restXmlGetObjectCommand(input, context);
  };
  GetObjectCommand2.prototype.deserialize = function(output, context) {
    return deserializeAws_restXmlGetObjectCommand(output, context);
  };
  return GetObjectCommand2;
}(Command);
var ListObjectsCommand = function(_super) {
  __extends(ListObjectsCommand2, _super);
  function ListObjectsCommand2(input) {
    var _this = _super.call(this) || this;
    _this.input = input;
    return _this;
  }
  ListObjectsCommand2.prototype.resolveMiddleware = function(clientStack, configuration, options) {
    this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
    this.middlewareStack.use(getBucketEndpointPlugin(configuration));
    var stack = clientStack.concat(this.middlewareStack);
    var logger2 = configuration.logger;
    var clientName = "S3Client";
    var commandName = "ListObjectsCommand";
    var handlerExecutionContext = {
      logger: logger2,
      clientName,
      commandName,
      inputFilterSensitiveLog: ListObjectsRequest.filterSensitiveLog,
      outputFilterSensitiveLog: ListObjectsOutput.filterSensitiveLog
    };
    var requestHandler = configuration.requestHandler;
    return stack.resolve(function(request) {
      return requestHandler.handle(request.request, options || {});
    }, handlerExecutionContext);
  };
  ListObjectsCommand2.prototype.serialize = function(input, context) {
    return serializeAws_restXmlListObjectsCommand(input, context);
  };
  ListObjectsCommand2.prototype.deserialize = function(output, context) {
    return deserializeAws_restXmlListObjectsCommand(output, context);
  };
  return ListObjectsCommand2;
}(Command);
var ListPartsCommand = function(_super) {
  __extends(ListPartsCommand2, _super);
  function ListPartsCommand2(input) {
    var _this = _super.call(this) || this;
    _this.input = input;
    return _this;
  }
  ListPartsCommand2.prototype.resolveMiddleware = function(clientStack, configuration, options) {
    this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
    this.middlewareStack.use(getBucketEndpointPlugin(configuration));
    var stack = clientStack.concat(this.middlewareStack);
    var logger2 = configuration.logger;
    var clientName = "S3Client";
    var commandName = "ListPartsCommand";
    var handlerExecutionContext = {
      logger: logger2,
      clientName,
      commandName,
      inputFilterSensitiveLog: ListPartsRequest.filterSensitiveLog,
      outputFilterSensitiveLog: ListPartsOutput.filterSensitiveLog
    };
    var requestHandler = configuration.requestHandler;
    return stack.resolve(function(request) {
      return requestHandler.handle(request.request, options || {});
    }, handlerExecutionContext);
  };
  ListPartsCommand2.prototype.serialize = function(input, context) {
    return serializeAws_restXmlListPartsCommand(input, context);
  };
  ListPartsCommand2.prototype.deserialize = function(output, context) {
    return deserializeAws_restXmlListPartsCommand(output, context);
  };
  return ListPartsCommand2;
}(Command);
var PutObjectCommand = function(_super) {
  __extends(PutObjectCommand2, _super);
  function PutObjectCommand2(input) {
    var _this = _super.call(this) || this;
    _this.input = input;
    return _this;
  }
  PutObjectCommand2.prototype.resolveMiddleware = function(clientStack, configuration, options) {
    this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
    this.middlewareStack.use(getSsecPlugin(configuration));
    this.middlewareStack.use(getBucketEndpointPlugin(configuration));
    var stack = clientStack.concat(this.middlewareStack);
    var logger2 = configuration.logger;
    var clientName = "S3Client";
    var commandName = "PutObjectCommand";
    var handlerExecutionContext = {
      logger: logger2,
      clientName,
      commandName,
      inputFilterSensitiveLog: PutObjectRequest.filterSensitiveLog,
      outputFilterSensitiveLog: PutObjectOutput.filterSensitiveLog
    };
    var requestHandler = configuration.requestHandler;
    return stack.resolve(function(request) {
      return requestHandler.handle(request.request, options || {});
    }, handlerExecutionContext);
  };
  PutObjectCommand2.prototype.serialize = function(input, context) {
    return serializeAws_restXmlPutObjectCommand(input, context);
  };
  PutObjectCommand2.prototype.deserialize = function(output, context) {
    return deserializeAws_restXmlPutObjectCommand(output, context);
  };
  return PutObjectCommand2;
}(Command);
var MetadataEntry;
(function(MetadataEntry2) {
  MetadataEntry2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(MetadataEntry || (MetadataEntry = {}));
var S3Location;
(function(S3Location2) {
  S3Location2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.Encryption && { Encryption: Encryption.filterSensitiveLog(obj.Encryption) });
  };
})(S3Location || (S3Location = {}));
var OutputLocation;
(function(OutputLocation2) {
  OutputLocation2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.S3 && { S3: S3Location.filterSensitiveLog(obj.S3) });
  };
})(OutputLocation || (OutputLocation = {}));
var FileHeaderInfo;
(function(FileHeaderInfo2) {
  FileHeaderInfo2["IGNORE"] = "IGNORE";
  FileHeaderInfo2["NONE"] = "NONE";
  FileHeaderInfo2["USE"] = "USE";
})(FileHeaderInfo || (FileHeaderInfo = {}));
var CSVInput;
(function(CSVInput2) {
  CSVInput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(CSVInput || (CSVInput = {}));
var JSONType;
(function(JSONType2) {
  JSONType2["DOCUMENT"] = "DOCUMENT";
  JSONType2["LINES"] = "LINES";
})(JSONType || (JSONType = {}));
var JSONInput;
(function(JSONInput2) {
  JSONInput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(JSONInput || (JSONInput = {}));
var ParquetInput;
(function(ParquetInput2) {
  ParquetInput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ParquetInput || (ParquetInput = {}));
var InputSerialization;
(function(InputSerialization2) {
  InputSerialization2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(InputSerialization || (InputSerialization = {}));
var QuoteFields;
(function(QuoteFields2) {
  QuoteFields2["ALWAYS"] = "ALWAYS";
  QuoteFields2["ASNEEDED"] = "ASNEEDED";
})(QuoteFields || (QuoteFields = {}));
var CSVOutput;
(function(CSVOutput2) {
  CSVOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(CSVOutput || (CSVOutput = {}));
var JSONOutput;
(function(JSONOutput2) {
  JSONOutput2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(JSONOutput || (JSONOutput = {}));
var OutputSerialization;
(function(OutputSerialization2) {
  OutputSerialization2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(OutputSerialization || (OutputSerialization = {}));
var SelectParameters;
(function(SelectParameters2) {
  SelectParameters2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(SelectParameters || (SelectParameters = {}));
var RestoreRequestType;
(function(RestoreRequestType2) {
  RestoreRequestType2["SELECT"] = "SELECT";
})(RestoreRequestType || (RestoreRequestType = {}));
var RestoreRequest;
(function(RestoreRequest2) {
  RestoreRequest2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.OutputLocation && { OutputLocation: OutputLocation.filterSensitiveLog(obj.OutputLocation) });
  };
})(RestoreRequest || (RestoreRequest = {}));
var RestoreObjectRequest;
(function(RestoreObjectRequest2) {
  RestoreObjectRequest2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.RestoreRequest && { RestoreRequest: RestoreRequest.filterSensitiveLog(obj.RestoreRequest) });
  };
})(RestoreObjectRequest || (RestoreObjectRequest = {}));
var ContinuationEvent;
(function(ContinuationEvent2) {
  ContinuationEvent2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ContinuationEvent || (ContinuationEvent = {}));
var EndEvent;
(function(EndEvent2) {
  EndEvent2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(EndEvent || (EndEvent = {}));
var Progress;
(function(Progress2) {
  Progress2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(Progress || (Progress = {}));
var ProgressEvent;
(function(ProgressEvent2) {
  ProgressEvent2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ProgressEvent || (ProgressEvent = {}));
var RecordsEvent;
(function(RecordsEvent2) {
  RecordsEvent2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(RecordsEvent || (RecordsEvent = {}));
var Stats;
(function(Stats2) {
  Stats2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(Stats || (Stats = {}));
var StatsEvent;
(function(StatsEvent2) {
  StatsEvent2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(StatsEvent || (StatsEvent = {}));
var SelectObjectContentEventStream;
(function(SelectObjectContentEventStream2) {
  SelectObjectContentEventStream2.visit = function(value, visitor) {
    if (value.Records !== void 0)
      return visitor.Records(value.Records);
    if (value.Stats !== void 0)
      return visitor.Stats(value.Stats);
    if (value.Progress !== void 0)
      return visitor.Progress(value.Progress);
    if (value.Cont !== void 0)
      return visitor.Cont(value.Cont);
    if (value.End !== void 0)
      return visitor.End(value.End);
    return visitor._(value.$unknown[0], value.$unknown[1]);
  };
  SelectObjectContentEventStream2.filterSensitiveLog = function(obj) {
    var _a;
    if (obj.Records !== void 0)
      return { Records: RecordsEvent.filterSensitiveLog(obj.Records) };
    if (obj.Stats !== void 0)
      return { Stats: StatsEvent.filterSensitiveLog(obj.Stats) };
    if (obj.Progress !== void 0)
      return { Progress: ProgressEvent.filterSensitiveLog(obj.Progress) };
    if (obj.Cont !== void 0)
      return { Cont: ContinuationEvent.filterSensitiveLog(obj.Cont) };
    if (obj.End !== void 0)
      return { End: EndEvent.filterSensitiveLog(obj.End) };
    if (obj.$unknown !== void 0)
      return _a = {}, _a[obj.$unknown[0]] = "UNKNOWN", _a;
  };
})(SelectObjectContentEventStream || (SelectObjectContentEventStream = {}));
var SelectObjectContentOutput;
(function(SelectObjectContentOutput2) {
  SelectObjectContentOutput2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.Payload && { Payload: "STREAMING_CONTENT" });
  };
})(SelectObjectContentOutput || (SelectObjectContentOutput = {}));
var RequestProgress;
(function(RequestProgress2) {
  RequestProgress2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(RequestProgress || (RequestProgress = {}));
var ScanRange;
(function(ScanRange2) {
  ScanRange2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(ScanRange || (ScanRange = {}));
var SelectObjectContentRequest;
(function(SelectObjectContentRequest2) {
  SelectObjectContentRequest2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.SSECustomerKey && { SSECustomerKey: SENSITIVE_STRING });
  };
})(SelectObjectContentRequest || (SelectObjectContentRequest = {}));
var UploadPartOutput;
(function(UploadPartOutput2) {
  UploadPartOutput2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.SSEKMSKeyId && { SSEKMSKeyId: SENSITIVE_STRING });
  };
})(UploadPartOutput || (UploadPartOutput = {}));
var UploadPartRequest;
(function(UploadPartRequest2) {
  UploadPartRequest2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.SSECustomerKey && { SSECustomerKey: SENSITIVE_STRING });
  };
})(UploadPartRequest || (UploadPartRequest = {}));
var CopyPartResult;
(function(CopyPartResult2) {
  CopyPartResult2.filterSensitiveLog = function(obj) {
    return __assign$4({}, obj);
  };
})(CopyPartResult || (CopyPartResult = {}));
var UploadPartCopyOutput;
(function(UploadPartCopyOutput2) {
  UploadPartCopyOutput2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4({}, obj), obj.SSEKMSKeyId && { SSEKMSKeyId: SENSITIVE_STRING });
  };
})(UploadPartCopyOutput || (UploadPartCopyOutput = {}));
var UploadPartCopyRequest;
(function(UploadPartCopyRequest2) {
  UploadPartCopyRequest2.filterSensitiveLog = function(obj) {
    return __assign$4(__assign$4(__assign$4({}, obj), obj.SSECustomerKey && { SSECustomerKey: SENSITIVE_STRING }), obj.CopySourceSSECustomerKey && { CopySourceSSECustomerKey: SENSITIVE_STRING });
  };
})(UploadPartCopyRequest || (UploadPartCopyRequest = {}));
var UploadPartCommand = function(_super) {
  __extends(UploadPartCommand2, _super);
  function UploadPartCommand2(input) {
    var _this = _super.call(this) || this;
    _this.input = input;
    return _this;
  }
  UploadPartCommand2.prototype.resolveMiddleware = function(clientStack, configuration, options) {
    this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
    this.middlewareStack.use(getSsecPlugin(configuration));
    this.middlewareStack.use(getBucketEndpointPlugin(configuration));
    var stack = clientStack.concat(this.middlewareStack);
    var logger2 = configuration.logger;
    var clientName = "S3Client";
    var commandName = "UploadPartCommand";
    var handlerExecutionContext = {
      logger: logger2,
      clientName,
      commandName,
      inputFilterSensitiveLog: UploadPartRequest.filterSensitiveLog,
      outputFilterSensitiveLog: UploadPartOutput.filterSensitiveLog
    };
    var requestHandler = configuration.requestHandler;
    return stack.resolve(function(request) {
      return requestHandler.handle(request.request, options || {});
    }, handlerExecutionContext);
  };
  UploadPartCommand2.prototype.serialize = function(input, context) {
    return serializeAws_restXmlUploadPartCommand(input, context);
  };
  UploadPartCommand2.prototype.deserialize = function(output, context) {
    return deserializeAws_restXmlUploadPartCommand(output, context);
  };
  return UploadPartCommand2;
}(Command);
function formatUrl(request) {
  var port = request.port, query = request.query;
  var protocol = request.protocol, path = request.path, hostname = request.hostname;
  if (protocol && protocol.substr(-1) !== ":") {
    protocol += ":";
  }
  if (port) {
    hostname += ":" + port;
  }
  if (path && path.charAt(0) !== "/") {
    path = "/" + path;
  }
  var queryString = query ? buildQueryString(query) : "";
  if (queryString && queryString[0] !== "?") {
    queryString = "?" + queryString;
  }
  return protocol + "//" + hostname + path + queryString;
}
function createRequest(client, command) {
  return tslib.exports.__awaiter(this, void 0, void 0, function() {
    var interceptMiddleware, clientStack, handler;
    var _this = this;
    return tslib.exports.__generator(this, function(_a) {
      switch (_a.label) {
        case 0:
          interceptMiddleware = function(next) {
            return function(args) {
              return tslib.exports.__awaiter(_this, void 0, void 0, function() {
                return tslib.exports.__generator(this, function(_a2) {
                  return [2, { output: { request: args.request }, response: void 0 }];
                });
              });
            };
          };
          clientStack = client.middlewareStack.clone();
          clientStack.add(interceptMiddleware, {
            step: "build",
            priority: "low"
          });
          handler = command.resolveMiddleware(clientStack, client.config, void 0);
          return [4, handler(command).then(function(output) {
            return output.output.request;
          })];
        case 1:
          return [2, _a.sent()];
      }
    });
  });
}
var UNSIGNED_PAYLOAD = "UNSIGNED-PAYLOAD";
var SHA256_HEADER = "X-Amz-Content-Sha256";
var S3RequestPresigner = function() {
  function S3RequestPresigner2(options) {
    var resolvedOptions = tslib.exports.__assign({
      service: options.signingName || options.service || "s3",
      uriEscapePath: options.uriEscapePath || false
    }, options);
    this.signer = new SignatureV4(resolvedOptions);
  }
  S3RequestPresigner2.prototype.presign = function(requestToSign, _a) {
    if (_a === void 0) {
      _a = {};
    }
    var _b = _a.unsignableHeaders, unsignableHeaders = _b === void 0 ? /* @__PURE__ */ new Set() : _b, _c = _a.unhoistableHeaders, unhoistableHeaders = _c === void 0 ? /* @__PURE__ */ new Set() : _c, options = tslib.exports.__rest(_a, ["unsignableHeaders", "unhoistableHeaders"]);
    return tslib.exports.__awaiter(this, void 0, void 0, function() {
      return tslib.exports.__generator(this, function(_d) {
        unsignableHeaders.add("content-type");
        Object.keys(requestToSign.headers).map(function(header) {
          return header.toLowerCase();
        }).filter(function(header) {
          return header.startsWith("x-amz-server-side-encryption");
        }).forEach(function(header) {
          unhoistableHeaders.add(header);
        });
        requestToSign.headers[SHA256_HEADER] = UNSIGNED_PAYLOAD;
        if (!requestToSign.headers["host"]) {
          requestToSign.headers.host = requestToSign.hostname;
        }
        return [2, this.signer.presign(requestToSign, tslib.exports.__assign({
          expiresIn: 900,
          unsignableHeaders,
          unhoistableHeaders
        }, options))];
      });
    });
  };
  return S3RequestPresigner2;
}();
var __values = globalThis && globalThis.__values || function(o) {
  var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
  if (m)
    return m.call(o);
  if (o && typeof o.length === "number")
    return {
      next: function() {
        if (o && i >= o.length)
          o = void 0;
        return { value: o && o[i++], done: !o };
      }
    };
  throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var __read$1 = globalThis && globalThis.__read || function(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m)
    return o;
  var i = m.call(o), r, ar = [], e;
  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
      ar.push(r.value);
  } catch (error) {
    e = { error };
  } finally {
    try {
      if (r && !r.done && (m = i["return"]))
        m.call(i);
    } finally {
      if (e)
        throw e.error;
    }
  }
  return ar;
};
var logger$4 = new ConsoleLogger("axios-http-handler");
var SEND_UPLOAD_PROGRESS_EVENT = "sendUploadProgress";
var SEND_DOWNLOAD_PROGRESS_EVENT = "sendDownloadProgress";
function isBlob(body) {
  return typeof Blob !== "undefined" && body instanceof Blob;
}
var normalizeHeaders = function(headers, normalizedName) {
  var e_1, _a;
  try {
    for (var _b = __values(Object.entries(headers)), _c = _b.next(); !_c.done; _c = _b.next()) {
      var _d = __read$1(_c.value, 2), k = _d[0], v = _d[1];
      if (k !== normalizedName && k.toUpperCase() === normalizedName.toUpperCase()) {
        headers[normalizedName] = v;
        delete headers[k];
      }
    }
  } catch (e_1_1) {
    e_1 = { error: e_1_1 };
  } finally {
    try {
      if (_c && !_c.done && (_a = _b.return))
        _a.call(_b);
    } finally {
      if (e_1)
        throw e_1.error;
    }
  }
};
var reactNativeRequestTransformer = [
  function(data, headers) {
    if (isBlob(data)) {
      normalizeHeaders(headers, "Content-Type");
      normalizeHeaders(headers, "Accept");
      return data;
    }
    return axios.defaults.transformRequest[0].call(null, data, headers);
  }
];
var AxiosHttpHandler = function() {
  function AxiosHttpHandler2(httpOptions, emitter, cancelTokenSource) {
    if (httpOptions === void 0) {
      httpOptions = {};
    }
    this.httpOptions = httpOptions;
    this.emitter = emitter;
    this.cancelTokenSource = cancelTokenSource;
  }
  AxiosHttpHandler2.prototype.destroy = function() {
  };
  AxiosHttpHandler2.prototype.handle = function(request, options) {
    var requestTimeoutInMs = this.httpOptions.requestTimeout;
    var emitter = this.emitter;
    var path = request.path;
    if (request.query) {
      var queryString = buildQueryString(request.query);
      if (queryString) {
        path += "?" + queryString;
      }
    }
    var port = request.port;
    var url = request.protocol + "//" + request.hostname + (port ? ":" + port : "") + path;
    var axiosRequest = {};
    axiosRequest.url = url;
    axiosRequest.method = request.method;
    axiosRequest.headers = request.headers;
    delete axiosRequest.headers["host"];
    if (request.body) {
      axiosRequest.data = request.body;
    } else {
      if (axiosRequest.headers["Content-Type"]) {
        axiosRequest.data = null;
      }
    }
    if (emitter) {
      axiosRequest.onUploadProgress = function(event) {
        emitter.emit(SEND_UPLOAD_PROGRESS_EVENT, event);
        logger$4.debug(event);
      };
      axiosRequest.onDownloadProgress = function(event) {
        emitter.emit(SEND_DOWNLOAD_PROGRESS_EVENT, event);
        logger$4.debug(event);
      };
    }
    if (this.cancelTokenSource) {
      axiosRequest.cancelToken = this.cancelTokenSource.token;
    }
    axiosRequest.responseType = "blob";
    if (Platform.isReactNative) {
      axiosRequest.transformRequest = reactNativeRequestTransformer;
    }
    var raceOfPromises = [
      axios.request(axiosRequest).then(function(response) {
        return {
          response: new HttpResponse({
            headers: response.headers,
            statusCode: response.status,
            body: response.data
          })
        };
      }).catch(function(error) {
        logger$4.error(error.message);
        throw error;
      }),
      requestTimeout(requestTimeoutInMs)
    ];
    return Promise.race(raceOfPromises);
  };
  return AxiosHttpHandler2;
}();
function requestTimeout(timeoutInMs) {
  if (timeoutInMs === void 0) {
    timeoutInMs = 0;
  }
  return new Promise(function(resolve, reject) {
    if (timeoutInMs) {
      setTimeout(function() {
        var timeoutError = new Error("Request did not complete within " + timeoutInMs + " ms");
        timeoutError.name = "TimeoutError";
        reject(timeoutError);
      }, timeoutInMs);
    }
  });
}
var StorageErrorStrings;
(function(StorageErrorStrings2) {
  StorageErrorStrings2["NO_CREDENTIALS"] = "No credentials";
  StorageErrorStrings2["NO_SRC_KEY"] = 'source param should be an object with the property "key" with value of type string';
  StorageErrorStrings2["NO_DEST_KEY"] = 'destination param should be an object with the property "key" with value of type string';
})(StorageErrorStrings || (StorageErrorStrings = {}));
var AWSS3ProviderMultipartCopierErrors;
(function(AWSS3ProviderMultipartCopierErrors2) {
  AWSS3ProviderMultipartCopierErrors2["CLEANUP_FAILED"] = "Multipart copy clean up failed";
  AWSS3ProviderMultipartCopierErrors2["NO_OBJECT_FOUND"] = "Object does not exist";
  AWSS3ProviderMultipartCopierErrors2["INVALID_QUEUESIZE"] = "Queue size must be a positive number";
  AWSS3ProviderMultipartCopierErrors2["NO_COPYSOURCE"] = "You must specify a copy source";
  AWSS3ProviderMultipartCopierErrors2["MAX_NUM_PARTS_EXCEEDED"] = "Only a maximum of 10000 parts are allowed";
})(AWSS3ProviderMultipartCopierErrors || (AWSS3ProviderMultipartCopierErrors = {}));
var events = { exports: {} };
var R = typeof Reflect === "object" ? Reflect : null;
var ReflectApply = R && typeof R.apply === "function" ? R.apply : function ReflectApply2(target, receiver, args) {
  return Function.prototype.apply.call(target, receiver, args);
};
var ReflectOwnKeys;
if (R && typeof R.ownKeys === "function") {
  ReflectOwnKeys = R.ownKeys;
} else if (Object.getOwnPropertySymbols) {
  ReflectOwnKeys = function ReflectOwnKeys2(target) {
    return Object.getOwnPropertyNames(target).concat(Object.getOwnPropertySymbols(target));
  };
} else {
  ReflectOwnKeys = function ReflectOwnKeys2(target) {
    return Object.getOwnPropertyNames(target);
  };
}
function ProcessEmitWarning(warning) {
  if (console && console.warn)
    console.warn(warning);
}
var NumberIsNaN = Number.isNaN || function NumberIsNaN2(value) {
  return value !== value;
};
function EventEmitter() {
  EventEmitter.init.call(this);
}
events.exports = EventEmitter;
events.exports.once = once2;
EventEmitter.EventEmitter = EventEmitter;
EventEmitter.prototype._events = void 0;
EventEmitter.prototype._eventsCount = 0;
EventEmitter.prototype._maxListeners = void 0;
var defaultMaxListeners = 10;
function checkListener(listener) {
  if (typeof listener !== "function") {
    throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof listener);
  }
}
Object.defineProperty(EventEmitter, "defaultMaxListeners", {
  enumerable: true,
  get: function() {
    return defaultMaxListeners;
  },
  set: function(arg) {
    if (typeof arg !== "number" || arg < 0 || NumberIsNaN(arg)) {
      throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + arg + ".");
    }
    defaultMaxListeners = arg;
  }
});
EventEmitter.init = function() {
  if (this._events === void 0 || this._events === Object.getPrototypeOf(this)._events) {
    this._events = /* @__PURE__ */ Object.create(null);
    this._eventsCount = 0;
  }
  this._maxListeners = this._maxListeners || void 0;
};
EventEmitter.prototype.setMaxListeners = function setMaxListeners(n) {
  if (typeof n !== "number" || n < 0 || NumberIsNaN(n)) {
    throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + n + ".");
  }
  this._maxListeners = n;
  return this;
};
function _getMaxListeners(that) {
  if (that._maxListeners === void 0)
    return EventEmitter.defaultMaxListeners;
  return that._maxListeners;
}
EventEmitter.prototype.getMaxListeners = function getMaxListeners() {
  return _getMaxListeners(this);
};
EventEmitter.prototype.emit = function emit(type) {
  var args = [];
  for (var i = 1; i < arguments.length; i++)
    args.push(arguments[i]);
  var doError = type === "error";
  var events2 = this._events;
  if (events2 !== void 0)
    doError = doError && events2.error === void 0;
  else if (!doError)
    return false;
  if (doError) {
    var er;
    if (args.length > 0)
      er = args[0];
    if (er instanceof Error) {
      throw er;
    }
    var err = new Error("Unhandled error." + (er ? " (" + er.message + ")" : ""));
    err.context = er;
    throw err;
  }
  var handler = events2[type];
  if (handler === void 0)
    return false;
  if (typeof handler === "function") {
    ReflectApply(handler, this, args);
  } else {
    var len = handler.length;
    var listeners2 = arrayClone(handler, len);
    for (var i = 0; i < len; ++i)
      ReflectApply(listeners2[i], this, args);
  }
  return true;
};
function _addListener(target, type, listener, prepend) {
  var m;
  var events2;
  var existing;
  checkListener(listener);
  events2 = target._events;
  if (events2 === void 0) {
    events2 = target._events = /* @__PURE__ */ Object.create(null);
    target._eventsCount = 0;
  } else {
    if (events2.newListener !== void 0) {
      target.emit(
        "newListener",
        type,
        listener.listener ? listener.listener : listener
      );
      events2 = target._events;
    }
    existing = events2[type];
  }
  if (existing === void 0) {
    existing = events2[type] = listener;
    ++target._eventsCount;
  } else {
    if (typeof existing === "function") {
      existing = events2[type] = prepend ? [listener, existing] : [existing, listener];
    } else if (prepend) {
      existing.unshift(listener);
    } else {
      existing.push(listener);
    }
    m = _getMaxListeners(target);
    if (m > 0 && existing.length > m && !existing.warned) {
      existing.warned = true;
      var w = new Error("Possible EventEmitter memory leak detected. " + existing.length + " " + String(type) + " listeners added. Use emitter.setMaxListeners() to increase limit");
      w.name = "MaxListenersExceededWarning";
      w.emitter = target;
      w.type = type;
      w.count = existing.length;
      ProcessEmitWarning(w);
    }
  }
  return target;
}
EventEmitter.prototype.addListener = function addListener(type, listener) {
  return _addListener(this, type, listener, false);
};
EventEmitter.prototype.on = EventEmitter.prototype.addListener;
EventEmitter.prototype.prependListener = function prependListener(type, listener) {
  return _addListener(this, type, listener, true);
};
function onceWrapper() {
  if (!this.fired) {
    this.target.removeListener(this.type, this.wrapFn);
    this.fired = true;
    if (arguments.length === 0)
      return this.listener.call(this.target);
    return this.listener.apply(this.target, arguments);
  }
}
function _onceWrap(target, type, listener) {
  var state = { fired: false, wrapFn: void 0, target, type, listener };
  var wrapped = onceWrapper.bind(state);
  wrapped.listener = listener;
  state.wrapFn = wrapped;
  return wrapped;
}
EventEmitter.prototype.once = function once(type, listener) {
  checkListener(listener);
  this.on(type, _onceWrap(this, type, listener));
  return this;
};
EventEmitter.prototype.prependOnceListener = function prependOnceListener(type, listener) {
  checkListener(listener);
  this.prependListener(type, _onceWrap(this, type, listener));
  return this;
};
EventEmitter.prototype.removeListener = function removeListener(type, listener) {
  var list, events2, position, i, originalListener;
  checkListener(listener);
  events2 = this._events;
  if (events2 === void 0)
    return this;
  list = events2[type];
  if (list === void 0)
    return this;
  if (list === listener || list.listener === listener) {
    if (--this._eventsCount === 0)
      this._events = /* @__PURE__ */ Object.create(null);
    else {
      delete events2[type];
      if (events2.removeListener)
        this.emit("removeListener", type, list.listener || listener);
    }
  } else if (typeof list !== "function") {
    position = -1;
    for (i = list.length - 1; i >= 0; i--) {
      if (list[i] === listener || list[i].listener === listener) {
        originalListener = list[i].listener;
        position = i;
        break;
      }
    }
    if (position < 0)
      return this;
    if (position === 0)
      list.shift();
    else {
      spliceOne(list, position);
    }
    if (list.length === 1)
      events2[type] = list[0];
    if (events2.removeListener !== void 0)
      this.emit("removeListener", type, originalListener || listener);
  }
  return this;
};
EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
EventEmitter.prototype.removeAllListeners = function removeAllListeners(type) {
  var listeners2, events2, i;
  events2 = this._events;
  if (events2 === void 0)
    return this;
  if (events2.removeListener === void 0) {
    if (arguments.length === 0) {
      this._events = /* @__PURE__ */ Object.create(null);
      this._eventsCount = 0;
    } else if (events2[type] !== void 0) {
      if (--this._eventsCount === 0)
        this._events = /* @__PURE__ */ Object.create(null);
      else
        delete events2[type];
    }
    return this;
  }
  if (arguments.length === 0) {
    var keys = Object.keys(events2);
    var key;
    for (i = 0; i < keys.length; ++i) {
      key = keys[i];
      if (key === "removeListener")
        continue;
      this.removeAllListeners(key);
    }
    this.removeAllListeners("removeListener");
    this._events = /* @__PURE__ */ Object.create(null);
    this._eventsCount = 0;
    return this;
  }
  listeners2 = events2[type];
  if (typeof listeners2 === "function") {
    this.removeListener(type, listeners2);
  } else if (listeners2 !== void 0) {
    for (i = listeners2.length - 1; i >= 0; i--) {
      this.removeListener(type, listeners2[i]);
    }
  }
  return this;
};
function _listeners(target, type, unwrap) {
  var events2 = target._events;
  if (events2 === void 0)
    return [];
  var evlistener = events2[type];
  if (evlistener === void 0)
    return [];
  if (typeof evlistener === "function")
    return unwrap ? [evlistener.listener || evlistener] : [evlistener];
  return unwrap ? unwrapListeners(evlistener) : arrayClone(evlistener, evlistener.length);
}
EventEmitter.prototype.listeners = function listeners(type) {
  return _listeners(this, type, true);
};
EventEmitter.prototype.rawListeners = function rawListeners(type) {
  return _listeners(this, type, false);
};
EventEmitter.listenerCount = function(emitter, type) {
  if (typeof emitter.listenerCount === "function") {
    return emitter.listenerCount(type);
  } else {
    return listenerCount.call(emitter, type);
  }
};
EventEmitter.prototype.listenerCount = listenerCount;
function listenerCount(type) {
  var events2 = this._events;
  if (events2 !== void 0) {
    var evlistener = events2[type];
    if (typeof evlistener === "function") {
      return 1;
    } else if (evlistener !== void 0) {
      return evlistener.length;
    }
  }
  return 0;
}
EventEmitter.prototype.eventNames = function eventNames() {
  return this._eventsCount > 0 ? ReflectOwnKeys(this._events) : [];
};
function arrayClone(arr, n) {
  var copy = new Array(n);
  for (var i = 0; i < n; ++i)
    copy[i] = arr[i];
  return copy;
}
function spliceOne(list, index) {
  for (; index + 1 < list.length; index++)
    list[index] = list[index + 1];
  list.pop();
}
function unwrapListeners(arr) {
  var ret = new Array(arr.length);
  for (var i = 0; i < ret.length; ++i) {
    ret[i] = arr[i].listener || arr[i];
  }
  return ret;
}
function once2(emitter, name2) {
  return new Promise(function(resolve, reject) {
    function errorListener(err) {
      emitter.removeListener(name2, resolver);
      reject(err);
    }
    function resolver() {
      if (typeof emitter.removeListener === "function") {
        emitter.removeListener("error", errorListener);
      }
      resolve([].slice.call(arguments));
    }
    eventTargetAgnosticAddListener(emitter, name2, resolver, { once: true });
    if (name2 !== "error") {
      addErrorHandlerIfEventEmitter(emitter, errorListener, { once: true });
    }
  });
}
function addErrorHandlerIfEventEmitter(emitter, handler, flags) {
  if (typeof emitter.on === "function") {
    eventTargetAgnosticAddListener(emitter, "error", handler, flags);
  }
}
function eventTargetAgnosticAddListener(emitter, name2, listener, flags) {
  if (typeof emitter.on === "function") {
    if (flags.once) {
      emitter.once(name2, listener);
    } else {
      emitter.on(name2, listener);
    }
  } else if (typeof emitter.addEventListener === "function") {
    emitter.addEventListener(name2, function wrapListener(arg) {
      if (flags.once) {
        emitter.removeEventListener(name2, wrapListener);
      }
      listener(arg);
    });
  } else {
    throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type ' + typeof emitter);
  }
}
var __assign$3 = globalThis && globalThis.__assign || function() {
  __assign$3 = Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s)
        if (Object.prototype.hasOwnProperty.call(s, p))
          t[p] = s[p];
    }
    return t;
  };
  return __assign$3.apply(this, arguments);
};
var __awaiter$2 = globalThis && globalThis.__awaiter || function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator$2 = globalThis && globalThis.__generator || function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1)
      throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f)
      throw new TypeError("Generator is already executing.");
    while (_)
      try {
        if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
          return t;
        if (y = 0, t)
          op = [op[0] & 2, t.value];
        switch (op[0]) {
          case 0:
          case 1:
            t = op;
            break;
          case 4:
            _.label++;
            return { value: op[1], done: false };
          case 5:
            _.label++;
            y = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            if (t[2])
              _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e) {
        op = [6, e];
        y = 0;
      } finally {
        f = t = 0;
      }
    if (op[0] & 5)
      throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
var logger$3 = new ConsoleLogger("AWSS3ProviderManagedUpload");
var localTestingStorageEndpoint$1 = "http://localhost:20005";
var SET_CONTENT_LENGTH_HEADER$1 = "contentLengthMiddleware";
var AWSS3ProviderManagedUpload = function() {
  function AWSS3ProviderManagedUpload2(params, opts, emitter) {
    this.minPartSize = 5 * 1024 * 1024;
    this.queueSize = 4;
    this.body = null;
    this.params = null;
    this.opts = null;
    this.completedParts = [];
    this.cancel = false;
    this.bytesUploaded = 0;
    this.totalBytesToUpload = 0;
    this.emitter = null;
    this.params = params;
    this.opts = opts;
    this.emitter = emitter;
  }
  AWSS3ProviderManagedUpload2.prototype.upload = function() {
    return __awaiter$2(this, void 0, void 0, function() {
      var _a, putObjectCommand, s3, uploadId, numberOfPartsToUpload, parts, start;
      var _this = this;
      return __generator$2(this, function(_b) {
        switch (_b.label) {
          case 0:
            _a = this;
            return [4, this.validateAndSanitizeBody(this.params.Body)];
          case 1:
            _a.body = _b.sent();
            this.totalBytesToUpload = this.byteLength(this.body);
            if (!(this.totalBytesToUpload <= this.minPartSize))
              return [3, 3];
            this.params.Body = this.body;
            putObjectCommand = new PutObjectCommand(this.params);
            return [4, this._createNewS3Client(this.opts, this.emitter)];
          case 2:
            s3 = _b.sent();
            return [2, s3.send(putObjectCommand)];
          case 3:
            return [4, this.createMultiPartUpload()];
          case 4:
            uploadId = _b.sent();
            numberOfPartsToUpload = Math.ceil(this.totalBytesToUpload / this.minPartSize);
            parts = this.createParts();
            start = 0;
            _b.label = 5;
          case 5:
            if (!(start < numberOfPartsToUpload))
              return [3, 10];
            return [4, this.checkIfUploadCancelled(uploadId)];
          case 6:
            _b.sent();
            return [4, this.uploadParts(uploadId, parts.slice(start, start + this.queueSize))];
          case 7:
            _b.sent();
            return [4, this.checkIfUploadCancelled(uploadId)];
          case 8:
            _b.sent();
            _b.label = 9;
          case 9:
            start += this.queueSize;
            return [3, 5];
          case 10:
            parts.map(function(part) {
              _this.removeEventListener(part);
            });
            return [4, this.finishMultiPartUpload(uploadId)];
          case 11:
            return [2, _b.sent()];
        }
      });
    });
  };
  AWSS3ProviderManagedUpload2.prototype.createParts = function() {
    var parts = [];
    for (var bodyStart = 0; bodyStart < this.totalBytesToUpload; ) {
      var bodyEnd = Math.min(bodyStart + this.minPartSize, this.totalBytesToUpload);
      parts.push({
        bodyPart: this.body.slice(bodyStart, bodyEnd),
        partNumber: parts.length + 1,
        emitter: new events.exports.EventEmitter(),
        _lastUploadedBytes: 0
      });
      bodyStart += this.minPartSize;
    }
    return parts;
  };
  AWSS3ProviderManagedUpload2.prototype.createMultiPartUpload = function() {
    return __awaiter$2(this, void 0, void 0, function() {
      var createMultiPartUploadCommand, s3, response;
      var _this = this;
      return __generator$2(this, function(_a) {
        switch (_a.label) {
          case 0:
            createMultiPartUploadCommand = new CreateMultipartUploadCommand(this.params);
            return [4, this._createNewS3Client(this.opts)];
          case 1:
            s3 = _a.sent();
            s3.middlewareStack.add(function(next) {
              return function(args) {
                if (_this.params.ContentType && args && args.request && args.request.headers) {
                  args.request.headers["Content-Type"] = _this.params.ContentType;
                }
                return next(args);
              };
            }, {
              step: "build"
            });
            return [4, s3.send(createMultiPartUploadCommand)];
          case 2:
            response = _a.sent();
            logger$3.debug(response.UploadId);
            return [2, response.UploadId];
        }
      });
    });
  };
  AWSS3ProviderManagedUpload2.prototype.uploadParts = function(uploadId, parts) {
    return __awaiter$2(this, void 0, void 0, function() {
      var allResults, i, error_1;
      var _this = this;
      return __generator$2(this, function(_a) {
        switch (_a.label) {
          case 0:
            _a.trys.push([0, 2, , 3]);
            return [4, Promise.all(parts.map(function(part) {
              return __awaiter$2(_this, void 0, void 0, function() {
                var s3, _a2, Key, Bucket2, SSECustomerAlgorithm, SSECustomerKey, SSECustomerKeyMD5;
                return __generator$2(this, function(_b) {
                  switch (_b.label) {
                    case 0:
                      this.setupEventListener(part);
                      return [4, this._createNewS3Client(this.opts, part.emitter)];
                    case 1:
                      s3 = _b.sent();
                      _a2 = this.params, Key = _a2.Key, Bucket2 = _a2.Bucket, SSECustomerAlgorithm = _a2.SSECustomerAlgorithm, SSECustomerKey = _a2.SSECustomerKey, SSECustomerKeyMD5 = _a2.SSECustomerKeyMD5;
                      return [2, s3.send(new UploadPartCommand(__assign$3(__assign$3(__assign$3({
                        PartNumber: part.partNumber,
                        Body: part.bodyPart,
                        UploadId: uploadId,
                        Key,
                        Bucket: Bucket2
                      }, SSECustomerAlgorithm && { SSECustomerAlgorithm }), SSECustomerKey && { SSECustomerKey }), SSECustomerKeyMD5 && { SSECustomerKeyMD5 })))];
                  }
                });
              });
            }))];
          case 1:
            allResults = _a.sent();
            for (i = 0; i < allResults.length; i++) {
              this.completedParts.push({
                PartNumber: parts[i].partNumber,
                ETag: allResults[i].ETag
              });
            }
            return [3, 3];
          case 2:
            error_1 = _a.sent();
            logger$3.error("error happened while uploading a part. Cancelling the multipart upload", error_1);
            this.cancelUpload();
            return [2];
          case 3:
            return [2];
        }
      });
    });
  };
  AWSS3ProviderManagedUpload2.prototype.finishMultiPartUpload = function(uploadId) {
    return __awaiter$2(this, void 0, void 0, function() {
      var input, completeUploadCommand, s3, data, error_2;
      return __generator$2(this, function(_a) {
        switch (_a.label) {
          case 0:
            input = {
              Bucket: this.params.Bucket,
              Key: this.params.Key,
              UploadId: uploadId,
              MultipartUpload: { Parts: this.completedParts }
            };
            completeUploadCommand = new CompleteMultipartUploadCommand(input);
            return [4, this._createNewS3Client(this.opts)];
          case 1:
            s3 = _a.sent();
            _a.label = 2;
          case 2:
            _a.trys.push([2, 4, , 5]);
            return [4, s3.send(completeUploadCommand)];
          case 3:
            data = _a.sent();
            return [2, data.Key];
          case 4:
            error_2 = _a.sent();
            logger$3.error("error happened while finishing the upload. Cancelling the multipart upload", error_2);
            this.cancelUpload();
            return [2];
          case 5:
            return [2];
        }
      });
    });
  };
  AWSS3ProviderManagedUpload2.prototype.checkIfUploadCancelled = function(uploadId) {
    return __awaiter$2(this, void 0, void 0, function() {
      var errorMessage, error_3;
      return __generator$2(this, function(_a) {
        switch (_a.label) {
          case 0:
            if (!this.cancel)
              return [3, 5];
            errorMessage = "Upload was cancelled.";
            _a.label = 1;
          case 1:
            _a.trys.push([1, 3, , 4]);
            return [4, this.cleanup(uploadId)];
          case 2:
            _a.sent();
            return [3, 4];
          case 3:
            error_3 = _a.sent();
            errorMessage += " " + error_3.message;
            return [3, 4];
          case 4:
            throw new Error(errorMessage);
          case 5:
            return [2];
        }
      });
    });
  };
  AWSS3ProviderManagedUpload2.prototype.cancelUpload = function() {
    this.cancel = true;
  };
  AWSS3ProviderManagedUpload2.prototype.cleanup = function(uploadId) {
    return __awaiter$2(this, void 0, void 0, function() {
      var input, s3, data;
      return __generator$2(this, function(_a) {
        switch (_a.label) {
          case 0:
            this.body = null;
            this.completedParts = [];
            this.bytesUploaded = 0;
            this.totalBytesToUpload = 0;
            input = {
              Bucket: this.params.Bucket,
              Key: this.params.Key,
              UploadId: uploadId
            };
            return [4, this._createNewS3Client(this.opts)];
          case 1:
            s3 = _a.sent();
            return [4, s3.send(new AbortMultipartUploadCommand(input))];
          case 2:
            _a.sent();
            return [4, s3.send(new ListPartsCommand(input))];
          case 3:
            data = _a.sent();
            if (data && data.Parts && data.Parts.length > 0) {
              throw new Error("Multi Part upload clean up failed");
            }
            return [2];
        }
      });
    });
  };
  AWSS3ProviderManagedUpload2.prototype.removeEventListener = function(part) {
    part.emitter.removeAllListeners(SEND_UPLOAD_PROGRESS_EVENT);
    part.emitter.removeAllListeners(SEND_DOWNLOAD_PROGRESS_EVENT);
  };
  AWSS3ProviderManagedUpload2.prototype.setupEventListener = function(part) {
    var _this = this;
    part.emitter.on(SEND_UPLOAD_PROGRESS_EVENT, function(progress) {
      _this.progressChanged(part.partNumber, progress.loaded - part._lastUploadedBytes);
      part._lastUploadedBytes = progress.loaded;
    });
  };
  AWSS3ProviderManagedUpload2.prototype.progressChanged = function(partNumber, incrementalUpdate) {
    this.bytesUploaded += incrementalUpdate;
    this.emitter.emit(SEND_UPLOAD_PROGRESS_EVENT, {
      loaded: this.bytesUploaded,
      total: this.totalBytesToUpload,
      part: partNumber,
      key: this.params.Key
    });
  };
  AWSS3ProviderManagedUpload2.prototype.byteLength = function(input) {
    if (input === null || input === void 0)
      return 0;
    if (typeof input.byteLength === "number") {
      return input.byteLength;
    } else if (typeof input.length === "number") {
      return input.length;
    } else if (typeof input.size === "number") {
      return input.size;
    } else if (typeof input.path === "string")
      ;
    else {
      throw new Error("Cannot determine length of " + input);
    }
  };
  AWSS3ProviderManagedUpload2.prototype.validateAndSanitizeBody = function(body) {
    return __awaiter$2(this, void 0, void 0, function() {
      return __generator$2(this, function(_a) {
        if (this.isGenericObject(body)) {
          return [2, JSON.stringify(body)];
        } else {
          return [2, body];
        }
      });
    });
  };
  AWSS3ProviderManagedUpload2.prototype.isGenericObject = function(body) {
    if (body !== null && typeof body === "object") {
      try {
        return !(this.byteLength(body) >= 0);
      } catch (error) {
        return true;
      }
    }
    return false;
  };
  AWSS3ProviderManagedUpload2.prototype._createNewS3Client = function(config, emitter) {
    return __awaiter$2(this, void 0, void 0, function() {
      var credentials, region, dangerouslyConnectToHttpEndpointForTesting, cancelTokenSource, useAccelerateEndpoint, localTestingConfig, client;
      return __generator$2(this, function(_a) {
        switch (_a.label) {
          case 0:
            return [4, this._getCredentials()];
          case 1:
            credentials = _a.sent();
            region = config.region, dangerouslyConnectToHttpEndpointForTesting = config.dangerouslyConnectToHttpEndpointForTesting, cancelTokenSource = config.cancelTokenSource, useAccelerateEndpoint = config.useAccelerateEndpoint;
            localTestingConfig = {};
            if (dangerouslyConnectToHttpEndpointForTesting) {
              localTestingConfig = {
                endpoint: localTestingStorageEndpoint$1,
                tls: false,
                bucketEndpoint: false,
                forcePathStyle: true
              };
            }
            client = new S3Client(__assign$3(__assign$3({
              region,
              credentials,
              useAccelerateEndpoint
            }, localTestingConfig), { requestHandler: new AxiosHttpHandler({}, emitter, cancelTokenSource), customUserAgent: getAmplifyUserAgent() }));
            client.middlewareStack.remove(SET_CONTENT_LENGTH_HEADER$1);
            return [2, client];
        }
      });
    });
  };
  AWSS3ProviderManagedUpload2.prototype._getCredentials = function() {
    return Credentials.get().then(function(credentials) {
      if (!credentials)
        return false;
      var cred = Credentials.shear(credentials);
      logger$3.debug("set credentials for storage", cred);
      return cred;
    }).catch(function(error) {
      logger$3.warn("ensure credentials error", error);
      return false;
    });
  };
  return AWSS3ProviderManagedUpload2;
}();
var __assign$2 = globalThis && globalThis.__assign || function() {
  __assign$2 = Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s)
        if (Object.prototype.hasOwnProperty.call(s, p))
          t[p] = s[p];
    }
    return t;
  };
  return __assign$2.apply(this, arguments);
};
var __awaiter$1 = globalThis && globalThis.__awaiter || function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator$1 = globalThis && globalThis.__generator || function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1)
      throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f)
      throw new TypeError("Generator is already executing.");
    while (_)
      try {
        if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
          return t;
        if (y = 0, t)
          op = [op[0] & 2, t.value];
        switch (op[0]) {
          case 0:
          case 1:
            t = op;
            break;
          case 4:
            _.label++;
            return { value: op[1], done: false };
          case 5:
            _.label++;
            y = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            if (t[2])
              _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e) {
        op = [6, e];
        y = 0;
      } finally {
        f = t = 0;
      }
    if (op[0] & 5)
      throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
var logger$2 = new ConsoleLogger("AWSS3Provider");
var AMPLIFY_SYMBOL = typeof Symbol !== "undefined" && typeof Symbol.for === "function" ? Symbol.for("amplify_default") : "@@amplify_default";
var SET_CONTENT_LENGTH_HEADER = "contentLengthMiddleware";
var DEFAULT_STORAGE_LEVEL = "public";
var DEFAULT_PRESIGN_EXPIRATION = 900;
var dispatchStorageEvent = function(track, event, attrs, metrics, message) {
  if (track) {
    var data = { attrs };
    if (metrics) {
      data["metrics"] = metrics;
    }
    Hub.dispatch("storage", {
      event,
      data,
      message
    }, "Storage", AMPLIFY_SYMBOL);
  }
};
var localTestingStorageEndpoint = "http://localhost:20005";
var AWSS3Provider = function() {
  function AWSS3Provider2(config) {
    this._config = config ? config : {};
    logger$2.debug("Storage Options", this._config);
  }
  AWSS3Provider2.prototype.getCategory = function() {
    return AWSS3Provider2.CATEGORY;
  };
  AWSS3Provider2.prototype.getProviderName = function() {
    return AWSS3Provider2.PROVIDER_NAME;
  };
  AWSS3Provider2.prototype.configure = function(config) {
    logger$2.debug("configure Storage", config);
    if (!config)
      return this._config;
    var amplifyConfig = Parser$1.parseMobilehubConfig(config);
    this._config = Object.assign({}, this._config, amplifyConfig.Storage);
    if (!this._config.bucket) {
      logger$2.debug("Do not have bucket yet");
    }
    return this._config;
  };
  AWSS3Provider2.prototype.copy = function(src, dest, config) {
    return __awaiter$1(this, void 0, void 0, function() {
      var credentialsOK, opt, acl, bucket, cacheControl, expires, track, serverSideEncryption, SSECustomerAlgorithm, SSECustomerKey, SSECustomerKeyMD5, SSEKMSKeyId, _a, srcLevel, srcIdentityId, srcKey, _b, destLevel, destKey, srcPrefix, destPrefix, finalSrcKey, finalDestKey, params, s3, error_1;
      return __generator$1(this, function(_c) {
        switch (_c.label) {
          case 0:
            return [4, this._ensureCredentials()];
          case 1:
            credentialsOK = _c.sent();
            if (!credentialsOK || !this._isWithCredentials(this._config)) {
              throw new Error(StorageErrorStrings.NO_CREDENTIALS);
            }
            opt = Object.assign({}, this._config, config);
            acl = opt.acl, bucket = opt.bucket, cacheControl = opt.cacheControl, expires = opt.expires, track = opt.track, serverSideEncryption = opt.serverSideEncryption, SSECustomerAlgorithm = opt.SSECustomerAlgorithm, SSECustomerKey = opt.SSECustomerKey, SSECustomerKeyMD5 = opt.SSECustomerKeyMD5, SSEKMSKeyId = opt.SSEKMSKeyId;
            _a = src.level, srcLevel = _a === void 0 ? DEFAULT_STORAGE_LEVEL : _a, srcIdentityId = src.identityId, srcKey = src.key;
            _b = dest.level, destLevel = _b === void 0 ? DEFAULT_STORAGE_LEVEL : _b, destKey = dest.key;
            if (!srcKey || typeof srcKey !== "string") {
              throw new Error(StorageErrorStrings.NO_SRC_KEY);
            }
            if (!destKey || typeof destKey !== "string") {
              throw new Error(StorageErrorStrings.NO_DEST_KEY);
            }
            if (srcLevel !== "protected" && srcIdentityId) {
              logger$2.warn(`You may copy files from another user if the source level is "protected", currently it's ` + srcLevel);
            }
            srcPrefix = this._prefix(__assign$2(__assign$2(__assign$2({}, opt), { level: srcLevel }), srcIdentityId && { identityId: srcIdentityId }));
            destPrefix = this._prefix(__assign$2(__assign$2({}, opt), { level: destLevel }));
            finalSrcKey = bucket + "/" + srcPrefix + srcKey;
            finalDestKey = "" + destPrefix + destKey;
            logger$2.debug("copying " + finalSrcKey + " to " + finalDestKey);
            params = {
              Bucket: bucket,
              CopySource: finalSrcKey,
              Key: finalDestKey,
              MetadataDirective: "COPY"
            };
            if (cacheControl)
              params.CacheControl = cacheControl;
            if (expires)
              params.Expires = expires;
            if (serverSideEncryption) {
              params.ServerSideEncryption = serverSideEncryption;
            }
            if (SSECustomerAlgorithm) {
              params.SSECustomerAlgorithm = SSECustomerAlgorithm;
            }
            if (SSECustomerKey) {
              params.SSECustomerKey = SSECustomerKey;
            }
            if (SSECustomerKeyMD5) {
              params.SSECustomerKeyMD5 = SSECustomerKeyMD5;
            }
            if (SSEKMSKeyId) {
              params.SSEKMSKeyId = SSEKMSKeyId;
            }
            if (acl)
              params.ACL = acl;
            s3 = this._createNewS3Client(opt);
            s3.middlewareStack.remove(SET_CONTENT_LENGTH_HEADER);
            _c.label = 2;
          case 2:
            _c.trys.push([2, 4, , 5]);
            return [4, s3.send(new CopyObjectCommand(params))];
          case 3:
            _c.sent();
            dispatchStorageEvent(track, "copy", {
              method: "copy",
              result: "success"
            }, null, "Copy success from " + srcKey + " to " + destKey);
            return [2, {
              key: destKey
            }];
          case 4:
            error_1 = _c.sent();
            dispatchStorageEvent(track, "copy", {
              method: "copy",
              result: "failed"
            }, null, "Copy failed from " + srcKey + " to " + destKey);
            throw error_1;
          case 5:
            return [2];
        }
      });
    });
  };
  AWSS3Provider2.prototype.get = function(key, config) {
    return __awaiter$1(this, void 0, void 0, function() {
      var credentialsOK, opt, bucket, download, cacheControl, contentDisposition, contentEncoding, contentLanguage, contentType, expires, track, SSECustomerAlgorithm, SSECustomerKey, SSECustomerKeyMD5, progressCallback, prefix, final_key, emitter, s3, params, getObjectCommand, response, error_2, signer, request, url, _a, error_3;
      return __generator$1(this, function(_b) {
        switch (_b.label) {
          case 0:
            return [4, this._ensureCredentials()];
          case 1:
            credentialsOK = _b.sent();
            if (!credentialsOK || !this._isWithCredentials(this._config)) {
              throw new Error(StorageErrorStrings.NO_CREDENTIALS);
            }
            opt = Object.assign({}, this._config, config);
            bucket = opt.bucket, download = opt.download, cacheControl = opt.cacheControl, contentDisposition = opt.contentDisposition, contentEncoding = opt.contentEncoding, contentLanguage = opt.contentLanguage, contentType = opt.contentType, expires = opt.expires, track = opt.track, SSECustomerAlgorithm = opt.SSECustomerAlgorithm, SSECustomerKey = opt.SSECustomerKey, SSECustomerKeyMD5 = opt.SSECustomerKeyMD5, progressCallback = opt.progressCallback;
            prefix = this._prefix(opt);
            final_key = prefix + key;
            emitter = new events.exports.EventEmitter();
            s3 = this._createNewS3Client(opt, emitter);
            logger$2.debug("get " + key + " from " + final_key);
            params = {
              Bucket: bucket,
              Key: final_key
            };
            if (cacheControl)
              params.ResponseCacheControl = cacheControl;
            if (contentDisposition)
              params.ResponseContentDisposition = contentDisposition;
            if (contentEncoding)
              params.ResponseContentEncoding = contentEncoding;
            if (contentLanguage)
              params.ResponseContentLanguage = contentLanguage;
            if (contentType)
              params.ResponseContentType = contentType;
            if (SSECustomerAlgorithm) {
              params.SSECustomerAlgorithm = SSECustomerAlgorithm;
            }
            if (SSECustomerKey) {
              params.SSECustomerKey = SSECustomerKey;
            }
            if (SSECustomerKeyMD5) {
              params.SSECustomerKeyMD5 = SSECustomerKeyMD5;
            }
            if (!(download === true))
              return [3, 5];
            getObjectCommand = new GetObjectCommand(params);
            _b.label = 2;
          case 2:
            _b.trys.push([2, 4, , 5]);
            if (progressCallback) {
              if (typeof progressCallback === "function") {
                emitter.on(SEND_DOWNLOAD_PROGRESS_EVENT, function(progress) {
                  progressCallback(progress);
                });
              } else {
                logger$2.warn("progressCallback should be a function, not a " + typeof progressCallback);
              }
            }
            return [4, s3.send(getObjectCommand)];
          case 3:
            response = _b.sent();
            emitter.removeAllListeners(SEND_DOWNLOAD_PROGRESS_EVENT);
            dispatchStorageEvent(track, "download", { method: "get", result: "success" }, {
              fileSize: Number(response.Body["size"] || response.Body["length"])
            }, "Download success for " + key);
            return [2, response];
          case 4:
            error_2 = _b.sent();
            dispatchStorageEvent(track, "download", {
              method: "get",
              result: "failed"
            }, null, "Download failed with " + error_2.message);
            throw error_2;
          case 5:
            _b.trys.push([5, 8, , 9]);
            signer = new S3RequestPresigner(__assign$2({}, s3.config));
            return [4, createRequest(s3, new GetObjectCommand(params))];
          case 6:
            request = _b.sent();
            _a = formatUrl;
            return [4, signer.presign(request, { expiresIn: expires || DEFAULT_PRESIGN_EXPIRATION })];
          case 7:
            url = _a.apply(void 0, [_b.sent()]);
            dispatchStorageEvent(track, "getSignedUrl", { method: "get", result: "success" }, null, "Signed URL: " + url);
            return [2, url];
          case 8:
            error_3 = _b.sent();
            logger$2.warn("get signed url error", error_3);
            dispatchStorageEvent(track, "getSignedUrl", { method: "get", result: "failed" }, null, "Could not get a signed URL for " + key);
            throw error_3;
          case 9:
            return [2];
        }
      });
    });
  };
  AWSS3Provider2.prototype.put = function(key, object, config) {
    return __awaiter$1(this, void 0, void 0, function() {
      var credentialsOK, opt, bucket, track, progressCallback, contentType, contentDisposition, contentEncoding, cacheControl, expires, metadata, tagging, acl, serverSideEncryption, SSECustomerAlgorithm, SSECustomerKey, SSECustomerKeyMD5, SSEKMSKeyId, type, prefix, final_key, params, emitter, uploader, response, error_4;
      return __generator$1(this, function(_a) {
        switch (_a.label) {
          case 0:
            return [4, this._ensureCredentials()];
          case 1:
            credentialsOK = _a.sent();
            if (!credentialsOK || !this._isWithCredentials(this._config)) {
              throw new Error(StorageErrorStrings.NO_CREDENTIALS);
            }
            opt = Object.assign({}, this._config, config);
            bucket = opt.bucket, track = opt.track, progressCallback = opt.progressCallback;
            contentType = opt.contentType, contentDisposition = opt.contentDisposition, contentEncoding = opt.contentEncoding, cacheControl = opt.cacheControl, expires = opt.expires, metadata = opt.metadata, tagging = opt.tagging, acl = opt.acl;
            serverSideEncryption = opt.serverSideEncryption, SSECustomerAlgorithm = opt.SSECustomerAlgorithm, SSECustomerKey = opt.SSECustomerKey, SSECustomerKeyMD5 = opt.SSECustomerKeyMD5, SSEKMSKeyId = opt.SSEKMSKeyId;
            type = contentType ? contentType : "binary/octet-stream";
            prefix = this._prefix(opt);
            final_key = prefix + key;
            logger$2.debug("put " + key + " to " + final_key);
            params = {
              Bucket: bucket,
              Key: final_key,
              Body: object,
              ContentType: type
            };
            if (cacheControl) {
              params.CacheControl = cacheControl;
            }
            if (contentDisposition) {
              params.ContentDisposition = contentDisposition;
            }
            if (contentEncoding) {
              params.ContentEncoding = contentEncoding;
            }
            if (expires) {
              params.Expires = expires;
            }
            if (metadata) {
              params.Metadata = metadata;
            }
            if (tagging) {
              params.Tagging = tagging;
            }
            if (serverSideEncryption) {
              params.ServerSideEncryption = serverSideEncryption;
            }
            if (SSECustomerAlgorithm) {
              params.SSECustomerAlgorithm = SSECustomerAlgorithm;
            }
            if (SSECustomerKey) {
              params.SSECustomerKey = SSECustomerKey;
            }
            if (SSECustomerKeyMD5) {
              params.SSECustomerKeyMD5 = SSECustomerKeyMD5;
            }
            if (SSEKMSKeyId) {
              params.SSEKMSKeyId = SSEKMSKeyId;
            }
            emitter = new events.exports.EventEmitter();
            uploader = new AWSS3ProviderManagedUpload(params, opt, emitter);
            if (acl) {
              params.ACL = acl;
            }
            _a.label = 2;
          case 2:
            _a.trys.push([2, 4, , 5]);
            if (progressCallback) {
              if (typeof progressCallback === "function") {
                emitter.on(SEND_UPLOAD_PROGRESS_EVENT, function(progress) {
                  progressCallback(progress);
                });
              } else {
                logger$2.warn("progressCallback should be a function, not a " + typeof progressCallback);
              }
            }
            return [4, uploader.upload()];
          case 3:
            response = _a.sent();
            logger$2.debug("upload result", response);
            dispatchStorageEvent(track, "upload", { method: "put", result: "success" }, null, "Upload success for " + key);
            return [2, {
              key
            }];
          case 4:
            error_4 = _a.sent();
            logger$2.warn("error uploading", error_4);
            dispatchStorageEvent(track, "upload", { method: "put", result: "failed" }, null, "Error uploading " + key);
            throw error_4;
          case 5:
            return [2];
        }
      });
    });
  };
  AWSS3Provider2.prototype.remove = function(key, config) {
    return __awaiter$1(this, void 0, void 0, function() {
      var credentialsOK, opt, bucket, track, prefix, final_key, s3, params, deleteObjectCommand, response, error_5;
      return __generator$1(this, function(_a) {
        switch (_a.label) {
          case 0:
            return [4, this._ensureCredentials()];
          case 1:
            credentialsOK = _a.sent();
            if (!credentialsOK || !this._isWithCredentials(this._config)) {
              throw new Error(StorageErrorStrings.NO_CREDENTIALS);
            }
            opt = Object.assign({}, this._config, config);
            bucket = opt.bucket, track = opt.track;
            prefix = this._prefix(opt);
            final_key = prefix + key;
            s3 = this._createNewS3Client(opt);
            logger$2.debug("remove " + key + " from " + final_key);
            params = {
              Bucket: bucket,
              Key: final_key
            };
            deleteObjectCommand = new DeleteObjectCommand(params);
            _a.label = 2;
          case 2:
            _a.trys.push([2, 4, , 5]);
            return [4, s3.send(deleteObjectCommand)];
          case 3:
            response = _a.sent();
            dispatchStorageEvent(track, "delete", { method: "remove", result: "success" }, null, "Deleted " + key + " successfully");
            return [2, response];
          case 4:
            error_5 = _a.sent();
            dispatchStorageEvent(track, "delete", { method: "remove", result: "failed" }, null, "Deletion of " + key + " failed with " + error_5);
            throw error_5;
          case 5:
            return [2];
        }
      });
    });
  };
  AWSS3Provider2.prototype.list = function(path, config) {
    return __awaiter$1(this, void 0, void 0, function() {
      var credentialsOK, opt, bucket, track, maxKeys, prefix, final_path, s3, params, listObjectsCommand, response, list, error_6;
      return __generator$1(this, function(_a) {
        switch (_a.label) {
          case 0:
            return [4, this._ensureCredentials()];
          case 1:
            credentialsOK = _a.sent();
            if (!credentialsOK || !this._isWithCredentials(this._config)) {
              throw new Error(StorageErrorStrings.NO_CREDENTIALS);
            }
            opt = Object.assign({}, this._config, config);
            bucket = opt.bucket, track = opt.track, maxKeys = opt.maxKeys;
            prefix = this._prefix(opt);
            final_path = prefix + path;
            s3 = this._createNewS3Client(opt);
            logger$2.debug("list " + path + " from " + final_path);
            params = {
              Bucket: bucket,
              Prefix: final_path,
              MaxKeys: maxKeys
            };
            listObjectsCommand = new ListObjectsCommand(params);
            _a.label = 2;
          case 2:
            _a.trys.push([2, 4, , 5]);
            return [4, s3.send(listObjectsCommand)];
          case 3:
            response = _a.sent();
            list = [];
            if (response && response.Contents) {
              list = response.Contents.map(function(item) {
                return {
                  key: item.Key.substr(prefix.length),
                  eTag: item.ETag,
                  lastModified: item.LastModified,
                  size: item.Size
                };
              });
            }
            dispatchStorageEvent(track, "list", { method: "list", result: "success" }, null, list.length + " items returned from list operation");
            logger$2.debug("list", list);
            return [2, list];
          case 4:
            error_6 = _a.sent();
            logger$2.warn("list error", error_6);
            dispatchStorageEvent(track, "list", { method: "list", result: "failed" }, null, "Listing items failed: " + error_6.message);
            throw error_6;
          case 5:
            return [2];
        }
      });
    });
  };
  AWSS3Provider2.prototype._ensureCredentials = function() {
    return __awaiter$1(this, void 0, void 0, function() {
      var credentials, cred, error_7;
      return __generator$1(this, function(_a) {
        switch (_a.label) {
          case 0:
            _a.trys.push([0, 2, , 3]);
            return [4, Credentials.get()];
          case 1:
            credentials = _a.sent();
            if (!credentials)
              return [2, false];
            cred = Credentials.shear(credentials);
            logger$2.debug("set credentials for storage", cred);
            this._config.credentials = cred;
            return [2, true];
          case 2:
            error_7 = _a.sent();
            logger$2.warn("ensure credentials error", error_7);
            return [2, false];
          case 3:
            return [2];
        }
      });
    });
  };
  AWSS3Provider2.prototype._isWithCredentials = function(config) {
    return typeof config === "object" && config.hasOwnProperty("credentials");
  };
  AWSS3Provider2.prototype._prefix = function(config) {
    var credentials = config.credentials, level = config.level;
    var customPrefix = config.customPrefix || {};
    var identityId = config.identityId || credentials.identityId;
    var privatePath = (customPrefix.private !== void 0 ? customPrefix.private : "private/") + identityId + "/";
    var protectedPath = (customPrefix.protected !== void 0 ? customPrefix.protected : "protected/") + identityId + "/";
    var publicPath = customPrefix.public !== void 0 ? customPrefix.public : "public/";
    switch (level) {
      case "private":
        return privatePath;
      case "protected":
        return protectedPath;
      default:
        return publicPath;
    }
  };
  AWSS3Provider2.prototype._createNewS3Client = function(config, emitter) {
    var region = config.region, credentials = config.credentials, cancelTokenSource = config.cancelTokenSource, dangerouslyConnectToHttpEndpointForTesting = config.dangerouslyConnectToHttpEndpointForTesting;
    var localTestingConfig = {};
    if (dangerouslyConnectToHttpEndpointForTesting) {
      localTestingConfig = {
        endpoint: localTestingStorageEndpoint,
        tls: false,
        bucketEndpoint: false,
        forcePathStyle: true
      };
    }
    var s3client = new S3Client(__assign$2(__assign$2({
      region,
      credentials,
      customUserAgent: getAmplifyUserAgent()
    }, localTestingConfig), { requestHandler: new AxiosHttpHandler({}, emitter, cancelTokenSource) }));
    return s3client;
  };
  AWSS3Provider2.CATEGORY = "Storage";
  AWSS3Provider2.PROVIDER_NAME = "AWSS3";
  return AWSS3Provider2;
}();
var __assign$1 = globalThis && globalThis.__assign || function() {
  __assign$1 = Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s)
        if (Object.prototype.hasOwnProperty.call(s, p))
          t[p] = s[p];
    }
    return t;
  };
  return __assign$1.apply(this, arguments);
};
var __awaiter = globalThis && globalThis.__awaiter || function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = globalThis && globalThis.__generator || function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1)
      throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f)
      throw new TypeError("Generator is already executing.");
    while (_)
      try {
        if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
          return t;
        if (y = 0, t)
          op = [op[0] & 2, t.value];
        switch (op[0]) {
          case 0:
          case 1:
            t = op;
            break;
          case 4:
            _.label++;
            return { value: op[1], done: false };
          case 5:
            _.label++;
            y = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            if (t[2])
              _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e) {
        op = [6, e];
        y = 0;
      } finally {
        f = t = 0;
      }
    if (op[0] & 5)
      throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
var __read = globalThis && globalThis.__read || function(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m)
    return o;
  var i = m.call(o), r, ar = [], e;
  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
      ar.push(r.value);
  } catch (error) {
    e = { error };
  } finally {
    try {
      if (r && !r.done && (m = i["return"]))
        m.call(i);
    } finally {
      if (e)
        throw e.error;
    }
  }
  return ar;
};
var logger$1 = new ConsoleLogger("StorageClass");
var DEFAULT_PROVIDER = "AWSS3";
var Storage$1 = function() {
  function Storage2() {
    this._config = {};
    this._pluggables = [];
    this._cancelTokenSourceMap = /* @__PURE__ */ new WeakMap();
    logger$1.debug("Storage Options", this._config);
    this.get = this.get.bind(this);
    this.put = this.put.bind(this);
    this.remove = this.remove.bind(this);
    this.list = this.list.bind(this);
  }
  Storage2.prototype.getModuleName = function() {
    return "Storage";
  };
  Storage2.prototype.addPluggable = function(pluggable) {
    if (pluggable && pluggable.getCategory() === "Storage") {
      this._pluggables.push(pluggable);
      var config = {};
      config = pluggable.configure(this._config[pluggable.getProviderName()]);
      return config;
    }
  };
  Storage2.prototype.getPluggable = function(providerName) {
    var pluggable = this._pluggables.find(function(pluggable2) {
      return pluggable2.getProviderName() === providerName;
    });
    if (pluggable === void 0) {
      logger$1.debug("No plugin found with providerName", providerName);
      return null;
    } else
      return pluggable;
  };
  Storage2.prototype.removePluggable = function(providerName) {
    this._pluggables = this._pluggables.filter(function(pluggable) {
      return pluggable.getProviderName() !== providerName;
    });
    return;
  };
  Storage2.prototype.configure = function(config) {
    var _this = this;
    logger$1.debug("configure Storage");
    if (!config)
      return this._config;
    var amplifyConfig = Parser$1.parseMobilehubConfig(config);
    var storageKeysFromConfig = Object.keys(amplifyConfig.Storage);
    var storageArrayKeys = [
      "bucket",
      "region",
      "level",
      "track",
      "customPrefix",
      "serverSideEncryption",
      "SSECustomerAlgorithm",
      "SSECustomerKey",
      "SSECustomerKeyMD5",
      "SSEKMSKeyId"
    ];
    var isInStorageArrayKeys = function(k) {
      return storageArrayKeys.some(function(x) {
        return x === k;
      });
    };
    var checkConfigKeysFromArray = function(k) {
      return k.find(function(k2) {
        return isInStorageArrayKeys(k2);
      });
    };
    if (storageKeysFromConfig && checkConfigKeysFromArray(storageKeysFromConfig) && !amplifyConfig.Storage[DEFAULT_PROVIDER]) {
      amplifyConfig.Storage[DEFAULT_PROVIDER] = {};
    }
    Object.entries(amplifyConfig.Storage).map(function(_a) {
      var _b = __read(_a, 2), key = _b[0], value = _b[1];
      if (key && isInStorageArrayKeys(key) && value !== void 0) {
        amplifyConfig.Storage[DEFAULT_PROVIDER][key] = value;
        delete amplifyConfig.Storage[key];
      }
    });
    Object.keys(amplifyConfig.Storage).forEach(function(providerName) {
      if (typeof amplifyConfig.Storage[providerName] !== "string") {
        _this._config[providerName] = __assign$1(__assign$1({}, _this._config[providerName]), amplifyConfig.Storage[providerName]);
      }
    });
    this._pluggables.forEach(function(pluggable) {
      pluggable.configure(_this._config[pluggable.getProviderName()]);
    });
    if (this._pluggables.length === 0) {
      this.addPluggable(new AWSS3Provider());
    }
    return this._config;
  };
  Storage2.prototype.getCancellableTokenSource = function() {
    return axios.CancelToken.source();
  };
  Storage2.prototype.updateRequestToBeCancellable = function(request, cancelTokenSource) {
    this._cancelTokenSourceMap.set(request, cancelTokenSource);
  };
  Storage2.prototype.cancel = function(request, message) {
    var cancelTokenSource = this._cancelTokenSourceMap.get(request);
    if (cancelTokenSource) {
      cancelTokenSource.cancel(message);
    } else {
      logger$1.debug("The request does not map to any cancel token");
    }
  };
  Storage2.prototype.copy = function(src, dest, config) {
    var _a = (config || {}).provider, provider = _a === void 0 ? DEFAULT_PROVIDER : _a;
    var prov = this._pluggables.find(function(pluggable) {
      return pluggable.getProviderName() === provider;
    });
    if (prov === void 0) {
      logger$1.debug("No plugin found with providerName", provider);
      return Promise.reject("No plugin found in Storage for the provider");
    }
    var cancelTokenSource = this.getCancellableTokenSource();
    var responsePromise = prov.copy(src, dest, __assign$1(__assign$1({}, config), { cancelTokenSource }));
    this.updateRequestToBeCancellable(responsePromise, cancelTokenSource);
    return responsePromise;
  };
  Storage2.prototype.get = function(key, config) {
    var _a = (config || {}).provider, provider = _a === void 0 ? DEFAULT_PROVIDER : _a;
    var prov = this._pluggables.find(function(pluggable) {
      return pluggable.getProviderName() === provider;
    });
    if (prov === void 0) {
      logger$1.debug("No plugin found with providerName", provider);
      return Promise.reject("No plugin found in Storage for the provider");
    }
    var cancelTokenSource = this.getCancellableTokenSource();
    var responsePromise = prov.get(key, __assign$1(__assign$1({}, config), { cancelTokenSource }));
    this.updateRequestToBeCancellable(responsePromise, cancelTokenSource);
    return responsePromise;
  };
  Storage2.prototype.isCancelError = function(error) {
    return axios.isCancel(error);
  };
  Storage2.prototype.put = function(key, object, config) {
    var _a = (config || {}).provider, provider = _a === void 0 ? DEFAULT_PROVIDER : _a;
    var prov = this._pluggables.find(function(pluggable) {
      return pluggable.getProviderName() === provider;
    });
    if (prov === void 0) {
      logger$1.debug("No plugin found with providerName", provider);
      return Promise.reject("No plugin found in Storage for the provider");
    }
    var cancelTokenSource = this.getCancellableTokenSource();
    var responsePromise = prov.put(key, object, __assign$1(__assign$1({}, config), { cancelTokenSource }));
    this.updateRequestToBeCancellable(responsePromise, cancelTokenSource);
    return responsePromise;
  };
  Storage2.prototype.remove = function(key, config) {
    return __awaiter(this, void 0, void 0, function() {
      var _a, provider, prov;
      return __generator(this, function(_b) {
        _a = (config || {}).provider, provider = _a === void 0 ? DEFAULT_PROVIDER : _a;
        prov = this._pluggables.find(function(pluggable) {
          return pluggable.getProviderName() === provider;
        });
        if (prov === void 0) {
          logger$1.debug("No plugin found with providerName", provider);
          return [2, Promise.reject("No plugin found in Storage for the provider")];
        }
        return [2, prov.remove(key, config)];
      });
    });
  };
  Storage2.prototype.list = function(path, config) {
    return __awaiter(this, void 0, void 0, function() {
      var _a, provider, prov;
      return __generator(this, function(_b) {
        _a = (config || {}).provider, provider = _a === void 0 ? DEFAULT_PROVIDER : _a;
        prov = this._pluggables.find(function(pluggable) {
          return pluggable.getProviderName() === provider;
        });
        if (prov === void 0) {
          logger$1.debug("No plugin found with providerName", provider);
          return [2, Promise.reject("No plugin found in Storage for the provider")];
        }
        return [2, prov.list(path, config)];
      });
    });
  };
  return Storage2;
}();
var __assign = globalThis && globalThis.__assign || function() {
  __assign = Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s)
        if (Object.prototype.hasOwnProperty.call(s, p))
          t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var logger = new ConsoleLogger("Storage");
var _instance = null;
var getInstance = function() {
  if (_instance) {
    return _instance;
  }
  logger.debug("Create Storage Instance, debug");
  _instance = new Storage$1();
  _instance.vault = new Storage$1();
  var old_configure = _instance.configure;
  _instance.configure = function(options) {
    logger.debug("storage configure called");
    var vaultConfig = __assign({}, old_configure.call(_instance, options));
    Object.keys(vaultConfig).forEach(function(providerName) {
      if (typeof vaultConfig[providerName] !== "string") {
        vaultConfig[providerName] = __assign(__assign({}, vaultConfig[providerName]), { level: "private" });
      }
    });
    logger.debug("storage vault configure called");
    _instance.vault.configure(vaultConfig);
  };
  return _instance;
};
var Storage = getInstance();
Amplify.register(Storage);
export { AWSS3Provider, Storage, Storage$1 as StorageClass, Storage as default };
//# sourceMappingURL=index2.js.map

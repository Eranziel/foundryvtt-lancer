import { t as tippy, R as RangeType, W as WeaponRangeTemplate, f as fade, d as targetsFromTemplate } from "./lancer.js";
function noop() {
}
const identity = (x) => x;
function assign(tar, src) {
  for (const k in src)
    tar[k] = src[k];
  return tar;
}
function run(fn) {
  return fn();
}
function blank_object() {
  return /* @__PURE__ */ Object.create(null);
}
function run_all(fns) {
  fns.forEach(run);
}
function is_function(thing) {
  return typeof thing === "function";
}
function safe_not_equal(a, b) {
  return a != a ? b == b : a !== b || (a && typeof a === "object" || typeof a === "function");
}
let src_url_equal_anchor;
function src_url_equal(element_src, url) {
  if (!src_url_equal_anchor) {
    src_url_equal_anchor = document.createElement("a");
  }
  src_url_equal_anchor.href = url;
  return element_src === src_url_equal_anchor.href;
}
function is_empty(obj) {
  return Object.keys(obj).length === 0;
}
function subscribe(store, ...callbacks) {
  if (store == null) {
    return noop;
  }
  const unsub = store.subscribe(...callbacks);
  return unsub.unsubscribe ? () => unsub.unsubscribe() : unsub;
}
function component_subscribe(component, store, callback) {
  component.$$.on_destroy.push(subscribe(store, callback));
}
function action_destroyer(action_result) {
  return action_result && is_function(action_result.destroy) ? action_result.destroy : noop;
}
const is_client = typeof window !== "undefined";
let now = is_client ? () => window.performance.now() : () => Date.now();
let raf = is_client ? (cb) => requestAnimationFrame(cb) : noop;
const tasks = /* @__PURE__ */ new Set();
function run_tasks(now2) {
  tasks.forEach((task) => {
    if (!task.c(now2)) {
      tasks.delete(task);
      task.f();
    }
  });
  if (tasks.size !== 0)
    raf(run_tasks);
}
function loop(callback) {
  let task;
  if (tasks.size === 0)
    raf(run_tasks);
  return {
    promise: new Promise((fulfill) => {
      tasks.add(task = { c: callback, f: fulfill });
    }),
    abort() {
      tasks.delete(task);
    }
  };
}
function append(target, node) {
  target.appendChild(node);
}
function get_root_for_style(node) {
  if (!node)
    return document;
  const root = node.getRootNode ? node.getRootNode() : node.ownerDocument;
  if (root && root.host) {
    return root;
  }
  return node.ownerDocument;
}
function append_empty_stylesheet(node) {
  const style_element = element("style");
  append_stylesheet(get_root_for_style(node), style_element);
  return style_element.sheet;
}
function append_stylesheet(node, style) {
  append(node.head || node, style);
}
function insert(target, node, anchor) {
  target.insertBefore(node, anchor || null);
}
function detach(node) {
  node.parentNode.removeChild(node);
}
function destroy_each(iterations, detaching) {
  for (let i = 0; i < iterations.length; i += 1) {
    if (iterations[i])
      iterations[i].d(detaching);
  }
}
function element(name) {
  return document.createElement(name);
}
function text(data) {
  return document.createTextNode(data);
}
function space() {
  return text(" ");
}
function empty() {
  return text("");
}
function listen(node, event, handler, options) {
  node.addEventListener(event, handler, options);
  return () => node.removeEventListener(event, handler, options);
}
function prevent_default(fn) {
  return function(event) {
    event.preventDefault();
    return fn.call(this, event);
  };
}
function attr(node, attribute, value) {
  if (value == null)
    node.removeAttribute(attribute);
  else if (node.getAttribute(attribute) !== value)
    node.setAttribute(attribute, value);
}
function to_number(value) {
  return value === "" ? null : +value;
}
function children(element2) {
  return Array.from(element2.childNodes);
}
function set_data(text2, data) {
  data = "" + data;
  if (text2.wholeText !== data)
    text2.data = data;
}
function set_input_value(input, value) {
  input.value = value == null ? "" : value;
}
function set_style(node, key, value, important) {
  if (value === null) {
    node.style.removeProperty(key);
  } else {
    node.style.setProperty(key, value, important ? "important" : "");
  }
}
function toggle_class(element2, name, toggle) {
  element2.classList[toggle ? "add" : "remove"](name);
}
function custom_event(type, detail, { bubbles = false, cancelable = false } = {}) {
  const e = document.createEvent("CustomEvent");
  e.initCustomEvent(type, bubbles, cancelable, detail);
  return e;
}
const managed_styles = /* @__PURE__ */ new Map();
let active = 0;
function hash(str) {
  let hash2 = 5381;
  let i = str.length;
  while (i--)
    hash2 = (hash2 << 5) - hash2 ^ str.charCodeAt(i);
  return hash2 >>> 0;
}
function create_style_information(doc, node) {
  const info = { stylesheet: append_empty_stylesheet(node), rules: {} };
  managed_styles.set(doc, info);
  return info;
}
function create_rule(node, a, b, duration, delay, ease, fn, uid = 0) {
  const step = 16.666 / duration;
  let keyframes = "{\n";
  for (let p = 0; p <= 1; p += step) {
    const t = a + (b - a) * ease(p);
    keyframes += p * 100 + `%{${fn(t, 1 - t)}}
`;
  }
  const rule = keyframes + `100% {${fn(b, 1 - b)}}
}`;
  const name = `__svelte_${hash(rule)}_${uid}`;
  const doc = get_root_for_style(node);
  const { stylesheet, rules } = managed_styles.get(doc) || create_style_information(doc, node);
  if (!rules[name]) {
    rules[name] = true;
    stylesheet.insertRule(`@keyframes ${name} ${rule}`, stylesheet.cssRules.length);
  }
  const animation = node.style.animation || "";
  node.style.animation = `${animation ? `${animation}, ` : ""}${name} ${duration}ms linear ${delay}ms 1 both`;
  active += 1;
  return name;
}
function delete_rule(node, name) {
  const previous = (node.style.animation || "").split(", ");
  const next = previous.filter(
    name ? (anim) => anim.indexOf(name) < 0 : (anim) => anim.indexOf("__svelte") === -1
  );
  const deleted = previous.length - next.length;
  if (deleted) {
    node.style.animation = next.join(", ");
    active -= deleted;
    if (!active)
      clear_rules();
  }
}
function clear_rules() {
  raf(() => {
    if (active)
      return;
    managed_styles.forEach((info) => {
      const { stylesheet } = info;
      let i = stylesheet.cssRules.length;
      while (i--)
        stylesheet.deleteRule(i);
      info.rules = {};
    });
    managed_styles.clear();
  });
}
function create_animation(node, from, fn, params) {
  if (!from)
    return noop;
  const to = node.getBoundingClientRect();
  if (from.left === to.left && from.right === to.right && from.top === to.top && from.bottom === to.bottom)
    return noop;
  const {
    delay = 0,
    duration = 300,
    easing = identity,
    start: start_time = now() + delay,
    end = start_time + duration,
    tick = noop,
    css
  } = fn(node, { from, to }, params);
  let running = true;
  let started = false;
  let name;
  function start() {
    if (css) {
      name = create_rule(node, 0, 1, duration, delay, easing, css);
    }
    if (!delay) {
      started = true;
    }
  }
  function stop() {
    if (css)
      delete_rule(node, name);
    running = false;
  }
  loop((now2) => {
    if (!started && now2 >= start_time) {
      started = true;
    }
    if (started && now2 >= end) {
      tick(1, 0);
      stop();
    }
    if (!running) {
      return false;
    }
    if (started) {
      const p = now2 - start_time;
      const t = 0 + 1 * easing(p / duration);
      tick(t, 1 - t);
    }
    return true;
  });
  start();
  tick(0, 1);
  return stop;
}
function fix_position(node) {
  const style = getComputedStyle(node);
  if (style.position !== "absolute" && style.position !== "fixed") {
    const { width, height } = style;
    const a = node.getBoundingClientRect();
    node.style.position = "absolute";
    node.style.width = width;
    node.style.height = height;
    add_transform(node, a);
  }
}
function add_transform(node, a) {
  const b = node.getBoundingClientRect();
  if (a.left !== b.left || a.top !== b.top) {
    const style = getComputedStyle(node);
    const transform = style.transform === "none" ? "" : style.transform;
    node.style.transform = `${transform} translate(${a.left - b.left}px, ${a.top - b.top}px)`;
  }
}
let current_component;
function set_current_component(component) {
  current_component = component;
}
function get_current_component() {
  if (!current_component)
    throw new Error("Function called outside component initialization");
  return current_component;
}
function onMount(fn) {
  get_current_component().$$.on_mount.push(fn);
}
function createEventDispatcher() {
  const component = get_current_component();
  return (type, detail, { cancelable = false } = {}) => {
    const callbacks = component.$$.callbacks[type];
    if (callbacks) {
      const event = custom_event(type, detail, { cancelable });
      callbacks.slice().forEach((fn) => {
        fn.call(component, event);
      });
      return !event.defaultPrevented;
    }
    return true;
  };
}
const dirty_components = [];
const binding_callbacks = [];
const render_callbacks = [];
const flush_callbacks = [];
const resolved_promise = Promise.resolve();
let update_scheduled = false;
function schedule_update() {
  if (!update_scheduled) {
    update_scheduled = true;
    resolved_promise.then(flush);
  }
}
function add_render_callback(fn) {
  render_callbacks.push(fn);
}
function add_flush_callback(fn) {
  flush_callbacks.push(fn);
}
const seen_callbacks = /* @__PURE__ */ new Set();
let flushidx = 0;
function flush() {
  const saved_component = current_component;
  do {
    while (flushidx < dirty_components.length) {
      const component = dirty_components[flushidx];
      flushidx++;
      set_current_component(component);
      update(component.$$);
    }
    set_current_component(null);
    dirty_components.length = 0;
    flushidx = 0;
    while (binding_callbacks.length)
      binding_callbacks.pop()();
    for (let i = 0; i < render_callbacks.length; i += 1) {
      const callback = render_callbacks[i];
      if (!seen_callbacks.has(callback)) {
        seen_callbacks.add(callback);
        callback();
      }
    }
    render_callbacks.length = 0;
  } while (dirty_components.length);
  while (flush_callbacks.length) {
    flush_callbacks.pop()();
  }
  update_scheduled = false;
  seen_callbacks.clear();
  set_current_component(saved_component);
}
function update($$) {
  if ($$.fragment !== null) {
    $$.update();
    run_all($$.before_update);
    const dirty = $$.dirty;
    $$.dirty = [-1];
    $$.fragment && $$.fragment.p($$.ctx, dirty);
    $$.after_update.forEach(add_render_callback);
  }
}
let promise;
function wait() {
  if (!promise) {
    promise = Promise.resolve();
    promise.then(() => {
      promise = null;
    });
  }
  return promise;
}
function dispatch(node, direction, kind) {
  node.dispatchEvent(custom_event(`${direction ? "intro" : "outro"}${kind}`));
}
const outroing = /* @__PURE__ */ new Set();
let outros;
function group_outros() {
  outros = {
    r: 0,
    c: [],
    p: outros
  };
}
function check_outros() {
  if (!outros.r) {
    run_all(outros.c);
  }
  outros = outros.p;
}
function transition_in(block, local) {
  if (block && block.i) {
    outroing.delete(block);
    block.i(local);
  }
}
function transition_out(block, local, detach2, callback) {
  if (block && block.o) {
    if (outroing.has(block))
      return;
    outroing.add(block);
    outros.c.push(() => {
      outroing.delete(block);
      if (callback) {
        if (detach2)
          block.d(1);
        callback();
      }
    });
    block.o(local);
  } else if (callback) {
    callback();
  }
}
const null_transition = { duration: 0 };
function create_in_transition(node, fn, params) {
  let config = fn(node, params);
  let running = false;
  let animation_name;
  let task;
  let uid = 0;
  function cleanup() {
    if (animation_name)
      delete_rule(node, animation_name);
  }
  function go() {
    const { delay = 0, duration = 300, easing = identity, tick = noop, css } = config || null_transition;
    if (css)
      animation_name = create_rule(node, 0, 1, duration, delay, easing, css, uid++);
    tick(0, 1);
    const start_time = now() + delay;
    const end_time = start_time + duration;
    if (task)
      task.abort();
    running = true;
    add_render_callback(() => dispatch(node, true, "start"));
    task = loop((now2) => {
      if (running) {
        if (now2 >= end_time) {
          tick(1, 0);
          dispatch(node, true, "end");
          cleanup();
          return running = false;
        }
        if (now2 >= start_time) {
          const t = easing((now2 - start_time) / duration);
          tick(t, 1 - t);
        }
      }
      return running;
    });
  }
  let started = false;
  return {
    start() {
      if (started)
        return;
      started = true;
      delete_rule(node);
      if (is_function(config)) {
        config = config();
        wait().then(go);
      } else {
        go();
      }
    },
    invalidate() {
      started = false;
    },
    end() {
      if (running) {
        cleanup();
        running = false;
      }
    }
  };
}
function create_out_transition(node, fn, params) {
  let config = fn(node, params);
  let running = true;
  let animation_name;
  const group = outros;
  group.r += 1;
  function go() {
    const { delay = 0, duration = 300, easing = identity, tick = noop, css } = config || null_transition;
    if (css)
      animation_name = create_rule(node, 1, 0, duration, delay, easing, css);
    const start_time = now() + delay;
    const end_time = start_time + duration;
    add_render_callback(() => dispatch(node, false, "start"));
    loop((now2) => {
      if (running) {
        if (now2 >= end_time) {
          tick(0, 1);
          dispatch(node, false, "end");
          if (!--group.r) {
            run_all(group.c);
          }
          return false;
        }
        if (now2 >= start_time) {
          const t = easing((now2 - start_time) / duration);
          tick(1 - t, t);
        }
      }
      return running;
    });
  }
  if (is_function(config)) {
    wait().then(() => {
      config = config();
      go();
    });
  } else {
    go();
  }
  return {
    end(reset) {
      if (reset && config.tick) {
        config.tick(1, 0);
      }
      if (running) {
        if (animation_name)
          delete_rule(node, animation_name);
        running = false;
      }
    }
  };
}
function create_bidirectional_transition(node, fn, params, intro) {
  let config = fn(node, params);
  let t = intro ? 0 : 1;
  let running_program = null;
  let pending_program = null;
  let animation_name = null;
  function clear_animation() {
    if (animation_name)
      delete_rule(node, animation_name);
  }
  function init2(program, duration) {
    const d = program.b - t;
    duration *= Math.abs(d);
    return {
      a: t,
      b: program.b,
      d,
      duration,
      start: program.start,
      end: program.start + duration,
      group: program.group
    };
  }
  function go(b) {
    const { delay = 0, duration = 300, easing = identity, tick = noop, css } = config || null_transition;
    const program = {
      start: now() + delay,
      b
    };
    if (!b) {
      program.group = outros;
      outros.r += 1;
    }
    if (running_program || pending_program) {
      pending_program = program;
    } else {
      if (css) {
        clear_animation();
        animation_name = create_rule(node, t, b, duration, delay, easing, css);
      }
      if (b)
        tick(0, 1);
      running_program = init2(program, duration);
      add_render_callback(() => dispatch(node, b, "start"));
      loop((now2) => {
        if (pending_program && now2 > pending_program.start) {
          running_program = init2(pending_program, duration);
          pending_program = null;
          dispatch(node, running_program.b, "start");
          if (css) {
            clear_animation();
            animation_name = create_rule(node, t, running_program.b, running_program.duration, 0, easing, config.css);
          }
        }
        if (running_program) {
          if (now2 >= running_program.end) {
            tick(t = running_program.b, 1 - t);
            dispatch(node, running_program.b, "end");
            if (!pending_program) {
              if (running_program.b) {
                clear_animation();
              } else {
                if (!--running_program.group.r)
                  run_all(running_program.group.c);
              }
            }
            running_program = null;
          } else if (now2 >= running_program.start) {
            const p = now2 - running_program.start;
            t = running_program.a + running_program.d * easing(p / running_program.duration);
            tick(t, 1 - t);
          }
        }
        return !!(running_program || pending_program);
      });
    }
  }
  return {
    run(b) {
      if (is_function(config)) {
        wait().then(() => {
          config = config();
          go(b);
        });
      } else {
        go(b);
      }
    },
    end() {
      clear_animation();
      running_program = pending_program = null;
    }
  };
}
function outro_and_destroy_block(block, lookup) {
  transition_out(block, 1, 1, () => {
    lookup.delete(block.key);
  });
}
function fix_and_outro_and_destroy_block(block, lookup) {
  block.f();
  outro_and_destroy_block(block, lookup);
}
function update_keyed_each(old_blocks, dirty, get_key, dynamic, ctx, list, lookup, node, destroy, create_each_block2, next, get_context) {
  let o = old_blocks.length;
  let n = list.length;
  let i = o;
  const old_indexes = {};
  while (i--)
    old_indexes[old_blocks[i].key] = i;
  const new_blocks = [];
  const new_lookup = /* @__PURE__ */ new Map();
  const deltas = /* @__PURE__ */ new Map();
  i = n;
  while (i--) {
    const child_ctx = get_context(ctx, list, i);
    const key = get_key(child_ctx);
    let block = lookup.get(key);
    if (!block) {
      block = create_each_block2(key, child_ctx);
      block.c();
    } else if (dynamic) {
      block.p(child_ctx, dirty);
    }
    new_lookup.set(key, new_blocks[i] = block);
    if (key in old_indexes)
      deltas.set(key, Math.abs(i - old_indexes[key]));
  }
  const will_move = /* @__PURE__ */ new Set();
  const did_move = /* @__PURE__ */ new Set();
  function insert2(block) {
    transition_in(block, 1);
    block.m(node, next);
    lookup.set(block.key, block);
    next = block.first;
    n--;
  }
  while (o && n) {
    const new_block = new_blocks[n - 1];
    const old_block = old_blocks[o - 1];
    const new_key = new_block.key;
    const old_key = old_block.key;
    if (new_block === old_block) {
      next = new_block.first;
      o--;
      n--;
    } else if (!new_lookup.has(old_key)) {
      destroy(old_block, lookup);
      o--;
    } else if (!lookup.has(new_key) || will_move.has(new_key)) {
      insert2(new_block);
    } else if (did_move.has(old_key)) {
      o--;
    } else if (deltas.get(new_key) > deltas.get(old_key)) {
      did_move.add(new_key);
      insert2(new_block);
    } else {
      will_move.add(old_key);
      o--;
    }
  }
  while (o--) {
    const old_block = old_blocks[o];
    if (!new_lookup.has(old_block.key))
      destroy(old_block, lookup);
  }
  while (n)
    insert2(new_blocks[n - 1]);
  return new_blocks;
}
function get_spread_update(levels, updates) {
  const update2 = {};
  const to_null_out = {};
  const accounted_for = { $$scope: 1 };
  let i = levels.length;
  while (i--) {
    const o = levels[i];
    const n = updates[i];
    if (n) {
      for (const key in o) {
        if (!(key in n))
          to_null_out[key] = 1;
      }
      for (const key in n) {
        if (!accounted_for[key]) {
          update2[key] = n[key];
          accounted_for[key] = 1;
        }
      }
      levels[i] = n;
    } else {
      for (const key in o) {
        accounted_for[key] = 1;
      }
    }
  }
  for (const key in to_null_out) {
    if (!(key in update2))
      update2[key] = void 0;
  }
  return update2;
}
function get_spread_object(spread_props) {
  return typeof spread_props === "object" && spread_props !== null ? spread_props : {};
}
function bind(component, name, callback) {
  const index = component.$$.props[name];
  if (index !== void 0) {
    component.$$.bound[index] = callback;
    callback(component.$$.ctx[index]);
  }
}
function create_component(block) {
  block && block.c();
}
function mount_component(component, target, anchor, customElement) {
  const { fragment, on_mount, on_destroy, after_update } = component.$$;
  fragment && fragment.m(target, anchor);
  if (!customElement) {
    add_render_callback(() => {
      const new_on_destroy = on_mount.map(run).filter(is_function);
      if (on_destroy) {
        on_destroy.push(...new_on_destroy);
      } else {
        run_all(new_on_destroy);
      }
      component.$$.on_mount = [];
    });
  }
  after_update.forEach(add_render_callback);
}
function destroy_component(component, detaching) {
  const $$ = component.$$;
  if ($$.fragment !== null) {
    run_all($$.on_destroy);
    $$.fragment && $$.fragment.d(detaching);
    $$.on_destroy = $$.fragment = null;
    $$.ctx = [];
  }
}
function make_dirty(component, i) {
  if (component.$$.dirty[0] === -1) {
    dirty_components.push(component);
    schedule_update();
    component.$$.dirty.fill(0);
  }
  component.$$.dirty[i / 31 | 0] |= 1 << i % 31;
}
function init(component, options, instance2, create_fragment2, not_equal, props, append_styles, dirty = [-1]) {
  const parent_component = current_component;
  set_current_component(component);
  const $$ = component.$$ = {
    fragment: null,
    ctx: null,
    props,
    update: noop,
    not_equal,
    bound: blank_object(),
    on_mount: [],
    on_destroy: [],
    on_disconnect: [],
    before_update: [],
    after_update: [],
    context: new Map(options.context || (parent_component ? parent_component.$$.context : [])),
    callbacks: blank_object(),
    dirty,
    skip_bound: false,
    root: options.target || parent_component.$$.root
  };
  append_styles && append_styles($$.root);
  let ready = false;
  $$.ctx = instance2 ? instance2(component, options.props || {}, (i, ret, ...rest) => {
    const value = rest.length ? rest[0] : ret;
    if ($$.ctx && not_equal($$.ctx[i], $$.ctx[i] = value)) {
      if (!$$.skip_bound && $$.bound[i])
        $$.bound[i](value);
      if (ready)
        make_dirty(component, i);
    }
    return ret;
  }) : [];
  $$.update();
  ready = true;
  run_all($$.before_update);
  $$.fragment = create_fragment2 ? create_fragment2($$.ctx) : false;
  if (options.target) {
    if (options.hydrate) {
      const nodes = children(options.target);
      $$.fragment && $$.fragment.l(nodes);
      nodes.forEach(detach);
    } else {
      $$.fragment && $$.fragment.c();
    }
    if (options.intro)
      transition_in(component.$$.fragment);
    mount_component(component, options.target, options.anchor, options.customElement);
    flush();
  }
  set_current_component(parent_component);
}
class SvelteComponent {
  $destroy() {
    destroy_component(this, 1);
    this.$destroy = noop;
  }
  $on(type, callback) {
    const callbacks = this.$$.callbacks[type] || (this.$$.callbacks[type] = []);
    callbacks.push(callback);
    return () => {
      const index = callbacks.indexOf(callback);
      if (index !== -1)
        callbacks.splice(index, 1);
    };
  }
  $set($$props) {
    if (this.$$set && !is_empty($$props)) {
      this.$$.skip_bound = true;
      this.$$set($$props);
      this.$$.skip_bound = false;
    }
  }
}
function cubicInOut(t) {
  return t < 0.5 ? 4 * t * t * t : 0.5 * Math.pow(2 * t - 2, 3) + 1;
}
function cubicOut(t) {
  const f = t - 1;
  return f * f * f + 1;
}
function flip(node, { from, to }, params = {}) {
  const style = getComputedStyle(node);
  const transform = style.transform === "none" ? "" : style.transform;
  const [ox, oy] = style.transformOrigin.split(" ").map(parseFloat);
  const dx = from.left + from.width * ox / to.width - (to.left + ox);
  const dy = from.top + from.height * oy / to.height - (to.top + oy);
  const { delay = 0, duration = (d) => Math.sqrt(d) * 120, easing = cubicOut } = params;
  return {
    delay,
    duration: is_function(duration) ? duration(Math.sqrt(dx * dx + dy * dy)) : duration,
    easing,
    css: (t, u) => {
      const x = u * dx;
      const y = u * dy;
      const sx = t + u * from.width / to.width;
      const sy = t + u * from.height / to.height;
      return `transform: ${transform} translate(${x}px, ${y}px) scale(${sx}, ${sy});`;
    }
  };
}
/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
function __rest(s, e) {
  var t = {};
  for (var p in s)
    if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
      t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function")
    for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
      if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
        t[p[i]] = s[p[i]];
    }
  return t;
}
function blur(node, { delay = 0, duration = 400, easing = cubicInOut, amount = 5, opacity = 0 } = {}) {
  const style = getComputedStyle(node);
  const target_opacity = +style.opacity;
  const f = style.filter === "none" ? "" : style.filter;
  const od = target_opacity * (1 - opacity);
  return {
    delay,
    duration,
    easing,
    css: (_t, u) => `opacity: ${target_opacity - od * u}; filter: ${f} blur(${u * amount}px);`
  };
}
function fly(node, { delay = 0, duration = 400, easing = cubicOut, x = 0, y = 0, opacity = 0 } = {}) {
  const style = getComputedStyle(node);
  const target_opacity = +style.opacity;
  const transform = style.transform === "none" ? "" : style.transform;
  const od = target_opacity * (1 - opacity);
  return {
    delay,
    duration,
    easing,
    css: (t, u) => `
			transform: ${transform} translate(${(1 - t) * x}px, ${(1 - t) * y}px);
			opacity: ${target_opacity - od * u}`
  };
}
function slide(node, { delay = 0, duration = 400, easing = cubicOut } = {}) {
  const style = getComputedStyle(node);
  const opacity = +style.opacity;
  const height = parseFloat(style.height);
  const padding_top = parseFloat(style.paddingTop);
  const padding_bottom = parseFloat(style.paddingBottom);
  const margin_top = parseFloat(style.marginTop);
  const margin_bottom = parseFloat(style.marginBottom);
  const border_top_width = parseFloat(style.borderTopWidth);
  const border_bottom_width = parseFloat(style.borderBottomWidth);
  return {
    delay,
    duration,
    easing,
    css: (t) => `overflow: hidden;opacity: ${Math.min(t * 20, 1) * opacity};height: ${t * height}px;padding-top: ${t * padding_top}px;padding-bottom: ${t * padding_bottom}px;margin-top: ${t * margin_top}px;margin-bottom: ${t * margin_bottom}px;border-top-width: ${t * border_top_width}px;border-bottom-width: ${t * border_bottom_width}px;`
  };
}
function crossfade(_a) {
  var { fallback } = _a, defaults = __rest(_a, ["fallback"]);
  const to_receive = /* @__PURE__ */ new Map();
  const to_send = /* @__PURE__ */ new Map();
  function crossfade2(from, node, params) {
    const { delay = 0, duration = (d2) => Math.sqrt(d2) * 30, easing = cubicOut } = assign(assign({}, defaults), params);
    const to = node.getBoundingClientRect();
    const dx = from.left - to.left;
    const dy = from.top - to.top;
    const dw = from.width / to.width;
    const dh = from.height / to.height;
    const d = Math.sqrt(dx * dx + dy * dy);
    const style = getComputedStyle(node);
    const transform = style.transform === "none" ? "" : style.transform;
    const opacity = +style.opacity;
    return {
      delay,
      duration: is_function(duration) ? duration(d) : duration,
      easing,
      css: (t, u) => `
				opacity: ${t * opacity};
				transform-origin: top left;
				transform: ${transform} translate(${u * dx}px,${u * dy}px) scale(${t + (1 - t) * dw}, ${t + (1 - t) * dh});
			`
    };
  }
  function transition(items, counterparts, intro) {
    return (node, params) => {
      items.set(params.key, {
        rect: node.getBoundingClientRect()
      });
      return () => {
        if (counterparts.has(params.key)) {
          const { rect } = counterparts.get(params.key);
          counterparts.delete(params.key);
          return crossfade2(rect, node, params);
        }
        items.delete(params.key);
        return fallback && fallback(node, params, intro);
      };
    };
  }
  return [
    transition(to_send, to_receive, false),
    transition(to_receive, to_send, true)
  ];
}
const subscriber_queue = [];
function readable(value, start) {
  return {
    subscribe: writable(value, start).subscribe
  };
}
function writable(value, start = noop) {
  let stop;
  const subscribers = /* @__PURE__ */ new Set();
  function set(new_value) {
    if (safe_not_equal(value, new_value)) {
      value = new_value;
      if (stop) {
        const run_queue = !subscriber_queue.length;
        for (const subscriber of subscribers) {
          subscriber[1]();
          subscriber_queue.push(subscriber, value);
        }
        if (run_queue) {
          for (let i = 0; i < subscriber_queue.length; i += 2) {
            subscriber_queue[i][0](subscriber_queue[i + 1]);
          }
          subscriber_queue.length = 0;
        }
      }
    }
  }
  function update2(fn) {
    set(fn(value));
  }
  function subscribe2(run2, invalidate = noop) {
    const subscriber = [run2, invalidate];
    subscribers.add(subscriber);
    if (subscribers.size === 1) {
      stop = start(set) || noop;
    }
    run2(value);
    return () => {
      subscribers.delete(subscriber);
      if (subscribers.size === 0) {
        stop();
        stop = null;
      }
    };
  }
  return { set, update: update2, subscribe: subscribe2 };
}
function derived(stores, fn, initial_value) {
  const single = !Array.isArray(stores);
  const stores_array = single ? [stores] : stores;
  const auto = fn.length < 2;
  return readable(initial_value, (set) => {
    let inited = false;
    const values = [];
    let pending = 0;
    let cleanup = noop;
    const sync = () => {
      if (pending) {
        return;
      }
      cleanup();
      const result = fn(single ? values[0] : values, set);
      if (auto) {
        set(result);
      } else {
        cleanup = is_function(result) ? result : noop;
      }
    };
    const unsubscribers = stores_array.map((store, i) => subscribe(store, (value) => {
      values[i] = value;
      pending &= ~(1 << i);
      if (inited) {
        sync();
      }
    }, () => {
      pending |= 1 << i;
    }));
    inited = true;
    sync();
    return function stop() {
      run_all(unsubscribers);
      cleanup();
    };
  });
}
const sidebarWidth = readable(0, (update2) => {
  const sidebar = $("#sidebar");
  function setWidth() {
    update2(sidebar.width() || 0);
  }
  setWidth();
  Hooks.on("collapseSidebar", setWidth);
});
const dataTransfer = readable(null, (update2) => {
  function updateData(e) {
    var _a;
    update2(e.defaultPrevented ? null : (_a = e.dataTransfer) != null ? _a : null);
  }
  document.addEventListener(
    "dragstart",
    (e) => {
      setTimeout(() => updateData(e), 0);
    },
    {
      capture: true,
      passive: true
    }
  );
  document.addEventListener(
    "dragend",
    (e) => {
      update2(null);
    },
    {
      capture: true,
      passive: true
    }
  );
});
const isDragging = derived(dataTransfer, (dt) => !!dt);
const userTargets = readable([], (update2) => {
  function updateData() {
    update2(Array.from(game.user.targets));
  }
  Hooks.on("targetToken", (user, _token, _isNewTarget) => {
    if (user.isSelf) {
      updateData();
    }
  });
  Hooks.on("createActiveEffect", updateData);
  Hooks.on("deleteActiveEffect", updateData);
  Hooks.on("updateToken", updateData);
});
function create_if_block$4(ctx) {
  let label;
  let t0_value = ctx[0].humanLabel + "";
  let t0;
  let t1;
  let input;
  let input_disabled_value;
  let t2;
  let span;
  let label_transition;
  let current;
  let mounted;
  let dispose;
  return {
    c() {
      label = element("label");
      t0 = text(t0_value);
      t1 = space();
      input = element("input");
      t2 = space();
      span = element("span");
      attr(input, "type", "checkbox");
      input.disabled = input_disabled_value = ctx[0].disabled;
      attr(span, "class", "checkmark");
      attr(label, "class", "container");
    },
    m(target, anchor) {
      insert(target, label, anchor);
      append(label, t0);
      append(label, t1);
      append(label, input);
      input.checked = ctx[0].uiState;
      append(label, t2);
      append(label, span);
      current = true;
      if (!mounted) {
        dispose = listen(input, "change", ctx[1]);
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if ((!current || dirty & 1) && t0_value !== (t0_value = ctx2[0].humanLabel + ""))
        set_data(t0, t0_value);
      if (!current || dirty & 1 && input_disabled_value !== (input_disabled_value = ctx2[0].disabled)) {
        input.disabled = input_disabled_value;
      }
      if (dirty & 1) {
        input.checked = ctx2[0].uiState;
      }
    },
    i(local) {
      if (current)
        return;
      if (local) {
        add_render_callback(() => {
          if (!label_transition)
            label_transition = create_bidirectional_transition(label, slide, {}, true);
          label_transition.run(1);
        });
      }
      current = true;
    },
    o(local) {
      if (local) {
        if (!label_transition)
          label_transition = create_bidirectional_transition(label, slide, {}, false);
        label_transition.run(0);
      }
      current = false;
    },
    d(detaching) {
      if (detaching)
        detach(label);
      if (detaching && label_transition)
        label_transition.end();
      mounted = false;
      dispose();
    }
  };
}
function create_fragment$7(ctx) {
  let if_block_anchor;
  let if_block = ctx[0].uiElement == "checkbox" && ctx[0].visible && create_if_block$4(ctx);
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
    },
    p(ctx2, [dirty]) {
      if (ctx2[0].uiElement == "checkbox" && ctx2[0].visible) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & 1) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$4(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      transition_in(if_block);
    },
    o(local) {
      transition_out(if_block);
    },
    d(detaching) {
      if (if_block)
        if_block.d(detaching);
      if (detaching)
        detach(if_block_anchor);
    }
  };
}
function instance$7($$self, $$props, $$invalidate) {
  let { data } = $$props;
  function input_change_handler() {
    data.uiState = this.checked;
    $$invalidate(0, data);
  }
  $$self.$$set = ($$props2) => {
    if ("data" in $$props2)
      $$invalidate(0, data = $$props2.data);
  };
  return [data, input_change_handler];
}
class Plugin extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$7, create_fragment$7, safe_not_equal, { data: 0 });
  }
}
var Cover_svelte_svelte_type_style_lang = /* @__PURE__ */ (() => 'i.svelte-1fjg61h.svelte-1fjg61h{border:none}input.svelte-1fjg61h.svelte-1fjg61h{opacity:0;position:fixed;width:0}label.svelte-1fjg61h.svelte-1fjg61h{display:inline-block;padding-left:5px;position:relative}.flexrow.svelte-1fjg61h label.svelte-1fjg61h{padding:0}.cover-arrow.svelte-1fjg61h.svelte-1fjg61h,.svelte-1fjg61h:not(.disabled) label.svelte-1fjg61h:hover:after{content:"";position:absolute;right:98%;top:calc(50% - 4px);background-color:var(--main-theme-color);width:8px;height:8px;clip-path:polygon(0 0,0 100%,100% 50%)}.card .cover-arrow.svelte-1fjg61h.svelte-1fjg61h,.card .svelte-1fjg61h:not(.disabled) label.svelte-1fjg61h:hover:after{right:unset;top:unset;bottom:90%;left:calc(50% - 3px);width:6px;height:6px;clip-path:polygon(0 0,100% 0,50% 100%)}.svelte-1fjg61h:not(.disabled) label.svelte-1fjg61h:hover:after{opacity:40%}.disabled.svelte-1fjg61h.svelte-1fjg61h{opacity:.4}\n')();
function get_each_context$4(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[10] = list[i];
  return child_ctx;
}
function create_if_block$3(ctx) {
  let div;
  let div_intro;
  let div_outro;
  let current;
  return {
    c() {
      div = element("div");
      attr(div, "class", "cover-arrow svelte-1fjg61h");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      current = true;
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
    },
    i(local) {
      if (current)
        return;
      if (local) {
        add_render_callback(() => {
          if (div_outro)
            div_outro.end(1);
          div_intro = create_in_transition(div, ctx[6], { key: ctx[4] });
          div_intro.start();
        });
      }
      current = true;
    },
    o(local) {
      if (div_intro)
        div_intro.invalidate();
      if (local) {
        div_outro = create_out_transition(div, ctx[7], { key: ctx[4] });
      }
      current = false;
    },
    d(detaching) {
      if (detaching)
        detach(div);
      if (detaching && div_outro)
        div_outro.end();
    }
  };
}
function create_each_block$4(ctx) {
  let input;
  let t0;
  let label;
  let i;
  let t1;
  let span;
  let t2_value = ctx[10].human + "";
  let t2;
  let t3;
  let t4;
  let label_class_value;
  let mounted;
  let dispose;
  let if_block = ctx[10].value == ctx[0] && create_if_block$3(ctx);
  return {
    c() {
      input = element("input");
      t0 = space();
      label = element("label");
      i = element("i");
      t1 = space();
      span = element("span");
      t2 = text(t2_value);
      t3 = space();
      if (if_block)
        if_block.c();
      t4 = space();
      attr(input, "type", "radio");
      attr(input, "id", ctx[4] + "-" + ctx[10].slug);
      attr(input, "class", "no-grow " + ctx[10].slug + "-cover svelte-1fjg61h");
      input.__value = ctx[10].value;
      input.value = input.__value;
      input.disabled = ctx[1];
      ctx[9][0].push(input);
      attr(i, "class", "mdi mdi-" + ctx[10].icon + " i--s svelte-1fjg61h");
      attr(i, "title", ctx[10].human);
      attr(span, "class", "no-grow");
      attr(label, "for", ctx[4] + "-" + ctx[10].slug);
      attr(label, "class", label_class_value = "lancer-cover-radio-label " + ctx[2] + " svelte-1fjg61h");
    },
    m(target, anchor) {
      insert(target, input, anchor);
      input.checked = input.__value === ctx[0];
      insert(target, t0, anchor);
      insert(target, label, anchor);
      append(label, i);
      append(label, t1);
      append(label, span);
      append(span, t2);
      append(label, t3);
      if (if_block)
        if_block.m(label, null);
      append(label, t4);
      if (!mounted) {
        dispose = listen(input, "change", ctx[8]);
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (dirty & 2) {
        input.disabled = ctx2[1];
      }
      if (dirty & 1) {
        input.checked = input.__value === ctx2[0];
      }
      if (ctx2[10].value == ctx2[0]) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & 1) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$3(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(label, t4);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
      if (dirty & 4 && label_class_value !== (label_class_value = "lancer-cover-radio-label " + ctx2[2] + " svelte-1fjg61h")) {
        attr(label, "class", label_class_value);
      }
    },
    d(detaching) {
      if (detaching)
        detach(input);
      ctx[9][0].splice(ctx[9][0].indexOf(input), 1);
      if (detaching)
        detach(t0);
      if (detaching)
        detach(label);
      if (if_block)
        if_block.d();
      mounted = false;
      dispose();
    }
  };
}
function create_fragment$6(ctx) {
  let div;
  let div_class_value;
  let each_value = ctx[5];
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$4(get_each_context$4(ctx, each_value, i));
  }
  return {
    c() {
      div = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(div, "class", div_class_value = "lancer-cover-radio " + ctx[3] + " svelte-1fjg61h");
      toggle_class(div, "disabled", ctx[1]);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].m(div, null);
      }
    },
    p(ctx2, [dirty]) {
      if (dirty & 55) {
        each_value = ctx2[5];
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$4(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block$4(child_ctx);
            each_blocks[i].c();
            each_blocks[i].m(div, null);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value.length;
      }
      if (dirty & 8 && div_class_value !== (div_class_value = "lancer-cover-radio " + ctx2[3] + " svelte-1fjg61h")) {
        attr(div, "class", div_class_value);
      }
      if (dirty & 10) {
        toggle_class(div, "disabled", ctx2[1]);
      }
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching)
        detach(div);
      destroy_each(each_blocks, detaching);
    }
  };
}
let counter$1 = 0;
function instance$6($$self, $$props, $$invalidate) {
  let { cover } = $$props;
  let { disabled = false } = $$props;
  let { labelClass = "" } = $$props;
  let { class: klass = "" } = $$props;
  let id = `accdiff-cover-input-${counter$1++}`;
  let inputs = [
    {
      slug: "no",
      human: "No Cover",
      value: 0,
      icon: "shield-outline"
    },
    {
      slug: "soft",
      human: "Soft Cover (-1)",
      value: 1,
      icon: "shield-half-full"
    },
    {
      slug: "hard",
      human: "Hard Cover (-2)",
      value: 2,
      icon: "shield"
    }
  ];
  let [send2, recv2] = crossfade({});
  const $$binding_groups = [[]];
  function input_change_handler() {
    cover = this.__value;
    $$invalidate(0, cover);
  }
  $$self.$$set = ($$props2) => {
    if ("cover" in $$props2)
      $$invalidate(0, cover = $$props2.cover);
    if ("disabled" in $$props2)
      $$invalidate(1, disabled = $$props2.disabled);
    if ("labelClass" in $$props2)
      $$invalidate(2, labelClass = $$props2.labelClass);
    if ("class" in $$props2)
      $$invalidate(3, klass = $$props2.class);
  };
  return [
    cover,
    disabled,
    labelClass,
    klass,
    id,
    inputs,
    send2,
    recv2,
    input_change_handler,
    $$binding_groups
  ];
}
class Cover extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$6, create_fragment$6, safe_not_equal, {
      cover: 0,
      disabled: 1,
      labelClass: 2,
      class: 3
    });
  }
}
var ConsumeLockOn_svelte_svelte_type_style_lang = /* @__PURE__ */ (() => "input.invisible.svelte-18dpgfx{display:none;opacity:0;position:absolute;width:0}\n")();
function create_fragment$5(ctx) {
  let input;
  let input_checked_value;
  let input_disabled_value;
  let mounted;
  let dispose;
  return {
    c() {
      input = element("input");
      attr(input, "type", "checkbox");
      attr(input, "id", ctx[2]);
      input.checked = input_checked_value = !!ctx[0].usingLockOn;
      input.disabled = input_disabled_value = !ctx[0].lockOnAvailable;
      attr(input, "class", "svelte-18dpgfx");
      toggle_class(input, "invisible", !ctx[1]);
    },
    m(target, anchor) {
      insert(target, input, anchor);
      if (!mounted) {
        dispose = listen(input, "input", ctx[3]);
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (dirty & 4) {
        attr(input, "id", ctx2[2]);
      }
      if (dirty & 1 && input_checked_value !== (input_checked_value = !!ctx2[0].usingLockOn)) {
        input.checked = input_checked_value;
      }
      if (dirty & 1 && input_disabled_value !== (input_disabled_value = !ctx2[0].lockOnAvailable)) {
        input.disabled = input_disabled_value;
      }
      if (dirty & 2) {
        toggle_class(input, "invisible", !ctx2[1]);
      }
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching)
        detach(input);
      mounted = false;
      dispose();
    }
  };
}
function instance$5($$self, $$props, $$invalidate) {
  let { lockOn } = $$props;
  let { visible = true } = $$props;
  let { id = "" } = $$props;
  function handleClick(e) {
    $$invalidate(0, lockOn.consumeLockOn = e.currentTarget.checked, lockOn);
  }
  $$self.$$set = ($$props2) => {
    if ("lockOn" in $$props2)
      $$invalidate(0, lockOn = $$props2.lockOn);
    if ("visible" in $$props2)
      $$invalidate(1, visible = $$props2.visible);
    if ("id" in $$props2)
      $$invalidate(2, id = $$props2.id);
  };
  return [lockOn, visible, id, handleClick];
}
class ConsumeLockOn extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$5, create_fragment$5, safe_not_equal, { lockOn: 0, visible: 1, id: 2 });
  }
}
var Total_svelte_svelte_type_style_lang = /* @__PURE__ */ (() => "i.svelte-eu4t90.svelte-eu4t90{border:none}.accdiff-grid.svelte-eu4t90.svelte-eu4t90{position:relative}.card.clipped.svelte-eu4t90.svelte-eu4t90{display:flex;flex-direction:row;align-items:center;padding:8px 8px 8px 16px;color:#fff;width:min-content;background-color:#443c3c}.total-container.svelte-eu4t90.svelte-eu4t90{filter:drop-shadow(1px 1px 0px)}.accurate.svelte-eu4t90>.card.total.svelte-eu4t90{background-color:#017934}.total-container.accurate.svelte-eu4t90.svelte-eu4t90{filter:drop-shadow(1px 1px 0px #013904)}.inaccurate.svelte-eu4t90>.card.total.svelte-eu4t90{background-color:#9c0d0d}.total-container.inaccurate.svelte-eu4t90.svelte-eu4t90{filter:drop-shadow(1px 1px 0px #5c0d0d)}.disabled.svelte-eu4t90.svelte-eu4t90{opacity:.4}.lancer-hit-thumb.svelte-eu4t90.svelte-eu4t90{margin-right:0;margin-left:4px;margin-bottom:4px}label.svelte-eu4t90.svelte-eu4t90{position:absolute;right:-4px;top:-4px}@keyframes svelte-eu4t90-lockon{70%{text-shadow:0 0 8px lightgreen}80%{text-shadow:0 0 8px green}90%{text-shadow:0 0 8px lightgreen}}.cci-condition-lock-on.svelte-eu4t90.svelte-eu4t90{text-shadow:0 0 12px white;transition:font-size .2s}.cci-condition-lock-on.i--l.svelte-eu4t90.svelte-eu4t90{animation:svelte-eu4t90-lockon .8s linear 1s infinite alternate}.accdiff-target-dropdown.svelte-eu4t90.svelte-eu4t90{display:none}@keyframes svelte-eu4t90-blur{30%{filter:none;opacity:.9}35%{filter:blur(1px);opacity:.7}40%{filter:blur(2px);opacity:.5}43%{filter:blur(1px);opacity:.5}50%{filter:none;opacity:.9}}.accdiff-total-invisibility img.svelte-eu4t90.svelte-eu4t90{animation:svelte-eu4t90-blur 2s linear 1s infinite alternate}.tippy-content .accdiff-target-dropdown.svelte-eu4t90.svelte-eu4t90{display:block}.accdiff-grid.svelte-eu4t90 .tippy-box{font-size:.8em;padding:0 0 4px;transform:none}.accdiff-grid.svelte-eu4t90 .tippy-box .tippy-content{transform:none}.accdiff-grid.svelte-eu4t90 .tippy-box .tippy-content .container{margin:0}.accdiff-grid.svelte-eu4t90 .tippy-box .tippy-content .checkmark{height:12px}\n")();
function get_each_context$3(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[11] = list[i];
  return child_ctx;
}
function get_each_context_1$2(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[14] = list[i];
  child_ctx[15] = list;
  child_ctx[16] = i;
  return child_ctx;
}
function create_if_block$2(ctx) {
  let div;
  let img;
  let img_alt_value;
  let img_src_value;
  let t0;
  let label;
  let i;
  let t1;
  let consumelockon;
  let updating_lockOn;
  let div_intro;
  let div_outro;
  let t2;
  let if_block_anchor;
  let current;
  function consumelockon_lockOn_binding(value) {
    ctx[8](value);
  }
  let consumelockon_props = { visible: false, id: ctx[5] };
  if (ctx[0] !== void 0) {
    consumelockon_props.lockOn = ctx[0];
  }
  consumelockon = new ConsumeLockOn({ props: consumelockon_props });
  binding_callbacks.push(() => bind(consumelockon, "lockOn", consumelockon_lockOn_binding));
  let if_block = !ctx[1] && create_if_block_1$1(ctx);
  return {
    c() {
      var _a, _b;
      div = element("div");
      img = element("img");
      t0 = space();
      label = element("label");
      i = element("i");
      t1 = space();
      create_component(consumelockon.$$.fragment);
      t2 = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
      attr(img, "class", "lancer-hit-thumb accdiff-target-has-dropdown svelte-eu4t90");
      attr(img, "alt", img_alt_value = (_a = ctx[0].target.name) != null ? _a : void 0);
      if (!src_url_equal(img.src, img_src_value = (_b = ctx[0].target.document.texture) == null ? void 0 : _b.src))
        attr(img, "src", img_src_value);
      attr(i, "class", "cci cci-condition-lock-on svelte-eu4t90");
      toggle_class(i, "i--click", ctx[0].lockOnAvailable);
      toggle_class(i, "i--sm", !ctx[0].usingLockOn);
      toggle_class(i, "i--l", ctx[0].usingLockOn);
      attr(label, "for", ctx[5]);
      attr(label, "title", "Consume Lock On (+1)");
      attr(label, "class", "svelte-eu4t90");
      toggle_class(label, "checked", ctx[0].usingLockOn);
      toggle_class(label, "disabled", !ctx[0].lockOnAvailable);
      attr(div, "class", "accdiff-grid " + ctx[6] + " svelte-eu4t90");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, img);
      ctx[7](img);
      append(div, t0);
      append(div, label);
      append(label, i);
      append(label, t1);
      mount_component(consumelockon, label, null);
      insert(target, t2, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(new_ctx, dirty) {
      var _a, _b;
      ctx = new_ctx;
      if (!current || dirty & 1 && img_alt_value !== (img_alt_value = (_a = ctx[0].target.name) != null ? _a : void 0)) {
        attr(img, "alt", img_alt_value);
      }
      if (!current || dirty & 1 && !src_url_equal(img.src, img_src_value = (_b = ctx[0].target.document.texture) == null ? void 0 : _b.src)) {
        attr(img, "src", img_src_value);
      }
      if (dirty & 1) {
        toggle_class(i, "i--click", ctx[0].lockOnAvailable);
      }
      if (dirty & 1) {
        toggle_class(i, "i--sm", !ctx[0].usingLockOn);
      }
      if (dirty & 1) {
        toggle_class(i, "i--l", ctx[0].usingLockOn);
      }
      const consumelockon_changes = {};
      if (!updating_lockOn && dirty & 1) {
        updating_lockOn = true;
        consumelockon_changes.lockOn = ctx[0];
        add_flush_callback(() => updating_lockOn = false);
      }
      consumelockon.$set(consumelockon_changes);
      if (dirty & 1) {
        toggle_class(label, "checked", ctx[0].usingLockOn);
      }
      if (dirty & 1) {
        toggle_class(label, "disabled", !ctx[0].lockOnAvailable);
      }
      if (!ctx[1]) {
        if (if_block) {
          if_block.p(ctx, dirty);
          if (dirty & 2) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_1$1(ctx);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(consumelockon.$$.fragment, local);
      add_render_callback(() => {
        if (div_outro)
          div_outro.end(1);
        div_intro = create_in_transition(div, send, {
          key: `${ctx[2]}-img`,
          delay: 100,
          duration: 200
        });
        div_intro.start();
      });
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(consumelockon.$$.fragment, local);
      if (div_intro)
        div_intro.invalidate();
      div_outro = create_out_transition(div, recv, {
        key: `${ctx[2]}-img`,
        duration: 200
      });
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching)
        detach(div);
      ctx[7](null);
      destroy_component(consumelockon);
      if (detaching && div_outro)
        div_outro.end();
      if (detaching)
        detach(t2);
      if (if_block)
        if_block.d(detaching);
      if (detaching)
        detach(if_block_anchor);
    }
  };
}
function create_if_block_1$1(ctx) {
  let div;
  let current;
  let each_value_1 = Object.keys(ctx[0].plugins);
  let each_blocks = [];
  for (let i = 0; i < each_value_1.length; i += 1) {
    each_blocks[i] = create_each_block_1$2(get_each_context_1$2(ctx, each_value_1, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      div = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(div, "class", "accdiff-target-dropdown svelte-eu4t90");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].m(div, null);
      }
      ctx[10](div);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty & 1) {
        each_value_1 = Object.keys(ctx2[0].plugins);
        let i;
        for (i = 0; i < each_value_1.length; i += 1) {
          const child_ctx = get_each_context_1$2(ctx2, each_value_1, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block_1$2(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(div, null);
          }
        }
        group_outros();
        for (i = each_value_1.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value_1.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching)
        detach(div);
      destroy_each(each_blocks, detaching);
      ctx[10](null);
    }
  };
}
function create_each_block_1$2(ctx) {
  let plugin;
  let updating_data;
  let current;
  function plugin_data_binding(value) {
    ctx[9](value, ctx[14]);
  }
  let plugin_props = {};
  if (ctx[0].plugins[ctx[14]] !== void 0) {
    plugin_props.data = ctx[0].plugins[ctx[14]];
  }
  plugin = new Plugin({ props: plugin_props });
  binding_callbacks.push(() => bind(plugin, "data", plugin_data_binding));
  return {
    c() {
      create_component(plugin.$$.fragment);
    },
    m(target, anchor) {
      mount_component(plugin, target, anchor);
      current = true;
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      const plugin_changes = {};
      if (!updating_data && dirty & 1) {
        updating_data = true;
        plugin_changes.data = ctx[0].plugins[ctx[14]];
        add_flush_callback(() => updating_data = false);
      }
      plugin.$set(plugin_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(plugin.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(plugin.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(plugin, detaching);
    }
  };
}
function create_each_block$3(key_1, ctx) {
  let div;
  let span;
  let t0_value = Math.abs(ctx[11]) + "";
  let t0;
  let span_intro;
  let span_outro;
  let t1;
  let i;
  let i_intro;
  let i_outro;
  let t2;
  let div_transition;
  let current;
  return {
    key: key_1,
    first: null,
    c() {
      div = element("div");
      span = element("span");
      t0 = text(t0_value);
      t1 = space();
      i = element("i");
      t2 = space();
      attr(i, "class", "cci i--m i--dark white--text middle svelte-eu4t90");
      toggle_class(i, "cci-accuracy", ctx[11] >= 0);
      toggle_class(i, "cci-difficulty", ctx[11] < 0);
      attr(div, "id", ctx[2]);
      attr(div, "class", "card clipped total svelte-eu4t90");
      this.first = div;
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, span);
      append(span, t0);
      append(div, t1);
      append(div, i);
      append(div, t2);
      current = true;
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      if ((!current || dirty & 1) && t0_value !== (t0_value = Math.abs(ctx[11]) + ""))
        set_data(t0, t0_value);
      if (dirty & 1) {
        toggle_class(i, "cci-accuracy", ctx[11] >= 0);
      }
      if (dirty & 1) {
        toggle_class(i, "cci-difficulty", ctx[11] < 0);
      }
      if (!current || dirty & 4) {
        attr(div, "id", ctx[2]);
      }
    },
    i(local) {
      if (current)
        return;
      if (local) {
        add_render_callback(() => {
          if (span_outro)
            span_outro.end(1);
          span_intro = create_in_transition(span, fly, { y: -50, duration: 400 });
          span_intro.start();
        });
      }
      if (local) {
        add_render_callback(() => {
          if (i_outro)
            i_outro.end(1);
          i_intro = create_in_transition(i, fly, { y: -50, duration: 200 });
          i_intro.start();
        });
      }
      add_render_callback(() => {
        if (!div_transition)
          div_transition = create_bidirectional_transition(div, blur, {}, true);
        div_transition.run(1);
      });
      current = true;
    },
    o(local) {
      if (span_intro)
        span_intro.invalidate();
      if (local) {
        span_outro = create_out_transition(span, fly, { y: 50, duration: 200 });
      }
      if (i_intro)
        i_intro.invalidate();
      if (local) {
        i_outro = create_out_transition(i, fly, { y: 50, duration: 200 });
      }
      if (!div_transition)
        div_transition = create_bidirectional_transition(div, blur, {}, false);
      div_transition.run(0);
      current = false;
    },
    d(detaching) {
      if (detaching)
        detach(div);
      if (detaching && span_outro)
        span_outro.end();
      if (detaching && i_outro)
        i_outro.end();
      if (detaching && div_transition)
        div_transition.end();
    }
  };
}
function create_fragment$4(ctx) {
  let show_if = isTarget(ctx[0]);
  let t;
  let div1;
  let div0;
  let each_blocks = [];
  let each_1_lookup = /* @__PURE__ */ new Map();
  let div1_intro;
  let div1_outro;
  let current;
  let if_block = show_if && create_if_block$2(ctx);
  let each_value = [ctx[0].total];
  const get_key = (ctx2) => ctx2[0].total;
  for (let i = 0; i < 1; i += 1) {
    let child_ctx = get_each_context$3(ctx, each_value, i);
    let key = get_key(child_ctx);
    each_1_lookup.set(key, each_blocks[i] = create_each_block$3(key, child_ctx));
  }
  return {
    c() {
      if (if_block)
        if_block.c();
      t = space();
      div1 = element("div");
      div0 = element("div");
      for (let i = 0; i < 1; i += 1) {
        each_blocks[i].c();
      }
      attr(div0, "class", "grid-enforcement total-container " + ctx[6] + " svelte-eu4t90");
      toggle_class(div0, "accurate", ctx[0].total > 0);
      toggle_class(div0, "inaccurate", ctx[0].total < 0);
      attr(div1, "class", "accdiff-grid accdiff-weight svelte-eu4t90");
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, t, anchor);
      insert(target, div1, anchor);
      append(div1, div0);
      for (let i = 0; i < 1; i += 1) {
        each_blocks[i].m(div0, null);
      }
      current = true;
    },
    p(new_ctx, [dirty]) {
      ctx = new_ctx;
      if (dirty & 1)
        show_if = isTarget(ctx[0]);
      if (show_if) {
        if (if_block) {
          if_block.p(ctx, dirty);
          if (dirty & 1) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$2(ctx);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(t.parentNode, t);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
      if (dirty & 5) {
        each_value = [ctx[0].total];
        group_outros();
        each_blocks = update_keyed_each(each_blocks, dirty, get_key, 1, ctx, each_value, each_1_lookup, div0, outro_and_destroy_block, create_each_block$3, null, get_each_context$3);
        check_outros();
      }
      if (dirty & 1) {
        toggle_class(div0, "accurate", ctx[0].total > 0);
      }
      if (dirty & 1) {
        toggle_class(div0, "inaccurate", ctx[0].total < 0);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      for (let i = 0; i < 1; i += 1) {
        transition_in(each_blocks[i]);
      }
      add_render_callback(() => {
        if (div1_outro)
          div1_outro.end(1);
        div1_intro = create_in_transition(div1, send, { key: ctx[2] });
        div1_intro.start();
      });
      current = true;
    },
    o(local) {
      transition_out(if_block);
      for (let i = 0; i < 1; i += 1) {
        transition_out(each_blocks[i]);
      }
      if (div1_intro)
        div1_intro.invalidate();
      div1_outro = create_out_transition(div1, recv, { key: ctx[2] });
      current = false;
    },
    d(detaching) {
      if (if_block)
        if_block.d(detaching);
      if (detaching)
        detach(t);
      if (detaching)
        detach(div1);
      for (let i = 0; i < 1; i += 1) {
        each_blocks[i].d();
      }
      if (detaching && div1_outro)
        div1_outro.end();
    }
  };
}
let lockonCounter = 0;
let counter = 0;
let [send, recv] = crossfade({ fallback: blur });
function isTarget(v) {
  return v == null ? void 0 : v.target;
}
function instance$4($$self, $$props, $$invalidate) {
  let { target } = $$props;
  let { onlyTarget = false } = $$props;
  let { id = `accdiff-total-display-${counter++}` } = $$props;
  let lockonId = isTarget(target) ? `accdiff-total-display-consume-lockon-${lockonCounter++}` : "";
  let pluginClasses = Object.values(target.plugins).filter((plugin) => {
    return plugin.uiElement == "checkbox" && plugin.uiState;
  }).map((plugin) => `accdiff-total-${plugin.slug}`).join(" ");
  let imgElement;
  let dropdownElement;
  onMount(() => {
    if (imgElement && dropdownElement) {
      tippy(imgElement, {
        content: dropdownElement,
        interactive: true,
        allowHTML: true,
        trigger: "click mouseenter"
      });
    }
  });
  function img_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      imgElement = $$value;
      $$invalidate(3, imgElement);
    });
  }
  function consumelockon_lockOn_binding(value) {
    target = value;
    $$invalidate(0, target);
  }
  function plugin_data_binding(value, key) {
    if ($$self.$$.not_equal(target.plugins[key], value)) {
      target.plugins[key] = value;
      $$invalidate(0, target);
    }
  }
  function div_binding($$value) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      dropdownElement = $$value;
      $$invalidate(4, dropdownElement);
    });
  }
  $$self.$$set = ($$props2) => {
    if ("target" in $$props2)
      $$invalidate(0, target = $$props2.target);
    if ("onlyTarget" in $$props2)
      $$invalidate(1, onlyTarget = $$props2.onlyTarget);
    if ("id" in $$props2)
      $$invalidate(2, id = $$props2.id);
  };
  return [
    target,
    onlyTarget,
    id,
    imgElement,
    dropdownElement,
    lockonId,
    pluginClasses,
    img_binding,
    consumelockon_lockOn_binding,
    plugin_data_binding,
    div_binding
  ];
}
class Total extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$4, create_fragment$4, safe_not_equal, { target: 0, onlyTarget: 1, id: 2 });
  }
}
function create_fragment$3(ctx) {
  let button0;
  let t1;
  let input;
  let t2;
  let button1;
  let mounted;
  let dispose;
  return {
    c() {
      button0 = element("button");
      button0.textContent = "-";
      t1 = space();
      input = element("input");
      t2 = space();
      button1 = element("button");
      button1.textContent = "+";
      attr(button0, "class", "mod-minus-button dec-set");
      attr(button0, "type", "button");
      attr(input, "id", ctx[1]);
      attr(input, "class", "difficulty lancer-invisible-input dec-set");
      set_style(input, "max-width", "2em");
      set_style(input, "text-align", "center");
      set_style(input, "font-size", "1.2em");
      attr(input, "type", "number");
      attr(input, "min", "0");
      attr(button1, "class", "mod-plus-button dec-set");
      attr(button1, "type", "button");
    },
    m(target, anchor) {
      insert(target, button0, anchor);
      insert(target, t1, anchor);
      insert(target, input, anchor);
      set_input_value(input, ctx[0]);
      insert(target, t2, anchor);
      insert(target, button1, anchor);
      if (!mounted) {
        dispose = [
          listen(button0, "click", ctx[2]),
          listen(input, "input", ctx[3]),
          listen(button1, "click", ctx[4])
        ];
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (dirty & 2) {
        attr(input, "id", ctx2[1]);
      }
      if (dirty & 1 && to_number(input.value) !== ctx2[0]) {
        set_input_value(input, ctx2[0]);
      }
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching)
        detach(button0);
      if (detaching)
        detach(t1);
      if (detaching)
        detach(input);
      if (detaching)
        detach(t2);
      if (detaching)
        detach(button1);
      mounted = false;
      run_all(dispose);
    }
  };
}
function instance$3($$self, $$props, $$invalidate) {
  let { value = 0 } = $$props;
  let { id } = $$props;
  const click_handler = () => $$invalidate(0, value = value - 1);
  function input_input_handler() {
    value = to_number(this.value);
    $$invalidate(0, value);
  }
  const click_handler_1 = () => $$invalidate(0, value = value + 1);
  $$self.$$set = ($$props2) => {
    if ("value" in $$props2)
      $$invalidate(0, value = $$props2.value);
    if ("id" in $$props2)
      $$invalidate(1, id = $$props2.id);
  };
  return [value, id, click_handler, input_input_handler, click_handler_1];
}
class PlusMinusInput extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$3, create_fragment$3, safe_not_equal, { value: 0, id: 1 });
  }
}
var Form_svelte_svelte_type_style_lang$1 = /* @__PURE__ */ (() => '.accdiff-grid{display:flex;justify-content:space-between}#accdiff.svelte-oy971t .container{display:flex;position:relative;padding-left:30px;margin-top:12px;margin-bottom:4px;font-size:.9em;user-select:none;align-items:center}#accdiff.svelte-oy971t .container input{position:absolute;opacity:0!important;height:0;width:0}#accdiff.svelte-oy971t .checkmark{position:absolute;left:5px;height:20px;width:20px;background-color:#a9a9a9;cursor:pointer}#accdiff.svelte-oy971t input[disabled]~.checkmark{opacity:.5;cursor:unset}#accdiff.svelte-oy971t .container:hover input:not([disabled])~.checkmark{background-color:#757575}#accdiff.svelte-oy971t .container input:checked~.checkmark{background-color:var(--main-theme-color, fuchsia)}#accdiff.svelte-oy971t .checkmark:after{content:"";position:absolute;display:none}#accdiff.svelte-oy971t .container input:checked~.checkmark:after{display:block}.accdiff-other-grid.svelte-oy971t.svelte-oy971t.svelte-oy971t{width:100%;padding-left:5px;display:flex;justify-content:center}.accdiff-weight{justify-content:center;font-weight:700}.accdiff-footer.svelte-oy971t.svelte-oy971t.svelte-oy971t{padding-top:8px;padding-bottom:4px;margin-top:12px;border-top:1px solid #782e22}.accdiff-grid.svelte-oy971t .accdiff-base-cover{margin-top:12px;margin-bottom:4px;font-size:.85em;padding-left:10px;cursor:pointer}.accdiff-grid.svelte-oy971t .accdiff-base-cover i,.accdiff-grid.svelte-oy971t .accdiff-base-cover span{vertical-align:middle}.accdiff-footer.svelte-oy971t .accdiff-targeted-cover span{opacity:0;position:fixed;width:0;visibility:hidden}.accdiff-footer.svelte-oy971t .accdiff-targeted-cover i{font-size:16px;vertical-align:top}#accdiff.svelte-oy971t .accdiff-target-row button.svelte-oy971t>i.svelte-oy971t,#accdiff.svelte-oy971t .mech-weapon button.svelte-oy971t>i.svelte-oy971t{margin-inline-end:0}.accdiff-target-row.svelte-oy971t.svelte-oy971t.svelte-oy971t{display:grid;grid-template-columns:auto auto auto;grid-row-gap:12px}.accdiff-target.svelte-oy971t.svelte-oy971t.svelte-oy971t{padding:5px;box-shadow:1px 1px 2px}.accdiff-total.svelte-oy971t.svelte-oy971t.svelte-oy971t{flex-wrap:nowrap;padding:4px 10px}.total-label.svelte-oy971t.svelte-oy971t.svelte-oy971t{white-space:nowrap}#accdiff.svelte-oy971t button.svelte-oy971t.svelte-oy971t{transition:.1s cubic-bezier(.075,.82,.165,1)}.accdiff-target-row.svelte-oy971t .accdiff-button.svelte-oy971t.svelte-oy971t{cursor:pointer;align-items:center;display:inline-flex;justify-content:center;margin:0;border:none;box-shadow:1px 1px 1px var(--main-theme-color)}.accdiff-target-row.svelte-oy971t .accdiff-button.svelte-oy971t.svelte-oy971t:hover,.accdiff-target-row.svelte-oy971t .accdiff-button.svelte-oy971t.svelte-oy971t:focus{box-shadow:1px 1px 1px var(--main-theme-color)}.accdiff-target-row.svelte-oy971t .accdiff-button.svelte-oy971t.svelte-oy971t:hover{background-color:var(--main-theme-text)}.accdiff-target-row.svelte-oy971t .accdiff-button.svelte-oy971t.svelte-oy971t:active{transform:translate(2px) translateY(2px);box-shadow:-1px -1px 1px var(--main-theme-color)}.accdiff-target-row.svelte-oy971t .accdiff-button i.svelte-oy971t.svelte-oy971t{text-shadow:none;color:rgba(var(--color-text-lightest),1)}.accdiff-target-row.svelte-oy971t .card-title.svelte-oy971t.svelte-oy971t{background-color:#0000}#accdiff.svelte-oy971t .mech-weapon span.svelte-oy971t.svelte-oy971t{margin-right:1em;margin-left:1em}#accdiff.svelte-oy971t .mech-weapon .range-button.svelte-oy971t.svelte-oy971t{cursor:pointer;box-shadow:1px 1px 1px .6px #000000b3;border:none;text-align:left;flex:0 0;margin:5px 0 7px 8px;padding:0;background-color:var(--main-theme-color)}#accdiff.svelte-oy971t .mech-weapon .range-button.svelte-oy971t.svelte-oy971t:hover,#accdiff.svelte-oy971t .mech-weapon .range-button.svelte-oy971t.svelte-oy971t:focus{box-shadow:1px 1px 1px .6px #000000b3}#accdiff.svelte-oy971t .mech-weapon .range-button.svelte-oy971t.svelte-oy971t:hover{background-color:var(--protocol-color)}#accdiff.svelte-oy971t .mech-weapon .range-button.svelte-oy971t.svelte-oy971t:active{transform:translate(2px) translateY(2px);box-shadow:-1px -1px 1px .6px #000000b3}#accdiff.svelte-oy971t .mech-weapon .range-button i.svelte-oy971t.svelte-oy971t{margin:2px;padding:0}\n')();
function get_each_context$2(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[28] = list[i];
  child_ctx[29] = list;
  child_ctx[30] = i;
  return child_ctx;
}
function get_each_context_1$1(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[31] = list[i];
  return child_ctx;
}
function get_each_context_2(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[31] = list[i];
  return child_ctx;
}
function get_each_context_3(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[36] = list[i];
  return child_ctx;
}
function create_if_block_10(ctx) {
  let div;
  let t0;
  let span;
  let t1;
  function select_block_type(ctx2, dirty) {
    if (ctx2[5] == "attack")
      return create_if_block_11;
    if (ctx2[5] == "hase")
      return create_if_block_13;
  }
  let current_block_type = select_block_type(ctx);
  let if_block = current_block_type && current_block_type(ctx);
  return {
    c() {
      div = element("div");
      if (if_block)
        if_block.c();
      t0 = space();
      span = element("span");
      t1 = text(ctx[3]);
      attr(span, "class", "svelte-oy971t");
      attr(div, "class", "lancer-header mech-weapon medium");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (if_block)
        if_block.m(div, null);
      append(div, t0);
      append(div, span);
      append(span, t1);
    },
    p(ctx2, dirty) {
      if (current_block_type === (current_block_type = select_block_type(ctx2)) && if_block) {
        if_block.p(ctx2, dirty);
      } else {
        if (if_block)
          if_block.d(1);
        if_block = current_block_type && current_block_type(ctx2);
        if (if_block) {
          if_block.c();
          if_block.m(div, t0);
        }
      }
      if (dirty[0] & 8)
        set_data(t1, ctx2[3]);
    },
    d(detaching) {
      if (detaching)
        detach(div);
      if (if_block) {
        if_block.d();
      }
    }
  };
}
function create_if_block_13(ctx) {
  let i;
  return {
    c() {
      i = element("i");
      attr(i, "class", "fas fa-dice-d20 i--m i--light svelte-oy971t");
    },
    m(target, anchor) {
      insert(target, i, anchor);
    },
    p: noop,
    d(detaching) {
      if (detaching)
        detach(i);
    }
  };
}
function create_if_block_11(ctx) {
  let i;
  let t;
  let if_block_anchor;
  let if_block = ctx[4] && create_if_block_12(ctx);
  return {
    c() {
      i = element("i");
      t = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
      attr(i, "class", "cci cci-weapon i--m i--light svelte-oy971t");
    },
    m(target, anchor) {
      insert(target, i, anchor);
      insert(target, t, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
    },
    p(ctx2, dirty) {
      if (ctx2[4]) {
        if (if_block) {
          if_block.p(ctx2, dirty);
        } else {
          if_block = create_if_block_12(ctx2);
          if_block.c();
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
    },
    d(detaching) {
      if (detaching)
        detach(i);
      if (detaching)
        detach(t);
      if (if_block)
        if_block.d(detaching);
      if (detaching)
        detach(if_block_anchor);
    }
  };
}
function create_if_block_12(ctx) {
  let each_1_anchor;
  let each_value_3 = ctx[8]();
  let each_blocks = [];
  for (let i = 0; i < each_value_3.length; i += 1) {
    each_blocks[i] = create_each_block_3(get_each_context_3(ctx, each_value_3, i));
  }
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      each_1_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].m(target, anchor);
      }
      insert(target, each_1_anchor, anchor);
    },
    p(ctx2, dirty) {
      if (dirty[0] & 768) {
        each_value_3 = ctx2[8]();
        let i;
        for (i = 0; i < each_value_3.length; i += 1) {
          const child_ctx = get_each_context_3(ctx2, each_value_3, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block_3(child_ctx);
            each_blocks[i].c();
            each_blocks[i].m(each_1_anchor.parentNode, each_1_anchor);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value_3.length;
      }
    },
    d(detaching) {
      destroy_each(each_blocks, detaching);
      if (detaching)
        detach(each_1_anchor);
    }
  };
}
function create_each_block_3(ctx) {
  let button;
  let i;
  let t;
  let mounted;
  let dispose;
  function click_handler() {
    return ctx[10](ctx[36]);
  }
  return {
    c() {
      button = element("button");
      i = element("i");
      t = space();
      attr(i, "class", "cci cci-" + ctx[36].type.toLowerCase() + " i--m i--light svelte-oy971t");
      attr(button, "class", "range-button svelte-oy971t");
      attr(button, "type", "button");
    },
    m(target, anchor) {
      insert(target, button, anchor);
      append(button, i);
      append(button, t);
      if (!mounted) {
        dispose = listen(button, "click", click_handler);
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
    },
    d(detaching) {
      if (detaching)
        detach(button);
      mounted = false;
      dispose();
    }
  };
}
function create_if_block_9(ctx) {
  let label;
  let t0;
  let input;
  let t1;
  let span;
  let mounted;
  let dispose;
  return {
    c() {
      label = element("label");
      t0 = text("Seeking\u2007(*)\r\n            ");
      input = element("input");
      t1 = space();
      span = element("span");
      attr(input, "type", "checkbox");
      attr(span, "class", "checkmark svelte-oy971t");
      attr(label, "class", "container");
    },
    m(target, anchor) {
      insert(target, label, anchor);
      append(label, t0);
      append(label, input);
      input.checked = ctx[0].seeking;
      append(label, t1);
      append(label, span);
      if (!mounted) {
        dispose = listen(input, "change", ctx[12]);
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (dirty[0] & 1) {
        input.checked = ctx2[0].seeking;
      }
    },
    d(detaching) {
      if (detaching)
        detach(label);
      mounted = false;
      dispose();
    }
  };
}
function create_if_block_7(ctx) {
  let div;
  let h3;
  let t1;
  let t2;
  let div_transition;
  let current;
  let each_value_2 = Object.keys(ctx[0].plugins);
  let each_blocks = [];
  for (let i = 0; i < each_value_2.length; i += 1) {
    each_blocks[i] = create_each_block_2(get_each_context_2(ctx, each_value_2, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  let if_block = ctx[2].length == 1 && create_if_block_8(ctx);
  return {
    c() {
      div = element("div");
      h3 = element("h3");
      h3.innerHTML = `<i class="cci cci-reticule i--m i--dark svelte-oy971t" style="vertical-align:middle;border:none"></i>
              \xA0Misc`;
      t1 = space();
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      t2 = space();
      if (if_block)
        if_block.c();
      set_style(h3, "border-top", "1px dashed #782e22");
      set_style(h3, "padding-right", "4px");
      set_style(h3, "padding-top", "16px");
      set_style(h3, "margin-top", "16px");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, h3);
      append(div, t1);
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].m(div, null);
      }
      append(div, t2);
      if (if_block)
        if_block.m(div, null);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty[0] & 1) {
        each_value_2 = Object.keys(ctx2[0].plugins);
        let i;
        for (i = 0; i < each_value_2.length; i += 1) {
          const child_ctx = get_each_context_2(ctx2, each_value_2, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block_2(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(div, t2);
          }
        }
        group_outros();
        for (i = each_value_2.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
      if (ctx2[2].length == 1) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty[0] & 4) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_8(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(div, null);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value_2.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      transition_in(if_block);
      add_render_callback(() => {
        if (!div_transition)
          div_transition = create_bidirectional_transition(div, slide, {}, true);
        div_transition.run(1);
      });
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      transition_out(if_block);
      if (!div_transition)
        div_transition = create_bidirectional_transition(div, slide, {}, false);
      div_transition.run(0);
      current = false;
    },
    d(detaching) {
      if (detaching)
        detach(div);
      destroy_each(each_blocks, detaching);
      if (if_block)
        if_block.d();
      if (detaching && div_transition)
        div_transition.end();
    }
  };
}
function create_each_block_2(ctx) {
  let plugin;
  let current;
  plugin = new Plugin({
    props: {
      data: ctx[0].plugins[ctx[31]]
    }
  });
  return {
    c() {
      create_component(plugin.$$.fragment);
    },
    m(target, anchor) {
      mount_component(plugin, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const plugin_changes = {};
      if (dirty[0] & 1)
        plugin_changes.data = ctx2[0].plugins[ctx2[31]];
      plugin.$set(plugin_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(plugin.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(plugin.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(plugin, detaching);
    }
  };
}
function create_if_block_8(ctx) {
  let label;
  let t0;
  let consumelockon;
  let updating_lockOn;
  let t1;
  let span;
  let t2;
  let each_1_anchor;
  let current;
  function consumelockon_lockOn_binding(value) {
    ctx[13](value);
  }
  let consumelockon_props = { id: "base-consume-lockon" };
  if (ctx[2][0] !== void 0) {
    consumelockon_props.lockOn = ctx[2][0];
  }
  consumelockon = new ConsumeLockOn({ props: consumelockon_props });
  binding_callbacks.push(() => bind(consumelockon, "lockOn", consumelockon_lockOn_binding));
  let each_value_1 = Object.keys(ctx[2][0].plugins);
  let each_blocks = [];
  for (let i = 0; i < each_value_1.length; i += 1) {
    each_blocks[i] = create_each_block_1$1(get_each_context_1$1(ctx, each_value_1, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      label = element("label");
      t0 = text("Consume\xA0Lock\xA0On\u2007(+1)\r\n                ");
      create_component(consumelockon.$$.fragment);
      t1 = space();
      span = element("span");
      t2 = space();
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      each_1_anchor = empty();
      attr(span, "class", "checkmark svelte-oy971t");
      attr(label, "class", "container");
      attr(label, "for", "base-consume-lockon");
    },
    m(target, anchor) {
      insert(target, label, anchor);
      append(label, t0);
      mount_component(consumelockon, label, null);
      append(label, t1);
      append(label, span);
      insert(target, t2, anchor);
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].m(target, anchor);
      }
      insert(target, each_1_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const consumelockon_changes = {};
      if (!updating_lockOn && dirty[0] & 4) {
        updating_lockOn = true;
        consumelockon_changes.lockOn = ctx2[2][0];
        add_flush_callback(() => updating_lockOn = false);
      }
      consumelockon.$set(consumelockon_changes);
      if (dirty[0] & 4) {
        each_value_1 = Object.keys(ctx2[2][0].plugins);
        let i;
        for (i = 0; i < each_value_1.length; i += 1) {
          const child_ctx = get_each_context_1$1(ctx2, each_value_1, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block_1$1(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(each_1_anchor.parentNode, each_1_anchor);
          }
        }
        group_outros();
        for (i = each_value_1.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(consumelockon.$$.fragment, local);
      for (let i = 0; i < each_value_1.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      transition_out(consumelockon.$$.fragment, local);
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching)
        detach(label);
      destroy_component(consumelockon);
      if (detaching)
        detach(t2);
      destroy_each(each_blocks, detaching);
      if (detaching)
        detach(each_1_anchor);
    }
  };
}
function create_each_block_1$1(ctx) {
  let plugin;
  let current;
  plugin = new Plugin({
    props: {
      data: ctx[2][0].plugins[ctx[31]]
    }
  });
  return {
    c() {
      create_component(plugin.$$.fragment);
    },
    m(target, anchor) {
      mount_component(plugin, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const plugin_changes = {};
      if (dirty[0] & 4)
        plugin_changes.data = ctx2[2][0].plugins[ctx2[31]];
      plugin.$set(plugin_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(plugin.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(plugin.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(plugin, detaching);
    }
  };
}
function create_if_block_4(ctx) {
  let div;
  let current_block_type_index;
  let if_block;
  let current;
  const if_block_creators = [create_if_block_5, create_if_block_6];
  const if_blocks = [];
  function select_block_type_1(ctx2, dirty) {
    if (ctx2[2].length == 0)
      return 0;
    if (ctx2[2].length == 1)
      return 1;
    return -1;
  }
  if (~(current_block_type_index = select_block_type_1(ctx))) {
    if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  }
  return {
    c() {
      div = element("div");
      if (if_block)
        if_block.c();
      attr(div, "class", "grid-enforcement");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (~current_block_type_index) {
        if_blocks[current_block_type_index].m(div, null);
      }
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type_1(ctx2);
      if (current_block_type_index === previous_block_index) {
        if (~current_block_type_index) {
          if_blocks[current_block_type_index].p(ctx2, dirty);
        }
      } else {
        if (if_block) {
          group_outros();
          transition_out(if_blocks[previous_block_index], 1, 1, () => {
            if_blocks[previous_block_index] = null;
          });
          check_outros();
        }
        if (~current_block_type_index) {
          if_block = if_blocks[current_block_type_index];
          if (!if_block) {
            if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
            if_block.c();
          } else {
            if_block.p(ctx2, dirty);
          }
          transition_in(if_block, 1);
          if_block.m(div, null);
        } else {
          if_block = null;
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching)
        detach(div);
      if (~current_block_type_index) {
        if_blocks[current_block_type_index].d();
      }
    }
  };
}
function create_if_block_6(ctx) {
  let div;
  let cover;
  let updating_cover;
  let div_transition;
  let current;
  function cover_cover_binding_1(value) {
    ctx[16](value);
  }
  let cover_props = {
    class: "accdiff-base-cover flexcol",
    disabled: ctx[0].seeking
  };
  if (ctx[2][0].cover !== void 0) {
    cover_props.cover = ctx[2][0].cover;
  }
  cover = new Cover({ props: cover_props });
  binding_callbacks.push(() => bind(cover, "cover", cover_cover_binding_1));
  return {
    c() {
      div = element("div");
      create_component(cover.$$.fragment);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(cover, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      const cover_changes = {};
      if (dirty[0] & 1)
        cover_changes.disabled = ctx2[0].seeking;
      if (!updating_cover && dirty[0] & 4) {
        updating_cover = true;
        cover_changes.cover = ctx2[2][0].cover;
        add_flush_callback(() => updating_cover = false);
      }
      cover.$set(cover_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(cover.$$.fragment, local);
      if (local) {
        add_render_callback(() => {
          if (!div_transition)
            div_transition = create_bidirectional_transition(div, slide, {}, true);
          div_transition.run(1);
        });
      }
      current = true;
    },
    o(local) {
      transition_out(cover.$$.fragment, local);
      if (local) {
        if (!div_transition)
          div_transition = create_bidirectional_transition(div, slide, {}, false);
        div_transition.run(0);
      }
      current = false;
    },
    d(detaching) {
      if (detaching)
        detach(div);
      destroy_component(cover);
      if (detaching && div_transition)
        div_transition.end();
    }
  };
}
function create_if_block_5(ctx) {
  let div;
  let cover;
  let updating_cover;
  let div_transition;
  let current;
  function cover_cover_binding(value) {
    ctx[15](value);
  }
  let cover_props = {
    class: "accdiff-base-cover flexcol",
    disabled: ctx[0].seeking
  };
  if (ctx[1].cover !== void 0) {
    cover_props.cover = ctx[1].cover;
  }
  cover = new Cover({ props: cover_props });
  binding_callbacks.push(() => bind(cover, "cover", cover_cover_binding));
  return {
    c() {
      div = element("div");
      create_component(cover.$$.fragment);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(cover, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      const cover_changes = {};
      if (dirty[0] & 1)
        cover_changes.disabled = ctx2[0].seeking;
      if (!updating_cover && dirty[0] & 2) {
        updating_cover = true;
        cover_changes.cover = ctx2[1].cover;
        add_flush_callback(() => updating_cover = false);
      }
      cover.$set(cover_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(cover.$$.fragment, local);
      if (local) {
        add_render_callback(() => {
          if (!div_transition)
            div_transition = create_bidirectional_transition(div, slide, {}, true);
          div_transition.run(1);
        });
      }
      current = true;
    },
    o(local) {
      transition_out(cover.$$.fragment, local);
      if (local) {
        if (!div_transition)
          div_transition = create_bidirectional_transition(div, slide, {}, false);
        div_transition.run(0);
      }
      current = false;
    },
    d(detaching) {
      if (detaching)
        detach(div);
      destroy_component(cover);
      if (detaching && div_transition)
        div_transition.end();
    }
  };
}
function create_if_block_2(ctx) {
  let previous_key = ctx[2].length;
  let key_block_anchor;
  let current;
  let key_block = create_key_block(ctx);
  return {
    c() {
      key_block.c();
      key_block_anchor = empty();
    },
    m(target, anchor) {
      key_block.m(target, anchor);
      insert(target, key_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty[0] & 4 && safe_not_equal(previous_key, previous_key = ctx2[2].length)) {
        group_outros();
        transition_out(key_block, 1, 1, noop);
        check_outros();
        key_block = create_key_block(ctx2);
        key_block.c();
        transition_in(key_block, 1);
        key_block.m(key_block_anchor.parentNode, key_block_anchor);
      } else {
        key_block.p(ctx2, dirty);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(key_block);
      current = true;
    },
    o(local) {
      transition_out(key_block);
      current = false;
    },
    d(detaching) {
      if (detaching)
        detach(key_block_anchor);
      key_block.d(detaching);
    }
  };
}
function create_if_block_3(ctx) {
  let t0;
  let t1_value = ctx[2][0].target.name + "";
  let t1;
  return {
    c() {
      t0 = text("vs ");
      t1 = text(t1_value);
    },
    m(target, anchor) {
      insert(target, t0, anchor);
      insert(target, t1, anchor);
    },
    p(ctx2, dirty) {
      if (dirty[0] & 4 && t1_value !== (t1_value = ctx2[2][0].target.name + ""))
        set_data(t1, t1_value);
    },
    d(detaching) {
      if (detaching)
        detach(t0);
      if (detaching)
        detach(t1);
    }
  };
}
function create_key_block(ctx) {
  let label;
  let t;
  let label_transition;
  let current;
  let if_block = ctx[2].length > 0 && create_if_block_3(ctx);
  return {
    c() {
      label = element("label");
      t = text("Total\r\n              ");
      if (if_block)
        if_block.c();
      attr(label, "class", "accdiff-weight flex-center flexrow total-label svelte-oy971t");
      attr(label, "for", "total-display-0");
    },
    m(target, anchor) {
      insert(target, label, anchor);
      append(label, t);
      if (if_block)
        if_block.m(label, null);
      current = true;
    },
    p(ctx2, dirty) {
      if (ctx2[2].length > 0) {
        if (if_block) {
          if_block.p(ctx2, dirty);
        } else {
          if_block = create_if_block_3(ctx2);
          if_block.c();
          if_block.m(label, null);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
    },
    i(local) {
      if (current)
        return;
      add_render_callback(() => {
        if (!label_transition)
          label_transition = create_bidirectional_transition(label, slide, {}, true);
        label_transition.run(1);
      });
      current = true;
    },
    o(local) {
      if (!label_transition)
        label_transition = create_bidirectional_transition(label, slide, {}, false);
      label_transition.run(0);
      current = false;
    },
    d(detaching) {
      if (detaching)
        detach(label);
      if (if_block)
        if_block.d();
      if (detaching && label_transition)
        label_transition.end();
    }
  };
}
function create_else_block(ctx) {
  let div;
  let each_blocks = [];
  let each_1_lookup = /* @__PURE__ */ new Map();
  let current;
  let each_value = ctx[2];
  const get_key = (ctx2) => ctx2[28].target.id;
  for (let i = 0; i < each_value.length; i += 1) {
    let child_ctx = get_each_context$2(ctx, each_value, i);
    let key = get_key(child_ctx);
    each_1_lookup.set(key, each_blocks[i] = create_each_block$2(key, child_ctx));
  }
  return {
    c() {
      div = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(div, "class", "accdiff-weight accdiff-target-row svelte-oy971t");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].m(div, null);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty[0] & 5) {
        each_value = ctx2[2];
        group_outros();
        for (let i = 0; i < each_blocks.length; i += 1)
          each_blocks[i].r();
        each_blocks = update_keyed_each(each_blocks, dirty, get_key, 1, ctx2, each_value, each_1_lookup, div, fix_and_outro_and_destroy_block, create_each_block$2, null, get_each_context$2);
        for (let i = 0; i < each_blocks.length; i += 1)
          each_blocks[i].a();
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching)
        detach(div);
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].d();
      }
    }
  };
}
function create_if_block_1(ctx) {
  let div;
  let total;
  let updating_target;
  let current;
  function total_target_binding(value) {
    ctx[19](value);
  }
  let total_props = { id: "total-display-0", onlyTarget: true };
  if (ctx[2][0] !== void 0) {
    total_props.target = ctx[2][0];
  }
  total = new Total({ props: total_props });
  binding_callbacks.push(() => bind(total, "target", total_target_binding));
  return {
    c() {
      div = element("div");
      create_component(total.$$.fragment);
      attr(div, "class", "flexrow flex-center accdiff-total svelte-oy971t");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(total, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      const total_changes = {};
      if (!updating_target && dirty[0] & 4) {
        updating_target = true;
        total_changes.target = ctx2[2][0];
        add_flush_callback(() => updating_target = false);
      }
      total.$set(total_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(total.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(total.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching)
        detach(div);
      destroy_component(total);
    }
  };
}
function create_if_block$1(ctx) {
  let div;
  let total;
  let current;
  total = new Total({
    props: {
      target: ctx[1],
      id: "total-display-0"
    }
  });
  return {
    c() {
      div = element("div");
      create_component(total.$$.fragment);
      attr(div, "class", "flexrow flex-center accdiff-total svelte-oy971t");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(total, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      const total_changes = {};
      if (dirty[0] & 2)
        total_changes.target = ctx2[1];
      total.$set(total_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(total.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(total.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching)
        detach(div);
      destroy_component(total);
    }
  };
}
function create_each_block$2(key_1, ctx) {
  let div2;
  let label;
  let t0_value = ctx[28].target.document.name + "";
  let t0;
  let label_for_value;
  let t1;
  let div0;
  let total;
  let updating_target;
  let t2;
  let div1;
  let button0;
  let t3;
  let input0;
  let t4;
  let cover;
  let updating_cover;
  let t5;
  let input1;
  let t6;
  let button1;
  let t7;
  let div2_intro;
  let div2_outro;
  let rect;
  let stop_animation = noop;
  let current;
  let mounted;
  let dispose;
  function total_target_binding_1(value) {
    ctx[20](value, ctx[28], ctx[29], ctx[30]);
  }
  let total_props = { id: `total-display-${ctx[30]}` };
  if (ctx[28] !== void 0) {
    total_props.target = ctx[28];
  }
  total = new Total({ props: total_props });
  binding_callbacks.push(() => bind(total, "target", total_target_binding_1));
  function click_handler_1() {
    return ctx[21](ctx[28], ctx[29], ctx[30]);
  }
  function input0_input_handler() {
    ctx[22].call(input0, ctx[29], ctx[30]);
  }
  function cover_cover_binding_2(value) {
    ctx[23](value, ctx[28]);
  }
  let cover_props = {
    disabled: ctx[0].seeking,
    class: "accdiff-targeted-cover flexrow flex-center",
    labelClass: "i--s"
  };
  if (ctx[28].cover !== void 0) {
    cover_props.cover = ctx[28].cover;
  }
  cover = new Cover({ props: cover_props });
  binding_callbacks.push(() => bind(cover, "cover", cover_cover_binding_2));
  function input1_input_handler() {
    ctx[24].call(input1, ctx[29], ctx[30]);
  }
  function click_handler_2() {
    return ctx[25](ctx[28], ctx[29], ctx[30]);
  }
  return {
    key: key_1,
    first: null,
    c() {
      div2 = element("div");
      label = element("label");
      t0 = text(t0_value);
      t1 = space();
      div0 = element("div");
      create_component(total.$$.fragment);
      t2 = space();
      div1 = element("div");
      button0 = element("button");
      button0.innerHTML = `<i class="cci cci-accuracy i--m svelte-oy971t" style="border:none"></i>`;
      t3 = space();
      input0 = element("input");
      t4 = space();
      create_component(cover.$$.fragment);
      t5 = space();
      input1 = element("input");
      t6 = space();
      button1 = element("button");
      button1.innerHTML = `<i class="cci cci-difficulty i--m svelte-oy971t" style="border:none"></i>`;
      t7 = space();
      attr(label, "class", "flexrow flex-center card card-title svelte-oy971t");
      attr(label, "for", label_for_value = ctx[28].target.id);
      attr(div0, "class", "flexrow accdiff-total svelte-oy971t");
      attr(button0, "class", "i--m no-grow accdiff-button svelte-oy971t");
      attr(button0, "type", "button");
      set_style(input0, "display", "none");
      attr(input0, "type", "number");
      attr(input0, "min", "0");
      set_style(input1, "display", "none");
      attr(input1, "type", "number");
      attr(input1, "min", "0");
      attr(button1, "class", "i--m no-grow accdiff-button svelte-oy971t");
      attr(button1, "type", "button");
      attr(div1, "class", "flexrow");
      attr(div2, "class", "flexcol card accdiff-target svelte-oy971t");
      this.first = div2;
    },
    m(target, anchor) {
      insert(target, div2, anchor);
      append(div2, label);
      append(label, t0);
      append(div2, t1);
      append(div2, div0);
      mount_component(total, div0, null);
      append(div2, t2);
      append(div2, div1);
      append(div1, button0);
      append(div1, t3);
      append(div1, input0);
      set_input_value(input0, ctx[28].accuracy);
      append(div1, t4);
      mount_component(cover, div1, null);
      append(div1, t5);
      append(div1, input1);
      set_input_value(input1, ctx[28].difficulty);
      append(div1, t6);
      append(div1, button1);
      append(div2, t7);
      current = true;
      if (!mounted) {
        dispose = [
          listen(button0, "click", click_handler_1),
          listen(input0, "input", input0_input_handler),
          listen(input1, "input", input1_input_handler),
          listen(button1, "click", click_handler_2)
        ];
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      if ((!current || dirty[0] & 4) && t0_value !== (t0_value = ctx[28].target.document.name + ""))
        set_data(t0, t0_value);
      if (!current || dirty[0] & 4 && label_for_value !== (label_for_value = ctx[28].target.id)) {
        attr(label, "for", label_for_value);
      }
      const total_changes = {};
      if (dirty[0] & 4)
        total_changes.id = `total-display-${ctx[30]}`;
      if (!updating_target && dirty[0] & 4) {
        updating_target = true;
        total_changes.target = ctx[28];
        add_flush_callback(() => updating_target = false);
      }
      total.$set(total_changes);
      if (dirty[0] & 4 && to_number(input0.value) !== ctx[28].accuracy) {
        set_input_value(input0, ctx[28].accuracy);
      }
      const cover_changes = {};
      if (dirty[0] & 1)
        cover_changes.disabled = ctx[0].seeking;
      if (!updating_cover && dirty[0] & 4) {
        updating_cover = true;
        cover_changes.cover = ctx[28].cover;
        add_flush_callback(() => updating_cover = false);
      }
      cover.$set(cover_changes);
      if (dirty[0] & 4 && to_number(input1.value) !== ctx[28].difficulty) {
        set_input_value(input1, ctx[28].difficulty);
      }
    },
    r() {
      rect = div2.getBoundingClientRect();
    },
    f() {
      fix_position(div2);
      stop_animation();
      add_transform(div2, rect);
    },
    a() {
      stop_animation();
      stop_animation = create_animation(div2, rect, flip, { duration: 200 });
    },
    i(local) {
      if (current)
        return;
      transition_in(total.$$.fragment, local);
      transition_in(cover.$$.fragment, local);
      add_render_callback(() => {
        if (div2_outro)
          div2_outro.end(1);
        div2_intro = create_in_transition(div2, slide, { delay: 100, duration: 300 });
        div2_intro.start();
      });
      current = true;
    },
    o(local) {
      transition_out(total.$$.fragment, local);
      transition_out(cover.$$.fragment, local);
      if (div2_intro)
        div2_intro.invalidate();
      div2_outro = create_out_transition(div2, slide, { duration: 100 });
      current = false;
    },
    d(detaching) {
      if (detaching)
        detach(div2);
      destroy_component(total);
      destroy_component(cover);
      if (detaching && div2_outro)
        div2_outro.end();
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_fragment$2(ctx) {
  let form;
  let t0;
  let div9;
  let div2;
  let div0;
  let h30;
  let t2;
  let label0;
  let t3;
  let input0;
  let t4;
  let span0;
  let t5;
  let t6;
  let show_if = ctx[5] == "attack" && (Object.values(ctx[0].plugins).length > 0 || ctx[2].length == 1);
  let t7;
  let div1;
  let h31;
  let t9;
  let label1;
  let t10;
  let input1;
  let t11;
  let span1;
  let t12;
  let label2;
  let t13;
  let input2;
  let input2_checked_value;
  let t14;
  let span2;
  let t15;
  let t16;
  let label3;
  let t18;
  let div5;
  let div3;
  let plusminusinput0;
  let updating_value;
  let t19;
  let div4;
  let plusminusinput1;
  let updating_value_1;
  let t20;
  let div8;
  let div7;
  let t21;
  let div6;
  let current_block_type_index;
  let if_block5;
  let div9_id_value;
  let t22;
  let div10;
  let button0;
  let t24;
  let button1;
  let current;
  let mounted;
  let dispose;
  let if_block0 = ctx[3] != "" && create_if_block_10(ctx);
  let if_block1 = ctx[5] == "attack" && create_if_block_9(ctx);
  let if_block2 = show_if && create_if_block_7(ctx);
  let if_block3 = ctx[5] == "attack" && create_if_block_4(ctx);
  function plusminusinput0_value_binding(value) {
    ctx[17](value);
  }
  let plusminusinput0_props = { id: "accdiff-other-acc" };
  if (ctx[1].accuracy !== void 0) {
    plusminusinput0_props.value = ctx[1].accuracy;
  }
  plusminusinput0 = new PlusMinusInput({ props: plusminusinput0_props });
  binding_callbacks.push(() => bind(plusminusinput0, "value", plusminusinput0_value_binding));
  function plusminusinput1_value_binding(value) {
    ctx[18](value);
  }
  let plusminusinput1_props = { id: "accdiff-other-diff" };
  if (ctx[1].difficulty !== void 0) {
    plusminusinput1_props.value = ctx[1].difficulty;
  }
  plusminusinput1 = new PlusMinusInput({ props: plusminusinput1_props });
  binding_callbacks.push(() => bind(plusminusinput1, "value", plusminusinput1_value_binding));
  let if_block4 = ctx[2].length < 2 && create_if_block_2(ctx);
  const if_block_creators = [create_if_block$1, create_if_block_1, create_else_block];
  const if_blocks = [];
  function select_block_type_2(ctx2, dirty) {
    if (ctx2[2].length == 0)
      return 0;
    if (ctx2[2].length == 1)
      return 1;
    return 2;
  }
  current_block_type_index = select_block_type_2(ctx);
  if_block5 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      form = element("form");
      if (if_block0)
        if_block0.c();
      t0 = space();
      div9 = element("div");
      div2 = element("div");
      div0 = element("div");
      h30 = element("h3");
      h30.innerHTML = `<i class="cci cci-accuracy i--m i--dark svelte-oy971t" style="vertical-align:middle;border:none"></i>
          Accuracy`;
      t2 = space();
      label0 = element("label");
      t3 = text("Accurate\u2007(+1)\r\n          ");
      input0 = element("input");
      t4 = space();
      span0 = element("span");
      t5 = space();
      if (if_block1)
        if_block1.c();
      t6 = space();
      if (if_block2)
        if_block2.c();
      t7 = space();
      div1 = element("div");
      h31 = element("h3");
      h31.innerHTML = `<i class="cci cci-difficulty i--m i--dark svelte-oy971t" style="vertical-align:middle;border:none"></i>
          Difficulty`;
      t9 = space();
      label1 = element("label");
      t10 = text("Inaccurate\u2007(-1)\r\n          ");
      input1 = element("input");
      t11 = space();
      span1 = element("span");
      t12 = space();
      label2 = element("label");
      t13 = text("Impaired\u2007(-1)\r\n          ");
      input2 = element("input");
      t14 = space();
      span2 = element("span");
      t15 = space();
      if (if_block3)
        if_block3.c();
      t16 = space();
      label3 = element("label");
      label3.textContent = "Other Sources";
      t18 = space();
      div5 = element("div");
      div3 = element("div");
      create_component(plusminusinput0.$$.fragment);
      t19 = space();
      div4 = element("div");
      create_component(plusminusinput1.$$.fragment);
      t20 = space();
      div8 = element("div");
      div7 = element("div");
      if (if_block4)
        if_block4.c();
      t21 = space();
      div6 = element("div");
      if_block5.c();
      t22 = space();
      div10 = element("div");
      button0 = element("button");
      button0.innerHTML = `<i class="fas fa-check svelte-oy971t"></i>
      Roll`;
      t24 = space();
      button1 = element("button");
      button1.innerHTML = `<i class="fas fa-times svelte-oy971t"></i>
      Cancel`;
      attr(input0, "type", "checkbox");
      attr(span0, "class", "checkmark svelte-oy971t");
      attr(label0, "class", "container");
      set_style(div0, "width", "100%");
      set_style(div0, "padding", "4px");
      set_style(div0, "border-right", "1px dashed #782e22");
      set_style(div0, "min-width", "180px");
      attr(input1, "type", "checkbox");
      attr(span1, "class", "checkmark svelte-oy971t");
      attr(label1, "class", "container");
      attr(input2, "type", "checkbox");
      input2.checked = input2_checked_value = !!ctx[0].impaired;
      input2.disabled = true;
      attr(span2, "class", "checkmark svelte-oy971t");
      attr(label2, "class", "container");
      set_style(div1, "width", "100%");
      set_style(div1, "padding", "4px");
      set_style(div1, "min-width", "180px");
      attr(div2, "class", "accdiff-grid svelte-oy971t");
      attr(label3, "class", "flexrow accdiff-footer accdiff-weight svelte-oy971t");
      attr(label3, "for", "accdiff-other-sources");
      attr(div3, "class", "accdiff-other-grid svelte-oy971t");
      set_style(div3, "border-right", "1px dashed #782e22");
      attr(div4, "class", "accdiff-other-grid svelte-oy971t");
      attr(div5, "id", "accdiff-other-sources");
      attr(div5, "class", "accdiff-grid svelte-oy971t");
      attr(div6, "class", "grid-enforcement");
      attr(div7, "class", "accdiff-total svelte-oy971t");
      attr(div8, "class", "grid-enforcement accdiff-footer svelte-oy971t");
      attr(div9, "id", div9_id_value = ctx[5] + "-accdiff-dialog");
      set_style(div9, "padding", "4px");
      attr(div9, "class", "svelte-oy971t");
      attr(button0, "class", "dialog-button submit default svelte-oy971t");
      attr(button0, "data-button", "submit");
      attr(button0, "type", "submit");
      attr(button1, "class", "dialog-button cancel svelte-oy971t");
      attr(button1, "data-button", "cancel");
      attr(button1, "type", "button");
      attr(div10, "class", "dialog-buttons flexrow");
      attr(form, "id", "accdiff");
      attr(form, "class", "accdiff window-content svelte-oy971t");
    },
    m(target, anchor) {
      insert(target, form, anchor);
      if (if_block0)
        if_block0.m(form, null);
      append(form, t0);
      append(form, div9);
      append(div9, div2);
      append(div2, div0);
      append(div0, h30);
      append(div0, t2);
      append(div0, label0);
      append(label0, t3);
      append(label0, input0);
      input0.checked = ctx[0].accurate;
      append(label0, t4);
      append(label0, span0);
      append(div0, t5);
      if (if_block1)
        if_block1.m(div0, null);
      append(div0, t6);
      if (if_block2)
        if_block2.m(div0, null);
      append(div2, t7);
      append(div2, div1);
      append(div1, h31);
      append(div1, t9);
      append(div1, label1);
      append(label1, t10);
      append(label1, input1);
      input1.checked = ctx[0].inaccurate;
      append(label1, t11);
      append(label1, span1);
      append(div1, t12);
      append(div1, label2);
      append(label2, t13);
      append(label2, input2);
      append(label2, t14);
      append(label2, span2);
      append(div1, t15);
      if (if_block3)
        if_block3.m(div1, null);
      append(div9, t16);
      append(div9, label3);
      append(div9, t18);
      append(div9, div5);
      append(div5, div3);
      mount_component(plusminusinput0, div3, null);
      append(div5, t19);
      append(div5, div4);
      mount_component(plusminusinput1, div4, null);
      append(div9, t20);
      append(div9, div8);
      append(div8, div7);
      if (if_block4)
        if_block4.m(div7, null);
      append(div7, t21);
      append(div7, div6);
      if_blocks[current_block_type_index].m(div6, null);
      append(form, t22);
      append(form, div10);
      append(div10, button0);
      append(div10, t24);
      append(div10, button1);
      current = true;
      if (!mounted) {
        dispose = [
          listen(input0, "change", ctx[11]),
          listen(input1, "change", ctx[14]),
          action_destroyer(focus$1.call(null, button0)),
          listen(button1, "click", ctx[26]),
          action_destroyer(ctx[7].call(null, form)),
          listen(form, "submit", prevent_default(ctx[27]))
        ];
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (ctx2[3] != "") {
        if (if_block0) {
          if_block0.p(ctx2, dirty);
        } else {
          if_block0 = create_if_block_10(ctx2);
          if_block0.c();
          if_block0.m(form, t0);
        }
      } else if (if_block0) {
        if_block0.d(1);
        if_block0 = null;
      }
      if (dirty[0] & 1) {
        input0.checked = ctx2[0].accurate;
      }
      if (ctx2[5] == "attack") {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
        } else {
          if_block1 = create_if_block_9(ctx2);
          if_block1.c();
          if_block1.m(div0, t6);
        }
      } else if (if_block1) {
        if_block1.d(1);
        if_block1 = null;
      }
      if (dirty[0] & 37)
        show_if = ctx2[5] == "attack" && (Object.values(ctx2[0].plugins).length > 0 || ctx2[2].length == 1);
      if (show_if) {
        if (if_block2) {
          if_block2.p(ctx2, dirty);
          if (dirty[0] & 37) {
            transition_in(if_block2, 1);
          }
        } else {
          if_block2 = create_if_block_7(ctx2);
          if_block2.c();
          transition_in(if_block2, 1);
          if_block2.m(div0, null);
        }
      } else if (if_block2) {
        group_outros();
        transition_out(if_block2, 1, 1, () => {
          if_block2 = null;
        });
        check_outros();
      }
      if (dirty[0] & 1) {
        input1.checked = ctx2[0].inaccurate;
      }
      if (!current || dirty[0] & 1 && input2_checked_value !== (input2_checked_value = !!ctx2[0].impaired)) {
        input2.checked = input2_checked_value;
      }
      if (ctx2[5] == "attack") {
        if (if_block3) {
          if_block3.p(ctx2, dirty);
          if (dirty[0] & 32) {
            transition_in(if_block3, 1);
          }
        } else {
          if_block3 = create_if_block_4(ctx2);
          if_block3.c();
          transition_in(if_block3, 1);
          if_block3.m(div1, null);
        }
      } else if (if_block3) {
        group_outros();
        transition_out(if_block3, 1, 1, () => {
          if_block3 = null;
        });
        check_outros();
      }
      const plusminusinput0_changes = {};
      if (!updating_value && dirty[0] & 2) {
        updating_value = true;
        plusminusinput0_changes.value = ctx2[1].accuracy;
        add_flush_callback(() => updating_value = false);
      }
      plusminusinput0.$set(plusminusinput0_changes);
      const plusminusinput1_changes = {};
      if (!updating_value_1 && dirty[0] & 2) {
        updating_value_1 = true;
        plusminusinput1_changes.value = ctx2[1].difficulty;
        add_flush_callback(() => updating_value_1 = false);
      }
      plusminusinput1.$set(plusminusinput1_changes);
      if (ctx2[2].length < 2) {
        if (if_block4) {
          if_block4.p(ctx2, dirty);
          if (dirty[0] & 4) {
            transition_in(if_block4, 1);
          }
        } else {
          if_block4 = create_if_block_2(ctx2);
          if_block4.c();
          transition_in(if_block4, 1);
          if_block4.m(div7, t21);
        }
      } else if (if_block4) {
        group_outros();
        transition_out(if_block4, 1, 1, () => {
          if_block4 = null;
        });
        check_outros();
      }
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type_2(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block5 = if_blocks[current_block_type_index];
        if (!if_block5) {
          if_block5 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block5.c();
        } else {
          if_block5.p(ctx2, dirty);
        }
        transition_in(if_block5, 1);
        if_block5.m(div6, null);
      }
      if (!current || dirty[0] & 32 && div9_id_value !== (div9_id_value = ctx2[5] + "-accdiff-dialog")) {
        attr(div9, "id", div9_id_value);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block2);
      transition_in(if_block3);
      transition_in(plusminusinput0.$$.fragment, local);
      transition_in(plusminusinput1.$$.fragment, local);
      transition_in(if_block4);
      transition_in(if_block5);
      current = true;
    },
    o(local) {
      transition_out(if_block2);
      transition_out(if_block3);
      transition_out(plusminusinput0.$$.fragment, local);
      transition_out(plusminusinput1.$$.fragment, local);
      transition_out(if_block4);
      transition_out(if_block5);
      current = false;
    },
    d(detaching) {
      if (detaching)
        detach(form);
      if (if_block0)
        if_block0.d();
      if (if_block1)
        if_block1.d();
      if (if_block2)
        if_block2.d();
      if (if_block3)
        if_block3.d();
      destroy_component(plusminusinput0);
      destroy_component(plusminusinput1);
      if (if_block4)
        if_block4.d();
      if_blocks[current_block_type_index].d();
      mounted = false;
      run_all(dispose);
    }
  };
}
function focus$1(el) {
  el.focus();
}
function instance$2($$self, $$props, $$invalidate) {
  let { weapon } = $$props;
  let { base } = $$props;
  let { targets } = $$props;
  let { title } = $$props;
  let { lancerItem } = $$props;
  let { kind } = $$props;
  const dispatch2 = createEventDispatcher();
  function escToCancel(_el) {
    function escHandler(ev) {
      if (ev.key === "Escape") {
        ev.preventDefault();
        dispatch2("cancel");
      }
    }
    window.addEventListener("keydown", escHandler);
    return {
      destroy() {
        window.removeEventListener("keydown", escHandler);
      }
    };
  }
  function findRanges() {
    var _a;
    return (_a = lancerItem == null ? void 0 : lancerItem.rangesFor([RangeType.Blast, RangeType.Burst, RangeType.Cone, RangeType.Line])) != null ? _a : [];
  }
  function deployTemplate(range) {
    var _a, _b, _c;
    const creator = lancerItem == null ? void 0 : lancerItem.parent;
    const token = (_c = (_b = (_a = creator == null ? void 0 : creator.token) == null ? void 0 : _a.object) != null ? _b : creator == null ? void 0 : creator.getActiveTokens().shift()) != null ? _c : void 0;
    const t = WeaponRangeTemplate.fromRange(range, token);
    if (!t)
      return;
    fade("out");
    t.document.updateSource({
      [`flags.${game.system.id}.isAttack`]: true
    });
    t.placeTemplate().catch((e) => {
      console.warn(e);
      return;
    }).then((t2) => {
      if (t2)
        targetsFromTemplate(t2.id);
      fade("in");
    });
  }
  const click_handler = (range) => deployTemplate(range);
  function input0_change_handler() {
    weapon.accurate = this.checked;
    $$invalidate(0, weapon);
  }
  function input_change_handler() {
    weapon.seeking = this.checked;
    $$invalidate(0, weapon);
  }
  function consumelockon_lockOn_binding(value) {
    if ($$self.$$.not_equal(targets[0], value)) {
      targets[0] = value;
      $$invalidate(2, targets), $$invalidate(0, weapon), $$invalidate(1, base);
    }
  }
  function input1_change_handler() {
    weapon.inaccurate = this.checked;
    $$invalidate(0, weapon);
  }
  function cover_cover_binding(value) {
    if ($$self.$$.not_equal(base.cover, value)) {
      base.cover = value;
      $$invalidate(1, base), $$invalidate(0, weapon);
    }
  }
  function cover_cover_binding_1(value) {
    if ($$self.$$.not_equal(targets[0].cover, value)) {
      targets[0].cover = value;
      $$invalidate(2, targets), $$invalidate(0, weapon), $$invalidate(1, base);
    }
  }
  function plusminusinput0_value_binding(value) {
    if ($$self.$$.not_equal(base.accuracy, value)) {
      base.accuracy = value;
      $$invalidate(1, base), $$invalidate(0, weapon);
    }
  }
  function plusminusinput1_value_binding(value) {
    if ($$self.$$.not_equal(base.difficulty, value)) {
      base.difficulty = value;
      $$invalidate(1, base), $$invalidate(0, weapon);
    }
  }
  function total_target_binding(value) {
    if ($$self.$$.not_equal(targets[0], value)) {
      targets[0] = value;
      $$invalidate(2, targets), $$invalidate(0, weapon), $$invalidate(1, base);
    }
  }
  function total_target_binding_1(value, data, each_value, i) {
    each_value[i] = value;
    $$invalidate(2, targets), $$invalidate(0, weapon), $$invalidate(1, base);
  }
  const click_handler_1 = (data, each_value, i) => $$invalidate(2, each_value[i].accuracy = data.accuracy + 1, targets);
  function input0_input_handler(each_value, i) {
    each_value[i].accuracy = to_number(this.value);
    $$invalidate(2, targets), $$invalidate(0, weapon), $$invalidate(1, base);
  }
  function cover_cover_binding_2(value, data) {
    if ($$self.$$.not_equal(data.cover, value)) {
      data.cover = value;
      $$invalidate(2, targets), $$invalidate(0, weapon), $$invalidate(1, base);
    }
  }
  function input1_input_handler(each_value, i) {
    each_value[i].difficulty = to_number(this.value);
    $$invalidate(2, targets), $$invalidate(0, weapon), $$invalidate(1, base);
  }
  const click_handler_2 = (data, each_value, i) => $$invalidate(2, each_value[i].difficulty = data.difficulty + 1, targets);
  const click_handler_3 = () => dispatch2("cancel");
  const submit_handler = () => dispatch2("submit");
  $$self.$$set = ($$props2) => {
    if ("weapon" in $$props2)
      $$invalidate(0, weapon = $$props2.weapon);
    if ("base" in $$props2)
      $$invalidate(1, base = $$props2.base);
    if ("targets" in $$props2)
      $$invalidate(2, targets = $$props2.targets);
    if ("title" in $$props2)
      $$invalidate(3, title = $$props2.title);
    if ("lancerItem" in $$props2)
      $$invalidate(4, lancerItem = $$props2.lancerItem);
    if ("kind" in $$props2)
      $$invalidate(5, kind = $$props2.kind);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty[0] & 3) {
      $$invalidate(1, base = base);
    }
    if ($$self.$$.dirty[0] & 7) {
      $$invalidate(2, targets = targets);
    }
  };
  return [
    weapon,
    base,
    targets,
    title,
    lancerItem,
    kind,
    dispatch2,
    escToCancel,
    findRanges,
    deployTemplate,
    click_handler,
    input0_change_handler,
    input_change_handler,
    consumelockon_lockOn_binding,
    input1_change_handler,
    cover_cover_binding,
    cover_cover_binding_1,
    plusminusinput0_value_binding,
    plusminusinput1_value_binding,
    total_target_binding,
    total_target_binding_1,
    click_handler_1,
    input0_input_handler,
    cover_cover_binding_2,
    input1_input_handler,
    click_handler_2,
    click_handler_3,
    submit_handler
  ];
}
class Form$1 extends SvelteComponent {
  constructor(options) {
    super();
    init(
      this,
      options,
      instance$2,
      create_fragment$2,
      safe_not_equal,
      {
        weapon: 0,
        base: 1,
        targets: 2,
        title: 3,
        lancerItem: 4,
        kind: 5
      },
      null,
      [-1, -1]
    );
  }
  get weapon() {
    return this.$$.ctx[0];
  }
  set weapon(weapon) {
    this.$$set({ weapon });
    flush();
  }
  get base() {
    return this.$$.ctx[1];
  }
  set base(base) {
    this.$$set({ base });
    flush();
  }
  get targets() {
    return this.$$.ctx[2];
  }
  set targets(targets) {
    this.$$set({ targets });
    flush();
  }
  get title() {
    return this.$$.ctx[3];
  }
  set title(title) {
    this.$$set({ title });
    flush();
  }
  get lancerItem() {
    return this.$$.ctx[4];
  }
  set lancerItem(lancerItem) {
    this.$$set({ lancerItem });
    flush();
  }
  get kind() {
    return this.$$.ctx[5];
  }
  set kind(kind) {
    this.$$set({ kind });
    flush();
  }
}
var Form_svelte_svelte_type_style_lang = /* @__PURE__ */ (() => ".message-body.svelte-v75hxi{margin:8px 4px}.damage-preview.svelte-v75hxi{text-align:center}.damaged.svelte-v75hxi{opacity:30%}\n")();
function get_each_context$1(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[11] = list[i];
  return child_ctx;
}
function get_each_context_1(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[11] = list[i];
  return child_ctx;
}
function create_if_block(ctx) {
  var _a, _b;
  let div1;
  let h3;
  let t0_value = ((_b = (_a = ctx[1]) == null ? void 0 : _a.name) != null ? _b : "UNKNOWN MECH") + "";
  let t0;
  let t1;
  let t2;
  let t3;
  let t4;
  let div0;
  let t5;
  let t6;
  let p;
  let t7;
  let t8;
  let t9;
  let each_value_1 = { length: ctx[3] };
  let each_blocks_1 = [];
  for (let i = 0; i < each_value_1.length; i += 1) {
    each_blocks_1[i] = create_each_block_1(get_each_context_1(ctx, each_value_1, i));
  }
  let each_value = { length: ctx[2] };
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$1(get_each_context$1(ctx, each_value, i));
  }
  return {
    c() {
      div1 = element("div");
      h3 = element("h3");
      t0 = text(t0_value);
      t1 = text(" has taken ");
      t2 = text(ctx[4]);
      t3 = text(" damage!");
      t4 = space();
      div0 = element("div");
      for (let i = 0; i < each_blocks_1.length; i += 1) {
        each_blocks_1[i].c();
      }
      t5 = space();
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      t6 = space();
      p = element("p");
      t7 = text("Roll ");
      t8 = text(ctx[2]);
      t9 = text("d6 to determine what happens.");
      attr(div0, "class", "damage-preview svelte-v75hxi");
      attr(p, "class", "message");
      attr(div1, "class", "message-body svelte-v75hxi");
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      append(div1, h3);
      append(h3, t0);
      append(h3, t1);
      append(h3, t2);
      append(h3, t3);
      append(div1, t4);
      append(div1, div0);
      for (let i = 0; i < each_blocks_1.length; i += 1) {
        each_blocks_1[i].m(div0, null);
      }
      append(div0, t5);
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].m(div0, null);
      }
      append(div1, t6);
      append(div1, p);
      append(p, t7);
      append(p, t8);
      append(p, t9);
    },
    p(ctx2, dirty) {
      var _a2, _b2;
      if (dirty & 2 && t0_value !== (t0_value = ((_b2 = (_a2 = ctx2[1]) == null ? void 0 : _a2.name) != null ? _b2 : "UNKNOWN MECH") + ""))
        set_data(t0, t0_value);
      if (dirty & 16)
        set_data(t2, ctx2[4]);
      if (dirty & 24) {
        each_value_1 = { length: ctx2[3] };
        let i;
        for (i = 0; i < each_value_1.length; i += 1) {
          const child_ctx = get_each_context_1(ctx2, each_value_1, i);
          if (each_blocks_1[i]) {
            each_blocks_1[i].p(child_ctx, dirty);
          } else {
            each_blocks_1[i] = create_each_block_1(child_ctx);
            each_blocks_1[i].c();
            each_blocks_1[i].m(div0, t5);
          }
        }
        for (; i < each_blocks_1.length; i += 1) {
          each_blocks_1[i].d(1);
        }
        each_blocks_1.length = each_value_1.length;
      }
      if (dirty & 4) {
        each_value = { length: ctx2[2] };
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$1(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block$1();
            each_blocks[i].c();
            each_blocks[i].m(div0, null);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value.length;
      }
      if (dirty & 4)
        set_data(t8, ctx2[2]);
    },
    d(detaching) {
      if (detaching)
        detach(div1);
      destroy_each(each_blocks_1, detaching);
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_each_block_1(ctx) {
  let i;
  let i_class_value;
  return {
    c() {
      i = element("i");
      attr(i, "class", i_class_value = "cci cci-" + ctx[4] + " i--m damage-pip svelte-v75hxi");
    },
    m(target, anchor) {
      insert(target, i, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & 16 && i_class_value !== (i_class_value = "cci cci-" + ctx2[4] + " i--m damage-pip svelte-v75hxi")) {
        attr(i, "class", i_class_value);
      }
    },
    d(detaching) {
      if (detaching)
        detach(i);
    }
  };
}
function create_each_block$1(ctx) {
  let i;
  return {
    c() {
      i = element("i");
      attr(i, "class", "mdi mdi-hexagon-outline i--m damage-pip damaged svelte-v75hxi");
    },
    m(target, anchor) {
      insert(target, i, anchor);
    },
    p: noop,
    d(detaching) {
      if (detaching)
        detach(i);
    }
  };
}
function create_fragment$1(ctx) {
  let form;
  let div0;
  let i0;
  let i0_class_value;
  let t0;
  let span;
  let t1;
  let t2;
  let show_if = ctx[1] && (ctx[1].is_mech() || ctx[1].is_npc());
  let t3;
  let div1;
  let button0;
  let t5;
  let button1;
  let mounted;
  let dispose;
  let if_block = show_if && create_if_block(ctx);
  return {
    c() {
      form = element("form");
      div0 = element("div");
      i0 = element("i");
      t0 = space();
      span = element("span");
      t1 = text(ctx[0]);
      t2 = space();
      if (if_block)
        if_block.c();
      t3 = space();
      div1 = element("div");
      button0 = element("button");
      button0.innerHTML = `<i class="fas fa-check"></i>
      Roll`;
      t5 = space();
      button1 = element("button");
      button1.innerHTML = `<i class="fas fa-times"></i>
      Cancel`;
      attr(i0, "class", i0_class_value = "cci cci-" + ctx[4] + " i--m i--light svelte-v75hxi");
      attr(div0, "class", "lancer-header medium");
      attr(button0, "class", "dialog-button submit default");
      attr(button0, "data-button", "submit");
      attr(button0, "type", "submit");
      attr(button1, "class", "dialog-button cancel");
      attr(button1, "data-button", "cancel");
      attr(button1, "type", "button");
      attr(div1, "class", "dialog-buttons flexrow");
      attr(form, "id", "structstress");
      attr(form, "class", "structstress window-content");
    },
    m(target, anchor) {
      insert(target, form, anchor);
      append(form, div0);
      append(div0, i0);
      append(div0, t0);
      append(div0, span);
      append(span, t1);
      append(form, t2);
      if (if_block)
        if_block.m(form, null);
      append(form, t3);
      append(form, div1);
      append(div1, button0);
      append(div1, t5);
      append(div1, button1);
      if (!mounted) {
        dispose = [
          action_destroyer(focus.call(null, button0)),
          listen(button1, "click", ctx[7]),
          listen(form, "submit", prevent_default(ctx[8]))
        ];
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (dirty & 16 && i0_class_value !== (i0_class_value = "cci cci-" + ctx2[4] + " i--m i--light svelte-v75hxi")) {
        attr(i0, "class", i0_class_value);
      }
      if (dirty & 1)
        set_data(t1, ctx2[0]);
      if (dirty & 2)
        show_if = ctx2[1] && (ctx2[1].is_mech() || ctx2[1].is_npc());
      if (show_if) {
        if (if_block) {
          if_block.p(ctx2, dirty);
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          if_block.m(form, t3);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching)
        detach(form);
      if (if_block)
        if_block.d();
      mounted = false;
      run_all(dispose);
    }
  };
}
function focus(el) {
  el.focus();
}
function instance$1($$self, $$props, $$invalidate) {
  let icon;
  let current;
  let damage;
  let { title } = $$props;
  let { stat } = $$props;
  let { lancerActor } = $$props;
  const dispatch2 = createEventDispatcher();
  function getCurrent(a) {
    if (!a || !a.is_mech() && !a.is_npc())
      return 0;
    return Math.max(a.system.derived[stat].value - 1, 0);
  }
  function getDamage(a) {
    if (!a || !a.is_mech() && !a.is_npc())
      return 0;
    return a.system.derived[stat].max - getCurrent(a);
  }
  const click_handler = () => dispatch2("cancel");
  const submit_handler = () => {
    dispatch2("submit");
  };
  $$self.$$set = ($$props2) => {
    if ("title" in $$props2)
      $$invalidate(0, title = $$props2.title);
    if ("stat" in $$props2)
      $$invalidate(6, stat = $$props2.stat);
    if ("lancerActor" in $$props2)
      $$invalidate(1, lancerActor = $$props2.lancerActor);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & 64) {
      $$invalidate(4, icon = stat === "stress" ? "reactor" : stat);
    }
    if ($$self.$$.dirty & 2) {
      $$invalidate(3, current = getCurrent(lancerActor));
    }
    if ($$self.$$.dirty & 2) {
      $$invalidate(2, damage = getDamage(lancerActor));
    }
  };
  return [
    title,
    lancerActor,
    damage,
    current,
    icon,
    dispatch2,
    stat,
    click_handler,
    submit_handler
  ];
}
class Form extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$1, create_fragment$1, safe_not_equal, { title: 0, stat: 6, lancerActor: 1 });
  }
  get title() {
    return this.$$.ctx[0];
  }
  set title(title) {
    this.$$set({ title });
    flush();
  }
  get stat() {
    return this.$$.ctx[6];
  }
  set stat(stat) {
    this.$$set({ stat });
    flush();
  }
  get lancerActor() {
    return this.$$.ctx[1];
  }
  set lancerActor(lancerActor) {
    this.$$set({ lancerActor });
    flush();
  }
}
var SlidingHUDZone_svelte_svelte_type_style_lang = /* @__PURE__ */ (() => "#hudzone.svelte-1wjy4n8.svelte-1wjy4n8{position:absolute;display:flex;align-items:flex-end;background-color:transparent;border:none;box-shadow:none;flex-direction:row-reverse;pointer-events:none;transition:right .6s,opacity .2s;z-index:999}#hudzone.svelte-1wjy4n8>.component.svelte-1wjy4n8{padding-right:12px;pointer-events:initial;flex:unset;filter:drop-shadow(.4rem .4rem .6rem #333)}#hudzone.faded.svelte-1wjy4n8.svelte-1wjy4n8{opacity:.2}#hudzone.faded.svelte-1wjy4n8>.component.svelte-1wjy4n8{pointer-events:unset}\n")();
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[20] = list[i];
  child_ctx[21] = list;
  child_ctx[22] = i;
  return child_ctx;
}
function create_each_block(key_1, ctx) {
  let div;
  let switch_instance;
  let key = ctx[20];
  let t;
  let div_transition;
  let rect;
  let stop_animation = noop;
  let current;
  const switch_instance_spread_levels = [{ kind: ctx[20] }, ctx[2][ctx[20]].data];
  const assign_switch_instance = () => ctx[16](switch_instance, key);
  const unassign_switch_instance = () => ctx[16](null, key);
  function submit_handler() {
    return ctx[17](ctx[20]);
  }
  function cancel_handler() {
    return ctx[18](ctx[20]);
  }
  var switch_value = ctx[6][ctx[20]];
  function switch_props(ctx2) {
    let switch_instance_props = {};
    for (let i = 0; i < switch_instance_spread_levels.length; i += 1) {
      switch_instance_props = assign(switch_instance_props, switch_instance_spread_levels[i]);
    }
    return { props: switch_instance_props };
  }
  if (switch_value) {
    switch_instance = new switch_value(switch_props());
    assign_switch_instance();
    switch_instance.$on("submit", submit_handler);
    switch_instance.$on("cancel", cancel_handler);
  }
  return {
    key: key_1,
    first: null,
    c() {
      div = element("div");
      if (switch_instance)
        create_component(switch_instance.$$.fragment);
      t = space();
      attr(div, "class", "component grid-enforcement svelte-1wjy4n8");
      this.first = div;
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (switch_instance) {
        mount_component(switch_instance, div, null);
      }
      append(div, t);
      current = true;
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      if (key !== ctx[20]) {
        unassign_switch_instance();
        key = ctx[20];
        assign_switch_instance();
      }
      const switch_instance_changes = dirty & 12 ? get_spread_update(switch_instance_spread_levels, [
        dirty & 8 && { kind: ctx[20] },
        get_spread_object(ctx[2][ctx[20]].data)
      ]) : {};
      if (switch_value !== (switch_value = ctx[6][ctx[20]])) {
        if (switch_instance) {
          group_outros();
          const old_component = switch_instance;
          transition_out(old_component.$$.fragment, 1, 0, () => {
            destroy_component(old_component, 1);
          });
          check_outros();
        }
        if (switch_value) {
          switch_instance = new switch_value(switch_props());
          assign_switch_instance();
          switch_instance.$on("submit", submit_handler);
          switch_instance.$on("cancel", cancel_handler);
          create_component(switch_instance.$$.fragment);
          transition_in(switch_instance.$$.fragment, 1);
          mount_component(switch_instance, div, t);
        } else {
          switch_instance = null;
        }
      } else if (switch_value) {
        switch_instance.$set(switch_instance_changes);
      }
    },
    r() {
      rect = div.getBoundingClientRect();
    },
    f() {
      fix_position(div);
      stop_animation();
      add_transform(div, rect);
    },
    a() {
      stop_animation();
      stop_animation = create_animation(div, rect, flip, {});
    },
    i(local) {
      if (current)
        return;
      if (switch_instance)
        transition_in(switch_instance.$$.fragment, local);
      add_render_callback(() => {
        if (!div_transition)
          div_transition = create_bidirectional_transition(div, slide, {}, true);
        div_transition.run(1);
      });
      current = true;
    },
    o(local) {
      if (switch_instance)
        transition_out(switch_instance.$$.fragment, local);
      if (!div_transition)
        div_transition = create_bidirectional_transition(div, slide, {}, false);
      div_transition.run(0);
      current = false;
    },
    d(detaching) {
      if (detaching)
        detach(div);
      unassign_switch_instance();
      if (switch_instance)
        destroy_component(switch_instance);
      if (detaching && div_transition)
        div_transition.end();
    }
  };
}
function create_fragment(ctx) {
  let div;
  let each_blocks = [];
  let each_1_lookup = /* @__PURE__ */ new Map();
  let current;
  let each_value = ctx[3];
  const get_key = (ctx2) => ctx2[20] + ctx2[2][ctx2[20]].data.title;
  for (let i = 0; i < each_value.length; i += 1) {
    let child_ctx = get_each_context(ctx, each_value, i);
    let key = get_key(child_ctx);
    each_1_lookup.set(key, each_blocks[i] = create_each_block(key, child_ctx));
  }
  return {
    c() {
      div = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(div, "id", "hudzone");
      attr(div, "class", "window-app svelte-1wjy4n8");
      set_style(div, "bottom", "0");
      set_style(div, "right", ctx[5] + "px");
      toggle_class(div, "faded", ctx[0] || ctx[4]);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].m(div, null);
      }
      current = true;
    },
    p(ctx2, [dirty]) {
      if (dirty & 206) {
        each_value = ctx2[3];
        group_outros();
        for (let i = 0; i < each_blocks.length; i += 1)
          each_blocks[i].r();
        each_blocks = update_keyed_each(each_blocks, dirty, get_key, 1, ctx2, each_value, each_1_lookup, div, fix_and_outro_and_destroy_block, create_each_block, null, get_each_context);
        for (let i = 0; i < each_blocks.length; i += 1)
          each_blocks[i].a();
        check_outros();
      }
      if (!current || dirty & 32) {
        set_style(div, "right", ctx2[5] + "px");
      }
      if (dirty & 17) {
        toggle_class(div, "faded", ctx2[0] || ctx2[4]);
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching)
        detach(div);
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].d();
      }
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let attackData;
  let visibleHudsKeys;
  let $userTargets;
  let $isDragging;
  let $sidebarWidth;
  component_subscribe($$self, userTargets, ($$value) => $$invalidate(15, $userTargets = $$value));
  component_subscribe($$self, isDragging, ($$value) => $$invalidate(4, $isDragging = $$value));
  component_subscribe($$self, sidebarWidth, ($$value) => $$invalidate(5, $sidebarWidth = $$value));
  let dispatch2 = createEventDispatcher();
  let dialogs = {
    hase: Form$1,
    attack: Form$1,
    struct: Form,
    stress: Form
  };
  let huds = {
    hase: { open: null },
    attack: { open: null },
    struct: { open: null },
    stress: { open: null }
  };
  function open(key, data2) {
    dispatch2(`${key}.cancel`);
    $$invalidate(2, huds[key].open = new Date().getTime(), huds);
    $$invalidate(2, huds[key].data = data2, huds);
  }
  function close(key) {
    dispatch2(`${key}.cancel`);
    $$invalidate(2, huds[key].open = null, huds);
    $$invalidate(2, huds[key].data = null, huds);
  }
  function refresh(key, data2) {
    $$invalidate(2, huds[key].data = data2, huds);
  }
  function data(key) {
    if (huds[key] && huds[key].data) {
      return huds[key].data;
    }
  }
  function isOpen(key) {
    return huds[key] && huds[key].open;
  }
  let { faded = false } = $$props;
  function fade2(dir) {
    $$invalidate(0, faded = dir == "out");
  }
  let { components = {} } = $$props;
  function forward(key, event, data2) {
    dispatch2(`${key}.${event}`, data2 ? data2 : void 0);
    $$invalidate(2, huds[key].open = null, huds);
    $$invalidate(2, huds[key].data = null, huds);
  }
  function switch_instance_binding($$value, key) {
    binding_callbacks[$$value ? "unshift" : "push"](() => {
      components[key] = $$value;
      $$invalidate(1, components);
    });
  }
  const submit_handler = (key) => forward(key, "submit", huds[key].data);
  const cancel_handler = (key) => forward(key, "cancel");
  $$self.$$set = ($$props2) => {
    if ("faded" in $$props2)
      $$invalidate(0, faded = $$props2.faded);
    if ("components" in $$props2)
      $$invalidate(1, components = $$props2.components);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & 4) {
      $$invalidate(14, attackData = huds.attack.data);
    }
    if ($$self.$$.dirty & 49152) {
      {
        if (attackData) {
          attackData.replaceTargets($userTargets);
          $$invalidate(14, attackData), $$invalidate(2, huds), $$invalidate(15, $userTargets);
        }
      }
    }
    if ($$self.$$.dirty & 4) {
      $$invalidate(3, visibleHudsKeys = Object.keys(huds).filter((key) => huds[key].open).sort((a, b) => huds[b].open - huds[a].open));
    }
  };
  return [
    faded,
    components,
    huds,
    visibleHudsKeys,
    $isDragging,
    $sidebarWidth,
    dialogs,
    forward,
    open,
    close,
    refresh,
    data,
    isOpen,
    fade2,
    attackData,
    $userTargets,
    switch_instance_binding,
    submit_handler,
    cancel_handler
  ];
}
class SlidingHUDZone extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      open: 8,
      close: 9,
      refresh: 10,
      data: 11,
      isOpen: 12,
      faded: 0,
      fade: 13,
      components: 1
    });
  }
  get open() {
    return this.$$.ctx[8];
  }
  get close() {
    return this.$$.ctx[9];
  }
  get refresh() {
    return this.$$.ctx[10];
  }
  get data() {
    return this.$$.ctx[11];
  }
  get isOpen() {
    return this.$$.ctx[12];
  }
  get faded() {
    return this.$$.ctx[0];
  }
  set faded(faded) {
    this.$$set({ faded });
    flush();
  }
  get fade() {
    return this.$$.ctx[13];
  }
  get components() {
    return this.$$.ctx[1];
  }
  set components(components) {
    this.$$set({ components });
    flush();
  }
}
export { SlidingHUDZone as default };
//# sourceMappingURL=SlidingHUDZone.js.map

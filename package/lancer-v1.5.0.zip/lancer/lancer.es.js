export { s as system_ready } from "./lancer.js";
//# sourceMappingURL=lancer.es.js.map

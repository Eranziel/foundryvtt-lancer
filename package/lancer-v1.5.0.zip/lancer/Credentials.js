import { c as commonjsGlobal, g as getAugmentedNamespace } from "./lancer.js";
var AWS_CLOUDWATCH_CATEGORY = "Logging";
var __values = globalThis && globalThis.__values || function(o) {
  var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
  if (m)
    return m.call(o);
  if (o && typeof o.length === "number")
    return {
      next: function() {
        if (o && i >= o.length)
          o = void 0;
        return { value: o && o[i++], done: !o };
      }
    };
  throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var __read$4 = globalThis && globalThis.__read || function(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m)
    return o;
  var i = m.call(o), r, ar = [], e;
  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
      ar.push(r.value);
  } catch (error) {
    e = { error };
  } finally {
    try {
      if (r && !r.done && (m = i["return"]))
        m.call(i);
    } finally {
      if (e)
        throw e.error;
    }
  }
  return ar;
};
var __spread$2 = globalThis && globalThis.__spread || function() {
  for (var ar = [], i = 0; i < arguments.length; i++)
    ar = ar.concat(__read$4(arguments[i]));
  return ar;
};
var LOG_LEVELS = {
  VERBOSE: 1,
  DEBUG: 2,
  INFO: 3,
  WARN: 4,
  ERROR: 5
};
var LOG_TYPE;
(function(LOG_TYPE2) {
  LOG_TYPE2["DEBUG"] = "DEBUG";
  LOG_TYPE2["ERROR"] = "ERROR";
  LOG_TYPE2["INFO"] = "INFO";
  LOG_TYPE2["WARN"] = "WARN";
  LOG_TYPE2["VERBOSE"] = "VERBOSE";
})(LOG_TYPE || (LOG_TYPE = {}));
var ConsoleLogger = function() {
  function ConsoleLogger2(name2, level) {
    if (level === void 0) {
      level = LOG_TYPE.WARN;
    }
    this.name = name2;
    this.level = level;
    this._pluggables = [];
  }
  ConsoleLogger2.prototype._padding = function(n) {
    return n < 10 ? "0" + n : "" + n;
  };
  ConsoleLogger2.prototype._ts = function() {
    var dt = new Date();
    return [this._padding(dt.getMinutes()), this._padding(dt.getSeconds())].join(":") + "." + dt.getMilliseconds();
  };
  ConsoleLogger2.prototype.configure = function(config) {
    if (!config)
      return this._config;
    this._config = config;
    return this._config;
  };
  ConsoleLogger2.prototype._log = function(type) {
    var e_1, _a;
    var msg = [];
    for (var _i = 1; _i < arguments.length; _i++) {
      msg[_i - 1] = arguments[_i];
    }
    var logger_level_name = this.level;
    if (ConsoleLogger2.LOG_LEVEL) {
      logger_level_name = ConsoleLogger2.LOG_LEVEL;
    }
    if (typeof window !== "undefined" && window.LOG_LEVEL) {
      logger_level_name = window.LOG_LEVEL;
    }
    var logger_level = LOG_LEVELS[logger_level_name];
    var type_level = LOG_LEVELS[type];
    if (!(type_level >= logger_level)) {
      return;
    }
    var log = console.log.bind(console);
    if (type === LOG_TYPE.ERROR && console.error) {
      log = console.error.bind(console);
    }
    if (type === LOG_TYPE.WARN && console.warn) {
      log = console.warn.bind(console);
    }
    var prefix = "[" + type + "] " + this._ts() + " " + this.name;
    var message = "";
    if (msg.length === 1 && typeof msg[0] === "string") {
      message = prefix + " - " + msg[0];
      log(message);
    } else if (msg.length === 1) {
      message = prefix + " " + msg[0];
      log(prefix, msg[0]);
    } else if (typeof msg[0] === "string") {
      var obj = msg.slice(1);
      if (obj.length === 1) {
        obj = obj[0];
      }
      message = prefix + " - " + msg[0] + " " + obj;
      log(prefix + " - " + msg[0], obj);
    } else {
      message = prefix + " " + msg;
      log(prefix, msg);
    }
    try {
      for (var _b = __values(this._pluggables), _c = _b.next(); !_c.done; _c = _b.next()) {
        var plugin = _c.value;
        var logEvent = { message, timestamp: Date.now() };
        plugin.pushLogs([logEvent]);
      }
    } catch (e_1_1) {
      e_1 = { error: e_1_1 };
    } finally {
      try {
        if (_c && !_c.done && (_a = _b.return))
          _a.call(_b);
      } finally {
        if (e_1)
          throw e_1.error;
      }
    }
  };
  ConsoleLogger2.prototype.log = function() {
    var msg = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      msg[_i] = arguments[_i];
    }
    this._log.apply(this, __spread$2([LOG_TYPE.INFO], msg));
  };
  ConsoleLogger2.prototype.info = function() {
    var msg = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      msg[_i] = arguments[_i];
    }
    this._log.apply(this, __spread$2([LOG_TYPE.INFO], msg));
  };
  ConsoleLogger2.prototype.warn = function() {
    var msg = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      msg[_i] = arguments[_i];
    }
    this._log.apply(this, __spread$2([LOG_TYPE.WARN], msg));
  };
  ConsoleLogger2.prototype.error = function() {
    var msg = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      msg[_i] = arguments[_i];
    }
    this._log.apply(this, __spread$2([LOG_TYPE.ERROR], msg));
  };
  ConsoleLogger2.prototype.debug = function() {
    var msg = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      msg[_i] = arguments[_i];
    }
    this._log.apply(this, __spread$2([LOG_TYPE.DEBUG], msg));
  };
  ConsoleLogger2.prototype.verbose = function() {
    var msg = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      msg[_i] = arguments[_i];
    }
    this._log.apply(this, __spread$2([LOG_TYPE.VERBOSE], msg));
  };
  ConsoleLogger2.prototype.addPluggable = function(pluggable) {
    if (pluggable && pluggable.getCategoryName() === AWS_CLOUDWATCH_CATEGORY) {
      this._pluggables.push(pluggable);
      pluggable.configure(this._config);
    }
  };
  ConsoleLogger2.prototype.listPluggables = function() {
    return this._pluggables;
  };
  ConsoleLogger2.LOG_LEVEL = null;
  return ConsoleLogger2;
}();
var __read$3 = globalThis && globalThis.__read || function(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m)
    return o;
  var i = m.call(o), r, ar = [], e;
  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
      ar.push(r.value);
  } catch (error) {
    e = { error };
  } finally {
    try {
      if (r && !r.done && (m = i["return"]))
        m.call(i);
    } finally {
      if (e)
        throw e.error;
    }
  }
  return ar;
};
var logger$8 = new ConsoleLogger("Amplify");
var AmplifyClass = function() {
  function AmplifyClass2() {
    this._components = [];
    this._config = {};
    this._modules = {};
    this.Auth = null;
    this.Analytics = null;
    this.API = null;
    this.Credentials = null;
    this.Storage = null;
    this.I18n = null;
    this.Cache = null;
    this.PubSub = null;
    this.Interactions = null;
    this.Pushnotification = null;
    this.UI = null;
    this.XR = null;
    this.Predictions = null;
    this.DataStore = null;
    this.Logger = ConsoleLogger;
    this.ServiceWorker = null;
  }
  AmplifyClass2.prototype.register = function(comp) {
    logger$8.debug("component registered in amplify", comp);
    this._components.push(comp);
    if (typeof comp.getModuleName === "function") {
      this._modules[comp.getModuleName()] = comp;
      this[comp.getModuleName()] = comp;
    } else {
      logger$8.debug("no getModuleName method for component", comp);
    }
    comp.configure(this._config);
  };
  AmplifyClass2.prototype.configure = function(config) {
    var _this = this;
    if (!config)
      return this._config;
    this._config = Object.assign(this._config, config);
    logger$8.debug("amplify config", this._config);
    Object.entries(this._modules).forEach(function(_a) {
      var _b = __read$3(_a, 2);
      _b[0];
      var comp = _b[1];
      Object.keys(comp).forEach(function(property) {
        if (_this._modules[property]) {
          comp[property] = _this._modules[property];
        }
      });
    });
    this._components.map(function(comp) {
      comp.configure(_this._config);
    });
    return this._config;
  };
  AmplifyClass2.prototype.addPluggable = function(pluggable) {
    if (pluggable && pluggable["getCategory"] && typeof pluggable["getCategory"] === "function") {
      this._components.map(function(comp) {
        if (comp["addPluggable"] && typeof comp["addPluggable"] === "function") {
          comp.addPluggable(pluggable);
        }
      });
    }
  };
  return AmplifyClass2;
}();
var Amplify = new AmplifyClass();
var version$1 = "4.2.9";
var BASE_USER_AGENT = "aws-amplify/" + version$1;
var Platform = {
  userAgent: BASE_USER_AGENT + " js",
  product: "",
  navigator: null,
  isReactNative: false
};
if (typeof navigator !== "undefined" && navigator.product) {
  Platform.product = navigator.product || "";
  Platform.navigator = navigator || null;
  switch (navigator.product) {
    case "ReactNative":
      Platform.userAgent = BASE_USER_AGENT + " react-native";
      Platform.isReactNative = true;
      break;
    default:
      Platform.userAgent = BASE_USER_AGENT + " js";
      Platform.isReactNative = false;
      break;
  }
}
var getAmplifyUserAgent = function() {
  return Platform.userAgent;
};
var __assign$3 = globalThis && globalThis.__assign || function() {
  __assign$3 = Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s)
        if (Object.prototype.hasOwnProperty.call(s, p))
          t[p] = s[p];
    }
    return t;
  };
  return __assign$3.apply(this, arguments);
};
var __read$2 = globalThis && globalThis.__read || function(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m)
    return o;
  var i = m.call(o), r, ar = [], e;
  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
      ar.push(r.value);
  } catch (error) {
    e = { error };
  } finally {
    try {
      if (r && !r.done && (m = i["return"]))
        m.call(i);
    } finally {
      if (e)
        throw e.error;
    }
  }
  return ar;
};
var __spread$1 = globalThis && globalThis.__spread || function() {
  for (var ar = [], i = 0; i < arguments.length; i++)
    ar = ar.concat(__read$2(arguments[i]));
  return ar;
};
var logger$7 = new ConsoleLogger("Hub");
var AMPLIFY_SYMBOL = typeof Symbol !== "undefined" && typeof Symbol.for === "function" ? Symbol.for("amplify_default") : "@@amplify_default";
function isLegacyCallback(callback) {
  return callback.onHubCapsule !== void 0;
}
var HubClass = function() {
  function HubClass2(name2) {
    this.listeners = [];
    this.patterns = [];
    this.protectedChannels = [
      "core",
      "auth",
      "api",
      "analytics",
      "interactions",
      "pubsub",
      "storage",
      "xr"
    ];
    this.name = name2;
  }
  HubClass2.prototype.remove = function(channel, listener) {
    if (channel instanceof RegExp) {
      var pattern_1 = this.patterns.find(function(_a) {
        var pattern = _a.pattern;
        return pattern.source === channel.source;
      });
      if (!pattern_1) {
        logger$7.warn("No listeners for " + channel);
        return;
      }
      this.patterns = __spread$1(this.patterns.filter(function(x) {
        return x !== pattern_1;
      }));
    } else {
      var holder = this.listeners[channel];
      if (!holder) {
        logger$7.warn("No listeners for " + channel);
        return;
      }
      this.listeners[channel] = __spread$1(holder.filter(function(_a) {
        var callback = _a.callback;
        return callback !== listener;
      }));
    }
  };
  HubClass2.prototype.dispatch = function(channel, payload, source, ampSymbol) {
    if (source === void 0) {
      source = "";
    }
    if (this.protectedChannels.indexOf(channel) > -1) {
      var hasAccess = ampSymbol === AMPLIFY_SYMBOL;
      if (!hasAccess) {
        logger$7.warn("WARNING: " + channel + " is protected and dispatching on it can have unintended consequences");
      }
    }
    var capsule = {
      channel,
      payload: __assign$3({}, payload),
      source,
      patternInfo: []
    };
    try {
      this._toListeners(capsule);
    } catch (e) {
      logger$7.error(e);
    }
  };
  HubClass2.prototype.listen = function(channel, callback, listenerName) {
    var _this = this;
    if (listenerName === void 0) {
      listenerName = "noname";
    }
    var cb;
    if (isLegacyCallback(callback)) {
      logger$7.warn("WARNING onHubCapsule is Deprecated. Please pass in a callback.");
      cb = callback.onHubCapsule.bind(callback);
    } else if (typeof callback !== "function") {
      throw new Error("No callback supplied to Hub");
    } else {
      cb = callback;
    }
    if (channel instanceof RegExp) {
      this.patterns.push({
        pattern: channel,
        callback: cb
      });
    } else {
      var holder = this.listeners[channel];
      if (!holder) {
        holder = [];
        this.listeners[channel] = holder;
      }
      holder.push({
        name: listenerName,
        callback: cb
      });
    }
    return function() {
      _this.remove(channel, cb);
    };
  };
  HubClass2.prototype._toListeners = function(capsule) {
    var channel = capsule.channel, payload = capsule.payload;
    var holder = this.listeners[channel];
    if (holder) {
      holder.forEach(function(listener) {
        logger$7.debug("Dispatching to " + channel + " with ", payload);
        try {
          listener.callback(capsule);
        } catch (e) {
          logger$7.error(e);
        }
      });
    }
    if (this.patterns.length > 0) {
      if (!payload.message) {
        logger$7.warn("Cannot perform pattern matching without a message key");
        return;
      }
      var payloadStr_1 = payload.message;
      this.patterns.forEach(function(pattern) {
        var match = payloadStr_1.match(pattern.pattern);
        if (match) {
          var _a = __read$2(match), groups = _a.slice(1);
          var dispatchingCapsule = __assign$3(__assign$3({}, capsule), { patternInfo: groups });
          try {
            pattern.callback(dispatchingCapsule);
          } catch (e) {
            logger$7.error(e);
          }
        }
      });
    }
  };
  return HubClass2;
}();
var Hub = new HubClass("__default__");
var logger$6 = new ConsoleLogger("I18n");
var I18n$1 = function() {
  function I18n2(options) {
    this._options = null;
    this._lang = null;
    this._dict = {};
    this._options = Object.assign({}, options);
    this._lang = this._options.language;
    if (!this._lang && typeof window !== "undefined" && window && window.navigator) {
      this._lang = window.navigator.language;
    }
    logger$6.debug(this._lang);
  }
  I18n2.prototype.setLanguage = function(lang) {
    this._lang = lang;
  };
  I18n2.prototype.get = function(key, defVal) {
    if (defVal === void 0) {
      defVal = void 0;
    }
    if (!this._lang) {
      return typeof defVal !== "undefined" ? defVal : key;
    }
    var lang = this._lang;
    var val = this.getByLanguage(key, lang);
    if (val) {
      return val;
    }
    if (lang.indexOf("-") > 0) {
      val = this.getByLanguage(key, lang.split("-")[0]);
    }
    if (val) {
      return val;
    }
    return typeof defVal !== "undefined" ? defVal : key;
  };
  I18n2.prototype.getByLanguage = function(key, language, defVal) {
    if (defVal === void 0) {
      defVal = null;
    }
    if (!language) {
      return defVal;
    }
    var lang_dict = this._dict[language];
    if (!lang_dict) {
      return defVal;
    }
    return lang_dict[key];
  };
  I18n2.prototype.putVocabulariesForLanguage = function(language, vocabularies) {
    var lang_dict = this._dict[language];
    if (!lang_dict) {
      lang_dict = this._dict[language] = {};
    }
    Object.assign(lang_dict, vocabularies);
  };
  I18n2.prototype.putVocabularies = function(vocabularies) {
    var _this = this;
    Object.keys(vocabularies).map(function(key) {
      _this.putVocabulariesForLanguage(key, vocabularies[key]);
    });
  };
  return I18n2;
}();
var logger$5 = new ConsoleLogger("I18n");
var _config = null;
var _i18n = null;
var I18n = function() {
  function I18n2() {
  }
  I18n2.configure = function(config) {
    logger$5.debug("configure I18n");
    if (!config) {
      return _config;
    }
    _config = Object.assign({}, _config, config.I18n || config);
    I18n2.createInstance();
    return _config;
  };
  I18n2.getModuleName = function() {
    return "I18n";
  };
  I18n2.createInstance = function() {
    logger$5.debug("create I18n instance");
    if (_i18n) {
      return;
    }
    _i18n = new I18n$1(_config);
  };
  I18n2.setLanguage = function(lang) {
    I18n2.checkConfig();
    return _i18n.setLanguage(lang);
  };
  I18n2.get = function(key, defVal) {
    if (!I18n2.checkConfig()) {
      return typeof defVal === "undefined" ? key : defVal;
    }
    return _i18n.get(key, defVal);
  };
  I18n2.putVocabulariesForLanguage = function(language, vocabularies) {
    I18n2.checkConfig();
    return _i18n.putVocabulariesForLanguage(language, vocabularies);
  };
  I18n2.putVocabularies = function(vocabularies) {
    I18n2.checkConfig();
    return _i18n.putVocabularies(vocabularies);
  };
  I18n2.checkConfig = function() {
    if (!_i18n) {
      _i18n = new I18n$1(_config);
    }
    return true;
  };
  return I18n2;
}();
Amplify.register(I18n);
var MIME_MAP = [
  { type: "text/plain", ext: "txt" },
  { type: "text/html", ext: "html" },
  { type: "text/javascript", ext: "js" },
  { type: "text/css", ext: "css" },
  { type: "text/csv", ext: "csv" },
  { type: "text/yaml", ext: "yml" },
  { type: "text/yaml", ext: "yaml" },
  { type: "text/calendar", ext: "ics" },
  { type: "text/calendar", ext: "ical" },
  { type: "image/apng", ext: "apng" },
  { type: "image/bmp", ext: "bmp" },
  { type: "image/gif", ext: "gif" },
  { type: "image/x-icon", ext: "ico" },
  { type: "image/x-icon", ext: "cur" },
  { type: "image/jpeg", ext: "jpg" },
  { type: "image/jpeg", ext: "jpeg" },
  { type: "image/jpeg", ext: "jfif" },
  { type: "image/jpeg", ext: "pjp" },
  { type: "image/jpeg", ext: "pjpeg" },
  { type: "image/png", ext: "png" },
  { type: "image/svg+xml", ext: "svg" },
  { type: "image/tiff", ext: "tif" },
  { type: "image/tiff", ext: "tiff" },
  { type: "image/webp", ext: "webp" },
  { type: "application/json", ext: "json" },
  { type: "application/xml", ext: "xml" },
  { type: "application/x-sh", ext: "sh" },
  { type: "application/zip", ext: "zip" },
  { type: "application/x-rar-compressed", ext: "rar" },
  { type: "application/x-tar", ext: "tar" },
  { type: "application/x-bzip", ext: "bz" },
  { type: "application/x-bzip2", ext: "bz2" },
  { type: "application/pdf", ext: "pdf" },
  { type: "application/java-archive", ext: "jar" },
  { type: "application/msword", ext: "doc" },
  { type: "application/vnd.ms-excel", ext: "xls" },
  { type: "application/vnd.ms-excel", ext: "xlsx" },
  { type: "message/rfc822", ext: "eml" }
];
var isEmpty = function(obj) {
  if (obj === void 0) {
    obj = {};
  }
  return Object.keys(obj).length === 0;
};
var sortByField = function(list, field, dir) {
  if (!list || !list.sort) {
    return false;
  }
  var dirX = dir && dir === "desc" ? -1 : 1;
  list.sort(function(a, b) {
    var a_val = a[field];
    var b_val = b[field];
    if (typeof b_val === "undefined") {
      return typeof a_val === "undefined" ? 0 : 1 * dirX;
    }
    if (typeof a_val === "undefined") {
      return -1 * dirX;
    }
    if (a_val < b_val) {
      return -1 * dirX;
    }
    if (a_val > b_val) {
      return 1 * dirX;
    }
    return 0;
  });
  return true;
};
var objectLessAttributes = function(obj, less) {
  var ret = Object.assign({}, obj);
  if (less) {
    if (typeof less === "string") {
      delete ret[less];
    } else {
      less.forEach(function(attr) {
        delete ret[attr];
      });
    }
  }
  return ret;
};
var filenameToContentType = function(filename, defVal) {
  if (defVal === void 0) {
    defVal = "application/octet-stream";
  }
  var name2 = filename.toLowerCase();
  var filtered = MIME_MAP.filter(function(mime) {
    return name2.endsWith("." + mime.ext);
  });
  return filtered.length > 0 ? filtered[0].type : defVal;
};
var isTextFile = function(contentType) {
  var type = contentType.toLowerCase();
  if (type.startsWith("text/")) {
    return true;
  }
  return "application/json" === type || "application/xml" === type || "application/sh" === type;
};
var generateRandomString = function() {
  var result = "";
  var chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  for (var i = 32; i > 0; i -= 1) {
    result += chars[Math.floor(Math.random() * chars.length)];
  }
  return result;
};
var makeQuerablePromise = function(promise) {
  if (promise.isResolved)
    return promise;
  var isPending = true;
  var isRejected = false;
  var isFullfilled = false;
  var result = promise.then(function(data) {
    isFullfilled = true;
    isPending = false;
    return data;
  }, function(e) {
    isRejected = true;
    isPending = false;
    throw e;
  });
  result.isFullfilled = function() {
    return isFullfilled;
  };
  result.isPending = function() {
    return isPending;
  };
  result.isRejected = function() {
    return isRejected;
  };
  return result;
};
var isWebWorker = function() {
  if (typeof self === "undefined") {
    return false;
  }
  var selfContext = self;
  return typeof selfContext.WorkerGlobalScope !== "undefined" && self instanceof selfContext.WorkerGlobalScope;
};
var browserOrNode = function() {
  var isBrowser = typeof window !== "undefined" && typeof window.document !== "undefined";
  var isNode = typeof process !== "undefined" && process.versions != null && process.versions.node != null;
  return {
    isBrowser,
    isNode
  };
};
var transferKeyToLowerCase = function(obj, whiteListForItself, whiteListForChildren) {
  if (whiteListForItself === void 0) {
    whiteListForItself = [];
  }
  if (whiteListForChildren === void 0) {
    whiteListForChildren = [];
  }
  if (!isStrictObject(obj))
    return obj;
  var ret = {};
  for (var key in obj) {
    if (obj.hasOwnProperty(key)) {
      var transferedKey = whiteListForItself.includes(key) ? key : key[0].toLowerCase() + key.slice(1);
      ret[transferedKey] = whiteListForChildren.includes(key) ? obj[key] : transferKeyToLowerCase(obj[key], whiteListForItself, whiteListForChildren);
    }
  }
  return ret;
};
var transferKeyToUpperCase = function(obj, whiteListForItself, whiteListForChildren) {
  if (whiteListForItself === void 0) {
    whiteListForItself = [];
  }
  if (whiteListForChildren === void 0) {
    whiteListForChildren = [];
  }
  if (!isStrictObject(obj))
    return obj;
  var ret = {};
  for (var key in obj) {
    if (obj.hasOwnProperty(key)) {
      var transferredKey = whiteListForItself.includes(key) ? key : key[0].toUpperCase() + key.slice(1);
      ret[transferredKey] = whiteListForChildren.includes(key) ? obj[key] : transferKeyToUpperCase(obj[key], whiteListForItself, whiteListForChildren);
    }
  }
  return ret;
};
var isStrictObject = function(obj) {
  return obj instanceof Object && !(obj instanceof Array) && !(obj instanceof Function) && !(obj instanceof Number) && !(obj instanceof String) && !(obj instanceof Boolean);
};
var JS = function() {
  function JS2() {
  }
  JS2.isEmpty = isEmpty;
  JS2.sortByField = sortByField;
  JS2.objectLessAttributes = objectLessAttributes;
  JS2.filenameToContentType = filenameToContentType;
  JS2.isTextFile = isTextFile;
  JS2.generateRandomString = generateRandomString;
  JS2.makeQuerablePromise = makeQuerablePromise;
  JS2.isWebWorker = isWebWorker;
  JS2.browserOrNode = browserOrNode;
  JS2.transferKeyToLowerCase = transferKeyToLowerCase;
  JS2.transferKeyToUpperCase = transferKeyToUpperCase;
  JS2.isStrictObject = isStrictObject;
  return JS2;
}();
var tslib = { exports: {} };
/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
(function(module2) {
  var __extends2;
  var __assign2;
  var __rest;
  var __decorate;
  var __param;
  var __metadata;
  var __awaiter2;
  var __generator2;
  var __exportStar;
  var __values2;
  var __read2;
  var __spread2;
  var __spreadArrays;
  var __await;
  var __asyncGenerator;
  var __asyncDelegator;
  var __asyncValues;
  var __makeTemplateObject;
  var __importStar;
  var __importDefault;
  var __classPrivateFieldGet;
  var __classPrivateFieldSet;
  var __createBinding;
  (function(factory) {
    var root = typeof commonjsGlobal === "object" ? commonjsGlobal : typeof self === "object" ? self : typeof this === "object" ? this : {};
    {
      factory(createExporter(root, createExporter(module2.exports)));
    }
    function createExporter(exports, previous) {
      if (exports !== root) {
        if (typeof Object.create === "function") {
          Object.defineProperty(exports, "__esModule", { value: true });
        } else {
          exports.__esModule = true;
        }
      }
      return function(id, v) {
        return exports[id] = previous ? previous(id, v) : v;
      };
    }
  })(function(exporter) {
    var extendStatics2 = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
      d.__proto__ = b;
    } || function(d, b) {
      for (var p in b)
        if (b.hasOwnProperty(p))
          d[p] = b[p];
    };
    __extends2 = function(d, b) {
      extendStatics2(d, b);
      function __() {
        this.constructor = d;
      }
      d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
    __assign2 = Object.assign || function(t) {
      for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s)
          if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
      }
      return t;
    };
    __rest = function(s, e) {
      var t = {};
      for (var p in s)
        if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
          t[p] = s[p];
      if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
          if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
            t[p[i]] = s[p[i]];
        }
      return t;
    };
    __decorate = function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function")
        r = Reflect.decorate(decorators, target, key, desc);
      else
        for (var i = decorators.length - 1; i >= 0; i--)
          if (d = decorators[i])
            r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    __param = function(paramIndex, decorator) {
      return function(target, key) {
        decorator(target, key, paramIndex);
      };
    };
    __metadata = function(metadataKey, metadataValue) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function")
        return Reflect.metadata(metadataKey, metadataValue);
    };
    __awaiter2 = function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    __generator2 = function(thisArg, body) {
      var _ = { label: 0, sent: function() {
        if (t[0] & 1)
          throw t[1];
        return t[1];
      }, trys: [], ops: [] }, f, y, t, g;
      return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
      }), g;
      function verb(n) {
        return function(v) {
          return step([n, v]);
        };
      }
      function step(op) {
        if (f)
          throw new TypeError("Generator is already executing.");
        while (_)
          try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
              return t;
            if (y = 0, t)
              op = [op[0] & 2, t.value];
            switch (op[0]) {
              case 0:
              case 1:
                t = op;
                break;
              case 4:
                _.label++;
                return { value: op[1], done: false };
              case 5:
                _.label++;
                y = op[1];
                op = [0];
                continue;
              case 7:
                op = _.ops.pop();
                _.trys.pop();
                continue;
              default:
                if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                  _ = 0;
                  continue;
                }
                if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                  _.label = op[1];
                  break;
                }
                if (op[0] === 6 && _.label < t[1]) {
                  _.label = t[1];
                  t = op;
                  break;
                }
                if (t && _.label < t[2]) {
                  _.label = t[2];
                  _.ops.push(op);
                  break;
                }
                if (t[2])
                  _.ops.pop();
                _.trys.pop();
                continue;
            }
            op = body.call(thisArg, _);
          } catch (e) {
            op = [6, e];
            y = 0;
          } finally {
            f = t = 0;
          }
        if (op[0] & 5)
          throw op[1];
        return { value: op[0] ? op[1] : void 0, done: true };
      }
    };
    __createBinding = function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    };
    __exportStar = function(m, exports) {
      for (var p in m)
        if (p !== "default" && !exports.hasOwnProperty(p))
          exports[p] = m[p];
    };
    __values2 = function(o) {
      var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
      if (m)
        return m.call(o);
      if (o && typeof o.length === "number")
        return {
          next: function() {
            if (o && i >= o.length)
              o = void 0;
            return { value: o && o[i++], done: !o };
          }
        };
      throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    };
    __read2 = function(o, n) {
      var m = typeof Symbol === "function" && o[Symbol.iterator];
      if (!m)
        return o;
      var i = m.call(o), r, ar = [], e;
      try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
          ar.push(r.value);
      } catch (error) {
        e = { error };
      } finally {
        try {
          if (r && !r.done && (m = i["return"]))
            m.call(i);
        } finally {
          if (e)
            throw e.error;
        }
      }
      return ar;
    };
    __spread2 = function() {
      for (var ar = [], i = 0; i < arguments.length; i++)
        ar = ar.concat(__read2(arguments[i]));
      return ar;
    };
    __spreadArrays = function() {
      for (var s = 0, i = 0, il = arguments.length; i < il; i++)
        s += arguments[i].length;
      for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
          r[k] = a[j];
      return r;
    };
    __await = function(v) {
      return this instanceof __await ? (this.v = v, this) : new __await(v);
    };
    __asyncGenerator = function(thisArg, _arguments, generator) {
      if (!Symbol.asyncIterator)
        throw new TypeError("Symbol.asyncIterator is not defined.");
      var g = generator.apply(thisArg, _arguments || []), i, q = [];
      return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
        return this;
      }, i;
      function verb(n) {
        if (g[n])
          i[n] = function(v) {
            return new Promise(function(a, b) {
              q.push([n, v, a, b]) > 1 || resume(n, v);
            });
          };
      }
      function resume(n, v) {
        try {
          step(g[n](v));
        } catch (e) {
          settle(q[0][3], e);
        }
      }
      function step(r) {
        r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
      }
      function fulfill(value) {
        resume("next", value);
      }
      function reject(value) {
        resume("throw", value);
      }
      function settle(f, v) {
        if (f(v), q.shift(), q.length)
          resume(q[0][0], q[0][1]);
      }
    };
    __asyncDelegator = function(o) {
      var i, p;
      return i = {}, verb("next"), verb("throw", function(e) {
        throw e;
      }), verb("return"), i[Symbol.iterator] = function() {
        return this;
      }, i;
      function verb(n, f) {
        i[n] = o[n] ? function(v) {
          return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v;
        } : f;
      }
    };
    __asyncValues = function(o) {
      if (!Symbol.asyncIterator)
        throw new TypeError("Symbol.asyncIterator is not defined.");
      var m = o[Symbol.asyncIterator], i;
      return m ? m.call(o) : (o = typeof __values2 === "function" ? __values2(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
        return this;
      }, i);
      function verb(n) {
        i[n] = o[n] && function(v) {
          return new Promise(function(resolve, reject) {
            v = o[n](v), settle(resolve, reject, v.done, v.value);
          });
        };
      }
      function settle(resolve, reject, d, v) {
        Promise.resolve(v).then(function(v2) {
          resolve({ value: v2, done: d });
        }, reject);
      }
    };
    __makeTemplateObject = function(cooked, raw) {
      if (Object.defineProperty) {
        Object.defineProperty(cooked, "raw", { value: raw });
      } else {
        cooked.raw = raw;
      }
      return cooked;
    };
    __importStar = function(mod) {
      if (mod && mod.__esModule)
        return mod;
      var result = {};
      if (mod != null) {
        for (var k in mod)
          if (Object.hasOwnProperty.call(mod, k))
            result[k] = mod[k];
      }
      result["default"] = mod;
      return result;
    };
    __importDefault = function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    __classPrivateFieldGet = function(receiver, privateMap) {
      if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
      }
      return privateMap.get(receiver);
    };
    __classPrivateFieldSet = function(receiver, privateMap, value) {
      if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to set private field on non-instance");
      }
      privateMap.set(receiver, value);
      return value;
    };
    exporter("__extends", __extends2);
    exporter("__assign", __assign2);
    exporter("__rest", __rest);
    exporter("__decorate", __decorate);
    exporter("__param", __param);
    exporter("__metadata", __metadata);
    exporter("__awaiter", __awaiter2);
    exporter("__generator", __generator2);
    exporter("__exportStar", __exportStar);
    exporter("__createBinding", __createBinding);
    exporter("__values", __values2);
    exporter("__read", __read2);
    exporter("__spread", __spread2);
    exporter("__spreadArrays", __spreadArrays);
    exporter("__await", __await);
    exporter("__asyncGenerator", __asyncGenerator);
    exporter("__asyncDelegator", __asyncDelegator);
    exporter("__asyncValues", __asyncValues);
    exporter("__makeTemplateObject", __makeTemplateObject);
    exporter("__importStar", __importStar);
    exporter("__importDefault", __importDefault);
    exporter("__classPrivateFieldGet", __classPrivateFieldGet);
    exporter("__classPrivateFieldSet", __classPrivateFieldSet);
  });
})(tslib);
var SHORT_TO_HEX = {};
var HEX_TO_SHORT = {};
for (var i$2 = 0; i$2 < 256; i$2++) {
  var encodedByte = i$2.toString(16).toLowerCase();
  if (encodedByte.length === 1) {
    encodedByte = "0" + encodedByte;
  }
  SHORT_TO_HEX[i$2] = encodedByte;
  HEX_TO_SHORT[encodedByte] = i$2;
}
function fromHex(encoded) {
  if (encoded.length % 2 !== 0) {
    throw new Error("Hex encoded strings must have an even number length");
  }
  var out = new Uint8Array(encoded.length / 2);
  for (var i = 0; i < encoded.length; i += 2) {
    var encodedByte = encoded.substr(i, 2).toLowerCase();
    if (encodedByte in HEX_TO_SHORT) {
      out[i / 2] = HEX_TO_SHORT[encodedByte];
    } else {
      throw new Error("Cannot decode unrecognized sequence " + encodedByte + " as hexadecimal");
    }
  }
  return out;
}
function toHex(bytes) {
  var out = "";
  for (var i = 0; i < bytes.byteLength; i++) {
    out += SHORT_TO_HEX[bytes[i]];
  }
  return out;
}
var __extends$1 = globalThis && globalThis.__extends || function() {
  var extendStatics2 = function(d, b) {
    extendStatics2 = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2)
        if (b2.hasOwnProperty(p))
          d2[p] = b2[p];
    };
    return extendStatics2(d, b);
  };
  return function(d, b) {
    extendStatics2(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __awaiter$4 = globalThis && globalThis.__awaiter || function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator$4 = globalThis && globalThis.__generator || function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1)
      throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f)
      throw new TypeError("Generator is already executing.");
    while (_)
      try {
        if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
          return t;
        if (y = 0, t)
          op = [op[0] & 2, t.value];
        switch (op[0]) {
          case 0:
          case 1:
            t = op;
            break;
          case 4:
            _.label++;
            return { value: op[1], done: false };
          case 5:
            _.label++;
            y = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            if (t[2])
              _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e) {
        op = [6, e];
        y = 0;
      } finally {
        f = t = 0;
      }
    if (op[0] & 5)
      throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
var __read$1 = globalThis && globalThis.__read || function(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m)
    return o;
  var i = m.call(o), r, ar = [], e;
  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
      ar.push(r.value);
  } catch (error) {
    e = { error };
  } finally {
    try {
      if (r && !r.done && (m = i["return"]))
        m.call(i);
    } finally {
      if (e)
        throw e.error;
    }
  }
  return ar;
};
var __spread = globalThis && globalThis.__spread || function() {
  for (var ar = [], i = 0; i < arguments.length; i++)
    ar = ar.concat(__read$1(arguments[i]));
  return ar;
};
var logger$4 = new ConsoleLogger("Util");
var NonRetryableError = function(_super) {
  __extends$1(NonRetryableError2, _super);
  function NonRetryableError2(message) {
    var _this = _super.call(this, message) || this;
    _this.nonRetryable = true;
    return _this;
  }
  return NonRetryableError2;
}(Error);
var isNonRetryableError = function(obj) {
  var key = "nonRetryable";
  return obj && obj[key];
};
function retry(functionToRetry, args, delayFn, attempt) {
  if (attempt === void 0) {
    attempt = 1;
  }
  return __awaiter$4(this, void 0, void 0, function() {
    var err_1, retryIn_1;
    return __generator$4(this, function(_a) {
      switch (_a.label) {
        case 0:
          if (typeof functionToRetry !== "function") {
            throw Error("functionToRetry must be a function");
          }
          logger$4.debug(functionToRetry.name + " attempt #" + attempt + " with this vars: " + JSON.stringify(args));
          _a.label = 1;
        case 1:
          _a.trys.push([1, 3, , 8]);
          return [4, functionToRetry.apply(void 0, __spread(args))];
        case 2:
          return [2, _a.sent()];
        case 3:
          err_1 = _a.sent();
          logger$4.debug("error on " + functionToRetry.name, err_1);
          if (isNonRetryableError(err_1)) {
            logger$4.debug(functionToRetry.name + " non retryable error", err_1);
            throw err_1;
          }
          retryIn_1 = delayFn(attempt, args, err_1);
          logger$4.debug(functionToRetry.name + " retrying in " + retryIn_1 + " ms");
          if (!(retryIn_1 !== false))
            return [3, 6];
          return [4, new Promise(function(res) {
            return setTimeout(res, retryIn_1);
          })];
        case 4:
          _a.sent();
          return [4, retry(functionToRetry, args, delayFn, attempt + 1)];
        case 5:
          return [2, _a.sent()];
        case 6:
          throw err_1;
        case 7:
          return [3, 8];
        case 8:
          return [2];
      }
    });
  });
}
var MAX_DELAY_MS = 5 * 60 * 1e3;
function jitteredBackoff(maxDelayMs) {
  var BASE_TIME_MS = 100;
  var JITTER_FACTOR = 100;
  return function(attempt) {
    var delay = Math.pow(2, attempt) * BASE_TIME_MS + JITTER_FACTOR * Math.random();
    return delay > maxDelayMs ? false : delay;
  };
}
var jitteredExponentialRetry = function(functionToRetry, args, maxDelayMs) {
  if (maxDelayMs === void 0) {
    maxDelayMs = MAX_DELAY_MS;
  }
  return retry(functionToRetry, args, jitteredBackoff(maxDelayMs));
};
var __assign$2 = globalThis && globalThis.__assign || function() {
  __assign$2 = Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s)
        if (Object.prototype.hasOwnProperty.call(s, p))
          t[p] = s[p];
    }
    return t;
  };
  return __assign$2.apply(this, arguments);
};
var logger$3 = new ConsoleLogger("Parser");
var parseMobileHubConfig = function(config) {
  var amplifyConfig = {};
  if (config["aws_mobile_analytics_app_id"]) {
    var Analytics = {
      AWSPinpoint: {
        appId: config["aws_mobile_analytics_app_id"],
        region: config["aws_mobile_analytics_app_region"]
      }
    };
    amplifyConfig.Analytics = Analytics;
  }
  if (config["aws_cognito_identity_pool_id"] || config["aws_user_pools_id"]) {
    amplifyConfig.Auth = {
      userPoolId: config["aws_user_pools_id"],
      userPoolWebClientId: config["aws_user_pools_web_client_id"],
      region: config["aws_cognito_region"],
      identityPoolId: config["aws_cognito_identity_pool_id"],
      identityPoolRegion: config["aws_cognito_region"],
      mandatorySignIn: config["aws_mandatory_sign_in"] === "enable"
    };
  }
  var storageConfig;
  if (config["aws_user_files_s3_bucket"]) {
    storageConfig = {
      AWSS3: {
        bucket: config["aws_user_files_s3_bucket"],
        region: config["aws_user_files_s3_bucket_region"],
        dangerouslyConnectToHttpEndpointForTesting: config["aws_user_files_s3_dangerously_connect_to_http_endpoint_for_testing"]
      }
    };
  } else {
    storageConfig = config ? config.Storage || config : {};
  }
  if (config["Logging"]) {
    amplifyConfig.Logging = __assign$2(__assign$2({}, config["Logging"]), { region: config["aws_project_region"] });
  }
  amplifyConfig.Analytics = Object.assign({}, amplifyConfig.Analytics, config.Analytics);
  amplifyConfig.Auth = Object.assign({}, amplifyConfig.Auth, config.Auth);
  amplifyConfig.Storage = Object.assign({}, storageConfig);
  amplifyConfig.Logging = Object.assign({}, amplifyConfig.Logging, config.Logging);
  logger$3.debug("parse config", config, "to amplifyconfig", amplifyConfig);
  return amplifyConfig;
};
var Parser$1 = function() {
  function Parser2() {
  }
  Parser2.parseMobilehubConfig = parseMobileHubConfig;
  return Parser2;
}();
var build$4 = {};
var crossPlatformSha256 = {};
var ie11Sha256 = {};
var isEmptyData$3 = {};
Object.defineProperty(isEmptyData$3, "__esModule", { value: true });
isEmptyData$3.isEmptyData = void 0;
function isEmptyData$2(data) {
  if (typeof data === "string") {
    return data.length === 0;
  }
  return data.byteLength === 0;
}
isEmptyData$3.isEmptyData = isEmptyData$2;
var constants$1 = {};
(function(exports) {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.EMPTY_DATA_SHA_256 = exports.SHA_256_HMAC_ALGO = exports.SHA_256_HASH = void 0;
  exports.SHA_256_HASH = { name: "SHA-256" };
  exports.SHA_256_HMAC_ALGO = {
    name: "HMAC",
    hash: exports.SHA_256_HASH
  };
  exports.EMPTY_DATA_SHA_256 = new Uint8Array([
    227,
    176,
    196,
    66,
    152,
    252,
    28,
    20,
    154,
    251,
    244,
    200,
    153,
    111,
    185,
    36,
    39,
    174,
    65,
    228,
    100,
    155,
    147,
    76,
    164,
    149,
    153,
    27,
    120,
    82,
    184,
    85
  ]);
})(constants$1);
var fromUtf8$3 = function(input) {
  var bytes = [];
  for (var i = 0, len = input.length; i < len; i++) {
    var value = input.charCodeAt(i);
    if (value < 128) {
      bytes.push(value);
    } else if (value < 2048) {
      bytes.push(value >> 6 | 192, value & 63 | 128);
    } else if (i + 1 < input.length && (value & 64512) === 55296 && (input.charCodeAt(i + 1) & 64512) === 56320) {
      var surrogatePair = 65536 + ((value & 1023) << 10) + (input.charCodeAt(++i) & 1023);
      bytes.push(surrogatePair >> 18 | 240, surrogatePair >> 12 & 63 | 128, surrogatePair >> 6 & 63 | 128, surrogatePair & 63 | 128);
    } else {
      bytes.push(value >> 12 | 224, value >> 6 & 63 | 128, value & 63 | 128);
    }
  }
  return Uint8Array.from(bytes);
};
var toUtf8$2 = function(input) {
  var decoded = "";
  for (var i = 0, len = input.length; i < len; i++) {
    var byte = input[i];
    if (byte < 128) {
      decoded += String.fromCharCode(byte);
    } else if (192 <= byte && byte < 224) {
      var nextByte = input[++i];
      decoded += String.fromCharCode((byte & 31) << 6 | nextByte & 63);
    } else if (240 <= byte && byte < 365) {
      var surrogatePair = [byte, input[++i], input[++i], input[++i]];
      var encoded = "%" + surrogatePair.map(function(byteValue) {
        return byteValue.toString(16);
      }).join("%");
      decoded += decodeURIComponent(encoded);
    } else {
      decoded += String.fromCharCode((byte & 15) << 12 | (input[++i] & 63) << 6 | input[++i] & 63);
    }
  }
  return decoded;
};
function fromUtf8$2(input) {
  return new TextEncoder().encode(input);
}
function toUtf8$1(input) {
  return new TextDecoder("utf-8").decode(input);
}
var fromUtf8$1 = function(input) {
  return typeof TextEncoder === "function" ? fromUtf8$2(input) : fromUtf8$3(input);
};
var toUtf8 = function(input) {
  return typeof TextDecoder === "function" ? toUtf8$1(input) : toUtf8$2(input);
};
var es$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  fromUtf8: fromUtf8$1,
  toUtf8
}, Symbol.toStringTag, { value: "Module" }));
var require$$0 = /* @__PURE__ */ getAugmentedNamespace(es$1);
var fallbackWindow = {};
function locateWindow() {
  if (typeof window !== "undefined") {
    return window;
  } else if (typeof self !== "undefined") {
    return self;
  }
  return fallbackWindow;
}
var es = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  locateWindow
}, Symbol.toStringTag, { value: "Module" }));
var require$$5 = /* @__PURE__ */ getAugmentedNamespace(es);
Object.defineProperty(ie11Sha256, "__esModule", { value: true });
ie11Sha256.Sha256 = void 0;
var isEmptyData_1 = isEmptyData$3;
var constants_1$3 = constants$1;
var util_utf8_browser_1$1 = require$$0;
var util_locate_window_1$2 = require$$5;
var Sha256$3 = function() {
  function Sha2562(secret) {
    if (secret) {
      this.operation = getKeyPromise(secret).then(function(keyData) {
        return (0, util_locate_window_1$2.locateWindow)().msCrypto.subtle.sign(constants_1$3.SHA_256_HMAC_ALGO, keyData);
      });
      this.operation.catch(function() {
      });
    } else {
      this.operation = Promise.resolve((0, util_locate_window_1$2.locateWindow)().msCrypto.subtle.digest("SHA-256"));
    }
  }
  Sha2562.prototype.update = function(toHash) {
    var _this = this;
    if ((0, isEmptyData_1.isEmptyData)(toHash)) {
      return;
    }
    this.operation = this.operation.then(function(operation) {
      operation.onerror = function() {
        _this.operation = Promise.reject(new Error("Error encountered updating hash"));
      };
      operation.process(toArrayBufferView(toHash));
      return operation;
    });
    this.operation.catch(function() {
    });
  };
  Sha2562.prototype.digest = function() {
    return this.operation.then(function(operation) {
      return new Promise(function(resolve, reject) {
        operation.onerror = function() {
          reject(new Error("Error encountered finalizing hash"));
        };
        operation.oncomplete = function() {
          if (operation.result) {
            resolve(new Uint8Array(operation.result));
          }
          reject(new Error("Error encountered finalizing hash"));
        };
        operation.finish();
      });
    });
  };
  return Sha2562;
}();
ie11Sha256.Sha256 = Sha256$3;
function getKeyPromise(secret) {
  return new Promise(function(resolve, reject) {
    var keyOperation = (0, util_locate_window_1$2.locateWindow)().msCrypto.subtle.importKey("raw", toArrayBufferView(secret), constants_1$3.SHA_256_HMAC_ALGO, false, ["sign"]);
    keyOperation.oncomplete = function() {
      if (keyOperation.result) {
        resolve(keyOperation.result);
      }
      reject(new Error("ImportKey completed without importing key."));
    };
    keyOperation.onerror = function() {
      reject(new Error("ImportKey failed to import key."));
    };
  });
}
function toArrayBufferView(data) {
  if (typeof data === "string") {
    return (0, util_utf8_browser_1$1.fromUtf8)(data);
  }
  if (ArrayBuffer.isView(data)) {
    return new Uint8Array(data.buffer, data.byteOffset, data.byteLength / Uint8Array.BYTES_PER_ELEMENT);
  }
  return new Uint8Array(data);
}
var webCryptoSha256 = {};
var build$3 = {};
var convertToBuffer$1 = {};
Object.defineProperty(convertToBuffer$1, "__esModule", { value: true });
convertToBuffer$1.convertToBuffer = void 0;
var util_utf8_browser_1 = require$$0;
var fromUtf8 = typeof Buffer !== "undefined" && Buffer.from ? function(input) {
  return Buffer.from(input, "utf8");
} : util_utf8_browser_1.fromUtf8;
function convertToBuffer(data) {
  if (data instanceof Uint8Array)
    return data;
  if (typeof data === "string") {
    return fromUtf8(data);
  }
  if (ArrayBuffer.isView(data)) {
    return new Uint8Array(data.buffer, data.byteOffset, data.byteLength / Uint8Array.BYTES_PER_ELEMENT);
  }
  return new Uint8Array(data);
}
convertToBuffer$1.convertToBuffer = convertToBuffer;
var isEmptyData$1 = {};
Object.defineProperty(isEmptyData$1, "__esModule", { value: true });
isEmptyData$1.isEmptyData = void 0;
function isEmptyData(data) {
  if (typeof data === "string") {
    return data.length === 0;
  }
  return data.byteLength === 0;
}
isEmptyData$1.isEmptyData = isEmptyData;
var numToUint8$1 = {};
Object.defineProperty(numToUint8$1, "__esModule", { value: true });
numToUint8$1.numToUint8 = void 0;
function numToUint8(num) {
  return new Uint8Array([
    (num & 4278190080) >> 24,
    (num & 16711680) >> 16,
    (num & 65280) >> 8,
    num & 255
  ]);
}
numToUint8$1.numToUint8 = numToUint8;
(function(exports) {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.numToUint8 = exports.isEmptyData = exports.convertToBuffer = void 0;
  var convertToBuffer_1 = convertToBuffer$1;
  Object.defineProperty(exports, "convertToBuffer", { enumerable: true, get: function() {
    return convertToBuffer_1.convertToBuffer;
  } });
  var isEmptyData_12 = isEmptyData$1;
  Object.defineProperty(exports, "isEmptyData", { enumerable: true, get: function() {
    return isEmptyData_12.isEmptyData;
  } });
  var numToUint8_1 = numToUint8$1;
  Object.defineProperty(exports, "numToUint8", { enumerable: true, get: function() {
    return numToUint8_1.numToUint8;
  } });
})(build$3);
Object.defineProperty(webCryptoSha256, "__esModule", { value: true });
webCryptoSha256.Sha256 = void 0;
var util_1$1 = build$3;
var constants_1$2 = constants$1;
var util_locate_window_1$1 = require$$5;
var Sha256$2 = function() {
  function Sha2562(secret) {
    this.toHash = new Uint8Array(0);
    if (secret !== void 0) {
      this.key = new Promise(function(resolve, reject) {
        (0, util_locate_window_1$1.locateWindow)().crypto.subtle.importKey("raw", (0, util_1$1.convertToBuffer)(secret), constants_1$2.SHA_256_HMAC_ALGO, false, ["sign"]).then(resolve, reject);
      });
      this.key.catch(function() {
      });
    }
  }
  Sha2562.prototype.update = function(data) {
    if ((0, util_1$1.isEmptyData)(data)) {
      return;
    }
    var update = (0, util_1$1.convertToBuffer)(data);
    var typedArray = new Uint8Array(this.toHash.byteLength + update.byteLength);
    typedArray.set(this.toHash, 0);
    typedArray.set(update, this.toHash.byteLength);
    this.toHash = typedArray;
  };
  Sha2562.prototype.digest = function() {
    var _this = this;
    if (this.key) {
      return this.key.then(function(key) {
        return (0, util_locate_window_1$1.locateWindow)().crypto.subtle.sign(constants_1$2.SHA_256_HMAC_ALGO, key, _this.toHash).then(function(data) {
          return new Uint8Array(data);
        });
      });
    }
    if ((0, util_1$1.isEmptyData)(this.toHash)) {
      return Promise.resolve(constants_1$2.EMPTY_DATA_SHA_256);
    }
    return Promise.resolve().then(function() {
      return (0, util_locate_window_1$1.locateWindow)().crypto.subtle.digest(constants_1$2.SHA_256_HASH, _this.toHash);
    }).then(function(data) {
      return Promise.resolve(new Uint8Array(data));
    });
  };
  return Sha2562;
}();
webCryptoSha256.Sha256 = Sha256$2;
var build$2 = {};
var jsSha256 = {};
var constants = {};
Object.defineProperty(constants, "__esModule", { value: true });
constants.MAX_HASHABLE_LENGTH = constants.INIT = constants.KEY = constants.DIGEST_LENGTH = constants.BLOCK_SIZE = void 0;
constants.BLOCK_SIZE = 64;
constants.DIGEST_LENGTH = 32;
constants.KEY = new Uint32Array([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);
constants.INIT = [
  1779033703,
  3144134277,
  1013904242,
  2773480762,
  1359893119,
  2600822924,
  528734635,
  1541459225
];
constants.MAX_HASHABLE_LENGTH = Math.pow(2, 53) - 1;
var RawSha256$1 = {};
Object.defineProperty(RawSha256$1, "__esModule", { value: true });
RawSha256$1.RawSha256 = void 0;
var constants_1$1 = constants;
var RawSha256 = function() {
  function RawSha2562() {
    this.state = Int32Array.from(constants_1$1.INIT);
    this.temp = new Int32Array(64);
    this.buffer = new Uint8Array(64);
    this.bufferLength = 0;
    this.bytesHashed = 0;
    this.finished = false;
  }
  RawSha2562.prototype.update = function(data) {
    if (this.finished) {
      throw new Error("Attempted to update an already finished hash.");
    }
    var position = 0;
    var byteLength = data.byteLength;
    this.bytesHashed += byteLength;
    if (this.bytesHashed * 8 > constants_1$1.MAX_HASHABLE_LENGTH) {
      throw new Error("Cannot hash more than 2^53 - 1 bits");
    }
    while (byteLength > 0) {
      this.buffer[this.bufferLength++] = data[position++];
      byteLength--;
      if (this.bufferLength === constants_1$1.BLOCK_SIZE) {
        this.hashBuffer();
        this.bufferLength = 0;
      }
    }
  };
  RawSha2562.prototype.digest = function() {
    if (!this.finished) {
      var bitsHashed = this.bytesHashed * 8;
      var bufferView = new DataView(this.buffer.buffer, this.buffer.byteOffset, this.buffer.byteLength);
      var undecoratedLength = this.bufferLength;
      bufferView.setUint8(this.bufferLength++, 128);
      if (undecoratedLength % constants_1$1.BLOCK_SIZE >= constants_1$1.BLOCK_SIZE - 8) {
        for (var i = this.bufferLength; i < constants_1$1.BLOCK_SIZE; i++) {
          bufferView.setUint8(i, 0);
        }
        this.hashBuffer();
        this.bufferLength = 0;
      }
      for (var i = this.bufferLength; i < constants_1$1.BLOCK_SIZE - 8; i++) {
        bufferView.setUint8(i, 0);
      }
      bufferView.setUint32(constants_1$1.BLOCK_SIZE - 8, Math.floor(bitsHashed / 4294967296), true);
      bufferView.setUint32(constants_1$1.BLOCK_SIZE - 4, bitsHashed);
      this.hashBuffer();
      this.finished = true;
    }
    var out = new Uint8Array(constants_1$1.DIGEST_LENGTH);
    for (var i = 0; i < 8; i++) {
      out[i * 4] = this.state[i] >>> 24 & 255;
      out[i * 4 + 1] = this.state[i] >>> 16 & 255;
      out[i * 4 + 2] = this.state[i] >>> 8 & 255;
      out[i * 4 + 3] = this.state[i] >>> 0 & 255;
    }
    return out;
  };
  RawSha2562.prototype.hashBuffer = function() {
    var _a = this, buffer = _a.buffer, state = _a.state;
    var state0 = state[0], state1 = state[1], state2 = state[2], state3 = state[3], state4 = state[4], state5 = state[5], state6 = state[6], state7 = state[7];
    for (var i = 0; i < constants_1$1.BLOCK_SIZE; i++) {
      if (i < 16) {
        this.temp[i] = (buffer[i * 4] & 255) << 24 | (buffer[i * 4 + 1] & 255) << 16 | (buffer[i * 4 + 2] & 255) << 8 | buffer[i * 4 + 3] & 255;
      } else {
        var u = this.temp[i - 2];
        var t1_1 = (u >>> 17 | u << 15) ^ (u >>> 19 | u << 13) ^ u >>> 10;
        u = this.temp[i - 15];
        var t2_1 = (u >>> 7 | u << 25) ^ (u >>> 18 | u << 14) ^ u >>> 3;
        this.temp[i] = (t1_1 + this.temp[i - 7] | 0) + (t2_1 + this.temp[i - 16] | 0);
      }
      var t1 = (((state4 >>> 6 | state4 << 26) ^ (state4 >>> 11 | state4 << 21) ^ (state4 >>> 25 | state4 << 7)) + (state4 & state5 ^ ~state4 & state6) | 0) + (state7 + (constants_1$1.KEY[i] + this.temp[i] | 0) | 0) | 0;
      var t2 = ((state0 >>> 2 | state0 << 30) ^ (state0 >>> 13 | state0 << 19) ^ (state0 >>> 22 | state0 << 10)) + (state0 & state1 ^ state0 & state2 ^ state1 & state2) | 0;
      state7 = state6;
      state6 = state5;
      state5 = state4;
      state4 = state3 + t1 | 0;
      state3 = state2;
      state2 = state1;
      state1 = state0;
      state0 = t1 + t2 | 0;
    }
    state[0] += state0;
    state[1] += state1;
    state[2] += state2;
    state[3] += state3;
    state[4] += state4;
    state[5] += state5;
    state[6] += state6;
    state[7] += state7;
  };
  return RawSha2562;
}();
RawSha256$1.RawSha256 = RawSha256;
Object.defineProperty(jsSha256, "__esModule", { value: true });
jsSha256.Sha256 = void 0;
var tslib_1$1 = tslib.exports;
var constants_1 = constants;
var RawSha256_1 = RawSha256$1;
var util_1 = build$3;
var Sha256$1 = function() {
  function Sha2562(secret) {
    this.hash = new RawSha256_1.RawSha256();
    if (secret) {
      this.outer = new RawSha256_1.RawSha256();
      var inner = bufferFromSecret(secret);
      var outer = new Uint8Array(constants_1.BLOCK_SIZE);
      outer.set(inner);
      for (var i = 0; i < constants_1.BLOCK_SIZE; i++) {
        inner[i] ^= 54;
        outer[i] ^= 92;
      }
      this.hash.update(inner);
      this.outer.update(outer);
      for (var i = 0; i < inner.byteLength; i++) {
        inner[i] = 0;
      }
    }
  }
  Sha2562.prototype.update = function(toHash) {
    if ((0, util_1.isEmptyData)(toHash) || this.error) {
      return;
    }
    try {
      this.hash.update((0, util_1.convertToBuffer)(toHash));
    } catch (e) {
      this.error = e;
    }
  };
  Sha2562.prototype.digestSync = function() {
    if (this.error) {
      throw this.error;
    }
    if (this.outer) {
      if (!this.outer.finished) {
        this.outer.update(this.hash.digest());
      }
      return this.outer.digest();
    }
    return this.hash.digest();
  };
  Sha2562.prototype.digest = function() {
    return (0, tslib_1$1.__awaiter)(this, void 0, void 0, function() {
      return (0, tslib_1$1.__generator)(this, function(_a) {
        return [2, this.digestSync()];
      });
    });
  };
  return Sha2562;
}();
jsSha256.Sha256 = Sha256$1;
function bufferFromSecret(secret) {
  var input = (0, util_1.convertToBuffer)(secret);
  if (input.byteLength > constants_1.BLOCK_SIZE) {
    var bufferHash = new RawSha256_1.RawSha256();
    bufferHash.update(input);
    input = bufferHash.digest();
  }
  var buffer = new Uint8Array(constants_1.BLOCK_SIZE);
  buffer.set(input);
  return buffer;
}
(function(exports) {
  Object.defineProperty(exports, "__esModule", { value: true });
  var tslib_12 = tslib.exports;
  (0, tslib_12.__exportStar)(jsSha256, exports);
})(build$2);
var build$1 = {};
var supportsWebCrypto$1 = {};
Object.defineProperty(supportsWebCrypto$1, "__esModule", { value: true });
supportsWebCrypto$1.supportsZeroByteGCM = supportsWebCrypto$1.supportsSubtleCrypto = supportsWebCrypto$1.supportsSecureRandom = supportsWebCrypto$1.supportsWebCrypto = void 0;
var tslib_1 = tslib.exports;
var subtleCryptoMethods = [
  "decrypt",
  "digest",
  "encrypt",
  "exportKey",
  "generateKey",
  "importKey",
  "sign",
  "verify"
];
function supportsWebCrypto(window2) {
  if (supportsSecureRandom(window2) && typeof window2.crypto.subtle === "object") {
    var subtle = window2.crypto.subtle;
    return supportsSubtleCrypto(subtle);
  }
  return false;
}
supportsWebCrypto$1.supportsWebCrypto = supportsWebCrypto;
function supportsSecureRandom(window2) {
  if (typeof window2 === "object" && typeof window2.crypto === "object") {
    var getRandomValues2 = window2.crypto.getRandomValues;
    return typeof getRandomValues2 === "function";
  }
  return false;
}
supportsWebCrypto$1.supportsSecureRandom = supportsSecureRandom;
function supportsSubtleCrypto(subtle) {
  return subtle && subtleCryptoMethods.every(function(methodName) {
    return typeof subtle[methodName] === "function";
  });
}
supportsWebCrypto$1.supportsSubtleCrypto = supportsSubtleCrypto;
function supportsZeroByteGCM(subtle) {
  return tslib_1.__awaiter(this, void 0, void 0, function() {
    var key, zeroByteAuthTag;
    return tslib_1.__generator(this, function(_b) {
      switch (_b.label) {
        case 0:
          if (!supportsSubtleCrypto(subtle))
            return [2, false];
          _b.label = 1;
        case 1:
          _b.trys.push([1, 4, , 5]);
          return [4, subtle.generateKey({ name: "AES-GCM", length: 128 }, false, ["encrypt"])];
        case 2:
          key = _b.sent();
          return [4, subtle.encrypt({
            name: "AES-GCM",
            iv: new Uint8Array(Array(12)),
            additionalData: new Uint8Array(Array(16)),
            tagLength: 128
          }, key, new Uint8Array(0))];
        case 3:
          zeroByteAuthTag = _b.sent();
          return [2, zeroByteAuthTag.byteLength === 16];
        case 4:
          _b.sent();
          return [2, false];
        case 5:
          return [2];
      }
    });
  });
}
supportsWebCrypto$1.supportsZeroByteGCM = supportsZeroByteGCM;
(function(exports) {
  Object.defineProperty(exports, "__esModule", { value: true });
  var tslib_12 = tslib.exports;
  tslib_12.__exportStar(supportsWebCrypto$1, exports);
})(build$1);
var build = {};
var CryptoOperation = {};
Object.defineProperty(CryptoOperation, "__esModule", { value: true });
var Key = {};
Object.defineProperty(Key, "__esModule", { value: true });
var KeyOperation = {};
Object.defineProperty(KeyOperation, "__esModule", { value: true });
var MsSubtleCrypto = {};
Object.defineProperty(MsSubtleCrypto, "__esModule", { value: true });
var MsWindow = {};
Object.defineProperty(MsWindow, "__esModule", { value: true });
MsWindow.isMsWindow = void 0;
var msSubtleCryptoMethods = [
  "decrypt",
  "digest",
  "encrypt",
  "exportKey",
  "generateKey",
  "importKey",
  "sign",
  "verify"
];
function quacksLikeAnMsWindow(window2) {
  return "MSInputMethodContext" in window2 && "msCrypto" in window2;
}
function isMsWindow(window2) {
  if (quacksLikeAnMsWindow(window2) && window2.msCrypto.subtle !== void 0) {
    var _a = window2.msCrypto, getRandomValues2 = _a.getRandomValues, subtle_1 = _a.subtle;
    return msSubtleCryptoMethods.map(function(methodName) {
      return subtle_1[methodName];
    }).concat(getRandomValues2).every(function(method) {
      return typeof method === "function";
    });
  }
  return false;
}
MsWindow.isMsWindow = isMsWindow;
(function(exports) {
  Object.defineProperty(exports, "__esModule", { value: true });
  var tslib_12 = tslib.exports;
  tslib_12.__exportStar(CryptoOperation, exports);
  tslib_12.__exportStar(Key, exports);
  tslib_12.__exportStar(KeyOperation, exports);
  tslib_12.__exportStar(MsSubtleCrypto, exports);
  tslib_12.__exportStar(MsWindow, exports);
})(build);
Object.defineProperty(crossPlatformSha256, "__esModule", { value: true });
crossPlatformSha256.Sha256 = void 0;
var ie11Sha256_1 = ie11Sha256;
var webCryptoSha256_1 = webCryptoSha256;
var sha256_js_1 = build$2;
var supports_web_crypto_1 = build$1;
var ie11_detection_1 = build;
var util_locate_window_1 = require$$5;
var Sha256 = function() {
  function Sha2562(secret) {
    if ((0, supports_web_crypto_1.supportsWebCrypto)((0, util_locate_window_1.locateWindow)())) {
      this.hash = new webCryptoSha256_1.Sha256(secret);
    } else if ((0, ie11_detection_1.isMsWindow)((0, util_locate_window_1.locateWindow)())) {
      this.hash = new ie11Sha256_1.Sha256(secret);
    } else {
      this.hash = new sha256_js_1.Sha256(secret);
    }
  }
  Sha2562.prototype.update = function(data, encoding) {
    this.hash.update(data, encoding);
  };
  Sha2562.prototype.digest = function() {
    return this.hash.digest();
  };
  return Sha2562;
}();
crossPlatformSha256.Sha256 = Sha256;
(function(exports) {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.WebCryptoSha256 = exports.Ie11Sha256 = void 0;
  var tslib_12 = tslib.exports;
  (0, tslib_12.__exportStar)(crossPlatformSha256, exports);
  var ie11Sha256_12 = ie11Sha256;
  Object.defineProperty(exports, "Ie11Sha256", { enumerable: true, get: function() {
    return ie11Sha256_12.Sha256;
  } });
  var webCryptoSha256_12 = webCryptoSha256;
  Object.defineProperty(exports, "WebCryptoSha256", { enumerable: true, get: function() {
    return webCryptoSha256_12.Sha256;
  } });
})(build$4);
var HttpResponse = function() {
  function HttpResponse2(options) {
    this.statusCode = options.statusCode;
    this.headers = options.headers || {};
    this.body = options.body;
  }
  HttpResponse2.isInstance = function(response) {
    if (!response)
      return false;
    var resp = response;
    return typeof resp.statusCode === "number" && typeof resp.headers === "object";
  };
  return HttpResponse2;
}();
var HttpRequest = function() {
  function HttpRequest2(options) {
    this.method = options.method || "GET";
    this.hostname = options.hostname || "localhost";
    this.port = options.port;
    this.query = options.query || {};
    this.headers = options.headers || {};
    this.body = options.body;
    this.protocol = options.protocol ? options.protocol.substr(-1) !== ":" ? options.protocol + ":" : options.protocol : "https:";
    this.path = options.path ? options.path.charAt(0) !== "/" ? "/" + options.path : options.path : "/";
  }
  HttpRequest2.isInstance = function(request) {
    if (!request)
      return false;
    var req = request;
    return "method" in req && "protocol" in req && "hostname" in req && "path" in req && typeof req["query"] === "object" && typeof req["headers"] === "object";
  };
  HttpRequest2.prototype.clone = function() {
    var cloned = new HttpRequest2(tslib.exports.__assign(tslib.exports.__assign({}, this), { headers: tslib.exports.__assign({}, this.headers) }));
    if (cloned.query)
      cloned.query = cloneQuery$1(cloned.query);
    return cloned;
  };
  return HttpRequest2;
}();
function cloneQuery$1(query) {
  return Object.keys(query).reduce(function(carry, paramName) {
    var _a;
    var param = query[paramName];
    return tslib.exports.__assign(tslib.exports.__assign({}, carry), (_a = {}, _a[paramName] = Array.isArray(param) ? tslib.exports.__spread(param) : param, _a));
  }, {});
}
var escapeUri = function(uri) {
  return encodeURIComponent(uri).replace(/[!'()*]/g, hexEncode);
};
var hexEncode = function(c) {
  return "%" + c.charCodeAt(0).toString(16).toUpperCase();
};
function buildQueryString(query) {
  var e_1, _a;
  var parts = [];
  try {
    for (var _b = tslib.exports.__values(Object.keys(query).sort()), _c = _b.next(); !_c.done; _c = _b.next()) {
      var key = _c.value;
      var value = query[key];
      key = escapeUri(key);
      if (Array.isArray(value)) {
        for (var i = 0, iLen = value.length; i < iLen; i++) {
          parts.push(key + "=" + escapeUri(value[i]));
        }
      } else {
        var qsEntry = key;
        if (value || typeof value === "string") {
          qsEntry += "=" + escapeUri(value);
        }
        parts.push(qsEntry);
      }
    }
  } catch (e_1_1) {
    e_1 = { error: e_1_1 };
  } finally {
    try {
      if (_c && !_c.done && (_a = _b.return))
        _a.call(_b);
    } finally {
      if (e_1)
        throw e_1.error;
    }
  }
  return parts.join("&");
}
function requestTimeout(timeoutInMs) {
  if (timeoutInMs === void 0) {
    timeoutInMs = 0;
  }
  return new Promise(function(resolve, reject) {
    if (timeoutInMs) {
      setTimeout(function() {
        var timeoutError = new Error("Request did not complete within " + timeoutInMs + " ms");
        timeoutError.name = "TimeoutError";
        reject(timeoutError);
      }, timeoutInMs);
    }
  });
}
var FetchHttpHandler = function() {
  function FetchHttpHandler2(_a) {
    var _b = _a === void 0 ? {} : _a, requestTimeout2 = _b.requestTimeout;
    this.requestTimeout = requestTimeout2;
  }
  FetchHttpHandler2.prototype.destroy = function() {
  };
  FetchHttpHandler2.prototype.handle = function(request, _a) {
    var _b = _a === void 0 ? {} : _a, abortSignal = _b.abortSignal;
    var requestTimeoutInMs = this.requestTimeout;
    if (abortSignal === null || abortSignal === void 0 ? void 0 : abortSignal.aborted) {
      var abortError = new Error("Request aborted");
      abortError.name = "AbortError";
      return Promise.reject(abortError);
    }
    var path = request.path;
    if (request.query) {
      var queryString = buildQueryString(request.query);
      if (queryString) {
        path += "?" + queryString;
      }
    }
    var port = request.port, method = request.method;
    var url = request.protocol + "//" + request.hostname + (port ? ":" + port : "") + path;
    var body = method === "GET" || method === "HEAD" ? void 0 : request.body;
    var requestOptions = {
      body,
      headers: new Headers(request.headers),
      method
    };
    if (typeof AbortController !== "undefined") {
      requestOptions["signal"] = abortSignal;
    }
    var fetchRequest = new Request(url, requestOptions);
    var raceOfPromises = [
      fetch(fetchRequest).then(function(response) {
        var e_1, _a2;
        var fetchHeaders = response.headers;
        var transformedHeaders = {};
        try {
          for (var _b2 = tslib.exports.__values(fetchHeaders.entries()), _c = _b2.next(); !_c.done; _c = _b2.next()) {
            var pair = _c.value;
            transformedHeaders[pair[0]] = pair[1];
          }
        } catch (e_1_1) {
          e_1 = { error: e_1_1 };
        } finally {
          try {
            if (_c && !_c.done && (_a2 = _b2.return))
              _a2.call(_b2);
          } finally {
            if (e_1)
              throw e_1.error;
          }
        }
        var hasReadableStream = response.body !== void 0;
        if (!hasReadableStream) {
          return response.blob().then(function(body2) {
            return {
              response: new HttpResponse({
                headers: transformedHeaders,
                statusCode: response.status,
                body: body2
              })
            };
          });
        }
        return {
          response: new HttpResponse({
            headers: transformedHeaders,
            statusCode: response.status,
            body: response.body
          })
        };
      }),
      requestTimeout(requestTimeoutInMs)
    ];
    if (abortSignal) {
      raceOfPromises.push(new Promise(function(resolve, reject) {
        abortSignal.onabort = function() {
          var abortError2 = new Error("Request aborted");
          abortError2.name = "AbortError";
          reject(abortError2);
        };
      }));
    }
    return Promise.race(raceOfPromises);
  };
  return FetchHttpHandler2;
}();
var alphabetByEncoding = {};
var alphabetByValue = new Array(64);
for (var i$1 = 0, start = "A".charCodeAt(0), limit = "Z".charCodeAt(0); i$1 + start <= limit; i$1++) {
  var char = String.fromCharCode(i$1 + start);
  alphabetByEncoding[char] = i$1;
  alphabetByValue[i$1] = char;
}
for (var i$1 = 0, start = "a".charCodeAt(0), limit = "z".charCodeAt(0); i$1 + start <= limit; i$1++) {
  var char = String.fromCharCode(i$1 + start);
  var index = i$1 + 26;
  alphabetByEncoding[char] = index;
  alphabetByValue[index] = char;
}
for (var i$1 = 0; i$1 < 10; i$1++) {
  alphabetByEncoding[i$1.toString(10)] = i$1 + 52;
  var char = i$1.toString(10);
  var index = i$1 + 52;
  alphabetByEncoding[char] = index;
  alphabetByValue[index] = char;
}
alphabetByEncoding["+"] = 62;
alphabetByValue[62] = "+";
alphabetByEncoding["/"] = 63;
alphabetByValue[63] = "/";
var bitsPerLetter = 6;
var bitsPerByte = 8;
var maxLetterValue = 63;
function fromBase64(input) {
  var totalByteLength = input.length / 4 * 3;
  if (input.substr(-2) === "==") {
    totalByteLength -= 2;
  } else if (input.substr(-1) === "=") {
    totalByteLength--;
  }
  var out = new ArrayBuffer(totalByteLength);
  var dataView = new DataView(out);
  for (var i = 0; i < input.length; i += 4) {
    var bits = 0;
    var bitLength = 0;
    for (var j = i, limit = i + 3; j <= limit; j++) {
      if (input[j] !== "=") {
        bits |= alphabetByEncoding[input[j]] << (limit - j) * bitsPerLetter;
        bitLength += bitsPerLetter;
      } else {
        bits >>= bitsPerLetter;
      }
    }
    var chunkOffset = i / 4 * 3;
    bits >>= bitLength % bitsPerByte;
    var byteLength = Math.floor(bitLength / bitsPerByte);
    for (var k = 0; k < byteLength; k++) {
      var offset = (byteLength - k - 1) * bitsPerByte;
      dataView.setUint8(chunkOffset + k, (bits & 255 << offset) >> offset);
    }
  }
  return new Uint8Array(out);
}
function toBase64(input) {
  var str = "";
  for (var i = 0; i < input.length; i += 3) {
    var bits = 0;
    var bitLength = 0;
    for (var j = i, limit = Math.min(i + 3, input.length); j < limit; j++) {
      bits |= input[j] << (limit - j - 1) * bitsPerByte;
      bitLength += bitsPerByte;
    }
    var bitClusterCount = Math.ceil(bitLength / bitsPerLetter);
    bits <<= bitClusterCount * bitsPerLetter - bitLength;
    for (var k = 1; k <= bitClusterCount; k++) {
      var offset = (bitClusterCount - k) * bitsPerLetter;
      str += alphabetByValue[(bits & maxLetterValue << offset) >> offset];
    }
    str += "==".slice(0, 4 - bitClusterCount);
  }
  return str;
}
var streamCollector = function(stream) {
  if (typeof Blob === "function" && stream instanceof Blob) {
    return collectBlob(stream);
  }
  return collectStream(stream);
};
function collectBlob(blob) {
  return tslib.exports.__awaiter(this, void 0, void 0, function() {
    var base64, arrayBuffer;
    return tslib.exports.__generator(this, function(_a) {
      switch (_a.label) {
        case 0:
          return [4, readToBase64(blob)];
        case 1:
          base64 = _a.sent();
          arrayBuffer = fromBase64(base64);
          return [2, new Uint8Array(arrayBuffer)];
      }
    });
  });
}
function collectStream(stream) {
  return tslib.exports.__awaiter(this, void 0, void 0, function() {
    var res, reader, isDone, _a, done, value, prior;
    return tslib.exports.__generator(this, function(_b) {
      switch (_b.label) {
        case 0:
          res = new Uint8Array(0);
          reader = stream.getReader();
          isDone = false;
          _b.label = 1;
        case 1:
          if (!!isDone)
            return [3, 3];
          return [4, reader.read()];
        case 2:
          _a = _b.sent(), done = _a.done, value = _a.value;
          if (value) {
            prior = res;
            res = new Uint8Array(prior.length + value.length);
            res.set(prior);
            res.set(value, prior.length);
          }
          isDone = done;
          return [3, 1];
        case 3:
          return [2, res];
      }
    });
  });
}
function readToBase64(blob) {
  return new Promise(function(resolve, reject) {
    var reader = new FileReader();
    reader.onloadend = function() {
      var _a;
      if (reader.readyState !== 2) {
        return reject(new Error("Reader aborted too early"));
      }
      var result = (_a = reader.result) !== null && _a !== void 0 ? _a : "";
      var commaIndex = result.indexOf(",");
      var dataOffset = commaIndex > -1 ? commaIndex + 1 : result.length;
      resolve(result.substring(dataOffset));
    };
    reader.onabort = function() {
      return reject(new Error("Read aborted"));
    };
    reader.onerror = function() {
      return reject(reader.error);
    };
    reader.readAsDataURL(blob);
  });
}
var invalidProvider = function(message) {
  return function() {
    return Promise.reject(message);
  };
};
var retryMiddleware = function(options) {
  return function(next, context) {
    return function(args) {
      return tslib.exports.__awaiter(void 0, void 0, void 0, function() {
        var _a;
        return tslib.exports.__generator(this, function(_b) {
          if ((_a = options === null || options === void 0 ? void 0 : options.retryStrategy) === null || _a === void 0 ? void 0 : _a.mode)
            context.userAgent = tslib.exports.__spread(context.userAgent || [], [["cfg/retry-mode", options.retryStrategy.mode]]);
          return [2, options.retryStrategy.retry(next, args)];
        });
      });
    };
  };
};
var retryMiddlewareOptions = {
  name: "retryMiddleware",
  tags: ["RETRY"],
  step: "finalizeRequest",
  priority: "high",
  override: true
};
var getRetryPlugin = function(options) {
  return {
    applyToStack: function(clientStack) {
      clientStack.add(retryMiddleware(options), retryMiddlewareOptions);
    }
  };
};
var DEFAULT_RETRY_DELAY_BASE = 100;
var MAXIMUM_RETRY_DELAY = 20 * 1e3;
var THROTTLING_RETRY_DELAY_BASE = 500;
var INITIAL_RETRY_TOKENS = 500;
var RETRY_COST = 5;
var TIMEOUT_RETRY_COST = 10;
var NO_RETRY_INCREMENT = 1;
var INVOCATION_ID_HEADER = "amz-sdk-invocation-id";
var REQUEST_HEADER = "amz-sdk-request";
var CLOCK_SKEW_ERROR_CODES = [
  "AuthFailure",
  "InvalidSignatureException",
  "RequestExpired",
  "RequestInTheFuture",
  "RequestTimeTooSkewed",
  "SignatureDoesNotMatch"
];
var THROTTLING_ERROR_CODES = [
  "BandwidthLimitExceeded",
  "EC2ThrottledException",
  "LimitExceededException",
  "PriorRequestNotComplete",
  "ProvisionedThroughputExceededException",
  "RequestLimitExceeded",
  "RequestThrottled",
  "RequestThrottledException",
  "SlowDown",
  "ThrottledException",
  "Throttling",
  "ThrottlingException",
  "TooManyRequestsException",
  "TransactionInProgressException"
];
var TRANSIENT_ERROR_CODES = ["AbortError", "TimeoutError", "RequestTimeout", "RequestTimeoutException"];
var TRANSIENT_ERROR_STATUS_CODES = [500, 502, 503, 504];
var isRetryableByTrait = function(error) {
  return error.$retryable !== void 0;
};
var isClockSkewError = function(error) {
  return CLOCK_SKEW_ERROR_CODES.includes(error.name);
};
var isThrottlingError = function(error) {
  var _a, _b;
  return ((_a = error.$metadata) === null || _a === void 0 ? void 0 : _a.httpStatusCode) === 429 || THROTTLING_ERROR_CODES.includes(error.name) || ((_b = error.$retryable) === null || _b === void 0 ? void 0 : _b.throttling) == true;
};
var isTransientError = function(error) {
  var _a;
  return TRANSIENT_ERROR_CODES.includes(error.name) || TRANSIENT_ERROR_STATUS_CODES.includes(((_a = error.$metadata) === null || _a === void 0 ? void 0 : _a.httpStatusCode) || 0);
};
var rngBrowser = { exports: {} };
var getRandomValues = typeof crypto != "undefined" && crypto.getRandomValues && crypto.getRandomValues.bind(crypto) || typeof msCrypto != "undefined" && typeof window.msCrypto.getRandomValues == "function" && msCrypto.getRandomValues.bind(msCrypto);
if (getRandomValues) {
  var rnds8 = new Uint8Array(16);
  rngBrowser.exports = function whatwgRNG() {
    getRandomValues(rnds8);
    return rnds8;
  };
} else {
  var rnds = new Array(16);
  rngBrowser.exports = function mathRNG() {
    for (var i = 0, r; i < 16; i++) {
      if ((i & 3) === 0)
        r = Math.random() * 4294967296;
      rnds[i] = r >>> ((i & 3) << 3) & 255;
    }
    return rnds;
  };
}
var byteToHex = [];
for (var i = 0; i < 256; ++i) {
  byteToHex[i] = (i + 256).toString(16).substr(1);
}
function bytesToUuid$2(buf, offset) {
  var i = offset || 0;
  var bth = byteToHex;
  return [
    bth[buf[i++]],
    bth[buf[i++]],
    bth[buf[i++]],
    bth[buf[i++]],
    "-",
    bth[buf[i++]],
    bth[buf[i++]],
    "-",
    bth[buf[i++]],
    bth[buf[i++]],
    "-",
    bth[buf[i++]],
    bth[buf[i++]],
    "-",
    bth[buf[i++]],
    bth[buf[i++]],
    bth[buf[i++]],
    bth[buf[i++]],
    bth[buf[i++]],
    bth[buf[i++]]
  ].join("");
}
var bytesToUuid_1 = bytesToUuid$2;
var rng$1 = rngBrowser.exports;
var bytesToUuid$1 = bytesToUuid_1;
var _nodeId;
var _clockseq;
var _lastMSecs = 0;
var _lastNSecs = 0;
function v1$1(options, buf, offset) {
  var i = buf && offset || 0;
  var b = buf || [];
  options = options || {};
  var node = options.node || _nodeId;
  var clockseq = options.clockseq !== void 0 ? options.clockseq : _clockseq;
  if (node == null || clockseq == null) {
    var seedBytes = rng$1();
    if (node == null) {
      node = _nodeId = [
        seedBytes[0] | 1,
        seedBytes[1],
        seedBytes[2],
        seedBytes[3],
        seedBytes[4],
        seedBytes[5]
      ];
    }
    if (clockseq == null) {
      clockseq = _clockseq = (seedBytes[6] << 8 | seedBytes[7]) & 16383;
    }
  }
  var msecs = options.msecs !== void 0 ? options.msecs : new Date().getTime();
  var nsecs = options.nsecs !== void 0 ? options.nsecs : _lastNSecs + 1;
  var dt = msecs - _lastMSecs + (nsecs - _lastNSecs) / 1e4;
  if (dt < 0 && options.clockseq === void 0) {
    clockseq = clockseq + 1 & 16383;
  }
  if ((dt < 0 || msecs > _lastMSecs) && options.nsecs === void 0) {
    nsecs = 0;
  }
  if (nsecs >= 1e4) {
    throw new Error("uuid.v1(): Can't create more than 10M uuids/sec");
  }
  _lastMSecs = msecs;
  _lastNSecs = nsecs;
  _clockseq = clockseq;
  msecs += 122192928e5;
  var tl = ((msecs & 268435455) * 1e4 + nsecs) % 4294967296;
  b[i++] = tl >>> 24 & 255;
  b[i++] = tl >>> 16 & 255;
  b[i++] = tl >>> 8 & 255;
  b[i++] = tl & 255;
  var tmh = msecs / 4294967296 * 1e4 & 268435455;
  b[i++] = tmh >>> 8 & 255;
  b[i++] = tmh & 255;
  b[i++] = tmh >>> 24 & 15 | 16;
  b[i++] = tmh >>> 16 & 255;
  b[i++] = clockseq >>> 8 | 128;
  b[i++] = clockseq & 255;
  for (var n = 0; n < 6; ++n) {
    b[i + n] = node[n];
  }
  return buf ? buf : bytesToUuid$1(b);
}
var v1_1 = v1$1;
var rng = rngBrowser.exports;
var bytesToUuid = bytesToUuid_1;
function v4$1(options, buf, offset) {
  var i = buf && offset || 0;
  if (typeof options == "string") {
    buf = options === "binary" ? new Array(16) : null;
    options = null;
  }
  options = options || {};
  var rnds = options.random || (options.rng || rng)();
  rnds[6] = rnds[6] & 15 | 64;
  rnds[8] = rnds[8] & 63 | 128;
  if (buf) {
    for (var ii = 0; ii < 16; ++ii) {
      buf[i + ii] = rnds[ii];
    }
  }
  return buf || bytesToUuid(rnds);
}
var v4_1 = v4$1;
var v1 = v1_1;
var v4 = v4_1;
var uuid = v4;
uuid.v1 = v1;
uuid.v4 = v4;
var uuid_1 = uuid;
var getDefaultRetryQuota = function(initialRetryTokens) {
  var MAX_CAPACITY = initialRetryTokens;
  var availableCapacity = initialRetryTokens;
  var getCapacityAmount = function(error) {
    return error.name === "TimeoutError" ? TIMEOUT_RETRY_COST : RETRY_COST;
  };
  var hasRetryTokens = function(error) {
    return getCapacityAmount(error) <= availableCapacity;
  };
  var retrieveRetryTokens = function(error) {
    if (!hasRetryTokens(error)) {
      throw new Error("No retry token available");
    }
    var capacityAmount = getCapacityAmount(error);
    availableCapacity -= capacityAmount;
    return capacityAmount;
  };
  var releaseRetryTokens = function(capacityReleaseAmount) {
    availableCapacity += capacityReleaseAmount !== null && capacityReleaseAmount !== void 0 ? capacityReleaseAmount : NO_RETRY_INCREMENT;
    availableCapacity = Math.min(availableCapacity, MAX_CAPACITY);
  };
  return Object.freeze({
    hasRetryTokens,
    retrieveRetryTokens,
    releaseRetryTokens
  });
};
var defaultDelayDecider = function(delayBase, attempts) {
  return Math.floor(Math.min(MAXIMUM_RETRY_DELAY, Math.random() * Math.pow(2, attempts) * delayBase));
};
var defaultRetryDecider = function(error) {
  if (!error) {
    return false;
  }
  return isRetryableByTrait(error) || isClockSkewError(error) || isThrottlingError(error) || isTransientError(error);
};
var DEFAULT_MAX_ATTEMPTS = 3;
var DEFAULT_RETRY_MODE = "standard";
var StandardRetryStrategy = function() {
  function StandardRetryStrategy2(maxAttemptsProvider, options) {
    var _a, _b, _c;
    this.maxAttemptsProvider = maxAttemptsProvider;
    this.mode = DEFAULT_RETRY_MODE;
    this.retryDecider = (_a = options === null || options === void 0 ? void 0 : options.retryDecider) !== null && _a !== void 0 ? _a : defaultRetryDecider;
    this.delayDecider = (_b = options === null || options === void 0 ? void 0 : options.delayDecider) !== null && _b !== void 0 ? _b : defaultDelayDecider;
    this.retryQuota = (_c = options === null || options === void 0 ? void 0 : options.retryQuota) !== null && _c !== void 0 ? _c : getDefaultRetryQuota(INITIAL_RETRY_TOKENS);
  }
  StandardRetryStrategy2.prototype.shouldRetry = function(error, attempts, maxAttempts) {
    return attempts < maxAttempts && this.retryDecider(error) && this.retryQuota.hasRetryTokens(error);
  };
  StandardRetryStrategy2.prototype.getMaxAttempts = function() {
    return tslib.exports.__awaiter(this, void 0, void 0, function() {
      var maxAttempts;
      return tslib.exports.__generator(this, function(_a) {
        switch (_a.label) {
          case 0:
            _a.trys.push([0, 2, , 3]);
            return [4, this.maxAttemptsProvider()];
          case 1:
            maxAttempts = _a.sent();
            return [3, 3];
          case 2:
            _a.sent();
            maxAttempts = DEFAULT_MAX_ATTEMPTS;
            return [3, 3];
          case 3:
            return [2, maxAttempts];
        }
      });
    });
  };
  StandardRetryStrategy2.prototype.retry = function(next, args) {
    return tslib.exports.__awaiter(this, void 0, void 0, function() {
      var retryTokenAmount, attempts, totalDelay, maxAttempts, request, _loop_1, this_1, state_1;
      return tslib.exports.__generator(this, function(_a) {
        switch (_a.label) {
          case 0:
            attempts = 0;
            totalDelay = 0;
            return [4, this.getMaxAttempts()];
          case 1:
            maxAttempts = _a.sent();
            request = args.request;
            if (HttpRequest.isInstance(request)) {
              request.headers[INVOCATION_ID_HEADER] = uuid_1.v4();
            }
            _loop_1 = function() {
              var _a2, response, output, err_1, delay_1;
              return tslib.exports.__generator(this, function(_b) {
                switch (_b.label) {
                  case 0:
                    _b.trys.push([0, 2, , 5]);
                    if (HttpRequest.isInstance(request)) {
                      request.headers[REQUEST_HEADER] = "attempt=" + (attempts + 1) + "; max=" + maxAttempts;
                    }
                    return [4, next(args)];
                  case 1:
                    _a2 = _b.sent(), response = _a2.response, output = _a2.output;
                    this_1.retryQuota.releaseRetryTokens(retryTokenAmount);
                    output.$metadata.attempts = attempts + 1;
                    output.$metadata.totalRetryDelay = totalDelay;
                    return [2, { value: { response, output } }];
                  case 2:
                    err_1 = _b.sent();
                    attempts++;
                    if (!this_1.shouldRetry(err_1, attempts, maxAttempts))
                      return [3, 4];
                    retryTokenAmount = this_1.retryQuota.retrieveRetryTokens(err_1);
                    delay_1 = this_1.delayDecider(isThrottlingError(err_1) ? THROTTLING_RETRY_DELAY_BASE : DEFAULT_RETRY_DELAY_BASE, attempts);
                    totalDelay += delay_1;
                    return [4, new Promise(function(resolve) {
                      return setTimeout(resolve, delay_1);
                    })];
                  case 3:
                    _b.sent();
                    return [2, "continue"];
                  case 4:
                    if (!err_1.$metadata) {
                      err_1.$metadata = {};
                    }
                    err_1.$metadata.attempts = attempts;
                    err_1.$metadata.totalRetryDelay = totalDelay;
                    throw err_1;
                  case 5:
                    return [2];
                }
              });
            };
            this_1 = this;
            _a.label = 2;
          case 2:
            return [5, _loop_1()];
          case 3:
            state_1 = _a.sent();
            if (typeof state_1 === "object")
              return [2, state_1.value];
            return [3, 2];
          case 4:
            return [2];
        }
      });
    });
  };
  return StandardRetryStrategy2;
}();
var resolveRetryConfig = function(input) {
  var maxAttempts = normalizeMaxAttempts(input.maxAttempts);
  return tslib.exports.__assign(tslib.exports.__assign({}, input), { maxAttempts, retryStrategy: input.retryStrategy || new StandardRetryStrategy(maxAttempts) });
};
var normalizeMaxAttempts = function(maxAttempts) {
  if (maxAttempts === void 0) {
    maxAttempts = DEFAULT_MAX_ATTEMPTS;
  }
  if (typeof maxAttempts === "number") {
    var promisified_1 = Promise.resolve(maxAttempts);
    return function() {
      return promisified_1;
    };
  }
  return maxAttempts;
};
function calculateBodyLength(body) {
  if (typeof body === "string") {
    var len = body.length;
    for (var i = len - 1; i >= 0; i--) {
      var code = body.charCodeAt(i);
      if (code > 127 && code <= 2047)
        len++;
      else if (code > 2047 && code <= 65535)
        len += 2;
    }
    return len;
  } else if (typeof body.byteLength === "number") {
    return body.byteLength;
  } else if (typeof body.size === "number") {
    return body.size;
  }
}
const BROWSER_ALIASES_MAP = {
  "Amazon Silk": "amazon_silk",
  "Android Browser": "android",
  Bada: "bada",
  BlackBerry: "blackberry",
  Chrome: "chrome",
  Chromium: "chromium",
  Electron: "electron",
  Epiphany: "epiphany",
  Firefox: "firefox",
  Focus: "focus",
  Generic: "generic",
  "Google Search": "google_search",
  Googlebot: "googlebot",
  "Internet Explorer": "ie",
  "K-Meleon": "k_meleon",
  Maxthon: "maxthon",
  "Microsoft Edge": "edge",
  "MZ Browser": "mz",
  "NAVER Whale Browser": "naver",
  Opera: "opera",
  "Opera Coast": "opera_coast",
  PhantomJS: "phantomjs",
  Puffin: "puffin",
  QupZilla: "qupzilla",
  QQ: "qq",
  QQLite: "qqlite",
  Safari: "safari",
  Sailfish: "sailfish",
  "Samsung Internet for Android": "samsung_internet",
  SeaMonkey: "seamonkey",
  Sleipnir: "sleipnir",
  Swing: "swing",
  Tizen: "tizen",
  "UC Browser": "uc",
  Vivaldi: "vivaldi",
  "WebOS Browser": "webos",
  WeChat: "wechat",
  "Yandex Browser": "yandex",
  Roku: "roku"
};
const BROWSER_MAP = {
  amazon_silk: "Amazon Silk",
  android: "Android Browser",
  bada: "Bada",
  blackberry: "BlackBerry",
  chrome: "Chrome",
  chromium: "Chromium",
  electron: "Electron",
  epiphany: "Epiphany",
  firefox: "Firefox",
  focus: "Focus",
  generic: "Generic",
  googlebot: "Googlebot",
  google_search: "Google Search",
  ie: "Internet Explorer",
  k_meleon: "K-Meleon",
  maxthon: "Maxthon",
  edge: "Microsoft Edge",
  mz: "MZ Browser",
  naver: "NAVER Whale Browser",
  opera: "Opera",
  opera_coast: "Opera Coast",
  phantomjs: "PhantomJS",
  puffin: "Puffin",
  qupzilla: "QupZilla",
  qq: "QQ Browser",
  qqlite: "QQ Browser Lite",
  safari: "Safari",
  sailfish: "Sailfish",
  samsung_internet: "Samsung Internet for Android",
  seamonkey: "SeaMonkey",
  sleipnir: "Sleipnir",
  swing: "Swing",
  tizen: "Tizen",
  uc: "UC Browser",
  vivaldi: "Vivaldi",
  webos: "WebOS Browser",
  wechat: "WeChat",
  yandex: "Yandex Browser"
};
const PLATFORMS_MAP = {
  tablet: "tablet",
  mobile: "mobile",
  desktop: "desktop",
  tv: "tv"
};
const OS_MAP = {
  WindowsPhone: "Windows Phone",
  Windows: "Windows",
  MacOS: "macOS",
  iOS: "iOS",
  Android: "Android",
  WebOS: "WebOS",
  BlackBerry: "BlackBerry",
  Bada: "Bada",
  Tizen: "Tizen",
  Linux: "Linux",
  ChromeOS: "Chrome OS",
  PlayStation4: "PlayStation 4",
  Roku: "Roku"
};
const ENGINE_MAP = {
  EdgeHTML: "EdgeHTML",
  Blink: "Blink",
  Trident: "Trident",
  Presto: "Presto",
  Gecko: "Gecko",
  WebKit: "WebKit"
};
class Utils {
  static getFirstMatch(regexp, ua) {
    const match = ua.match(regexp);
    return match && match.length > 0 && match[1] || "";
  }
  static getSecondMatch(regexp, ua) {
    const match = ua.match(regexp);
    return match && match.length > 1 && match[2] || "";
  }
  static matchAndReturnConst(regexp, ua, _const) {
    if (regexp.test(ua)) {
      return _const;
    }
    return void 0;
  }
  static getWindowsVersionName(version2) {
    switch (version2) {
      case "NT":
        return "NT";
      case "XP":
        return "XP";
      case "NT 5.0":
        return "2000";
      case "NT 5.1":
        return "XP";
      case "NT 5.2":
        return "2003";
      case "NT 6.0":
        return "Vista";
      case "NT 6.1":
        return "7";
      case "NT 6.2":
        return "8";
      case "NT 6.3":
        return "8.1";
      case "NT 10.0":
        return "10";
      default:
        return void 0;
    }
  }
  static getMacOSVersionName(version2) {
    const v = version2.split(".").splice(0, 2).map((s) => parseInt(s, 10) || 0);
    v.push(0);
    if (v[0] !== 10)
      return void 0;
    switch (v[1]) {
      case 5:
        return "Leopard";
      case 6:
        return "Snow Leopard";
      case 7:
        return "Lion";
      case 8:
        return "Mountain Lion";
      case 9:
        return "Mavericks";
      case 10:
        return "Yosemite";
      case 11:
        return "El Capitan";
      case 12:
        return "Sierra";
      case 13:
        return "High Sierra";
      case 14:
        return "Mojave";
      case 15:
        return "Catalina";
      default:
        return void 0;
    }
  }
  static getAndroidVersionName(version2) {
    const v = version2.split(".").splice(0, 2).map((s) => parseInt(s, 10) || 0);
    v.push(0);
    if (v[0] === 1 && v[1] < 5)
      return void 0;
    if (v[0] === 1 && v[1] < 6)
      return "Cupcake";
    if (v[0] === 1 && v[1] >= 6)
      return "Donut";
    if (v[0] === 2 && v[1] < 2)
      return "Eclair";
    if (v[0] === 2 && v[1] === 2)
      return "Froyo";
    if (v[0] === 2 && v[1] > 2)
      return "Gingerbread";
    if (v[0] === 3)
      return "Honeycomb";
    if (v[0] === 4 && v[1] < 1)
      return "Ice Cream Sandwich";
    if (v[0] === 4 && v[1] < 4)
      return "Jelly Bean";
    if (v[0] === 4 && v[1] >= 4)
      return "KitKat";
    if (v[0] === 5)
      return "Lollipop";
    if (v[0] === 6)
      return "Marshmallow";
    if (v[0] === 7)
      return "Nougat";
    if (v[0] === 8)
      return "Oreo";
    if (v[0] === 9)
      return "Pie";
    return void 0;
  }
  static getVersionPrecision(version2) {
    return version2.split(".").length;
  }
  static compareVersions(versionA, versionB, isLoose = false) {
    const versionAPrecision = Utils.getVersionPrecision(versionA);
    const versionBPrecision = Utils.getVersionPrecision(versionB);
    let precision = Math.max(versionAPrecision, versionBPrecision);
    let lastPrecision = 0;
    const chunks = Utils.map([versionA, versionB], (version2) => {
      const delta = precision - Utils.getVersionPrecision(version2);
      const _version = version2 + new Array(delta + 1).join(".0");
      return Utils.map(_version.split("."), (chunk) => new Array(20 - chunk.length).join("0") + chunk).reverse();
    });
    if (isLoose) {
      lastPrecision = precision - Math.min(versionAPrecision, versionBPrecision);
    }
    precision -= 1;
    while (precision >= lastPrecision) {
      if (chunks[0][precision] > chunks[1][precision]) {
        return 1;
      }
      if (chunks[0][precision] === chunks[1][precision]) {
        if (precision === lastPrecision) {
          return 0;
        }
        precision -= 1;
      } else if (chunks[0][precision] < chunks[1][precision]) {
        return -1;
      }
    }
    return void 0;
  }
  static map(arr, iterator) {
    const result = [];
    let i;
    if (Array.prototype.map) {
      return Array.prototype.map.call(arr, iterator);
    }
    for (i = 0; i < arr.length; i += 1) {
      result.push(iterator(arr[i]));
    }
    return result;
  }
  static find(arr, predicate) {
    let i;
    let l;
    if (Array.prototype.find) {
      return Array.prototype.find.call(arr, predicate);
    }
    for (i = 0, l = arr.length; i < l; i += 1) {
      const value = arr[i];
      if (predicate(value, i)) {
        return value;
      }
    }
    return void 0;
  }
  static assign(obj, ...assigners) {
    const result = obj;
    let i;
    let l;
    if (Object.assign) {
      return Object.assign(obj, ...assigners);
    }
    for (i = 0, l = assigners.length; i < l; i += 1) {
      const assigner = assigners[i];
      if (typeof assigner === "object" && assigner !== null) {
        const keys = Object.keys(assigner);
        keys.forEach((key) => {
          result[key] = assigner[key];
        });
      }
    }
    return obj;
  }
  static getBrowserAlias(browserName) {
    return BROWSER_ALIASES_MAP[browserName];
  }
  static getBrowserTypeByAlias(browserAlias) {
    return BROWSER_MAP[browserAlias] || "";
  }
}
const commonVersionIdentifier = /version\/(\d+(\.?_?\d+)+)/i;
const browsersList = [
  {
    test: [/googlebot/i],
    describe(ua) {
      const browser2 = {
        name: "Googlebot"
      };
      const version2 = Utils.getFirstMatch(/googlebot\/(\d+(\.\d+))/i, ua) || Utils.getFirstMatch(commonVersionIdentifier, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/opera/i],
    describe(ua) {
      const browser2 = {
        name: "Opera"
      };
      const version2 = Utils.getFirstMatch(commonVersionIdentifier, ua) || Utils.getFirstMatch(/(?:opera)[\s/](\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/opr\/|opios/i],
    describe(ua) {
      const browser2 = {
        name: "Opera"
      };
      const version2 = Utils.getFirstMatch(/(?:opr|opios)[\s/](\S+)/i, ua) || Utils.getFirstMatch(commonVersionIdentifier, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/SamsungBrowser/i],
    describe(ua) {
      const browser2 = {
        name: "Samsung Internet for Android"
      };
      const version2 = Utils.getFirstMatch(commonVersionIdentifier, ua) || Utils.getFirstMatch(/(?:SamsungBrowser)[\s/](\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/Whale/i],
    describe(ua) {
      const browser2 = {
        name: "NAVER Whale Browser"
      };
      const version2 = Utils.getFirstMatch(commonVersionIdentifier, ua) || Utils.getFirstMatch(/(?:whale)[\s/](\d+(?:\.\d+)+)/i, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/MZBrowser/i],
    describe(ua) {
      const browser2 = {
        name: "MZ Browser"
      };
      const version2 = Utils.getFirstMatch(/(?:MZBrowser)[\s/](\d+(?:\.\d+)+)/i, ua) || Utils.getFirstMatch(commonVersionIdentifier, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/focus/i],
    describe(ua) {
      const browser2 = {
        name: "Focus"
      };
      const version2 = Utils.getFirstMatch(/(?:focus)[\s/](\d+(?:\.\d+)+)/i, ua) || Utils.getFirstMatch(commonVersionIdentifier, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/swing/i],
    describe(ua) {
      const browser2 = {
        name: "Swing"
      };
      const version2 = Utils.getFirstMatch(/(?:swing)[\s/](\d+(?:\.\d+)+)/i, ua) || Utils.getFirstMatch(commonVersionIdentifier, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/coast/i],
    describe(ua) {
      const browser2 = {
        name: "Opera Coast"
      };
      const version2 = Utils.getFirstMatch(commonVersionIdentifier, ua) || Utils.getFirstMatch(/(?:coast)[\s/](\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/opt\/\d+(?:.?_?\d+)+/i],
    describe(ua) {
      const browser2 = {
        name: "Opera Touch"
      };
      const version2 = Utils.getFirstMatch(/(?:opt)[\s/](\d+(\.?_?\d+)+)/i, ua) || Utils.getFirstMatch(commonVersionIdentifier, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/yabrowser/i],
    describe(ua) {
      const browser2 = {
        name: "Yandex Browser"
      };
      const version2 = Utils.getFirstMatch(/(?:yabrowser)[\s/](\d+(\.?_?\d+)+)/i, ua) || Utils.getFirstMatch(commonVersionIdentifier, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/ucbrowser/i],
    describe(ua) {
      const browser2 = {
        name: "UC Browser"
      };
      const version2 = Utils.getFirstMatch(commonVersionIdentifier, ua) || Utils.getFirstMatch(/(?:ucbrowser)[\s/](\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/Maxthon|mxios/i],
    describe(ua) {
      const browser2 = {
        name: "Maxthon"
      };
      const version2 = Utils.getFirstMatch(commonVersionIdentifier, ua) || Utils.getFirstMatch(/(?:Maxthon|mxios)[\s/](\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/epiphany/i],
    describe(ua) {
      const browser2 = {
        name: "Epiphany"
      };
      const version2 = Utils.getFirstMatch(commonVersionIdentifier, ua) || Utils.getFirstMatch(/(?:epiphany)[\s/](\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/puffin/i],
    describe(ua) {
      const browser2 = {
        name: "Puffin"
      };
      const version2 = Utils.getFirstMatch(commonVersionIdentifier, ua) || Utils.getFirstMatch(/(?:puffin)[\s/](\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/sleipnir/i],
    describe(ua) {
      const browser2 = {
        name: "Sleipnir"
      };
      const version2 = Utils.getFirstMatch(commonVersionIdentifier, ua) || Utils.getFirstMatch(/(?:sleipnir)[\s/](\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/k-meleon/i],
    describe(ua) {
      const browser2 = {
        name: "K-Meleon"
      };
      const version2 = Utils.getFirstMatch(commonVersionIdentifier, ua) || Utils.getFirstMatch(/(?:k-meleon)[\s/](\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/micromessenger/i],
    describe(ua) {
      const browser2 = {
        name: "WeChat"
      };
      const version2 = Utils.getFirstMatch(/(?:micromessenger)[\s/](\d+(\.?_?\d+)+)/i, ua) || Utils.getFirstMatch(commonVersionIdentifier, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/qqbrowser/i],
    describe(ua) {
      const browser2 = {
        name: /qqbrowserlite/i.test(ua) ? "QQ Browser Lite" : "QQ Browser"
      };
      const version2 = Utils.getFirstMatch(/(?:qqbrowserlite|qqbrowser)[/](\d+(\.?_?\d+)+)/i, ua) || Utils.getFirstMatch(commonVersionIdentifier, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/msie|trident/i],
    describe(ua) {
      const browser2 = {
        name: "Internet Explorer"
      };
      const version2 = Utils.getFirstMatch(/(?:msie |rv:)(\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/\sedg\//i],
    describe(ua) {
      const browser2 = {
        name: "Microsoft Edge"
      };
      const version2 = Utils.getFirstMatch(/\sedg\/(\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/edg([ea]|ios)/i],
    describe(ua) {
      const browser2 = {
        name: "Microsoft Edge"
      };
      const version2 = Utils.getSecondMatch(/edg([ea]|ios)\/(\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/vivaldi/i],
    describe(ua) {
      const browser2 = {
        name: "Vivaldi"
      };
      const version2 = Utils.getFirstMatch(/vivaldi\/(\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/seamonkey/i],
    describe(ua) {
      const browser2 = {
        name: "SeaMonkey"
      };
      const version2 = Utils.getFirstMatch(/seamonkey\/(\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/sailfish/i],
    describe(ua) {
      const browser2 = {
        name: "Sailfish"
      };
      const version2 = Utils.getFirstMatch(/sailfish\s?browser\/(\d+(\.\d+)?)/i, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/silk/i],
    describe(ua) {
      const browser2 = {
        name: "Amazon Silk"
      };
      const version2 = Utils.getFirstMatch(/silk\/(\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/phantom/i],
    describe(ua) {
      const browser2 = {
        name: "PhantomJS"
      };
      const version2 = Utils.getFirstMatch(/phantomjs\/(\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/slimerjs/i],
    describe(ua) {
      const browser2 = {
        name: "SlimerJS"
      };
      const version2 = Utils.getFirstMatch(/slimerjs\/(\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/blackberry|\bbb\d+/i, /rim\stablet/i],
    describe(ua) {
      const browser2 = {
        name: "BlackBerry"
      };
      const version2 = Utils.getFirstMatch(commonVersionIdentifier, ua) || Utils.getFirstMatch(/blackberry[\d]+\/(\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/(web|hpw)[o0]s/i],
    describe(ua) {
      const browser2 = {
        name: "WebOS Browser"
      };
      const version2 = Utils.getFirstMatch(commonVersionIdentifier, ua) || Utils.getFirstMatch(/w(?:eb)?[o0]sbrowser\/(\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/bada/i],
    describe(ua) {
      const browser2 = {
        name: "Bada"
      };
      const version2 = Utils.getFirstMatch(/dolfin\/(\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/tizen/i],
    describe(ua) {
      const browser2 = {
        name: "Tizen"
      };
      const version2 = Utils.getFirstMatch(/(?:tizen\s?)?browser\/(\d+(\.?_?\d+)+)/i, ua) || Utils.getFirstMatch(commonVersionIdentifier, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/qupzilla/i],
    describe(ua) {
      const browser2 = {
        name: "QupZilla"
      };
      const version2 = Utils.getFirstMatch(/(?:qupzilla)[\s/](\d+(\.?_?\d+)+)/i, ua) || Utils.getFirstMatch(commonVersionIdentifier, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/firefox|iceweasel|fxios/i],
    describe(ua) {
      const browser2 = {
        name: "Firefox"
      };
      const version2 = Utils.getFirstMatch(/(?:firefox|iceweasel|fxios)[\s/](\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/electron/i],
    describe(ua) {
      const browser2 = {
        name: "Electron"
      };
      const version2 = Utils.getFirstMatch(/(?:electron)\/(\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/MiuiBrowser/i],
    describe(ua) {
      const browser2 = {
        name: "Miui"
      };
      const version2 = Utils.getFirstMatch(/(?:MiuiBrowser)[\s/](\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/chromium/i],
    describe(ua) {
      const browser2 = {
        name: "Chromium"
      };
      const version2 = Utils.getFirstMatch(/(?:chromium)[\s/](\d+(\.?_?\d+)+)/i, ua) || Utils.getFirstMatch(commonVersionIdentifier, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/chrome|crios|crmo/i],
    describe(ua) {
      const browser2 = {
        name: "Chrome"
      };
      const version2 = Utils.getFirstMatch(/(?:chrome|crios|crmo)\/(\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/GSA/i],
    describe(ua) {
      const browser2 = {
        name: "Google Search"
      };
      const version2 = Utils.getFirstMatch(/(?:GSA)\/(\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test(parser) {
      const notLikeAndroid = !parser.test(/like android/i);
      const butAndroid = parser.test(/android/i);
      return notLikeAndroid && butAndroid;
    },
    describe(ua) {
      const browser2 = {
        name: "Android Browser"
      };
      const version2 = Utils.getFirstMatch(commonVersionIdentifier, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/playstation 4/i],
    describe(ua) {
      const browser2 = {
        name: "PlayStation 4"
      };
      const version2 = Utils.getFirstMatch(commonVersionIdentifier, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/safari|applewebkit/i],
    describe(ua) {
      const browser2 = {
        name: "Safari"
      };
      const version2 = Utils.getFirstMatch(commonVersionIdentifier, ua);
      if (version2) {
        browser2.version = version2;
      }
      return browser2;
    }
  },
  {
    test: [/.*/i],
    describe(ua) {
      const regexpWithoutDeviceSpec = /^(.*)\/(.*) /;
      const regexpWithDeviceSpec = /^(.*)\/(.*)[ \t]\((.*)/;
      const hasDeviceSpec = ua.search("\\(") !== -1;
      const regexp = hasDeviceSpec ? regexpWithDeviceSpec : regexpWithoutDeviceSpec;
      return {
        name: Utils.getFirstMatch(regexp, ua),
        version: Utils.getSecondMatch(regexp, ua)
      };
    }
  }
];
var osParsersList = [
  {
    test: [/Roku\/DVP/],
    describe(ua) {
      const version2 = Utils.getFirstMatch(/Roku\/DVP-(\d+\.\d+)/i, ua);
      return {
        name: OS_MAP.Roku,
        version: version2
      };
    }
  },
  {
    test: [/windows phone/i],
    describe(ua) {
      const version2 = Utils.getFirstMatch(/windows phone (?:os)?\s?(\d+(\.\d+)*)/i, ua);
      return {
        name: OS_MAP.WindowsPhone,
        version: version2
      };
    }
  },
  {
    test: [/windows /i],
    describe(ua) {
      const version2 = Utils.getFirstMatch(/Windows ((NT|XP)( \d\d?.\d)?)/i, ua);
      const versionName = Utils.getWindowsVersionName(version2);
      return {
        name: OS_MAP.Windows,
        version: version2,
        versionName
      };
    }
  },
  {
    test: [/Macintosh(.*?) FxiOS(.*?)\//],
    describe(ua) {
      const result = {
        name: OS_MAP.iOS
      };
      const version2 = Utils.getSecondMatch(/(Version\/)(\d[\d.]+)/, ua);
      if (version2) {
        result.version = version2;
      }
      return result;
    }
  },
  {
    test: [/macintosh/i],
    describe(ua) {
      const version2 = Utils.getFirstMatch(/mac os x (\d+(\.?_?\d+)+)/i, ua).replace(/[_\s]/g, ".");
      const versionName = Utils.getMacOSVersionName(version2);
      const os = {
        name: OS_MAP.MacOS,
        version: version2
      };
      if (versionName) {
        os.versionName = versionName;
      }
      return os;
    }
  },
  {
    test: [/(ipod|iphone|ipad)/i],
    describe(ua) {
      const version2 = Utils.getFirstMatch(/os (\d+([_\s]\d+)*) like mac os x/i, ua).replace(/[_\s]/g, ".");
      return {
        name: OS_MAP.iOS,
        version: version2
      };
    }
  },
  {
    test(parser) {
      const notLikeAndroid = !parser.test(/like android/i);
      const butAndroid = parser.test(/android/i);
      return notLikeAndroid && butAndroid;
    },
    describe(ua) {
      const version2 = Utils.getFirstMatch(/android[\s/-](\d+(\.\d+)*)/i, ua);
      const versionName = Utils.getAndroidVersionName(version2);
      const os = {
        name: OS_MAP.Android,
        version: version2
      };
      if (versionName) {
        os.versionName = versionName;
      }
      return os;
    }
  },
  {
    test: [/(web|hpw)[o0]s/i],
    describe(ua) {
      const version2 = Utils.getFirstMatch(/(?:web|hpw)[o0]s\/(\d+(\.\d+)*)/i, ua);
      const os = {
        name: OS_MAP.WebOS
      };
      if (version2 && version2.length) {
        os.version = version2;
      }
      return os;
    }
  },
  {
    test: [/blackberry|\bbb\d+/i, /rim\stablet/i],
    describe(ua) {
      const version2 = Utils.getFirstMatch(/rim\stablet\sos\s(\d+(\.\d+)*)/i, ua) || Utils.getFirstMatch(/blackberry\d+\/(\d+([_\s]\d+)*)/i, ua) || Utils.getFirstMatch(/\bbb(\d+)/i, ua);
      return {
        name: OS_MAP.BlackBerry,
        version: version2
      };
    }
  },
  {
    test: [/bada/i],
    describe(ua) {
      const version2 = Utils.getFirstMatch(/bada\/(\d+(\.\d+)*)/i, ua);
      return {
        name: OS_MAP.Bada,
        version: version2
      };
    }
  },
  {
    test: [/tizen/i],
    describe(ua) {
      const version2 = Utils.getFirstMatch(/tizen[/\s](\d+(\.\d+)*)/i, ua);
      return {
        name: OS_MAP.Tizen,
        version: version2
      };
    }
  },
  {
    test: [/linux/i],
    describe() {
      return {
        name: OS_MAP.Linux
      };
    }
  },
  {
    test: [/CrOS/],
    describe() {
      return {
        name: OS_MAP.ChromeOS
      };
    }
  },
  {
    test: [/PlayStation 4/],
    describe(ua) {
      const version2 = Utils.getFirstMatch(/PlayStation 4[/\s](\d+(\.\d+)*)/i, ua);
      return {
        name: OS_MAP.PlayStation4,
        version: version2
      };
    }
  }
];
var platformParsersList = [
  {
    test: [/googlebot/i],
    describe() {
      return {
        type: "bot",
        vendor: "Google"
      };
    }
  },
  {
    test: [/huawei/i],
    describe(ua) {
      const model = Utils.getFirstMatch(/(can-l01)/i, ua) && "Nova";
      const platform = {
        type: PLATFORMS_MAP.mobile,
        vendor: "Huawei"
      };
      if (model) {
        platform.model = model;
      }
      return platform;
    }
  },
  {
    test: [/nexus\s*(?:7|8|9|10).*/i],
    describe() {
      return {
        type: PLATFORMS_MAP.tablet,
        vendor: "Nexus"
      };
    }
  },
  {
    test: [/ipad/i],
    describe() {
      return {
        type: PLATFORMS_MAP.tablet,
        vendor: "Apple",
        model: "iPad"
      };
    }
  },
  {
    test: [/Macintosh(.*?) FxiOS(.*?)\//],
    describe() {
      return {
        type: PLATFORMS_MAP.tablet,
        vendor: "Apple",
        model: "iPad"
      };
    }
  },
  {
    test: [/kftt build/i],
    describe() {
      return {
        type: PLATFORMS_MAP.tablet,
        vendor: "Amazon",
        model: "Kindle Fire HD 7"
      };
    }
  },
  {
    test: [/silk/i],
    describe() {
      return {
        type: PLATFORMS_MAP.tablet,
        vendor: "Amazon"
      };
    }
  },
  {
    test: [/tablet(?! pc)/i],
    describe() {
      return {
        type: PLATFORMS_MAP.tablet
      };
    }
  },
  {
    test(parser) {
      const iDevice = parser.test(/ipod|iphone/i);
      const likeIDevice = parser.test(/like (ipod|iphone)/i);
      return iDevice && !likeIDevice;
    },
    describe(ua) {
      const model = Utils.getFirstMatch(/(ipod|iphone)/i, ua);
      return {
        type: PLATFORMS_MAP.mobile,
        vendor: "Apple",
        model
      };
    }
  },
  {
    test: [/nexus\s*[0-6].*/i, /galaxy nexus/i],
    describe() {
      return {
        type: PLATFORMS_MAP.mobile,
        vendor: "Nexus"
      };
    }
  },
  {
    test: [/[^-]mobi/i],
    describe() {
      return {
        type: PLATFORMS_MAP.mobile
      };
    }
  },
  {
    test(parser) {
      return parser.getBrowserName(true) === "blackberry";
    },
    describe() {
      return {
        type: PLATFORMS_MAP.mobile,
        vendor: "BlackBerry"
      };
    }
  },
  {
    test(parser) {
      return parser.getBrowserName(true) === "bada";
    },
    describe() {
      return {
        type: PLATFORMS_MAP.mobile
      };
    }
  },
  {
    test(parser) {
      return parser.getBrowserName() === "windows phone";
    },
    describe() {
      return {
        type: PLATFORMS_MAP.mobile,
        vendor: "Microsoft"
      };
    }
  },
  {
    test(parser) {
      const osMajorVersion = Number(String(parser.getOSVersion()).split(".")[0]);
      return parser.getOSName(true) === "android" && osMajorVersion >= 3;
    },
    describe() {
      return {
        type: PLATFORMS_MAP.tablet
      };
    }
  },
  {
    test(parser) {
      return parser.getOSName(true) === "android";
    },
    describe() {
      return {
        type: PLATFORMS_MAP.mobile
      };
    }
  },
  {
    test(parser) {
      return parser.getOSName(true) === "macos";
    },
    describe() {
      return {
        type: PLATFORMS_MAP.desktop,
        vendor: "Apple"
      };
    }
  },
  {
    test(parser) {
      return parser.getOSName(true) === "windows";
    },
    describe() {
      return {
        type: PLATFORMS_MAP.desktop
      };
    }
  },
  {
    test(parser) {
      return parser.getOSName(true) === "linux";
    },
    describe() {
      return {
        type: PLATFORMS_MAP.desktop
      };
    }
  },
  {
    test(parser) {
      return parser.getOSName(true) === "playstation 4";
    },
    describe() {
      return {
        type: PLATFORMS_MAP.tv
      };
    }
  },
  {
    test(parser) {
      return parser.getOSName(true) === "roku";
    },
    describe() {
      return {
        type: PLATFORMS_MAP.tv
      };
    }
  }
];
var enginesParsersList = [
  {
    test(parser) {
      return parser.getBrowserName(true) === "microsoft edge";
    },
    describe(ua) {
      const isBlinkBased = /\sedg\//i.test(ua);
      if (isBlinkBased) {
        return {
          name: ENGINE_MAP.Blink
        };
      }
      const version2 = Utils.getFirstMatch(/edge\/(\d+(\.?_?\d+)+)/i, ua);
      return {
        name: ENGINE_MAP.EdgeHTML,
        version: version2
      };
    }
  },
  {
    test: [/trident/i],
    describe(ua) {
      const engine = {
        name: ENGINE_MAP.Trident
      };
      const version2 = Utils.getFirstMatch(/trident\/(\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        engine.version = version2;
      }
      return engine;
    }
  },
  {
    test(parser) {
      return parser.test(/presto/i);
    },
    describe(ua) {
      const engine = {
        name: ENGINE_MAP.Presto
      };
      const version2 = Utils.getFirstMatch(/presto\/(\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        engine.version = version2;
      }
      return engine;
    }
  },
  {
    test(parser) {
      const isGecko = parser.test(/gecko/i);
      const likeGecko = parser.test(/like gecko/i);
      return isGecko && !likeGecko;
    },
    describe(ua) {
      const engine = {
        name: ENGINE_MAP.Gecko
      };
      const version2 = Utils.getFirstMatch(/gecko\/(\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        engine.version = version2;
      }
      return engine;
    }
  },
  {
    test: [/(apple)?webkit\/537\.36/i],
    describe() {
      return {
        name: ENGINE_MAP.Blink
      };
    }
  },
  {
    test: [/(apple)?webkit/i],
    describe(ua) {
      const engine = {
        name: ENGINE_MAP.WebKit
      };
      const version2 = Utils.getFirstMatch(/webkit\/(\d+(\.?_?\d+)+)/i, ua);
      if (version2) {
        engine.version = version2;
      }
      return engine;
    }
  }
];
class Parser {
  constructor(UA, skipParsing = false) {
    if (UA === void 0 || UA === null || UA === "") {
      throw new Error("UserAgent parameter can't be empty");
    }
    this._ua = UA;
    this.parsedResult = {};
    if (skipParsing !== true) {
      this.parse();
    }
  }
  getUA() {
    return this._ua;
  }
  test(regex) {
    return regex.test(this._ua);
  }
  parseBrowser() {
    this.parsedResult.browser = {};
    const browserDescriptor = Utils.find(browsersList, (_browser) => {
      if (typeof _browser.test === "function") {
        return _browser.test(this);
      }
      if (_browser.test instanceof Array) {
        return _browser.test.some((condition) => this.test(condition));
      }
      throw new Error("Browser's test function is not valid");
    });
    if (browserDescriptor) {
      this.parsedResult.browser = browserDescriptor.describe(this.getUA());
    }
    return this.parsedResult.browser;
  }
  getBrowser() {
    if (this.parsedResult.browser) {
      return this.parsedResult.browser;
    }
    return this.parseBrowser();
  }
  getBrowserName(toLowerCase) {
    if (toLowerCase) {
      return String(this.getBrowser().name).toLowerCase() || "";
    }
    return this.getBrowser().name || "";
  }
  getBrowserVersion() {
    return this.getBrowser().version;
  }
  getOS() {
    if (this.parsedResult.os) {
      return this.parsedResult.os;
    }
    return this.parseOS();
  }
  parseOS() {
    this.parsedResult.os = {};
    const os = Utils.find(osParsersList, (_os) => {
      if (typeof _os.test === "function") {
        return _os.test(this);
      }
      if (_os.test instanceof Array) {
        return _os.test.some((condition) => this.test(condition));
      }
      throw new Error("Browser's test function is not valid");
    });
    if (os) {
      this.parsedResult.os = os.describe(this.getUA());
    }
    return this.parsedResult.os;
  }
  getOSName(toLowerCase) {
    const { name: name2 } = this.getOS();
    if (toLowerCase) {
      return String(name2).toLowerCase() || "";
    }
    return name2 || "";
  }
  getOSVersion() {
    return this.getOS().version;
  }
  getPlatform() {
    if (this.parsedResult.platform) {
      return this.parsedResult.platform;
    }
    return this.parsePlatform();
  }
  getPlatformType(toLowerCase = false) {
    const { type } = this.getPlatform();
    if (toLowerCase) {
      return String(type).toLowerCase() || "";
    }
    return type || "";
  }
  parsePlatform() {
    this.parsedResult.platform = {};
    const platform = Utils.find(platformParsersList, (_platform) => {
      if (typeof _platform.test === "function") {
        return _platform.test(this);
      }
      if (_platform.test instanceof Array) {
        return _platform.test.some((condition) => this.test(condition));
      }
      throw new Error("Browser's test function is not valid");
    });
    if (platform) {
      this.parsedResult.platform = platform.describe(this.getUA());
    }
    return this.parsedResult.platform;
  }
  getEngine() {
    if (this.parsedResult.engine) {
      return this.parsedResult.engine;
    }
    return this.parseEngine();
  }
  getEngineName(toLowerCase) {
    if (toLowerCase) {
      return String(this.getEngine().name).toLowerCase() || "";
    }
    return this.getEngine().name || "";
  }
  parseEngine() {
    this.parsedResult.engine = {};
    const engine = Utils.find(enginesParsersList, (_engine) => {
      if (typeof _engine.test === "function") {
        return _engine.test(this);
      }
      if (_engine.test instanceof Array) {
        return _engine.test.some((condition) => this.test(condition));
      }
      throw new Error("Browser's test function is not valid");
    });
    if (engine) {
      this.parsedResult.engine = engine.describe(this.getUA());
    }
    return this.parsedResult.engine;
  }
  parse() {
    this.parseBrowser();
    this.parseOS();
    this.parsePlatform();
    this.parseEngine();
    return this;
  }
  getResult() {
    return Utils.assign({}, this.parsedResult);
  }
  satisfies(checkTree) {
    const platformsAndOSes = {};
    let platformsAndOSCounter = 0;
    const browsers = {};
    let browsersCounter = 0;
    const allDefinitions = Object.keys(checkTree);
    allDefinitions.forEach((key) => {
      const currentDefinition = checkTree[key];
      if (typeof currentDefinition === "string") {
        browsers[key] = currentDefinition;
        browsersCounter += 1;
      } else if (typeof currentDefinition === "object") {
        platformsAndOSes[key] = currentDefinition;
        platformsAndOSCounter += 1;
      }
    });
    if (platformsAndOSCounter > 0) {
      const platformsAndOSNames = Object.keys(platformsAndOSes);
      const OSMatchingDefinition = Utils.find(platformsAndOSNames, (name2) => this.isOS(name2));
      if (OSMatchingDefinition) {
        const osResult = this.satisfies(platformsAndOSes[OSMatchingDefinition]);
        if (osResult !== void 0) {
          return osResult;
        }
      }
      const platformMatchingDefinition = Utils.find(
        platformsAndOSNames,
        (name2) => this.isPlatform(name2)
      );
      if (platformMatchingDefinition) {
        const platformResult = this.satisfies(platformsAndOSes[platformMatchingDefinition]);
        if (platformResult !== void 0) {
          return platformResult;
        }
      }
    }
    if (browsersCounter > 0) {
      const browserNames = Object.keys(browsers);
      const matchingDefinition = Utils.find(browserNames, (name2) => this.isBrowser(name2, true));
      if (matchingDefinition !== void 0) {
        return this.compareVersion(browsers[matchingDefinition]);
      }
    }
    return void 0;
  }
  isBrowser(browserName, includingAlias = false) {
    const defaultBrowserName = this.getBrowserName().toLowerCase();
    let browserNameLower = browserName.toLowerCase();
    const alias = Utils.getBrowserTypeByAlias(browserNameLower);
    if (includingAlias && alias) {
      browserNameLower = alias.toLowerCase();
    }
    return browserNameLower === defaultBrowserName;
  }
  compareVersion(version2) {
    let expectedResults = [0];
    let comparableVersion = version2;
    let isLoose = false;
    const currentBrowserVersion = this.getBrowserVersion();
    if (typeof currentBrowserVersion !== "string") {
      return void 0;
    }
    if (version2[0] === ">" || version2[0] === "<") {
      comparableVersion = version2.substr(1);
      if (version2[1] === "=") {
        isLoose = true;
        comparableVersion = version2.substr(2);
      } else {
        expectedResults = [];
      }
      if (version2[0] === ">") {
        expectedResults.push(1);
      } else {
        expectedResults.push(-1);
      }
    } else if (version2[0] === "=") {
      comparableVersion = version2.substr(1);
    } else if (version2[0] === "~") {
      isLoose = true;
      comparableVersion = version2.substr(1);
    }
    return expectedResults.indexOf(
      Utils.compareVersions(currentBrowserVersion, comparableVersion, isLoose)
    ) > -1;
  }
  isOS(osName) {
    return this.getOSName(true) === String(osName).toLowerCase();
  }
  isPlatform(platformType) {
    return this.getPlatformType(true) === String(platformType).toLowerCase();
  }
  isEngine(engineName) {
    return this.getEngineName(true) === String(engineName).toLowerCase();
  }
  is(anything, includingAlias = false) {
    return this.isBrowser(anything, includingAlias) || this.isOS(anything) || this.isPlatform(anything);
  }
  some(anythings = []) {
    return anythings.some((anything) => this.is(anything));
  }
}
/*!
 * Bowser - a browser detector
 * https://github.com/lancedikson/bowser
 * MIT License | (c) Dustin Diaz 2012-2015
 * MIT License | (c) Denis Demchenko 2015-2019
 */
class Bowser {
  static getParser(UA, skipParsing = false) {
    if (typeof UA !== "string") {
      throw new Error("UserAgent should be a string");
    }
    return new Parser(UA, skipParsing);
  }
  static parse(UA) {
    return new Parser(UA).getResult();
  }
  static get BROWSER_MAP() {
    return BROWSER_MAP;
  }
  static get ENGINE_MAP() {
    return ENGINE_MAP;
  }
  static get OS_MAP() {
    return OS_MAP;
  }
  static get PLATFORMS_MAP() {
    return PLATFORMS_MAP;
  }
}
var defaultUserAgent = function(_a) {
  var serviceId = _a.serviceId, clientVersion = _a.clientVersion;
  return function() {
    return tslib.exports.__awaiter(void 0, void 0, void 0, function() {
      var parsedUA, sections;
      var _a2, _b, _c, _d, _e, _f, _g;
      return tslib.exports.__generator(this, function(_h) {
        parsedUA = ((_a2 = window === null || window === void 0 ? void 0 : window.navigator) === null || _a2 === void 0 ? void 0 : _a2.userAgent) ? Bowser.parse(window.navigator.userAgent) : void 0;
        sections = [
          ["aws-sdk-js", clientVersion],
          ["os/" + (((_b = parsedUA === null || parsedUA === void 0 ? void 0 : parsedUA.os) === null || _b === void 0 ? void 0 : _b.name) || "other"), (_c = parsedUA === null || parsedUA === void 0 ? void 0 : parsedUA.os) === null || _c === void 0 ? void 0 : _c.version],
          ["lang/js"],
          ["md/browser", ((_e = (_d = parsedUA === null || parsedUA === void 0 ? void 0 : parsedUA.browser) === null || _d === void 0 ? void 0 : _d.name) !== null && _e !== void 0 ? _e : "unknown") + "_" + ((_g = (_f = parsedUA === null || parsedUA === void 0 ? void 0 : parsedUA.browser) === null || _f === void 0 ? void 0 : _f.version) !== null && _g !== void 0 ? _g : "unknown")]
        ];
        if (serviceId) {
          sections.push(["api/" + serviceId, clientVersion]);
        }
        return [2, sections];
      });
    });
  };
};
function parseQueryString(querystring) {
  var e_1, _a;
  var query = {};
  querystring = querystring.replace(/^\?/, "");
  if (querystring) {
    try {
      for (var _b = tslib.exports.__values(querystring.split("&")), _c = _b.next(); !_c.done; _c = _b.next()) {
        var pair = _c.value;
        var _d = tslib.exports.__read(pair.split("="), 2), key = _d[0], _e = _d[1], value = _e === void 0 ? null : _e;
        key = decodeURIComponent(key);
        if (value) {
          value = decodeURIComponent(value);
        }
        if (!(key in query)) {
          query[key] = value;
        } else if (Array.isArray(query[key])) {
          query[key].push(value);
        } else {
          query[key] = [query[key], value];
        }
      }
    } catch (e_1_1) {
      e_1 = { error: e_1_1 };
    } finally {
      try {
        if (_c && !_c.done && (_a = _b.return))
          _a.call(_b);
      } finally {
        if (e_1)
          throw e_1.error;
      }
    }
  }
  return query;
}
var parseUrl = function(url) {
  var _a = new URL(url), hostname = _a.hostname, pathname = _a.pathname, port = _a.port, protocol = _a.protocol, search = _a.search;
  var query;
  if (search) {
    query = parseQueryString(search);
  }
  return {
    hostname,
    port: port ? parseInt(port) : void 0,
    protocol,
    path: pathname,
    query
  };
};
var resolveEndpointsConfig = function(input) {
  var _a;
  return tslib.exports.__assign(tslib.exports.__assign({}, input), { tls: (_a = input.tls) !== null && _a !== void 0 ? _a : true, endpoint: input.endpoint ? normalizeEndpoint(input) : function() {
    return getEndPointFromRegion(input);
  }, isCustomEndpoint: input.endpoint ? true : false });
};
var normalizeEndpoint = function(input) {
  var endpoint = input.endpoint, urlParser = input.urlParser;
  if (typeof endpoint === "string") {
    var promisified_1 = Promise.resolve(urlParser(endpoint));
    return function() {
      return promisified_1;
    };
  } else if (typeof endpoint === "object") {
    var promisified_2 = Promise.resolve(endpoint);
    return function() {
      return promisified_2;
    };
  }
  return endpoint;
};
var getEndPointFromRegion = function(input) {
  return tslib.exports.__awaiter(void 0, void 0, void 0, function() {
    var _a, tls, region, dnsHostRegex, hostname;
    var _b;
    return tslib.exports.__generator(this, function(_c) {
      switch (_c.label) {
        case 0:
          _a = input.tls, tls = _a === void 0 ? true : _a;
          return [4, input.region()];
        case 1:
          region = _c.sent();
          dnsHostRegex = new RegExp(/^([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9])$/);
          if (!dnsHostRegex.test(region)) {
            throw new Error("Invalid region in client config");
          }
          return [4, input.regionInfoProvider(region)];
        case 2:
          hostname = ((_b = _c.sent()) !== null && _b !== void 0 ? _b : {}).hostname;
          if (!hostname) {
            throw new Error("Cannot resolve hostname from client config");
          }
          return [2, input.urlParser((tls ? "https:" : "http:") + "//" + hostname)];
      }
    });
  });
};
var resolveRegionConfig = function(input) {
  if (!input.region) {
    throw new Error("Region is missing");
  }
  return tslib.exports.__assign(tslib.exports.__assign({}, input), { region: normalizeRegion(input.region) });
};
var normalizeRegion = function(region) {
  if (typeof region === "string") {
    var promisified_1 = Promise.resolve(region);
    return function() {
      return promisified_1;
    };
  }
  return region;
};
var CONTENT_LENGTH_HEADER = "content-length";
function contentLengthMiddleware(bodyLengthChecker) {
  var _this = this;
  return function(next) {
    return function(args) {
      return tslib.exports.__awaiter(_this, void 0, void 0, function() {
        var request, body, headers, length;
        var _a;
        return tslib.exports.__generator(this, function(_b) {
          request = args.request;
          if (HttpRequest.isInstance(request)) {
            body = request.body, headers = request.headers;
            if (body && Object.keys(headers).map(function(str) {
              return str.toLowerCase();
            }).indexOf(CONTENT_LENGTH_HEADER) === -1) {
              length = bodyLengthChecker(body);
              if (length !== void 0) {
                request.headers = tslib.exports.__assign(tslib.exports.__assign({}, request.headers), (_a = {}, _a[CONTENT_LENGTH_HEADER] = String(length), _a));
              }
            }
          }
          return [2, next(tslib.exports.__assign(tslib.exports.__assign({}, args), { request }))];
        });
      });
    };
  };
}
var contentLengthMiddlewareOptions = {
  step: "build",
  tags: ["SET_CONTENT_LENGTH", "CONTENT_LENGTH"],
  name: "contentLengthMiddleware",
  override: true
};
var getContentLengthPlugin = function(options) {
  return {
    applyToStack: function(clientStack) {
      clientStack.add(contentLengthMiddleware(options.bodyLengthChecker), contentLengthMiddlewareOptions);
    }
  };
};
function resolveHostHeaderConfig(input) {
  return input;
}
var hostHeaderMiddleware = function(options) {
  return function(next) {
    return function(args) {
      return tslib.exports.__awaiter(void 0, void 0, void 0, function() {
        var request, _a, handlerProtocol;
        return tslib.exports.__generator(this, function(_b) {
          if (!HttpRequest.isInstance(args.request))
            return [2, next(args)];
          request = args.request;
          _a = (options.requestHandler.metadata || {}).handlerProtocol, handlerProtocol = _a === void 0 ? "" : _a;
          if (handlerProtocol.indexOf("h2") >= 0 && !request.headers[":authority"]) {
            delete request.headers["host"];
            request.headers[":authority"] = "";
          } else if (!request.headers["host"]) {
            request.headers["host"] = request.hostname;
          }
          return [2, next(args)];
        });
      });
    };
  };
};
var hostHeaderMiddlewareOptions = {
  name: "hostHeaderMiddleware",
  step: "build",
  priority: "low",
  tags: ["HOST"],
  override: true
};
var getHostHeaderPlugin = function(options) {
  return {
    applyToStack: function(clientStack) {
      clientStack.add(hostHeaderMiddleware(options), hostHeaderMiddlewareOptions);
    }
  };
};
var loggerMiddleware = function() {
  return function(next, context) {
    return function(args) {
      return tslib.exports.__awaiter(void 0, void 0, void 0, function() {
        var clientName, commandName, inputFilterSensitiveLog, logger2, outputFilterSensitiveLog, response, _a, $metadata, outputWithoutMetadata;
        return tslib.exports.__generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              clientName = context.clientName, commandName = context.commandName, inputFilterSensitiveLog = context.inputFilterSensitiveLog, logger2 = context.logger, outputFilterSensitiveLog = context.outputFilterSensitiveLog;
              return [4, next(args)];
            case 1:
              response = _b.sent();
              if (!logger2) {
                return [2, response];
              }
              if (typeof logger2.info === "function") {
                _a = response.output, $metadata = _a.$metadata, outputWithoutMetadata = tslib.exports.__rest(_a, ["$metadata"]);
                logger2.info({
                  clientName,
                  commandName,
                  input: inputFilterSensitiveLog(args.input),
                  output: outputFilterSensitiveLog(outputWithoutMetadata),
                  metadata: $metadata
                });
              }
              return [2, response];
          }
        });
      });
    };
  };
};
var loggerMiddlewareOptions = {
  name: "loggerMiddleware",
  tags: ["LOGGER"],
  step: "initialize",
  override: true
};
var getLoggerPlugin = function(options) {
  return {
    applyToStack: function(clientStack) {
      clientStack.add(loggerMiddleware(), loggerMiddlewareOptions);
    }
  };
};
var ALGORITHM_QUERY_PARAM = "X-Amz-Algorithm";
var CREDENTIAL_QUERY_PARAM = "X-Amz-Credential";
var AMZ_DATE_QUERY_PARAM = "X-Amz-Date";
var SIGNED_HEADERS_QUERY_PARAM = "X-Amz-SignedHeaders";
var EXPIRES_QUERY_PARAM = "X-Amz-Expires";
var SIGNATURE_QUERY_PARAM = "X-Amz-Signature";
var TOKEN_QUERY_PARAM = "X-Amz-Security-Token";
var AUTH_HEADER = "authorization";
var AMZ_DATE_HEADER = AMZ_DATE_QUERY_PARAM.toLowerCase();
var DATE_HEADER = "date";
var GENERATED_HEADERS = [AUTH_HEADER, AMZ_DATE_HEADER, DATE_HEADER];
var SIGNATURE_HEADER = SIGNATURE_QUERY_PARAM.toLowerCase();
var SHA256_HEADER = "x-amz-content-sha256";
var TOKEN_HEADER = TOKEN_QUERY_PARAM.toLowerCase();
var ALWAYS_UNSIGNABLE_HEADERS = {
  authorization: true,
  "cache-control": true,
  connection: true,
  expect: true,
  from: true,
  "keep-alive": true,
  "max-forwards": true,
  pragma: true,
  referer: true,
  te: true,
  trailer: true,
  "transfer-encoding": true,
  upgrade: true,
  "user-agent": true,
  "x-amzn-trace-id": true
};
var PROXY_HEADER_PATTERN = /^proxy-/;
var SEC_HEADER_PATTERN = /^sec-/;
var ALGORITHM_IDENTIFIER = "AWS4-HMAC-SHA256";
var EVENT_ALGORITHM_IDENTIFIER = "AWS4-HMAC-SHA256-PAYLOAD";
var UNSIGNED_PAYLOAD = "UNSIGNED-PAYLOAD";
var MAX_CACHE_SIZE = 50;
var KEY_TYPE_IDENTIFIER = "aws4_request";
var MAX_PRESIGNED_TTL = 60 * 60 * 24 * 7;
var signingKeyCache = {};
var cacheQueue = [];
function createScope(shortDate, region, service) {
  return shortDate + "/" + region + "/" + service + "/" + KEY_TYPE_IDENTIFIER;
}
var getSigningKey = function(sha256Constructor, credentials, shortDate, region, service) {
  return tslib.exports.__awaiter(void 0, void 0, void 0, function() {
    var credsHash, cacheKey, key, _a, _b, signable, e_1_1;
    var e_1, _c;
    return tslib.exports.__generator(this, function(_d) {
      switch (_d.label) {
        case 0:
          return [4, hmac(sha256Constructor, credentials.secretAccessKey, credentials.accessKeyId)];
        case 1:
          credsHash = _d.sent();
          cacheKey = shortDate + ":" + region + ":" + service + ":" + toHex(credsHash) + ":" + credentials.sessionToken;
          if (cacheKey in signingKeyCache) {
            return [2, signingKeyCache[cacheKey]];
          }
          cacheQueue.push(cacheKey);
          while (cacheQueue.length > MAX_CACHE_SIZE) {
            delete signingKeyCache[cacheQueue.shift()];
          }
          key = "AWS4" + credentials.secretAccessKey;
          _d.label = 2;
        case 2:
          _d.trys.push([2, 7, 8, 9]);
          _a = tslib.exports.__values([shortDate, region, service, KEY_TYPE_IDENTIFIER]), _b = _a.next();
          _d.label = 3;
        case 3:
          if (!!_b.done)
            return [3, 6];
          signable = _b.value;
          return [4, hmac(sha256Constructor, key, signable)];
        case 4:
          key = _d.sent();
          _d.label = 5;
        case 5:
          _b = _a.next();
          return [3, 3];
        case 6:
          return [3, 9];
        case 7:
          e_1_1 = _d.sent();
          e_1 = { error: e_1_1 };
          return [3, 9];
        case 8:
          try {
            if (_b && !_b.done && (_c = _a.return))
              _c.call(_a);
          } finally {
            if (e_1)
              throw e_1.error;
          }
          return [7];
        case 9:
          return [2, signingKeyCache[cacheKey] = key];
      }
    });
  });
};
function hmac(ctor, secret, data) {
  var hash = new ctor(secret);
  hash.update(data);
  return hash.digest();
}
function getCanonicalHeaders(_a, unsignableHeaders, signableHeaders) {
  var e_1, _b;
  var headers = _a.headers;
  var canonical = {};
  try {
    for (var _c = tslib.exports.__values(Object.keys(headers).sort()), _d = _c.next(); !_d.done; _d = _c.next()) {
      var headerName = _d.value;
      var canonicalHeaderName = headerName.toLowerCase();
      if (canonicalHeaderName in ALWAYS_UNSIGNABLE_HEADERS || (unsignableHeaders === null || unsignableHeaders === void 0 ? void 0 : unsignableHeaders.has(canonicalHeaderName)) || PROXY_HEADER_PATTERN.test(canonicalHeaderName) || SEC_HEADER_PATTERN.test(canonicalHeaderName)) {
        if (!signableHeaders || signableHeaders && !signableHeaders.has(canonicalHeaderName)) {
          continue;
        }
      }
      canonical[canonicalHeaderName] = headers[headerName].trim().replace(/\s+/g, " ");
    }
  } catch (e_1_1) {
    e_1 = { error: e_1_1 };
  } finally {
    try {
      if (_d && !_d.done && (_b = _c.return))
        _b.call(_c);
    } finally {
      if (e_1)
        throw e_1.error;
    }
  }
  return canonical;
}
function getCanonicalQuery(_a) {
  var e_1, _b;
  var _c = _a.query, query = _c === void 0 ? {} : _c;
  var keys = [];
  var serialized = {};
  var _loop_1 = function(key2) {
    if (key2.toLowerCase() === SIGNATURE_HEADER) {
      return "continue";
    }
    keys.push(key2);
    var value = query[key2];
    if (typeof value === "string") {
      serialized[key2] = escapeUri(key2) + "=" + escapeUri(value);
    } else if (Array.isArray(value)) {
      serialized[key2] = value.slice(0).sort().reduce(function(encoded, value2) {
        return encoded.concat([escapeUri(key2) + "=" + escapeUri(value2)]);
      }, []).join("&");
    }
  };
  try {
    for (var _d = tslib.exports.__values(Object.keys(query).sort()), _e = _d.next(); !_e.done; _e = _d.next()) {
      var key = _e.value;
      _loop_1(key);
    }
  } catch (e_1_1) {
    e_1 = { error: e_1_1 };
  } finally {
    try {
      if (_e && !_e.done && (_b = _d.return))
        _b.call(_d);
    } finally {
      if (e_1)
        throw e_1.error;
    }
  }
  return keys.map(function(key2) {
    return serialized[key2];
  }).filter(function(serialized2) {
    return serialized2;
  }).join("&");
}
var isArrayBuffer = function(arg) {
  return typeof ArrayBuffer === "function" && arg instanceof ArrayBuffer || Object.prototype.toString.call(arg) === "[object ArrayBuffer]";
};
function getPayloadHash(_a, hashConstructor) {
  var headers = _a.headers, body = _a.body;
  return tslib.exports.__awaiter(this, void 0, void 0, function() {
    var _b, _c, headerName, hashCtor, _d;
    var e_1, _e;
    return tslib.exports.__generator(this, function(_f) {
      switch (_f.label) {
        case 0:
          try {
            for (_b = tslib.exports.__values(Object.keys(headers)), _c = _b.next(); !_c.done; _c = _b.next()) {
              headerName = _c.value;
              if (headerName.toLowerCase() === SHA256_HEADER) {
                return [2, headers[headerName]];
              }
            }
          } catch (e_1_1) {
            e_1 = { error: e_1_1 };
          } finally {
            try {
              if (_c && !_c.done && (_e = _b.return))
                _e.call(_b);
            } finally {
              if (e_1)
                throw e_1.error;
            }
          }
          if (!(body == void 0))
            return [3, 1];
          return [2, "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"];
        case 1:
          if (!(typeof body === "string" || ArrayBuffer.isView(body) || isArrayBuffer(body)))
            return [3, 3];
          hashCtor = new hashConstructor();
          hashCtor.update(body);
          _d = toHex;
          return [4, hashCtor.digest()];
        case 2:
          return [2, _d.apply(void 0, [_f.sent()])];
        case 3:
          return [2, UNSIGNED_PAYLOAD];
      }
    });
  });
}
function hasHeader(soughtHeader, headers) {
  var e_1, _a;
  soughtHeader = soughtHeader.toLowerCase();
  try {
    for (var _b = tslib.exports.__values(Object.keys(headers)), _c = _b.next(); !_c.done; _c = _b.next()) {
      var headerName = _c.value;
      if (soughtHeader === headerName.toLowerCase()) {
        return true;
      }
    }
  } catch (e_1_1) {
    e_1 = { error: e_1_1 };
  } finally {
    try {
      if (_c && !_c.done && (_a = _b.return))
        _a.call(_b);
    } finally {
      if (e_1)
        throw e_1.error;
    }
  }
  return false;
}
function cloneRequest(_a) {
  var headers = _a.headers, query = _a.query, rest = tslib.exports.__rest(_a, ["headers", "query"]);
  return tslib.exports.__assign(tslib.exports.__assign({}, rest), { headers: tslib.exports.__assign({}, headers), query: query ? cloneQuery(query) : void 0 });
}
function cloneQuery(query) {
  return Object.keys(query).reduce(function(carry, paramName) {
    var _a;
    var param = query[paramName];
    return tslib.exports.__assign(tslib.exports.__assign({}, carry), (_a = {}, _a[paramName] = Array.isArray(param) ? tslib.exports.__spread(param) : param, _a));
  }, {});
}
function moveHeadersToQuery(request, options) {
  var e_1, _a;
  var _b;
  if (options === void 0) {
    options = {};
  }
  var _c = typeof request.clone === "function" ? request.clone() : cloneRequest(request), headers = _c.headers, _d = _c.query, query = _d === void 0 ? {} : _d;
  try {
    for (var _e = tslib.exports.__values(Object.keys(headers)), _f = _e.next(); !_f.done; _f = _e.next()) {
      var name2 = _f.value;
      var lname = name2.toLowerCase();
      if (lname.substr(0, 6) === "x-amz-" && !((_b = options.unhoistableHeaders) === null || _b === void 0 ? void 0 : _b.has(lname))) {
        query[name2] = headers[name2];
        delete headers[name2];
      }
    }
  } catch (e_1_1) {
    e_1 = { error: e_1_1 };
  } finally {
    try {
      if (_f && !_f.done && (_a = _e.return))
        _a.call(_e);
    } finally {
      if (e_1)
        throw e_1.error;
    }
  }
  return tslib.exports.__assign(tslib.exports.__assign({}, request), {
    headers,
    query
  });
}
function prepareRequest(request) {
  var e_1, _a;
  request = typeof request.clone === "function" ? request.clone() : cloneRequest(request);
  try {
    for (var _b = tslib.exports.__values(Object.keys(request.headers)), _c = _b.next(); !_c.done; _c = _b.next()) {
      var headerName = _c.value;
      if (GENERATED_HEADERS.indexOf(headerName.toLowerCase()) > -1) {
        delete request.headers[headerName];
      }
    }
  } catch (e_1_1) {
    e_1 = { error: e_1_1 };
  } finally {
    try {
      if (_c && !_c.done && (_a = _b.return))
        _a.call(_b);
    } finally {
      if (e_1)
        throw e_1.error;
    }
  }
  return request;
}
function iso8601(time) {
  return toDate(time).toISOString().replace(/\.\d{3}Z$/, "Z");
}
function toDate(time) {
  if (typeof time === "number") {
    return new Date(time * 1e3);
  }
  if (typeof time === "string") {
    if (Number(time)) {
      return new Date(Number(time) * 1e3);
    }
    return new Date(time);
  }
  return time;
}
var SignatureV4 = function() {
  function SignatureV42(_a) {
    var applyChecksum = _a.applyChecksum, credentials = _a.credentials, region = _a.region, service = _a.service, sha256 = _a.sha256, _b = _a.uriEscapePath, uriEscapePath = _b === void 0 ? true : _b;
    this.service = service;
    this.sha256 = sha256;
    this.uriEscapePath = uriEscapePath;
    this.applyChecksum = typeof applyChecksum === "boolean" ? applyChecksum : true;
    this.regionProvider = normalizeRegionProvider(region);
    this.credentialProvider = normalizeCredentialsProvider(credentials);
  }
  SignatureV42.prototype.presign = function(originalRequest, options) {
    if (options === void 0) {
      options = {};
    }
    return tslib.exports.__awaiter(this, void 0, void 0, function() {
      var _a, signingDate, _b, expiresIn, unsignableHeaders, unhoistableHeaders, signableHeaders, signingRegion, signingService, credentials, region, _c, _d, longDate, shortDate, scope, request, canonicalHeaders, _e, _f, _g, _h, _j, _k;
      return tslib.exports.__generator(this, function(_l) {
        switch (_l.label) {
          case 0:
            _a = options.signingDate, signingDate = _a === void 0 ? new Date() : _a, _b = options.expiresIn, expiresIn = _b === void 0 ? 3600 : _b, unsignableHeaders = options.unsignableHeaders, unhoistableHeaders = options.unhoistableHeaders, signableHeaders = options.signableHeaders, signingRegion = options.signingRegion, signingService = options.signingService;
            return [4, this.credentialProvider()];
          case 1:
            credentials = _l.sent();
            if (!(signingRegion !== null && signingRegion !== void 0))
              return [3, 2];
            _c = signingRegion;
            return [3, 4];
          case 2:
            return [4, this.regionProvider()];
          case 3:
            _c = _l.sent();
            _l.label = 4;
          case 4:
            region = _c;
            _d = formatDate(signingDate), longDate = _d.longDate, shortDate = _d.shortDate;
            if (expiresIn > MAX_PRESIGNED_TTL) {
              return [2, Promise.reject("Signature version 4 presigned URLs must have an expiration date less than one week in the future")];
            }
            scope = createScope(shortDate, region, signingService !== null && signingService !== void 0 ? signingService : this.service);
            request = moveHeadersToQuery(prepareRequest(originalRequest), { unhoistableHeaders });
            if (credentials.sessionToken) {
              request.query[TOKEN_QUERY_PARAM] = credentials.sessionToken;
            }
            request.query[ALGORITHM_QUERY_PARAM] = ALGORITHM_IDENTIFIER;
            request.query[CREDENTIAL_QUERY_PARAM] = credentials.accessKeyId + "/" + scope;
            request.query[AMZ_DATE_QUERY_PARAM] = longDate;
            request.query[EXPIRES_QUERY_PARAM] = expiresIn.toString(10);
            canonicalHeaders = getCanonicalHeaders(request, unsignableHeaders, signableHeaders);
            request.query[SIGNED_HEADERS_QUERY_PARAM] = getCanonicalHeaderList(canonicalHeaders);
            _e = request.query;
            _f = SIGNATURE_QUERY_PARAM;
            _g = this.getSignature;
            _h = [
              longDate,
              scope,
              this.getSigningKey(credentials, region, shortDate, signingService)
            ];
            _j = this.createCanonicalRequest;
            _k = [request, canonicalHeaders];
            return [4, getPayloadHash(originalRequest, this.sha256)];
          case 5:
            return [4, _g.apply(this, _h.concat([_j.apply(this, _k.concat([_l.sent()]))]))];
          case 6:
            _e[_f] = _l.sent();
            return [2, request];
        }
      });
    });
  };
  SignatureV42.prototype.sign = function(toSign, options) {
    return tslib.exports.__awaiter(this, void 0, void 0, function() {
      return tslib.exports.__generator(this, function(_a) {
        if (typeof toSign === "string") {
          return [2, this.signString(toSign, options)];
        } else if (toSign.headers && toSign.payload) {
          return [2, this.signEvent(toSign, options)];
        } else {
          return [2, this.signRequest(toSign, options)];
        }
      });
    });
  };
  SignatureV42.prototype.signEvent = function(_a, _b) {
    var headers = _a.headers, payload = _a.payload;
    var _c = _b.signingDate, signingDate = _c === void 0 ? new Date() : _c, priorSignature = _b.priorSignature, signingRegion = _b.signingRegion, signingService = _b.signingService;
    return tslib.exports.__awaiter(this, void 0, void 0, function() {
      var region, _d, _e, shortDate, longDate, scope, hashedPayload, hash, hashedHeaders, _f, stringToSign;
      return tslib.exports.__generator(this, function(_g) {
        switch (_g.label) {
          case 0:
            if (!(signingRegion !== null && signingRegion !== void 0))
              return [3, 1];
            _d = signingRegion;
            return [3, 3];
          case 1:
            return [4, this.regionProvider()];
          case 2:
            _d = _g.sent();
            _g.label = 3;
          case 3:
            region = _d;
            _e = formatDate(signingDate), shortDate = _e.shortDate, longDate = _e.longDate;
            scope = createScope(shortDate, region, signingService !== null && signingService !== void 0 ? signingService : this.service);
            return [4, getPayloadHash({ headers: {}, body: payload }, this.sha256)];
          case 4:
            hashedPayload = _g.sent();
            hash = new this.sha256();
            hash.update(headers);
            _f = toHex;
            return [4, hash.digest()];
          case 5:
            hashedHeaders = _f.apply(void 0, [_g.sent()]);
            stringToSign = [
              EVENT_ALGORITHM_IDENTIFIER,
              longDate,
              scope,
              priorSignature,
              hashedHeaders,
              hashedPayload
            ].join("\n");
            return [2, this.signString(stringToSign, { signingDate, signingRegion: region, signingService })];
        }
      });
    });
  };
  SignatureV42.prototype.signString = function(stringToSign, _a) {
    var _b = _a === void 0 ? {} : _a, _c = _b.signingDate, signingDate = _c === void 0 ? new Date() : _c, signingRegion = _b.signingRegion, signingService = _b.signingService;
    return tslib.exports.__awaiter(this, void 0, void 0, function() {
      var credentials, region, _d, shortDate, hash, _e, _f, _g;
      return tslib.exports.__generator(this, function(_h) {
        switch (_h.label) {
          case 0:
            return [4, this.credentialProvider()];
          case 1:
            credentials = _h.sent();
            if (!(signingRegion !== null && signingRegion !== void 0))
              return [3, 2];
            _d = signingRegion;
            return [3, 4];
          case 2:
            return [4, this.regionProvider()];
          case 3:
            _d = _h.sent();
            _h.label = 4;
          case 4:
            region = _d;
            shortDate = formatDate(signingDate).shortDate;
            _f = (_e = this.sha256).bind;
            return [4, this.getSigningKey(credentials, region, shortDate, signingService)];
          case 5:
            hash = new (_f.apply(_e, [void 0, _h.sent()]))();
            hash.update(stringToSign);
            _g = toHex;
            return [4, hash.digest()];
          case 6:
            return [2, _g.apply(void 0, [_h.sent()])];
        }
      });
    });
  };
  SignatureV42.prototype.signRequest = function(requestToSign, _a) {
    var _b = _a === void 0 ? {} : _a, _c = _b.signingDate, signingDate = _c === void 0 ? new Date() : _c, signableHeaders = _b.signableHeaders, unsignableHeaders = _b.unsignableHeaders, signingRegion = _b.signingRegion, signingService = _b.signingService;
    return tslib.exports.__awaiter(this, void 0, void 0, function() {
      var credentials, region, _d, request, _e, longDate, shortDate, scope, payloadHash, canonicalHeaders, signature;
      return tslib.exports.__generator(this, function(_f) {
        switch (_f.label) {
          case 0:
            return [4, this.credentialProvider()];
          case 1:
            credentials = _f.sent();
            if (!(signingRegion !== null && signingRegion !== void 0))
              return [3, 2];
            _d = signingRegion;
            return [3, 4];
          case 2:
            return [4, this.regionProvider()];
          case 3:
            _d = _f.sent();
            _f.label = 4;
          case 4:
            region = _d;
            request = prepareRequest(requestToSign);
            _e = formatDate(signingDate), longDate = _e.longDate, shortDate = _e.shortDate;
            scope = createScope(shortDate, region, signingService !== null && signingService !== void 0 ? signingService : this.service);
            request.headers[AMZ_DATE_HEADER] = longDate;
            if (credentials.sessionToken) {
              request.headers[TOKEN_HEADER] = credentials.sessionToken;
            }
            return [4, getPayloadHash(request, this.sha256)];
          case 5:
            payloadHash = _f.sent();
            if (!hasHeader(SHA256_HEADER, request.headers) && this.applyChecksum) {
              request.headers[SHA256_HEADER] = payloadHash;
            }
            canonicalHeaders = getCanonicalHeaders(request, unsignableHeaders, signableHeaders);
            return [4, this.getSignature(longDate, scope, this.getSigningKey(credentials, region, shortDate, signingService), this.createCanonicalRequest(request, canonicalHeaders, payloadHash))];
          case 6:
            signature = _f.sent();
            request.headers[AUTH_HEADER] = ALGORITHM_IDENTIFIER + " " + ("Credential=" + credentials.accessKeyId + "/" + scope + ", ") + ("SignedHeaders=" + getCanonicalHeaderList(canonicalHeaders) + ", ") + ("Signature=" + signature);
            return [2, request];
        }
      });
    });
  };
  SignatureV42.prototype.createCanonicalRequest = function(request, canonicalHeaders, payloadHash) {
    var sortedHeaders = Object.keys(canonicalHeaders).sort();
    return request.method + "\n" + this.getCanonicalPath(request) + "\n" + getCanonicalQuery(request) + "\n" + sortedHeaders.map(function(name2) {
      return name2 + ":" + canonicalHeaders[name2];
    }).join("\n") + "\n\n" + sortedHeaders.join(";") + "\n" + payloadHash;
  };
  SignatureV42.prototype.createStringToSign = function(longDate, credentialScope, canonicalRequest) {
    return tslib.exports.__awaiter(this, void 0, void 0, function() {
      var hash, hashedRequest;
      return tslib.exports.__generator(this, function(_a) {
        switch (_a.label) {
          case 0:
            hash = new this.sha256();
            hash.update(canonicalRequest);
            return [4, hash.digest()];
          case 1:
            hashedRequest = _a.sent();
            return [2, ALGORITHM_IDENTIFIER + "\n" + longDate + "\n" + credentialScope + "\n" + toHex(hashedRequest)];
        }
      });
    });
  };
  SignatureV42.prototype.getCanonicalPath = function(_a) {
    var path = _a.path;
    if (this.uriEscapePath) {
      var doubleEncoded = encodeURIComponent(path.replace(/^\//, ""));
      return "/" + doubleEncoded.replace(/%2F/g, "/");
    }
    return path;
  };
  SignatureV42.prototype.getSignature = function(longDate, credentialScope, keyPromise, canonicalRequest) {
    return tslib.exports.__awaiter(this, void 0, void 0, function() {
      var stringToSign, hash, _a, _b, _c;
      return tslib.exports.__generator(this, function(_d) {
        switch (_d.label) {
          case 0:
            return [4, this.createStringToSign(longDate, credentialScope, canonicalRequest)];
          case 1:
            stringToSign = _d.sent();
            _b = (_a = this.sha256).bind;
            return [4, keyPromise];
          case 2:
            hash = new (_b.apply(_a, [void 0, _d.sent()]))();
            hash.update(stringToSign);
            _c = toHex;
            return [4, hash.digest()];
          case 3:
            return [2, _c.apply(void 0, [_d.sent()])];
        }
      });
    });
  };
  SignatureV42.prototype.getSigningKey = function(credentials, region, shortDate, service) {
    return getSigningKey(this.sha256, credentials, shortDate, region, service || this.service);
  };
  return SignatureV42;
}();
var formatDate = function(now) {
  var longDate = iso8601(now).replace(/[\-:]/g, "");
  return {
    longDate,
    shortDate: longDate.substr(0, 8)
  };
};
var getCanonicalHeaderList = function(headers) {
  return Object.keys(headers).sort().join(";");
};
var normalizeRegionProvider = function(region) {
  if (typeof region === "string") {
    var promisified_1 = Promise.resolve(region);
    return function() {
      return promisified_1;
    };
  } else {
    return region;
  }
};
var normalizeCredentialsProvider = function(credentials) {
  if (typeof credentials === "object") {
    var promisified_2 = Promise.resolve(credentials);
    return function() {
      return promisified_2;
    };
  } else {
    return credentials;
  }
};
function resolveAwsAuthConfig(input) {
  var _this = this;
  var credentials = input.credentials || input.credentialDefaultProvider(input);
  var normalizedCreds = normalizeProvider(credentials);
  var _a = input.signingEscapePath, signingEscapePath = _a === void 0 ? true : _a, _b = input.systemClockOffset, systemClockOffset = _b === void 0 ? input.systemClockOffset || 0 : _b, sha256 = input.sha256;
  var signer;
  if (input.signer) {
    signer = normalizeProvider(input.signer);
  } else {
    signer = function() {
      return normalizeProvider(input.region)().then(function(region) {
        return tslib.exports.__awaiter(_this, void 0, void 0, function() {
          return tslib.exports.__generator(this, function(_a2) {
            switch (_a2.label) {
              case 0:
                return [4, input.regionInfoProvider(region)];
              case 1:
                return [2, [_a2.sent() || {}, region]];
            }
          });
        });
      }).then(function(_a2) {
        var _b2 = tslib.exports.__read(_a2, 2), regionInfo = _b2[0], region = _b2[1];
        var signingRegion = regionInfo.signingRegion, signingService = regionInfo.signingService;
        input.signingRegion = input.signingRegion || signingRegion || region;
        input.signingName = input.signingName || signingService || input.serviceId;
        return new SignatureV4({
          credentials: normalizedCreds,
          region: input.signingRegion,
          service: input.signingName,
          sha256,
          uriEscapePath: signingEscapePath
        });
      });
    };
  }
  return tslib.exports.__assign(tslib.exports.__assign({}, input), {
    systemClockOffset,
    signingEscapePath,
    credentials: normalizedCreds,
    signer
  });
}
function normalizeProvider(input) {
  if (typeof input === "object") {
    var promisified_1 = Promise.resolve(input);
    return function() {
      return promisified_1;
    };
  }
  return input;
}
function resolveUserAgentConfig(input) {
  return tslib.exports.__assign(tslib.exports.__assign({}, input), { customUserAgent: typeof input.customUserAgent === "string" ? [[input.customUserAgent]] : input.customUserAgent });
}
var USER_AGENT = "user-agent";
var X_AMZ_USER_AGENT = "x-amz-user-agent";
var SPACE = " ";
var UA_ESCAPE_REGEX = /[^\!\#\$\%\&\'\*\+\-\.\^\_\`\|\~\d\w]/g;
var userAgentMiddleware = function(options) {
  return function(next, context) {
    return function(args) {
      return tslib.exports.__awaiter(void 0, void 0, void 0, function() {
        var request, headers, userAgent, defaultUserAgent2, customUserAgent, normalUAValue;
        var _a, _b;
        return tslib.exports.__generator(this, function(_c) {
          switch (_c.label) {
            case 0:
              request = args.request;
              if (!HttpRequest.isInstance(request))
                return [2, next(args)];
              headers = request.headers;
              userAgent = ((_a = context === null || context === void 0 ? void 0 : context.userAgent) === null || _a === void 0 ? void 0 : _a.map(escapeUserAgent)) || [];
              return [4, options.defaultUserAgentProvider()];
            case 1:
              defaultUserAgent2 = _c.sent().map(escapeUserAgent);
              customUserAgent = ((_b = options === null || options === void 0 ? void 0 : options.customUserAgent) === null || _b === void 0 ? void 0 : _b.map(escapeUserAgent)) || [];
              headers[X_AMZ_USER_AGENT] = tslib.exports.__spread(defaultUserAgent2, userAgent, customUserAgent).join(SPACE);
              normalUAValue = tslib.exports.__spread(defaultUserAgent2.filter(function(section) {
                return section.startsWith("aws-sdk-");
              }), customUserAgent).join(SPACE);
              if (options.runtime !== "browser" && normalUAValue) {
                headers[USER_AGENT] = headers[USER_AGENT] ? headers[USER_AGENT] + " " + normalUAValue : normalUAValue;
              }
              return [2, next(tslib.exports.__assign(tslib.exports.__assign({}, args), { request }))];
          }
        });
      });
    };
  };
};
var escapeUserAgent = function(_a) {
  var _b = tslib.exports.__read(_a, 2), name2 = _b[0], version2 = _b[1];
  var prefixSeparatorIndex = name2.indexOf("/");
  var prefix = name2.substring(0, prefixSeparatorIndex);
  var uaName = name2.substring(prefixSeparatorIndex + 1);
  if (prefix === "api") {
    uaName = uaName.toLowerCase();
  }
  return [prefix, uaName, version2].filter(function(item) {
    return item && item.length > 0;
  }).map(function(item) {
    return item === null || item === void 0 ? void 0 : item.replace(UA_ESCAPE_REGEX, "_");
  }).join("/");
};
var getUserAgentMiddlewareOptions = {
  name: "getUserAgentMiddleware",
  step: "build",
  priority: "low",
  tags: ["SET_USER_AGENT", "USER_AGENT"],
  override: true
};
var getUserAgentPlugin = function(config) {
  return {
    applyToStack: function(clientStack) {
      clientStack.add(userAgentMiddleware(config), getUserAgentMiddlewareOptions);
    }
  };
};
var constructStack = function() {
  var absoluteEntries = [];
  var relativeEntries = [];
  var entriesNameSet = /* @__PURE__ */ new Set();
  var sort = function(entries) {
    return entries.sort(function(a, b) {
      return stepWeights[b.step] - stepWeights[a.step] || priorityWeights[b.priority || "normal"] - priorityWeights[a.priority || "normal"];
    });
  };
  var removeByName = function(toRemove) {
    var isRemoved = false;
    var filterCb = function(entry) {
      if (entry.name && entry.name === toRemove) {
        isRemoved = true;
        entriesNameSet.delete(toRemove);
        return false;
      }
      return true;
    };
    absoluteEntries = absoluteEntries.filter(filterCb);
    relativeEntries = relativeEntries.filter(filterCb);
    return isRemoved;
  };
  var removeByReference = function(toRemove) {
    var isRemoved = false;
    var filterCb = function(entry) {
      if (entry.middleware === toRemove) {
        isRemoved = true;
        if (entry.name)
          entriesNameSet.delete(entry.name);
        return false;
      }
      return true;
    };
    absoluteEntries = absoluteEntries.filter(filterCb);
    relativeEntries = relativeEntries.filter(filterCb);
    return isRemoved;
  };
  var cloneTo = function(toStack) {
    absoluteEntries.forEach(function(entry) {
      toStack.add(entry.middleware, tslib.exports.__assign({}, entry));
    });
    relativeEntries.forEach(function(entry) {
      toStack.addRelativeTo(entry.middleware, tslib.exports.__assign({}, entry));
    });
    return toStack;
  };
  var expandRelativeMiddlewareList = function(from) {
    var expandedMiddlewareList = [];
    from.before.forEach(function(entry) {
      if (entry.before.length === 0 && entry.after.length === 0) {
        expandedMiddlewareList.push(entry);
      } else {
        expandedMiddlewareList.push.apply(expandedMiddlewareList, tslib.exports.__spread(expandRelativeMiddlewareList(entry)));
      }
    });
    expandedMiddlewareList.push(from);
    from.after.reverse().forEach(function(entry) {
      if (entry.before.length === 0 && entry.after.length === 0) {
        expandedMiddlewareList.push(entry);
      } else {
        expandedMiddlewareList.push.apply(expandedMiddlewareList, tslib.exports.__spread(expandRelativeMiddlewareList(entry)));
      }
    });
    return expandedMiddlewareList;
  };
  var getMiddlewareList = function() {
    var normalizedAbsoluteEntries = [];
    var normalizedRelativeEntries = [];
    var normalizedEntriesNameMap = {};
    absoluteEntries.forEach(function(entry) {
      var normalizedEntry = tslib.exports.__assign(tslib.exports.__assign({}, entry), { before: [], after: [] });
      if (normalizedEntry.name)
        normalizedEntriesNameMap[normalizedEntry.name] = normalizedEntry;
      normalizedAbsoluteEntries.push(normalizedEntry);
    });
    relativeEntries.forEach(function(entry) {
      var normalizedEntry = tslib.exports.__assign(tslib.exports.__assign({}, entry), { before: [], after: [] });
      if (normalizedEntry.name)
        normalizedEntriesNameMap[normalizedEntry.name] = normalizedEntry;
      normalizedRelativeEntries.push(normalizedEntry);
    });
    normalizedRelativeEntries.forEach(function(entry) {
      if (entry.toMiddleware) {
        var toMiddleware = normalizedEntriesNameMap[entry.toMiddleware];
        if (toMiddleware === void 0) {
          throw new Error(entry.toMiddleware + " is not found when adding " + (entry.name || "anonymous") + " middleware " + entry.relation + " " + entry.toMiddleware);
        }
        if (entry.relation === "after") {
          toMiddleware.after.push(entry);
        }
        if (entry.relation === "before") {
          toMiddleware.before.push(entry);
        }
      }
    });
    var mainChain = sort(normalizedAbsoluteEntries).map(expandRelativeMiddlewareList).reduce(function(wholeList, expendedMiddlewareList) {
      wholeList.push.apply(wholeList, tslib.exports.__spread(expendedMiddlewareList));
      return wholeList;
    }, []);
    return mainChain.map(function(entry) {
      return entry.middleware;
    });
  };
  var stack = {
    add: function(middleware, options) {
      if (options === void 0) {
        options = {};
      }
      var name2 = options.name, override = options.override;
      var entry = tslib.exports.__assign({ step: "initialize", priority: "normal", middleware }, options);
      if (name2) {
        if (entriesNameSet.has(name2)) {
          if (!override)
            throw new Error("Duplicate middleware name '" + name2 + "'");
          var toOverrideIndex = absoluteEntries.findIndex(function(entry2) {
            return entry2.name === name2;
          });
          var toOverride = absoluteEntries[toOverrideIndex];
          if (toOverride.step !== entry.step || toOverride.priority !== entry.priority) {
            throw new Error('"' + name2 + '" middleware with ' + toOverride.priority + " priority in " + toOverride.step + " step cannot be " + ("overridden by same-name middleware with " + entry.priority + " priority in " + entry.step + " step."));
          }
          absoluteEntries.splice(toOverrideIndex, 1);
        }
        entriesNameSet.add(name2);
      }
      absoluteEntries.push(entry);
    },
    addRelativeTo: function(middleware, options) {
      var name2 = options.name, override = options.override;
      var entry = tslib.exports.__assign({ middleware }, options);
      if (name2) {
        if (entriesNameSet.has(name2)) {
          if (!override)
            throw new Error("Duplicate middleware name '" + name2 + "'");
          var toOverrideIndex = relativeEntries.findIndex(function(entry2) {
            return entry2.name === name2;
          });
          var toOverride = relativeEntries[toOverrideIndex];
          if (toOverride.toMiddleware !== entry.toMiddleware || toOverride.relation !== entry.relation) {
            throw new Error('"' + name2 + '" middleware ' + toOverride.relation + ' "' + toOverride.toMiddleware + '" middleware cannot be overridden ' + ("by same-name middleware " + entry.relation + ' "' + entry.toMiddleware + '" middleware.'));
          }
          relativeEntries.splice(toOverrideIndex, 1);
        }
        entriesNameSet.add(name2);
      }
      relativeEntries.push(entry);
    },
    clone: function() {
      return cloneTo(constructStack());
    },
    use: function(plugin) {
      plugin.applyToStack(stack);
    },
    remove: function(toRemove) {
      if (typeof toRemove === "string")
        return removeByName(toRemove);
      else
        return removeByReference(toRemove);
    },
    removeByTag: function(toRemove) {
      var isRemoved = false;
      var filterCb = function(entry) {
        var tags = entry.tags, name2 = entry.name;
        if (tags && tags.includes(toRemove)) {
          if (name2)
            entriesNameSet.delete(name2);
          isRemoved = true;
          return false;
        }
        return true;
      };
      absoluteEntries = absoluteEntries.filter(filterCb);
      relativeEntries = relativeEntries.filter(filterCb);
      return isRemoved;
    },
    concat: function(from) {
      var cloned = cloneTo(constructStack());
      cloned.use(from);
      return cloned;
    },
    applyToStack: cloneTo,
    resolve: function(handler, context) {
      var e_1, _a;
      try {
        for (var _b = tslib.exports.__values(getMiddlewareList().reverse()), _c = _b.next(); !_c.done; _c = _b.next()) {
          var middleware = _c.value;
          handler = middleware(handler, context);
        }
      } catch (e_1_1) {
        e_1 = { error: e_1_1 };
      } finally {
        try {
          if (_c && !_c.done && (_a = _b.return))
            _a.call(_b);
        } finally {
          if (e_1)
            throw e_1.error;
        }
      }
      return handler;
    }
  };
  return stack;
};
var stepWeights = {
  initialize: 5,
  serialize: 4,
  build: 3,
  finalizeRequest: 2,
  deserialize: 1
};
var priorityWeights = {
  high: 3,
  normal: 2,
  low: 1
};
var Client = function() {
  function Client2(config) {
    this.middlewareStack = constructStack();
    this.config = config;
  }
  Client2.prototype.send = function(command, optionsOrCb, cb) {
    var options = typeof optionsOrCb !== "function" ? optionsOrCb : void 0;
    var callback = typeof optionsOrCb === "function" ? optionsOrCb : cb;
    var handler = command.resolveMiddleware(this.middlewareStack, this.config, options);
    if (callback) {
      handler(command).then(function(result) {
        return callback(null, result.output);
      }, function(err) {
        return callback(err);
      }).catch(
        function() {
        }
      );
    } else {
      return handler(command).then(function(result) {
        return result.output;
      });
    }
  };
  Client2.prototype.destroy = function() {
    if (this.config.requestHandler.destroy)
      this.config.requestHandler.destroy();
  };
  return Client2;
}();
var Command = function() {
  function Command2() {
    this.middlewareStack = constructStack();
  }
  return Command2;
}();
var StringWrapper = function() {
  var Class = Object.getPrototypeOf(this).constructor;
  var Constructor = Function.bind.apply(String, tslib.exports.__spread([null], arguments));
  var instance = new Constructor();
  Object.setPrototypeOf(instance, Class.prototype);
  return instance;
};
StringWrapper.prototype = Object.create(String.prototype, {
  constructor: {
    value: StringWrapper,
    enumerable: false,
    writable: true,
    configurable: true
  }
});
Object.setPrototypeOf(StringWrapper, String);
(function(_super) {
  tslib.exports.__extends(LazyJsonString, _super);
  function LazyJsonString() {
    return _super !== null && _super.apply(this, arguments) || this;
  }
  LazyJsonString.prototype.deserializeJSON = function() {
    return JSON.parse(_super.prototype.toString.call(this));
  };
  LazyJsonString.prototype.toJSON = function() {
    return _super.prototype.toString.call(this);
  };
  LazyJsonString.fromObject = function(object) {
    if (object instanceof LazyJsonString) {
      return object;
    } else if (object instanceof String || typeof object === "string") {
      return new LazyJsonString(object);
    }
    return new LazyJsonString(JSON.stringify(object));
  };
  return LazyJsonString;
})(StringWrapper);
var deserializerMiddleware = function(options, deserializer) {
  return function(next, context) {
    return function(args) {
      return tslib.exports.__awaiter(void 0, void 0, void 0, function() {
        var response, parsed;
        return tslib.exports.__generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              return [4, next(args)];
            case 1:
              response = _a.sent().response;
              return [4, deserializer(response, options)];
            case 2:
              parsed = _a.sent();
              return [2, {
                response,
                output: parsed
              }];
          }
        });
      });
    };
  };
};
var serializerMiddleware = function(options, serializer) {
  return function(next, context) {
    return function(args) {
      return tslib.exports.__awaiter(void 0, void 0, void 0, function() {
        var request;
        return tslib.exports.__generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              return [4, serializer(args.input, options)];
            case 1:
              request = _a.sent();
              return [2, next(tslib.exports.__assign(tslib.exports.__assign({}, args), { request }))];
          }
        });
      });
    };
  };
};
var deserializerMiddlewareOption = {
  name: "deserializerMiddleware",
  step: "deserialize",
  tags: ["DESERIALIZER"],
  override: true
};
var serializerMiddlewareOption = {
  name: "serializerMiddleware",
  step: "serialize",
  tags: ["SERIALIZER"],
  override: true
};
function getSerdePlugin(config, serializer, deserializer) {
  return {
    applyToStack: function(commandStack) {
      commandStack.add(deserializerMiddleware(config, deserializer), deserializerMiddlewareOption);
      commandStack.add(serializerMiddleware(config, serializer), serializerMiddlewareOption);
    }
  };
}
var __awaiter$3 = globalThis && globalThis.__awaiter || function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator$3 = globalThis && globalThis.__generator || function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1)
      throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f)
      throw new TypeError("Generator is already executing.");
    while (_)
      try {
        if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
          return t;
        if (y = 0, t)
          op = [op[0] & 2, t.value];
        switch (op[0]) {
          case 0:
          case 1:
            t = op;
            break;
          case 4:
            _.label++;
            return { value: op[1], done: false };
          case 5:
            _.label++;
            y = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            if (t[2])
              _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e) {
        op = [6, e];
        y = 0;
      } finally {
        f = t = 0;
      }
    if (op[0] & 5)
      throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
var logger$2 = new ConsoleLogger("CognitoCredentials");
var waitForInit$1 = new Promise(function(res, rej) {
  if (!browserOrNode().isBrowser) {
    logger$2.debug("not in the browser, directly resolved");
    return res();
  }
  var ga = window["gapi"] && window["gapi"].auth2 ? window["gapi"].auth2 : null;
  if (ga) {
    logger$2.debug("google api already loaded");
    return res();
  } else {
    setTimeout(function() {
      return res();
    }, 2e3);
  }
});
var GoogleOAuth$1 = function() {
  function GoogleOAuth2() {
    this.initialized = false;
    this.refreshGoogleToken = this.refreshGoogleToken.bind(this);
    this._refreshGoogleTokenImpl = this._refreshGoogleTokenImpl.bind(this);
  }
  GoogleOAuth2.prototype.refreshGoogleToken = function() {
    return __awaiter$3(this, void 0, void 0, function() {
      return __generator$3(this, function(_a) {
        switch (_a.label) {
          case 0:
            if (!!this.initialized)
              return [3, 2];
            logger$2.debug("need to wait for the Google SDK loaded");
            return [4, waitForInit$1];
          case 1:
            _a.sent();
            this.initialized = true;
            logger$2.debug("finish waiting");
            _a.label = 2;
          case 2:
            return [2, this._refreshGoogleTokenImpl()];
        }
      });
    });
  };
  GoogleOAuth2.prototype._refreshGoogleTokenImpl = function() {
    var ga = null;
    if (browserOrNode().isBrowser)
      ga = window["gapi"] && window["gapi"].auth2 ? window["gapi"].auth2 : null;
    if (!ga) {
      logger$2.debug("no gapi auth2 available");
      return Promise.reject("no gapi auth2 available");
    }
    return new Promise(function(res, rej) {
      ga.getAuthInstance().then(function(googleAuth) {
        if (!googleAuth) {
          logger$2.debug("google Auth undefined");
          rej(new NonRetryableError("google Auth undefined"));
        }
        var googleUser = googleAuth.currentUser.get();
        if (googleUser.isSignedIn()) {
          logger$2.debug("refreshing the google access token");
          googleUser.reloadAuthResponse().then(function(authResponse) {
            var id_token = authResponse.id_token, expires_at = authResponse.expires_at;
            res({ token: id_token, expires_at });
          }).catch(function(err) {
            if (err && err.error === "network_error") {
              rej("Network error reloading google auth response");
            } else {
              rej(new NonRetryableError("Failed to reload google auth response"));
            }
          });
        } else {
          rej(new NonRetryableError("User is not signed in with Google"));
        }
      }).catch(function(err) {
        logger$2.debug("Failed to refresh google token", err);
        rej(new NonRetryableError("Failed to refresh google token"));
      });
    });
  };
  return GoogleOAuth2;
}();
var __awaiter$2 = globalThis && globalThis.__awaiter || function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator$2 = globalThis && globalThis.__generator || function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1)
      throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f)
      throw new TypeError("Generator is already executing.");
    while (_)
      try {
        if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
          return t;
        if (y = 0, t)
          op = [op[0] & 2, t.value];
        switch (op[0]) {
          case 0:
          case 1:
            t = op;
            break;
          case 4:
            _.label++;
            return { value: op[1], done: false };
          case 5:
            _.label++;
            y = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            if (t[2])
              _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e) {
        op = [6, e];
        y = 0;
      } finally {
        f = t = 0;
      }
    if (op[0] & 5)
      throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
var logger$1 = new ConsoleLogger("CognitoCredentials");
var waitForInit = new Promise(function(res, rej) {
  if (!browserOrNode().isBrowser) {
    logger$1.debug("not in the browser, directly resolved");
    return res();
  }
  var fb = window["FB"];
  if (fb) {
    logger$1.debug("FB SDK already loaded");
    return res();
  } else {
    setTimeout(function() {
      return res();
    }, 2e3);
  }
});
var FacebookOAuth$1 = function() {
  function FacebookOAuth2() {
    this.initialized = false;
    this.refreshFacebookToken = this.refreshFacebookToken.bind(this);
    this._refreshFacebookTokenImpl = this._refreshFacebookTokenImpl.bind(this);
  }
  FacebookOAuth2.prototype.refreshFacebookToken = function() {
    return __awaiter$2(this, void 0, void 0, function() {
      return __generator$2(this, function(_a) {
        switch (_a.label) {
          case 0:
            if (!!this.initialized)
              return [3, 2];
            logger$1.debug("need to wait for the Facebook SDK loaded");
            return [4, waitForInit];
          case 1:
            _a.sent();
            this.initialized = true;
            logger$1.debug("finish waiting");
            _a.label = 2;
          case 2:
            return [2, this._refreshFacebookTokenImpl()];
        }
      });
    });
  };
  FacebookOAuth2.prototype._refreshFacebookTokenImpl = function() {
    var fb = null;
    if (browserOrNode().isBrowser)
      fb = window["FB"];
    if (!fb) {
      var errorMessage = "no fb sdk available";
      logger$1.debug(errorMessage);
      return Promise.reject(new NonRetryableError(errorMessage));
    }
    return new Promise(function(res, rej) {
      fb.getLoginStatus(function(fbResponse) {
        if (!fbResponse || !fbResponse.authResponse) {
          var errorMessage2 = "no response from facebook when refreshing the jwt token";
          logger$1.debug(errorMessage2);
          rej(new NonRetryableError(errorMessage2));
        } else {
          var response = fbResponse.authResponse;
          var accessToken = response.accessToken, expiresIn = response.expiresIn;
          var date = new Date();
          var expires_at = expiresIn * 1e3 + date.getTime();
          if (!accessToken) {
            var errorMessage2 = "the jwtToken is undefined";
            logger$1.debug(errorMessage2);
            rej(new NonRetryableError(errorMessage2));
          }
          res({
            token: accessToken,
            expires_at
          });
        }
      }, { scope: "public_profile,email" });
    });
  };
  return FacebookOAuth2;
}();
var GoogleOAuth = new GoogleOAuth$1();
var FacebookOAuth = new FacebookOAuth$1();
var dataMemory = {};
var MemoryStorage = function() {
  function MemoryStorage2() {
  }
  MemoryStorage2.setItem = function(key, value) {
    dataMemory[key] = value;
    return dataMemory[key];
  };
  MemoryStorage2.getItem = function(key) {
    return Object.prototype.hasOwnProperty.call(dataMemory, key) ? dataMemory[key] : void 0;
  };
  MemoryStorage2.removeItem = function(key) {
    return delete dataMemory[key];
  };
  MemoryStorage2.clear = function() {
    dataMemory = {};
    return dataMemory;
  };
  return MemoryStorage2;
}();
var StorageHelper = function() {
  function StorageHelper2() {
    try {
      this.storageWindow = window.localStorage;
      this.storageWindow.setItem("aws.amplify.test-ls", 1);
      this.storageWindow.removeItem("aws.amplify.test-ls");
    } catch (exception) {
      this.storageWindow = MemoryStorage;
    }
  }
  StorageHelper2.prototype.getStorage = function() {
    return this.storageWindow;
  };
  return StorageHelper2;
}();
/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
var extendStatics = function(d, b) {
  extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
    d2.__proto__ = b2;
  } || function(d2, b2) {
    for (var p in b2)
      if (Object.prototype.hasOwnProperty.call(b2, p))
        d2[p] = b2[p];
  };
  return extendStatics(d, b);
};
function __extends(d, b) {
  if (typeof b !== "function" && b !== null)
    throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
  extendStatics(d, b);
  function __() {
    this.constructor = d;
  }
  d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}
var __assign$1 = function() {
  __assign$1 = Object.assign || function __assign2(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s)
        if (Object.prototype.hasOwnProperty.call(s, p))
          t[p] = s[p];
    }
    return t;
  };
  return __assign$1.apply(this, arguments);
};
function __awaiter$1(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
}
function __generator$1(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1)
      throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f)
      throw new TypeError("Generator is already executing.");
    while (_)
      try {
        if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
          return t;
        if (y = 0, t)
          op = [op[0] & 2, t.value];
        switch (op[0]) {
          case 0:
          case 1:
            t = op;
            break;
          case 4:
            _.label++;
            return { value: op[1], done: false };
          case 5:
            _.label++;
            y = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            if (t[2])
              _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e) {
        op = [6, e];
        y = 0;
      } finally {
        f = t = 0;
      }
    if (op[0] & 5)
      throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
}
function __read(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m)
    return o;
  var i = m.call(o), r, ar = [], e;
  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
      ar.push(r.value);
  } catch (error) {
    e = { error };
  } finally {
    try {
      if (r && !r.done && (m = i["return"]))
        m.call(i);
    } finally {
      if (e)
        throw e.error;
    }
  }
  return ar;
}
const name = "@aws-sdk/client-cognito-identity";
const description = "AWS SDK for JavaScript Cognito Identity Client for Node.js, Browser and React Native";
const version = "3.6.1";
const scripts = {
  clean: "yarn remove-definitions && yarn remove-dist && yarn remove-documentation",
  "build-documentation": "yarn remove-documentation && typedoc ./",
  prepublishOnly: "yarn build",
  pretest: "yarn build:cjs",
  "remove-definitions": "rimraf ./types",
  "remove-dist": "rimraf ./dist",
  "remove-documentation": "rimraf ./docs",
  "test:unit": "mocha **/cjs/**/*.spec.js",
  "test:e2e": "mocha **/cjs/**/*.ispec.js && karma start karma.conf.js",
  test: "yarn test:unit",
  "build:cjs": "tsc -p tsconfig.json",
  "build:es": "tsc -p tsconfig.es.json",
  build: "yarn build:cjs && yarn build:es",
  postbuild: "downlevel-dts types types/ts3.4"
};
const main = "./dist/cjs/index.js";
const types = "./types/index.d.ts";
const module = "./dist/es/index.js";
const browser = {
  "./runtimeConfig": "./runtimeConfig.browser"
};
const sideEffects = false;
const dependencies = {
  "@aws-crypto/sha256-browser": "^1.0.0",
  "@aws-crypto/sha256-js": "^1.0.0",
  "@aws-sdk/config-resolver": "3.6.1",
  "@aws-sdk/credential-provider-node": "3.6.1",
  "@aws-sdk/fetch-http-handler": "3.6.1",
  "@aws-sdk/hash-node": "3.6.1",
  "@aws-sdk/invalid-dependency": "3.6.1",
  "@aws-sdk/middleware-content-length": "3.6.1",
  "@aws-sdk/middleware-host-header": "3.6.1",
  "@aws-sdk/middleware-logger": "3.6.1",
  "@aws-sdk/middleware-retry": "3.6.1",
  "@aws-sdk/middleware-serde": "3.6.1",
  "@aws-sdk/middleware-signing": "3.6.1",
  "@aws-sdk/middleware-stack": "3.6.1",
  "@aws-sdk/middleware-user-agent": "3.6.1",
  "@aws-sdk/node-config-provider": "3.6.1",
  "@aws-sdk/node-http-handler": "3.6.1",
  "@aws-sdk/protocol-http": "3.6.1",
  "@aws-sdk/smithy-client": "3.6.1",
  "@aws-sdk/types": "3.6.1",
  "@aws-sdk/url-parser": "3.6.1",
  "@aws-sdk/url-parser-native": "3.6.1",
  "@aws-sdk/util-base64-browser": "3.6.1",
  "@aws-sdk/util-base64-node": "3.6.1",
  "@aws-sdk/util-body-length-browser": "3.6.1",
  "@aws-sdk/util-body-length-node": "3.6.1",
  "@aws-sdk/util-user-agent-browser": "3.6.1",
  "@aws-sdk/util-user-agent-node": "3.6.1",
  "@aws-sdk/util-utf8-browser": "3.6.1",
  "@aws-sdk/util-utf8-node": "3.6.1",
  tslib: "^2.0.0"
};
const devDependencies = {
  "@aws-sdk/client-documentation-generator": "3.6.1",
  "@aws-sdk/client-iam": "3.6.1",
  "@types/chai": "^4.2.11",
  "@types/mocha": "^8.0.4",
  "@types/node": "^12.7.5",
  "downlevel-dts": "0.7.0",
  jest: "^26.1.0",
  rimraf: "^3.0.0",
  typedoc: "^0.19.2",
  typescript: "~4.1.2"
};
const engines = {
  node: ">=10.0.0"
};
const typesVersions = {
  "<4.0": {
    "types/*": [
      "types/ts3.4/*"
    ]
  }
};
const author = {
  name: "AWS SDK for JavaScript Team",
  url: "https://aws.amazon.com/javascript/"
};
const license = "Apache-2.0";
const homepage = "https://github.com/aws/aws-sdk-js-v3/tree/main/clients/client-cognito-identity";
const repository = {
  type: "git",
  url: "https://github.com/aws/aws-sdk-js-v3.git",
  directory: "clients/client-cognito-identity"
};
var packageInfo = {
  name,
  description,
  version,
  scripts,
  main,
  types,
  module,
  browser,
  "react-native": {
    "./runtimeConfig": "./runtimeConfig.native"
  },
  sideEffects,
  dependencies,
  devDependencies,
  engines,
  typesVersions,
  author,
  license,
  homepage,
  repository
};
var AWS_TEMPLATE = "cognito-identity.{region}.amazonaws.com";
var AWS_CN_TEMPLATE = "cognito-identity.{region}.amazonaws.com.cn";
var AWS_ISO_TEMPLATE = "cognito-identity.{region}.c2s.ic.gov";
var AWS_ISO_B_TEMPLATE = "cognito-identity.{region}.sc2s.sgov.gov";
var AWS_US_GOV_TEMPLATE = "cognito-identity.{region}.amazonaws.com";
var AWS_REGIONS = /* @__PURE__ */ new Set([
  "af-south-1",
  "ap-east-1",
  "ap-northeast-1",
  "ap-northeast-2",
  "ap-south-1",
  "ap-southeast-1",
  "ap-southeast-2",
  "ca-central-1",
  "eu-central-1",
  "eu-north-1",
  "eu-south-1",
  "eu-west-1",
  "eu-west-2",
  "eu-west-3",
  "me-south-1",
  "sa-east-1",
  "us-east-1",
  "us-east-2",
  "us-west-1",
  "us-west-2"
]);
var AWS_CN_REGIONS = /* @__PURE__ */ new Set(["cn-north-1", "cn-northwest-1"]);
var AWS_ISO_REGIONS = /* @__PURE__ */ new Set(["us-iso-east-1"]);
var AWS_ISO_B_REGIONS = /* @__PURE__ */ new Set(["us-isob-east-1"]);
var AWS_US_GOV_REGIONS = /* @__PURE__ */ new Set(["us-gov-east-1", "us-gov-west-1"]);
var defaultRegionInfoProvider = function(region, options) {
  var regionInfo = void 0;
  switch (region) {
    case "ap-northeast-1":
      regionInfo = {
        hostname: "cognito-identity.ap-northeast-1.amazonaws.com",
        partition: "aws"
      };
      break;
    case "ap-northeast-2":
      regionInfo = {
        hostname: "cognito-identity.ap-northeast-2.amazonaws.com",
        partition: "aws"
      };
      break;
    case "ap-south-1":
      regionInfo = {
        hostname: "cognito-identity.ap-south-1.amazonaws.com",
        partition: "aws"
      };
      break;
    case "ap-southeast-1":
      regionInfo = {
        hostname: "cognito-identity.ap-southeast-1.amazonaws.com",
        partition: "aws"
      };
      break;
    case "ap-southeast-2":
      regionInfo = {
        hostname: "cognito-identity.ap-southeast-2.amazonaws.com",
        partition: "aws"
      };
      break;
    case "ca-central-1":
      regionInfo = {
        hostname: "cognito-identity.ca-central-1.amazonaws.com",
        partition: "aws"
      };
      break;
    case "cn-north-1":
      regionInfo = {
        hostname: "cognito-identity.cn-north-1.amazonaws.com.cn",
        partition: "aws-cn"
      };
      break;
    case "eu-central-1":
      regionInfo = {
        hostname: "cognito-identity.eu-central-1.amazonaws.com",
        partition: "aws"
      };
      break;
    case "eu-north-1":
      regionInfo = {
        hostname: "cognito-identity.eu-north-1.amazonaws.com",
        partition: "aws"
      };
      break;
    case "eu-west-1":
      regionInfo = {
        hostname: "cognito-identity.eu-west-1.amazonaws.com",
        partition: "aws"
      };
      break;
    case "eu-west-2":
      regionInfo = {
        hostname: "cognito-identity.eu-west-2.amazonaws.com",
        partition: "aws"
      };
      break;
    case "eu-west-3":
      regionInfo = {
        hostname: "cognito-identity.eu-west-3.amazonaws.com",
        partition: "aws"
      };
      break;
    case "fips-us-east-1":
      regionInfo = {
        hostname: "cognito-identity-fips.us-east-1.amazonaws.com",
        partition: "aws",
        signingRegion: "us-east-1"
      };
      break;
    case "fips-us-east-2":
      regionInfo = {
        hostname: "cognito-identity-fips.us-east-2.amazonaws.com",
        partition: "aws",
        signingRegion: "us-east-2"
      };
      break;
    case "fips-us-gov-west-1":
      regionInfo = {
        hostname: "cognito-identity-fips.us-gov-west-1.amazonaws.com",
        partition: "aws-us-gov",
        signingRegion: "us-gov-west-1"
      };
      break;
    case "fips-us-west-2":
      regionInfo = {
        hostname: "cognito-identity-fips.us-west-2.amazonaws.com",
        partition: "aws",
        signingRegion: "us-west-2"
      };
      break;
    case "sa-east-1":
      regionInfo = {
        hostname: "cognito-identity.sa-east-1.amazonaws.com",
        partition: "aws"
      };
      break;
    case "us-east-1":
      regionInfo = {
        hostname: "cognito-identity.us-east-1.amazonaws.com",
        partition: "aws"
      };
      break;
    case "us-east-2":
      regionInfo = {
        hostname: "cognito-identity.us-east-2.amazonaws.com",
        partition: "aws"
      };
      break;
    case "us-gov-west-1":
      regionInfo = {
        hostname: "cognito-identity.us-gov-west-1.amazonaws.com",
        partition: "aws-us-gov"
      };
      break;
    case "us-west-1":
      regionInfo = {
        hostname: "cognito-identity.us-west-1.amazonaws.com",
        partition: "aws"
      };
      break;
    case "us-west-2":
      regionInfo = {
        hostname: "cognito-identity.us-west-2.amazonaws.com",
        partition: "aws"
      };
      break;
    default:
      if (AWS_REGIONS.has(region)) {
        regionInfo = {
          hostname: AWS_TEMPLATE.replace("{region}", region),
          partition: "aws"
        };
      }
      if (AWS_CN_REGIONS.has(region)) {
        regionInfo = {
          hostname: AWS_CN_TEMPLATE.replace("{region}", region),
          partition: "aws-cn"
        };
      }
      if (AWS_ISO_REGIONS.has(region)) {
        regionInfo = {
          hostname: AWS_ISO_TEMPLATE.replace("{region}", region),
          partition: "aws-iso"
        };
      }
      if (AWS_ISO_B_REGIONS.has(region)) {
        regionInfo = {
          hostname: AWS_ISO_B_TEMPLATE.replace("{region}", region),
          partition: "aws-iso-b"
        };
      }
      if (AWS_US_GOV_REGIONS.has(region)) {
        regionInfo = {
          hostname: AWS_US_GOV_TEMPLATE.replace("{region}", region),
          partition: "aws-us-gov"
        };
      }
      if (regionInfo === void 0) {
        regionInfo = {
          hostname: AWS_TEMPLATE.replace("{region}", region),
          partition: "aws"
        };
      }
  }
  return Promise.resolve(__assign$1({ signingService: "cognito-identity" }, regionInfo));
};
var ClientSharedValues = {
  apiVersion: "2014-06-30",
  disableHostPrefix: false,
  logger: {},
  regionInfoProvider: defaultRegionInfoProvider,
  serviceId: "Cognito Identity",
  urlParser: parseUrl
};
var ClientDefaultValues = __assign$1(__assign$1({}, ClientSharedValues), { runtime: "browser", base64Decoder: fromBase64, base64Encoder: toBase64, bodyLengthChecker: calculateBodyLength, credentialDefaultProvider: function(_) {
  return function() {
    return Promise.reject(new Error("Credential is missing"));
  };
}, defaultUserAgentProvider: defaultUserAgent({
  serviceId: ClientSharedValues.serviceId,
  clientVersion: packageInfo.version
}), maxAttempts: DEFAULT_MAX_ATTEMPTS, region: invalidProvider("Region is missing"), requestHandler: new FetchHttpHandler(), sha256: build$4.Sha256, streamCollector, utf8Decoder: fromUtf8$1, utf8Encoder: toUtf8 });
var CognitoIdentityClient = function(_super) {
  __extends(CognitoIdentityClient2, _super);
  function CognitoIdentityClient2(configuration) {
    var _this = this;
    var _config_0 = __assign$1(__assign$1({}, ClientDefaultValues), configuration);
    var _config_1 = resolveRegionConfig(_config_0);
    var _config_2 = resolveEndpointsConfig(_config_1);
    var _config_3 = resolveAwsAuthConfig(_config_2);
    var _config_4 = resolveRetryConfig(_config_3);
    var _config_5 = resolveHostHeaderConfig(_config_4);
    var _config_6 = resolveUserAgentConfig(_config_5);
    _this = _super.call(this, _config_6) || this;
    _this.config = _config_6;
    _this.middlewareStack.use(getRetryPlugin(_this.config));
    _this.middlewareStack.use(getContentLengthPlugin(_this.config));
    _this.middlewareStack.use(getHostHeaderPlugin(_this.config));
    _this.middlewareStack.use(getLoggerPlugin(_this.config));
    _this.middlewareStack.use(getUserAgentPlugin(_this.config));
    return _this;
  }
  CognitoIdentityClient2.prototype.destroy = function() {
    _super.prototype.destroy.call(this);
  };
  return CognitoIdentityClient2;
}(Client);
var AmbiguousRoleResolutionType;
(function(AmbiguousRoleResolutionType2) {
  AmbiguousRoleResolutionType2["AUTHENTICATED_ROLE"] = "AuthenticatedRole";
  AmbiguousRoleResolutionType2["DENY"] = "Deny";
})(AmbiguousRoleResolutionType || (AmbiguousRoleResolutionType = {}));
var CognitoIdentityProvider;
(function(CognitoIdentityProvider2) {
  CognitoIdentityProvider2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(CognitoIdentityProvider || (CognitoIdentityProvider = {}));
var CreateIdentityPoolInput;
(function(CreateIdentityPoolInput2) {
  CreateIdentityPoolInput2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(CreateIdentityPoolInput || (CreateIdentityPoolInput = {}));
var IdentityPool;
(function(IdentityPool2) {
  IdentityPool2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(IdentityPool || (IdentityPool = {}));
var InternalErrorException;
(function(InternalErrorException2) {
  InternalErrorException2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(InternalErrorException || (InternalErrorException = {}));
var InvalidParameterException;
(function(InvalidParameterException2) {
  InvalidParameterException2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(InvalidParameterException || (InvalidParameterException = {}));
var LimitExceededException;
(function(LimitExceededException2) {
  LimitExceededException2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(LimitExceededException || (LimitExceededException = {}));
var NotAuthorizedException;
(function(NotAuthorizedException2) {
  NotAuthorizedException2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(NotAuthorizedException || (NotAuthorizedException = {}));
var ResourceConflictException;
(function(ResourceConflictException2) {
  ResourceConflictException2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(ResourceConflictException || (ResourceConflictException = {}));
var TooManyRequestsException;
(function(TooManyRequestsException2) {
  TooManyRequestsException2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(TooManyRequestsException || (TooManyRequestsException = {}));
var DeleteIdentitiesInput;
(function(DeleteIdentitiesInput2) {
  DeleteIdentitiesInput2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(DeleteIdentitiesInput || (DeleteIdentitiesInput = {}));
var ErrorCode;
(function(ErrorCode2) {
  ErrorCode2["ACCESS_DENIED"] = "AccessDenied";
  ErrorCode2["INTERNAL_SERVER_ERROR"] = "InternalServerError";
})(ErrorCode || (ErrorCode = {}));
var UnprocessedIdentityId;
(function(UnprocessedIdentityId2) {
  UnprocessedIdentityId2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(UnprocessedIdentityId || (UnprocessedIdentityId = {}));
var DeleteIdentitiesResponse;
(function(DeleteIdentitiesResponse2) {
  DeleteIdentitiesResponse2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(DeleteIdentitiesResponse || (DeleteIdentitiesResponse = {}));
var DeleteIdentityPoolInput;
(function(DeleteIdentityPoolInput2) {
  DeleteIdentityPoolInput2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(DeleteIdentityPoolInput || (DeleteIdentityPoolInput = {}));
var ResourceNotFoundException;
(function(ResourceNotFoundException2) {
  ResourceNotFoundException2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(ResourceNotFoundException || (ResourceNotFoundException = {}));
var DescribeIdentityInput;
(function(DescribeIdentityInput2) {
  DescribeIdentityInput2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(DescribeIdentityInput || (DescribeIdentityInput = {}));
var IdentityDescription;
(function(IdentityDescription2) {
  IdentityDescription2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(IdentityDescription || (IdentityDescription = {}));
var DescribeIdentityPoolInput;
(function(DescribeIdentityPoolInput2) {
  DescribeIdentityPoolInput2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(DescribeIdentityPoolInput || (DescribeIdentityPoolInput = {}));
var ExternalServiceException;
(function(ExternalServiceException2) {
  ExternalServiceException2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(ExternalServiceException || (ExternalServiceException = {}));
var GetCredentialsForIdentityInput;
(function(GetCredentialsForIdentityInput2) {
  GetCredentialsForIdentityInput2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(GetCredentialsForIdentityInput || (GetCredentialsForIdentityInput = {}));
var Credentials$1;
(function(Credentials2) {
  Credentials2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(Credentials$1 || (Credentials$1 = {}));
var GetCredentialsForIdentityResponse;
(function(GetCredentialsForIdentityResponse2) {
  GetCredentialsForIdentityResponse2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(GetCredentialsForIdentityResponse || (GetCredentialsForIdentityResponse = {}));
var InvalidIdentityPoolConfigurationException;
(function(InvalidIdentityPoolConfigurationException2) {
  InvalidIdentityPoolConfigurationException2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(InvalidIdentityPoolConfigurationException || (InvalidIdentityPoolConfigurationException = {}));
var GetIdInput;
(function(GetIdInput2) {
  GetIdInput2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(GetIdInput || (GetIdInput = {}));
var GetIdResponse;
(function(GetIdResponse2) {
  GetIdResponse2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(GetIdResponse || (GetIdResponse = {}));
var GetIdentityPoolRolesInput;
(function(GetIdentityPoolRolesInput2) {
  GetIdentityPoolRolesInput2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(GetIdentityPoolRolesInput || (GetIdentityPoolRolesInput = {}));
var MappingRuleMatchType;
(function(MappingRuleMatchType2) {
  MappingRuleMatchType2["CONTAINS"] = "Contains";
  MappingRuleMatchType2["EQUALS"] = "Equals";
  MappingRuleMatchType2["NOT_EQUAL"] = "NotEqual";
  MappingRuleMatchType2["STARTS_WITH"] = "StartsWith";
})(MappingRuleMatchType || (MappingRuleMatchType = {}));
var MappingRule;
(function(MappingRule2) {
  MappingRule2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(MappingRule || (MappingRule = {}));
var RulesConfigurationType;
(function(RulesConfigurationType2) {
  RulesConfigurationType2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(RulesConfigurationType || (RulesConfigurationType = {}));
var RoleMappingType;
(function(RoleMappingType2) {
  RoleMappingType2["RULES"] = "Rules";
  RoleMappingType2["TOKEN"] = "Token";
})(RoleMappingType || (RoleMappingType = {}));
var RoleMapping;
(function(RoleMapping2) {
  RoleMapping2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(RoleMapping || (RoleMapping = {}));
var GetIdentityPoolRolesResponse;
(function(GetIdentityPoolRolesResponse2) {
  GetIdentityPoolRolesResponse2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(GetIdentityPoolRolesResponse || (GetIdentityPoolRolesResponse = {}));
var GetOpenIdTokenInput;
(function(GetOpenIdTokenInput2) {
  GetOpenIdTokenInput2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(GetOpenIdTokenInput || (GetOpenIdTokenInput = {}));
var GetOpenIdTokenResponse;
(function(GetOpenIdTokenResponse2) {
  GetOpenIdTokenResponse2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(GetOpenIdTokenResponse || (GetOpenIdTokenResponse = {}));
var DeveloperUserAlreadyRegisteredException;
(function(DeveloperUserAlreadyRegisteredException2) {
  DeveloperUserAlreadyRegisteredException2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(DeveloperUserAlreadyRegisteredException || (DeveloperUserAlreadyRegisteredException = {}));
var GetOpenIdTokenForDeveloperIdentityInput;
(function(GetOpenIdTokenForDeveloperIdentityInput2) {
  GetOpenIdTokenForDeveloperIdentityInput2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(GetOpenIdTokenForDeveloperIdentityInput || (GetOpenIdTokenForDeveloperIdentityInput = {}));
var GetOpenIdTokenForDeveloperIdentityResponse;
(function(GetOpenIdTokenForDeveloperIdentityResponse2) {
  GetOpenIdTokenForDeveloperIdentityResponse2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(GetOpenIdTokenForDeveloperIdentityResponse || (GetOpenIdTokenForDeveloperIdentityResponse = {}));
var ListIdentitiesInput;
(function(ListIdentitiesInput2) {
  ListIdentitiesInput2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(ListIdentitiesInput || (ListIdentitiesInput = {}));
var ListIdentitiesResponse;
(function(ListIdentitiesResponse2) {
  ListIdentitiesResponse2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(ListIdentitiesResponse || (ListIdentitiesResponse = {}));
var ListIdentityPoolsInput;
(function(ListIdentityPoolsInput2) {
  ListIdentityPoolsInput2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(ListIdentityPoolsInput || (ListIdentityPoolsInput = {}));
var IdentityPoolShortDescription;
(function(IdentityPoolShortDescription2) {
  IdentityPoolShortDescription2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(IdentityPoolShortDescription || (IdentityPoolShortDescription = {}));
var ListIdentityPoolsResponse;
(function(ListIdentityPoolsResponse2) {
  ListIdentityPoolsResponse2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(ListIdentityPoolsResponse || (ListIdentityPoolsResponse = {}));
var ListTagsForResourceInput;
(function(ListTagsForResourceInput2) {
  ListTagsForResourceInput2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(ListTagsForResourceInput || (ListTagsForResourceInput = {}));
var ListTagsForResourceResponse;
(function(ListTagsForResourceResponse2) {
  ListTagsForResourceResponse2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(ListTagsForResourceResponse || (ListTagsForResourceResponse = {}));
var LookupDeveloperIdentityInput;
(function(LookupDeveloperIdentityInput2) {
  LookupDeveloperIdentityInput2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(LookupDeveloperIdentityInput || (LookupDeveloperIdentityInput = {}));
var LookupDeveloperIdentityResponse;
(function(LookupDeveloperIdentityResponse2) {
  LookupDeveloperIdentityResponse2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(LookupDeveloperIdentityResponse || (LookupDeveloperIdentityResponse = {}));
var MergeDeveloperIdentitiesInput;
(function(MergeDeveloperIdentitiesInput2) {
  MergeDeveloperIdentitiesInput2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(MergeDeveloperIdentitiesInput || (MergeDeveloperIdentitiesInput = {}));
var MergeDeveloperIdentitiesResponse;
(function(MergeDeveloperIdentitiesResponse2) {
  MergeDeveloperIdentitiesResponse2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(MergeDeveloperIdentitiesResponse || (MergeDeveloperIdentitiesResponse = {}));
var ConcurrentModificationException;
(function(ConcurrentModificationException2) {
  ConcurrentModificationException2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(ConcurrentModificationException || (ConcurrentModificationException = {}));
var SetIdentityPoolRolesInput;
(function(SetIdentityPoolRolesInput2) {
  SetIdentityPoolRolesInput2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(SetIdentityPoolRolesInput || (SetIdentityPoolRolesInput = {}));
var TagResourceInput;
(function(TagResourceInput2) {
  TagResourceInput2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(TagResourceInput || (TagResourceInput = {}));
var TagResourceResponse;
(function(TagResourceResponse2) {
  TagResourceResponse2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(TagResourceResponse || (TagResourceResponse = {}));
var UnlinkDeveloperIdentityInput;
(function(UnlinkDeveloperIdentityInput2) {
  UnlinkDeveloperIdentityInput2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(UnlinkDeveloperIdentityInput || (UnlinkDeveloperIdentityInput = {}));
var UnlinkIdentityInput;
(function(UnlinkIdentityInput2) {
  UnlinkIdentityInput2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(UnlinkIdentityInput || (UnlinkIdentityInput = {}));
var UntagResourceInput;
(function(UntagResourceInput2) {
  UntagResourceInput2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(UntagResourceInput || (UntagResourceInput = {}));
var UntagResourceResponse;
(function(UntagResourceResponse2) {
  UntagResourceResponse2.filterSensitiveLog = function(obj) {
    return __assign$1({}, obj);
  };
})(UntagResourceResponse || (UntagResourceResponse = {}));
var serializeAws_json1_1GetCredentialsForIdentityCommand = function(input, context) {
  return __awaiter$1(void 0, void 0, void 0, function() {
    var headers, body;
    return __generator$1(this, function(_a) {
      headers = {
        "content-type": "application/x-amz-json-1.1",
        "x-amz-target": "AWSCognitoIdentityService.GetCredentialsForIdentity"
      };
      body = JSON.stringify(serializeAws_json1_1GetCredentialsForIdentityInput(input));
      return [2, buildHttpRpcRequest(context, headers, "/", void 0, body)];
    });
  });
};
var serializeAws_json1_1GetIdCommand = function(input, context) {
  return __awaiter$1(void 0, void 0, void 0, function() {
    var headers, body;
    return __generator$1(this, function(_a) {
      headers = {
        "content-type": "application/x-amz-json-1.1",
        "x-amz-target": "AWSCognitoIdentityService.GetId"
      };
      body = JSON.stringify(serializeAws_json1_1GetIdInput(input));
      return [2, buildHttpRpcRequest(context, headers, "/", void 0, body)];
    });
  });
};
var deserializeAws_json1_1GetCredentialsForIdentityCommand = function(output, context) {
  return __awaiter$1(void 0, void 0, void 0, function() {
    var data, contents, response;
    return __generator$1(this, function(_a) {
      switch (_a.label) {
        case 0:
          if (output.statusCode >= 300) {
            return [2, deserializeAws_json1_1GetCredentialsForIdentityCommandError(output, context)];
          }
          return [4, parseBody(output.body, context)];
        case 1:
          data = _a.sent();
          contents = {};
          contents = deserializeAws_json1_1GetCredentialsForIdentityResponse(data);
          response = __assign$1({ $metadata: deserializeMetadata(output) }, contents);
          return [2, Promise.resolve(response)];
      }
    });
  });
};
var deserializeAws_json1_1GetCredentialsForIdentityCommandError = function(output, context) {
  return __awaiter$1(void 0, void 0, void 0, function() {
    var parsedOutput, _a, response, errorCode, _b, _c, _d, _e, _f, _g, _h, _j, _k, parsedBody, message;
    var _l;
    return __generator$1(this, function(_m) {
      switch (_m.label) {
        case 0:
          _a = [__assign$1({}, output)];
          _l = {};
          return [4, parseBody(output.body, context)];
        case 1:
          parsedOutput = __assign$1.apply(void 0, _a.concat([(_l.body = _m.sent(), _l)]));
          errorCode = "UnknownError";
          errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
          _b = errorCode;
          switch (_b) {
            case "ExternalServiceException":
              return [3, 2];
            case "com.amazonaws.cognitoidentity#ExternalServiceException":
              return [3, 2];
            case "InternalErrorException":
              return [3, 4];
            case "com.amazonaws.cognitoidentity#InternalErrorException":
              return [3, 4];
            case "InvalidIdentityPoolConfigurationException":
              return [3, 6];
            case "com.amazonaws.cognitoidentity#InvalidIdentityPoolConfigurationException":
              return [3, 6];
            case "InvalidParameterException":
              return [3, 8];
            case "com.amazonaws.cognitoidentity#InvalidParameterException":
              return [3, 8];
            case "NotAuthorizedException":
              return [3, 10];
            case "com.amazonaws.cognitoidentity#NotAuthorizedException":
              return [3, 10];
            case "ResourceConflictException":
              return [3, 12];
            case "com.amazonaws.cognitoidentity#ResourceConflictException":
              return [3, 12];
            case "ResourceNotFoundException":
              return [3, 14];
            case "com.amazonaws.cognitoidentity#ResourceNotFoundException":
              return [3, 14];
            case "TooManyRequestsException":
              return [3, 16];
            case "com.amazonaws.cognitoidentity#TooManyRequestsException":
              return [3, 16];
          }
          return [3, 18];
        case 2:
          _c = [{}];
          return [4, deserializeAws_json1_1ExternalServiceExceptionResponse(parsedOutput)];
        case 3:
          response = __assign$1.apply(void 0, [__assign$1.apply(void 0, _c.concat([_m.sent()])), { name: errorCode, $metadata: deserializeMetadata(output) }]);
          return [3, 19];
        case 4:
          _d = [{}];
          return [4, deserializeAws_json1_1InternalErrorExceptionResponse(parsedOutput)];
        case 5:
          response = __assign$1.apply(void 0, [__assign$1.apply(void 0, _d.concat([_m.sent()])), { name: errorCode, $metadata: deserializeMetadata(output) }]);
          return [3, 19];
        case 6:
          _e = [{}];
          return [4, deserializeAws_json1_1InvalidIdentityPoolConfigurationExceptionResponse(parsedOutput)];
        case 7:
          response = __assign$1.apply(void 0, [__assign$1.apply(void 0, _e.concat([_m.sent()])), { name: errorCode, $metadata: deserializeMetadata(output) }]);
          return [3, 19];
        case 8:
          _f = [{}];
          return [4, deserializeAws_json1_1InvalidParameterExceptionResponse(parsedOutput)];
        case 9:
          response = __assign$1.apply(void 0, [__assign$1.apply(void 0, _f.concat([_m.sent()])), { name: errorCode, $metadata: deserializeMetadata(output) }]);
          return [3, 19];
        case 10:
          _g = [{}];
          return [4, deserializeAws_json1_1NotAuthorizedExceptionResponse(parsedOutput)];
        case 11:
          response = __assign$1.apply(void 0, [__assign$1.apply(void 0, _g.concat([_m.sent()])), { name: errorCode, $metadata: deserializeMetadata(output) }]);
          return [3, 19];
        case 12:
          _h = [{}];
          return [4, deserializeAws_json1_1ResourceConflictExceptionResponse(parsedOutput)];
        case 13:
          response = __assign$1.apply(void 0, [__assign$1.apply(void 0, _h.concat([_m.sent()])), { name: errorCode, $metadata: deserializeMetadata(output) }]);
          return [3, 19];
        case 14:
          _j = [{}];
          return [4, deserializeAws_json1_1ResourceNotFoundExceptionResponse(parsedOutput)];
        case 15:
          response = __assign$1.apply(void 0, [__assign$1.apply(void 0, _j.concat([_m.sent()])), { name: errorCode, $metadata: deserializeMetadata(output) }]);
          return [3, 19];
        case 16:
          _k = [{}];
          return [4, deserializeAws_json1_1TooManyRequestsExceptionResponse(parsedOutput)];
        case 17:
          response = __assign$1.apply(void 0, [__assign$1.apply(void 0, _k.concat([_m.sent()])), { name: errorCode, $metadata: deserializeMetadata(output) }]);
          return [3, 19];
        case 18:
          parsedBody = parsedOutput.body;
          errorCode = parsedBody.code || parsedBody.Code || errorCode;
          response = __assign$1(__assign$1({}, parsedBody), { name: "" + errorCode, message: parsedBody.message || parsedBody.Message || errorCode, $fault: "client", $metadata: deserializeMetadata(output) });
          _m.label = 19;
        case 19:
          message = response.message || response.Message || errorCode;
          response.message = message;
          delete response.Message;
          return [2, Promise.reject(Object.assign(new Error(message), response))];
      }
    });
  });
};
var deserializeAws_json1_1GetIdCommand = function(output, context) {
  return __awaiter$1(void 0, void 0, void 0, function() {
    var data, contents, response;
    return __generator$1(this, function(_a) {
      switch (_a.label) {
        case 0:
          if (output.statusCode >= 300) {
            return [2, deserializeAws_json1_1GetIdCommandError(output, context)];
          }
          return [4, parseBody(output.body, context)];
        case 1:
          data = _a.sent();
          contents = {};
          contents = deserializeAws_json1_1GetIdResponse(data);
          response = __assign$1({ $metadata: deserializeMetadata(output) }, contents);
          return [2, Promise.resolve(response)];
      }
    });
  });
};
var deserializeAws_json1_1GetIdCommandError = function(output, context) {
  return __awaiter$1(void 0, void 0, void 0, function() {
    var parsedOutput, _a, response, errorCode, _b, _c, _d, _e, _f, _g, _h, _j, _k, parsedBody, message;
    var _l;
    return __generator$1(this, function(_m) {
      switch (_m.label) {
        case 0:
          _a = [__assign$1({}, output)];
          _l = {};
          return [4, parseBody(output.body, context)];
        case 1:
          parsedOutput = __assign$1.apply(void 0, _a.concat([(_l.body = _m.sent(), _l)]));
          errorCode = "UnknownError";
          errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
          _b = errorCode;
          switch (_b) {
            case "ExternalServiceException":
              return [3, 2];
            case "com.amazonaws.cognitoidentity#ExternalServiceException":
              return [3, 2];
            case "InternalErrorException":
              return [3, 4];
            case "com.amazonaws.cognitoidentity#InternalErrorException":
              return [3, 4];
            case "InvalidParameterException":
              return [3, 6];
            case "com.amazonaws.cognitoidentity#InvalidParameterException":
              return [3, 6];
            case "LimitExceededException":
              return [3, 8];
            case "com.amazonaws.cognitoidentity#LimitExceededException":
              return [3, 8];
            case "NotAuthorizedException":
              return [3, 10];
            case "com.amazonaws.cognitoidentity#NotAuthorizedException":
              return [3, 10];
            case "ResourceConflictException":
              return [3, 12];
            case "com.amazonaws.cognitoidentity#ResourceConflictException":
              return [3, 12];
            case "ResourceNotFoundException":
              return [3, 14];
            case "com.amazonaws.cognitoidentity#ResourceNotFoundException":
              return [3, 14];
            case "TooManyRequestsException":
              return [3, 16];
            case "com.amazonaws.cognitoidentity#TooManyRequestsException":
              return [3, 16];
          }
          return [3, 18];
        case 2:
          _c = [{}];
          return [4, deserializeAws_json1_1ExternalServiceExceptionResponse(parsedOutput)];
        case 3:
          response = __assign$1.apply(void 0, [__assign$1.apply(void 0, _c.concat([_m.sent()])), { name: errorCode, $metadata: deserializeMetadata(output) }]);
          return [3, 19];
        case 4:
          _d = [{}];
          return [4, deserializeAws_json1_1InternalErrorExceptionResponse(parsedOutput)];
        case 5:
          response = __assign$1.apply(void 0, [__assign$1.apply(void 0, _d.concat([_m.sent()])), { name: errorCode, $metadata: deserializeMetadata(output) }]);
          return [3, 19];
        case 6:
          _e = [{}];
          return [4, deserializeAws_json1_1InvalidParameterExceptionResponse(parsedOutput)];
        case 7:
          response = __assign$1.apply(void 0, [__assign$1.apply(void 0, _e.concat([_m.sent()])), { name: errorCode, $metadata: deserializeMetadata(output) }]);
          return [3, 19];
        case 8:
          _f = [{}];
          return [4, deserializeAws_json1_1LimitExceededExceptionResponse(parsedOutput)];
        case 9:
          response = __assign$1.apply(void 0, [__assign$1.apply(void 0, _f.concat([_m.sent()])), { name: errorCode, $metadata: deserializeMetadata(output) }]);
          return [3, 19];
        case 10:
          _g = [{}];
          return [4, deserializeAws_json1_1NotAuthorizedExceptionResponse(parsedOutput)];
        case 11:
          response = __assign$1.apply(void 0, [__assign$1.apply(void 0, _g.concat([_m.sent()])), { name: errorCode, $metadata: deserializeMetadata(output) }]);
          return [3, 19];
        case 12:
          _h = [{}];
          return [4, deserializeAws_json1_1ResourceConflictExceptionResponse(parsedOutput)];
        case 13:
          response = __assign$1.apply(void 0, [__assign$1.apply(void 0, _h.concat([_m.sent()])), { name: errorCode, $metadata: deserializeMetadata(output) }]);
          return [3, 19];
        case 14:
          _j = [{}];
          return [4, deserializeAws_json1_1ResourceNotFoundExceptionResponse(parsedOutput)];
        case 15:
          response = __assign$1.apply(void 0, [__assign$1.apply(void 0, _j.concat([_m.sent()])), { name: errorCode, $metadata: deserializeMetadata(output) }]);
          return [3, 19];
        case 16:
          _k = [{}];
          return [4, deserializeAws_json1_1TooManyRequestsExceptionResponse(parsedOutput)];
        case 17:
          response = __assign$1.apply(void 0, [__assign$1.apply(void 0, _k.concat([_m.sent()])), { name: errorCode, $metadata: deserializeMetadata(output) }]);
          return [3, 19];
        case 18:
          parsedBody = parsedOutput.body;
          errorCode = parsedBody.code || parsedBody.Code || errorCode;
          response = __assign$1(__assign$1({}, parsedBody), { name: "" + errorCode, message: parsedBody.message || parsedBody.Message || errorCode, $fault: "client", $metadata: deserializeMetadata(output) });
          _m.label = 19;
        case 19:
          message = response.message || response.Message || errorCode;
          response.message = message;
          delete response.Message;
          return [2, Promise.reject(Object.assign(new Error(message), response))];
      }
    });
  });
};
var deserializeAws_json1_1ExternalServiceExceptionResponse = function(parsedOutput, context) {
  return __awaiter$1(void 0, void 0, void 0, function() {
    var body, deserialized, contents;
    return __generator$1(this, function(_a) {
      body = parsedOutput.body;
      deserialized = deserializeAws_json1_1ExternalServiceException(body);
      contents = __assign$1({ name: "ExternalServiceException", $fault: "client", $metadata: deserializeMetadata(parsedOutput) }, deserialized);
      return [2, contents];
    });
  });
};
var deserializeAws_json1_1InternalErrorExceptionResponse = function(parsedOutput, context) {
  return __awaiter$1(void 0, void 0, void 0, function() {
    var body, deserialized, contents;
    return __generator$1(this, function(_a) {
      body = parsedOutput.body;
      deserialized = deserializeAws_json1_1InternalErrorException(body);
      contents = __assign$1({ name: "InternalErrorException", $fault: "server", $metadata: deserializeMetadata(parsedOutput) }, deserialized);
      return [2, contents];
    });
  });
};
var deserializeAws_json1_1InvalidIdentityPoolConfigurationExceptionResponse = function(parsedOutput, context) {
  return __awaiter$1(void 0, void 0, void 0, function() {
    var body, deserialized, contents;
    return __generator$1(this, function(_a) {
      body = parsedOutput.body;
      deserialized = deserializeAws_json1_1InvalidIdentityPoolConfigurationException(body);
      contents = __assign$1({ name: "InvalidIdentityPoolConfigurationException", $fault: "client", $metadata: deserializeMetadata(parsedOutput) }, deserialized);
      return [2, contents];
    });
  });
};
var deserializeAws_json1_1InvalidParameterExceptionResponse = function(parsedOutput, context) {
  return __awaiter$1(void 0, void 0, void 0, function() {
    var body, deserialized, contents;
    return __generator$1(this, function(_a) {
      body = parsedOutput.body;
      deserialized = deserializeAws_json1_1InvalidParameterException(body);
      contents = __assign$1({ name: "InvalidParameterException", $fault: "client", $metadata: deserializeMetadata(parsedOutput) }, deserialized);
      return [2, contents];
    });
  });
};
var deserializeAws_json1_1LimitExceededExceptionResponse = function(parsedOutput, context) {
  return __awaiter$1(void 0, void 0, void 0, function() {
    var body, deserialized, contents;
    return __generator$1(this, function(_a) {
      body = parsedOutput.body;
      deserialized = deserializeAws_json1_1LimitExceededException(body);
      contents = __assign$1({ name: "LimitExceededException", $fault: "client", $metadata: deserializeMetadata(parsedOutput) }, deserialized);
      return [2, contents];
    });
  });
};
var deserializeAws_json1_1NotAuthorizedExceptionResponse = function(parsedOutput, context) {
  return __awaiter$1(void 0, void 0, void 0, function() {
    var body, deserialized, contents;
    return __generator$1(this, function(_a) {
      body = parsedOutput.body;
      deserialized = deserializeAws_json1_1NotAuthorizedException(body);
      contents = __assign$1({ name: "NotAuthorizedException", $fault: "client", $metadata: deserializeMetadata(parsedOutput) }, deserialized);
      return [2, contents];
    });
  });
};
var deserializeAws_json1_1ResourceConflictExceptionResponse = function(parsedOutput, context) {
  return __awaiter$1(void 0, void 0, void 0, function() {
    var body, deserialized, contents;
    return __generator$1(this, function(_a) {
      body = parsedOutput.body;
      deserialized = deserializeAws_json1_1ResourceConflictException(body);
      contents = __assign$1({ name: "ResourceConflictException", $fault: "client", $metadata: deserializeMetadata(parsedOutput) }, deserialized);
      return [2, contents];
    });
  });
};
var deserializeAws_json1_1ResourceNotFoundExceptionResponse = function(parsedOutput, context) {
  return __awaiter$1(void 0, void 0, void 0, function() {
    var body, deserialized, contents;
    return __generator$1(this, function(_a) {
      body = parsedOutput.body;
      deserialized = deserializeAws_json1_1ResourceNotFoundException(body);
      contents = __assign$1({ name: "ResourceNotFoundException", $fault: "client", $metadata: deserializeMetadata(parsedOutput) }, deserialized);
      return [2, contents];
    });
  });
};
var deserializeAws_json1_1TooManyRequestsExceptionResponse = function(parsedOutput, context) {
  return __awaiter$1(void 0, void 0, void 0, function() {
    var body, deserialized, contents;
    return __generator$1(this, function(_a) {
      body = parsedOutput.body;
      deserialized = deserializeAws_json1_1TooManyRequestsException(body);
      contents = __assign$1({ name: "TooManyRequestsException", $fault: "client", $metadata: deserializeMetadata(parsedOutput) }, deserialized);
      return [2, contents];
    });
  });
};
var serializeAws_json1_1GetCredentialsForIdentityInput = function(input, context) {
  return __assign$1(__assign$1(__assign$1({}, input.CustomRoleArn !== void 0 && input.CustomRoleArn !== null && { CustomRoleArn: input.CustomRoleArn }), input.IdentityId !== void 0 && input.IdentityId !== null && { IdentityId: input.IdentityId }), input.Logins !== void 0 && input.Logins !== null && { Logins: serializeAws_json1_1LoginsMap(input.Logins) });
};
var serializeAws_json1_1GetIdInput = function(input, context) {
  return __assign$1(__assign$1(__assign$1({}, input.AccountId !== void 0 && input.AccountId !== null && { AccountId: input.AccountId }), input.IdentityPoolId !== void 0 && input.IdentityPoolId !== null && { IdentityPoolId: input.IdentityPoolId }), input.Logins !== void 0 && input.Logins !== null && { Logins: serializeAws_json1_1LoginsMap(input.Logins) });
};
var serializeAws_json1_1LoginsMap = function(input, context) {
  return Object.entries(input).reduce(function(acc, _a) {
    var _b;
    var _c = __read(_a, 2), key = _c[0], value = _c[1];
    if (value === null) {
      return acc;
    }
    return __assign$1(__assign$1({}, acc), (_b = {}, _b[key] = value, _b));
  }, {});
};
var deserializeAws_json1_1Credentials = function(output, context) {
  return {
    AccessKeyId: output.AccessKeyId !== void 0 && output.AccessKeyId !== null ? output.AccessKeyId : void 0,
    Expiration: output.Expiration !== void 0 && output.Expiration !== null ? new Date(Math.round(output.Expiration * 1e3)) : void 0,
    SecretKey: output.SecretKey !== void 0 && output.SecretKey !== null ? output.SecretKey : void 0,
    SessionToken: output.SessionToken !== void 0 && output.SessionToken !== null ? output.SessionToken : void 0
  };
};
var deserializeAws_json1_1ExternalServiceException = function(output, context) {
  return {
    message: output.message !== void 0 && output.message !== null ? output.message : void 0
  };
};
var deserializeAws_json1_1GetCredentialsForIdentityResponse = function(output, context) {
  return {
    Credentials: output.Credentials !== void 0 && output.Credentials !== null ? deserializeAws_json1_1Credentials(output.Credentials) : void 0,
    IdentityId: output.IdentityId !== void 0 && output.IdentityId !== null ? output.IdentityId : void 0
  };
};
var deserializeAws_json1_1GetIdResponse = function(output, context) {
  return {
    IdentityId: output.IdentityId !== void 0 && output.IdentityId !== null ? output.IdentityId : void 0
  };
};
var deserializeAws_json1_1InternalErrorException = function(output, context) {
  return {
    message: output.message !== void 0 && output.message !== null ? output.message : void 0
  };
};
var deserializeAws_json1_1InvalidIdentityPoolConfigurationException = function(output, context) {
  return {
    message: output.message !== void 0 && output.message !== null ? output.message : void 0
  };
};
var deserializeAws_json1_1InvalidParameterException = function(output, context) {
  return {
    message: output.message !== void 0 && output.message !== null ? output.message : void 0
  };
};
var deserializeAws_json1_1LimitExceededException = function(output, context) {
  return {
    message: output.message !== void 0 && output.message !== null ? output.message : void 0
  };
};
var deserializeAws_json1_1NotAuthorizedException = function(output, context) {
  return {
    message: output.message !== void 0 && output.message !== null ? output.message : void 0
  };
};
var deserializeAws_json1_1ResourceConflictException = function(output, context) {
  return {
    message: output.message !== void 0 && output.message !== null ? output.message : void 0
  };
};
var deserializeAws_json1_1ResourceNotFoundException = function(output, context) {
  return {
    message: output.message !== void 0 && output.message !== null ? output.message : void 0
  };
};
var deserializeAws_json1_1TooManyRequestsException = function(output, context) {
  return {
    message: output.message !== void 0 && output.message !== null ? output.message : void 0
  };
};
var deserializeMetadata = function(output) {
  var _a;
  return {
    httpStatusCode: output.statusCode,
    requestId: (_a = output.headers["x-amzn-requestid"]) !== null && _a !== void 0 ? _a : output.headers["x-amzn-request-id"],
    extendedRequestId: output.headers["x-amz-id-2"],
    cfId: output.headers["x-amz-cf-id"]
  };
};
var collectBody = function(streamBody, context) {
  if (streamBody === void 0) {
    streamBody = new Uint8Array();
  }
  if (streamBody instanceof Uint8Array) {
    return Promise.resolve(streamBody);
  }
  return context.streamCollector(streamBody) || Promise.resolve(new Uint8Array());
};
var collectBodyString = function(streamBody, context) {
  return collectBody(streamBody, context).then(function(body) {
    return context.utf8Encoder(body);
  });
};
var buildHttpRpcRequest = function(context, headers, path, resolvedHostname, body) {
  return __awaiter$1(void 0, void 0, void 0, function() {
    var _a, hostname, _b, protocol, port, contents;
    return __generator$1(this, function(_c) {
      switch (_c.label) {
        case 0:
          return [4, context.endpoint()];
        case 1:
          _a = _c.sent(), hostname = _a.hostname, _b = _a.protocol, protocol = _b === void 0 ? "https" : _b, port = _a.port;
          contents = {
            protocol,
            hostname,
            port,
            method: "POST",
            path,
            headers
          };
          if (resolvedHostname !== void 0) {
            contents.hostname = resolvedHostname;
          }
          if (body !== void 0) {
            contents.body = body;
          }
          return [2, new HttpRequest(contents)];
      }
    });
  });
};
var parseBody = function(streamBody, context) {
  return collectBodyString(streamBody, context).then(function(encoded) {
    if (encoded.length) {
      return JSON.parse(encoded);
    }
    return {};
  });
};
var loadRestJsonErrorCode = function(output, data) {
  var findKey = function(object, key) {
    return Object.keys(object).find(function(k) {
      return k.toLowerCase() === key.toLowerCase();
    });
  };
  var sanitizeErrorCode = function(rawValue) {
    var cleanValue = rawValue;
    if (cleanValue.indexOf(":") >= 0) {
      cleanValue = cleanValue.split(":")[0];
    }
    if (cleanValue.indexOf("#") >= 0) {
      cleanValue = cleanValue.split("#")[1];
    }
    return cleanValue;
  };
  var headerKey = findKey(output.headers, "x-amzn-errortype");
  if (headerKey !== void 0) {
    return sanitizeErrorCode(output.headers[headerKey]);
  }
  if (data.code !== void 0) {
    return sanitizeErrorCode(data.code);
  }
  if (data["__type"] !== void 0) {
    return sanitizeErrorCode(data["__type"]);
  }
  return "";
};
var GetCredentialsForIdentityCommand = function(_super) {
  __extends(GetCredentialsForIdentityCommand2, _super);
  function GetCredentialsForIdentityCommand2(input) {
    var _this = _super.call(this) || this;
    _this.input = input;
    return _this;
  }
  GetCredentialsForIdentityCommand2.prototype.resolveMiddleware = function(clientStack, configuration, options) {
    this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
    var stack = clientStack.concat(this.middlewareStack);
    var logger2 = configuration.logger;
    var clientName = "CognitoIdentityClient";
    var commandName = "GetCredentialsForIdentityCommand";
    var handlerExecutionContext = {
      logger: logger2,
      clientName,
      commandName,
      inputFilterSensitiveLog: GetCredentialsForIdentityInput.filterSensitiveLog,
      outputFilterSensitiveLog: GetCredentialsForIdentityResponse.filterSensitiveLog
    };
    var requestHandler = configuration.requestHandler;
    return stack.resolve(function(request) {
      return requestHandler.handle(request.request, options || {});
    }, handlerExecutionContext);
  };
  GetCredentialsForIdentityCommand2.prototype.serialize = function(input, context) {
    return serializeAws_json1_1GetCredentialsForIdentityCommand(input, context);
  };
  GetCredentialsForIdentityCommand2.prototype.deserialize = function(output, context) {
    return deserializeAws_json1_1GetCredentialsForIdentityCommand(output, context);
  };
  return GetCredentialsForIdentityCommand2;
}(Command);
var GetIdCommand = function(_super) {
  __extends(GetIdCommand2, _super);
  function GetIdCommand2(input) {
    var _this = _super.call(this) || this;
    _this.input = input;
    return _this;
  }
  GetIdCommand2.prototype.resolveMiddleware = function(clientStack, configuration, options) {
    this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
    var stack = clientStack.concat(this.middlewareStack);
    var logger2 = configuration.logger;
    var clientName = "CognitoIdentityClient";
    var commandName = "GetIdCommand";
    var handlerExecutionContext = {
      logger: logger2,
      clientName,
      commandName,
      inputFilterSensitiveLog: GetIdInput.filterSensitiveLog,
      outputFilterSensitiveLog: GetIdResponse.filterSensitiveLog
    };
    var requestHandler = configuration.requestHandler;
    return stack.resolve(function(request) {
      return requestHandler.handle(request.request, options || {});
    }, handlerExecutionContext);
  };
  GetIdCommand2.prototype.serialize = function(input, context) {
    return serializeAws_json1_1GetIdCommand(input, context);
  };
  GetIdCommand2.prototype.deserialize = function(output, context) {
    return deserializeAws_json1_1GetIdCommand(output, context);
  };
  return GetIdCommand2;
}(Command);
var ProviderError = function(_super) {
  tslib.exports.__extends(ProviderError2, _super);
  function ProviderError2(message, tryNextLink) {
    if (tryNextLink === void 0) {
      tryNextLink = true;
    }
    var _this = _super.call(this, message) || this;
    _this.tryNextLink = tryNextLink;
    return _this;
  }
  return ProviderError2;
}(Error);
function resolveLogins(logins) {
  return Promise.all(Object.keys(logins).reduce(function(arr, name2) {
    var tokenOrProvider = logins[name2];
    if (typeof tokenOrProvider === "string") {
      arr.push([name2, tokenOrProvider]);
    } else {
      arr.push(tokenOrProvider().then(function(token) {
        return [name2, token];
      }));
    }
    return arr;
  }, [])).then(function(resolvedPairs) {
    return resolvedPairs.reduce(function(logins2, _a) {
      var _b = tslib.exports.__read(_a, 2), key = _b[0], value = _b[1];
      logins2[key] = value;
      return logins2;
    }, {});
  });
}
function fromCognitoIdentity(parameters) {
  var _this = this;
  return function() {
    return tslib.exports.__awaiter(_this, void 0, void 0, function() {
      var _a, _b, _c, AccessKeyId, Expiration, _d, SecretKey, SessionToken, _e, _f, _g, _h;
      var _j;
      return tslib.exports.__generator(this, function(_k) {
        switch (_k.label) {
          case 0:
            _f = (_e = parameters.client).send;
            _g = GetCredentialsForIdentityCommand.bind;
            _j = {
              CustomRoleArn: parameters.customRoleArn,
              IdentityId: parameters.identityId
            };
            if (!parameters.logins)
              return [3, 2];
            return [4, resolveLogins(parameters.logins)];
          case 1:
            _h = _k.sent();
            return [3, 3];
          case 2:
            _h = void 0;
            _k.label = 3;
          case 3:
            return [4, _f.apply(_e, [new (_g.apply(GetCredentialsForIdentityCommand, [void 0, (_j.Logins = _h, _j)]))()])];
          case 4:
            _a = _k.sent().Credentials, _b = _a === void 0 ? throwOnMissingCredentials() : _a, _c = _b.AccessKeyId, AccessKeyId = _c === void 0 ? throwOnMissingAccessKeyId() : _c, Expiration = _b.Expiration, _d = _b.SecretKey, SecretKey = _d === void 0 ? throwOnMissingSecretKey() : _d, SessionToken = _b.SessionToken;
            return [2, {
              identityId: parameters.identityId,
              accessKeyId: AccessKeyId,
              secretAccessKey: SecretKey,
              sessionToken: SessionToken,
              expiration: Expiration
            }];
        }
      });
    });
  };
}
function throwOnMissingAccessKeyId() {
  throw new ProviderError("Response from Amazon Cognito contained no access key ID");
}
function throwOnMissingCredentials() {
  throw new ProviderError("Response from Amazon Cognito contained no credentials");
}
function throwOnMissingSecretKey() {
  throw new ProviderError("Response from Amazon Cognito contained no secret key");
}
var STORE_NAME = "IdentityIds";
var IndexedDbStorage = function() {
  function IndexedDbStorage2(dbName) {
    if (dbName === void 0) {
      dbName = "aws:cognito-identity-ids";
    }
    this.dbName = dbName;
  }
  IndexedDbStorage2.prototype.getItem = function(key) {
    return this.withObjectStore("readonly", function(store) {
      var req = store.get(key);
      return new Promise(function(resolve) {
        req.onerror = function() {
          return resolve(null);
        };
        req.onsuccess = function() {
          return resolve(req.result ? req.result.value : null);
        };
      });
    }).catch(function() {
      return null;
    });
  };
  IndexedDbStorage2.prototype.removeItem = function(key) {
    return this.withObjectStore("readwrite", function(store) {
      var req = store.delete(key);
      return new Promise(function(resolve, reject) {
        req.onerror = function() {
          return reject(req.error);
        };
        req.onsuccess = function() {
          return resolve();
        };
      });
    });
  };
  IndexedDbStorage2.prototype.setItem = function(id, value) {
    return this.withObjectStore("readwrite", function(store) {
      var req = store.put({ id, value });
      return new Promise(function(resolve, reject) {
        req.onerror = function() {
          return reject(req.error);
        };
        req.onsuccess = function() {
          return resolve();
        };
      });
    });
  };
  IndexedDbStorage2.prototype.getDb = function() {
    var openDbRequest = self.indexedDB.open(this.dbName, 1);
    return new Promise(function(resolve, reject) {
      openDbRequest.onsuccess = function() {
        resolve(openDbRequest.result);
      };
      openDbRequest.onerror = function() {
        reject(openDbRequest.error);
      };
      openDbRequest.onblocked = function() {
        reject(new Error("Unable to access DB"));
      };
      openDbRequest.onupgradeneeded = function() {
        var db = openDbRequest.result;
        db.onerror = function() {
          reject(new Error("Failed to create object store"));
        };
        db.createObjectStore(STORE_NAME, { keyPath: "id" });
      };
    });
  };
  IndexedDbStorage2.prototype.withObjectStore = function(mode, action) {
    return this.getDb().then(function(db) {
      var tx = db.transaction(STORE_NAME, mode);
      tx.oncomplete = function() {
        return db.close();
      };
      return new Promise(function(resolve, reject) {
        tx.onerror = function() {
          return reject(tx.error);
        };
        resolve(action(tx.objectStore(STORE_NAME)));
      }).catch(function(err) {
        db.close();
        throw err;
      });
    });
  };
  return IndexedDbStorage2;
}();
var InMemoryStorage = function() {
  function InMemoryStorage2(store) {
    if (store === void 0) {
      store = {};
    }
    this.store = store;
  }
  InMemoryStorage2.prototype.getItem = function(key) {
    if (key in this.store) {
      return this.store[key];
    }
    return null;
  };
  InMemoryStorage2.prototype.removeItem = function(key) {
    delete this.store[key];
  };
  InMemoryStorage2.prototype.setItem = function(key, value) {
    this.store[key] = value;
  };
  return InMemoryStorage2;
}();
var inMemoryStorage = new InMemoryStorage();
function localStorage() {
  if (typeof self === "object" && self.indexedDB) {
    return new IndexedDbStorage();
  }
  if (typeof window === "object" && window.localStorage) {
    return window.localStorage;
  }
  return inMemoryStorage;
}
function fromCognitoIdentityPool(_a) {
  var _this = this;
  var accountId = _a.accountId, _b = _a.cache, cache = _b === void 0 ? localStorage() : _b, client = _a.client, customRoleArn = _a.customRoleArn, identityPoolId = _a.identityPoolId, logins = _a.logins, _c = _a.userIdentifier, userIdentifier = _c === void 0 ? !logins || Object.keys(logins).length === 0 ? "ANONYMOUS" : void 0 : _c;
  var cacheKey = userIdentifier ? "aws:cognito-identity-credentials:" + identityPoolId + ":" + userIdentifier : void 0;
  var provider = function() {
    return tslib.exports.__awaiter(_this, void 0, void 0, function() {
      var identityId, _a2, _b2, IdentityId, _c2, _d, _e, _f;
      var _g;
      return tslib.exports.__generator(this, function(_h) {
        switch (_h.label) {
          case 0:
            _a2 = cacheKey;
            if (!_a2)
              return [3, 2];
            return [4, cache.getItem(cacheKey)];
          case 1:
            _a2 = _h.sent();
            _h.label = 2;
          case 2:
            identityId = _a2;
            if (!!identityId)
              return [3, 7];
            _d = (_c2 = client).send;
            _e = GetIdCommand.bind;
            _g = {
              AccountId: accountId,
              IdentityPoolId: identityPoolId
            };
            if (!logins)
              return [3, 4];
            return [4, resolveLogins(logins)];
          case 3:
            _f = _h.sent();
            return [3, 5];
          case 4:
            _f = void 0;
            _h.label = 5;
          case 5:
            return [4, _d.apply(_c2, [new (_e.apply(GetIdCommand, [void 0, (_g.Logins = _f, _g)]))()])];
          case 6:
            _b2 = _h.sent().IdentityId, IdentityId = _b2 === void 0 ? throwOnMissingId() : _b2;
            identityId = IdentityId;
            if (cacheKey) {
              Promise.resolve(cache.setItem(cacheKey, identityId)).catch(function() {
              });
            }
            _h.label = 7;
          case 7:
            provider = fromCognitoIdentity({
              client,
              customRoleArn,
              logins,
              identityId
            });
            return [2, provider()];
        }
      });
    });
  };
  return function() {
    return provider().catch(function(err) {
      return tslib.exports.__awaiter(_this, void 0, void 0, function() {
        return tslib.exports.__generator(this, function(_a2) {
          if (cacheKey) {
            Promise.resolve(cache.removeItem(cacheKey)).catch(function() {
            });
          }
          throw err;
        });
      });
    });
  };
}
function throwOnMissingId() {
  throw new ProviderError("Response from Amazon Cognito contained no identity ID");
}
var __assign = globalThis && globalThis.__assign || function() {
  __assign = Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s)
        if (Object.prototype.hasOwnProperty.call(s, p))
          t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __awaiter = globalThis && globalThis.__awaiter || function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = globalThis && globalThis.__generator || function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1)
      throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f)
      throw new TypeError("Generator is already executing.");
    while (_)
      try {
        if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
          return t;
        if (y = 0, t)
          op = [op[0] & 2, t.value];
        switch (op[0]) {
          case 0:
          case 1:
            t = op;
            break;
          case 4:
            _.label++;
            return { value: op[1], done: false };
          case 5:
            _.label++;
            y = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            if (t[2])
              _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e) {
        op = [6, e];
        y = 0;
      } finally {
        f = t = 0;
      }
    if (op[0] & 5)
      throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
var logger = new ConsoleLogger("Credentials");
var CREDENTIALS_TTL = 50 * 60 * 1e3;
var COGNITO_IDENTITY_KEY_PREFIX = "CognitoIdentityId-";
var CredentialsClass = function() {
  function CredentialsClass2(config) {
    this._gettingCredPromise = null;
    this._refreshHandlers = {};
    this.Auth = void 0;
    this.configure(config);
    this._refreshHandlers["google"] = GoogleOAuth.refreshGoogleToken;
    this._refreshHandlers["facebook"] = FacebookOAuth.refreshFacebookToken;
  }
  CredentialsClass2.prototype.getModuleName = function() {
    return "Credentials";
  };
  CredentialsClass2.prototype.getCredSource = function() {
    return this._credentials_source;
  };
  CredentialsClass2.prototype.configure = function(config) {
    if (!config)
      return this._config || {};
    this._config = Object.assign({}, this._config, config);
    var refreshHandlers = this._config.refreshHandlers;
    if (refreshHandlers) {
      this._refreshHandlers = __assign(__assign({}, this._refreshHandlers), refreshHandlers);
    }
    this._storage = this._config.storage;
    if (!this._storage) {
      this._storage = new StorageHelper().getStorage();
    }
    this._storageSync = Promise.resolve();
    if (typeof this._storage["sync"] === "function") {
      this._storageSync = this._storage["sync"]();
    }
    return this._config;
  };
  CredentialsClass2.prototype.get = function() {
    logger.debug("getting credentials");
    return this._pickupCredentials();
  };
  CredentialsClass2.prototype._getCognitoIdentityIdStorageKey = function(identityPoolId) {
    return "" + COGNITO_IDENTITY_KEY_PREFIX + identityPoolId;
  };
  CredentialsClass2.prototype._pickupCredentials = function() {
    logger.debug("picking up credentials");
    if (!this._gettingCredPromise || !this._gettingCredPromise.isPending()) {
      logger.debug("getting new cred promise");
      this._gettingCredPromise = makeQuerablePromise(this._keepAlive());
    } else {
      logger.debug("getting old cred promise");
    }
    return this._gettingCredPromise;
  };
  CredentialsClass2.prototype._keepAlive = function() {
    return __awaiter(this, void 0, void 0, function() {
      var cred, _a, Auth, user_1, session, refreshToken_1, refreshRequest, err_1;
      return __generator(this, function(_b) {
        switch (_b.label) {
          case 0:
            logger.debug("checking if credentials exists and not expired");
            cred = this._credentials;
            if (cred && !this._isExpired(cred) && !this._isPastTTL()) {
              logger.debug("credentials not changed and not expired, directly return");
              return [2, Promise.resolve(cred)];
            }
            logger.debug("need to get a new credential or refresh the existing one");
            _a = this.Auth, Auth = _a === void 0 ? Amplify.Auth : _a;
            if (!Auth || typeof Auth.currentUserCredentials !== "function") {
              return [2, Promise.reject("No Auth module registered in Amplify")];
            }
            if (!(!this._isExpired(cred) && this._isPastTTL()))
              return [3, 6];
            logger.debug("ttl has passed but token is not yet expired");
            _b.label = 1;
          case 1:
            _b.trys.push([1, 5, , 6]);
            return [4, Auth.currentUserPoolUser()];
          case 2:
            user_1 = _b.sent();
            return [4, Auth.currentSession()];
          case 3:
            session = _b.sent();
            refreshToken_1 = session.refreshToken;
            refreshRequest = new Promise(function(res, rej) {
              user_1.refreshSession(refreshToken_1, function(err, data) {
                return err ? rej(err) : res(data);
              });
            });
            return [4, refreshRequest];
          case 4:
            _b.sent();
            return [3, 6];
          case 5:
            err_1 = _b.sent();
            logger.debug("Error attempting to refreshing the session", err_1);
            return [3, 6];
          case 6:
            return [2, Auth.currentUserCredentials()];
        }
      });
    });
  };
  CredentialsClass2.prototype.refreshFederatedToken = function(federatedInfo) {
    logger.debug("Getting federated credentials");
    var provider = federatedInfo.provider, user = federatedInfo.user, token = federatedInfo.token, identity_id = federatedInfo.identity_id;
    var expires_at = federatedInfo.expires_at;
    expires_at = new Date(expires_at).getFullYear() === 1970 ? expires_at * 1e3 : expires_at;
    var that = this;
    logger.debug("checking if federated jwt token expired");
    if (expires_at > new Date().getTime()) {
      logger.debug("token not expired");
      return this._setCredentialsFromFederation({
        provider,
        token,
        user,
        identity_id,
        expires_at
      });
    } else {
      if (that._refreshHandlers[provider] && typeof that._refreshHandlers[provider] === "function") {
        logger.debug("getting refreshed jwt token from federation provider");
        return this._providerRefreshWithRetry({
          refreshHandler: that._refreshHandlers[provider],
          provider,
          user
        });
      } else {
        logger.debug("no refresh handler for provider:", provider);
        this.clear();
        return Promise.reject("no refresh handler for provider");
      }
    }
  };
  CredentialsClass2.prototype._providerRefreshWithRetry = function(_a) {
    var _this = this;
    var refreshHandler = _a.refreshHandler, provider = _a.provider, user = _a.user;
    var MAX_DELAY_MS2 = 10 * 1e3;
    return jitteredExponentialRetry(refreshHandler, [], MAX_DELAY_MS2).then(function(data) {
      logger.debug("refresh federated token sucessfully", data);
      return _this._setCredentialsFromFederation({
        provider,
        token: data.token,
        user,
        identity_id: data.identity_id,
        expires_at: data.expires_at
      });
    }).catch(function(e) {
      var isNetworkError = typeof e === "string" && e.toLowerCase().lastIndexOf("network error", e.length) === 0;
      if (!isNetworkError) {
        _this.clear();
      }
      logger.debug("refresh federated token failed", e);
      return Promise.reject("refreshing federation token failed: " + e);
    });
  };
  CredentialsClass2.prototype._isExpired = function(credentials) {
    if (!credentials) {
      logger.debug("no credentials for expiration check");
      return true;
    }
    logger.debug("are these credentials expired?", credentials);
    var ts = Date.now();
    var expiration = credentials.expiration;
    return expiration.getTime() <= ts;
  };
  CredentialsClass2.prototype._isPastTTL = function() {
    return this._nextCredentialsRefresh <= Date.now();
  };
  CredentialsClass2.prototype._setCredentialsForGuest = function() {
    return __awaiter(this, void 0, void 0, function() {
      var _a, identityPoolId, region, mandatorySignIn, identityId, _b, cognitoClient, credentials, cognitoIdentityParams, credentialsProvider;
      var _this = this;
      return __generator(this, function(_c) {
        switch (_c.label) {
          case 0:
            logger.debug("setting credentials for guest");
            _a = this._config, identityPoolId = _a.identityPoolId, region = _a.region, mandatorySignIn = _a.mandatorySignIn;
            if (mandatorySignIn) {
              return [2, Promise.reject("cannot get guest credentials when mandatory signin enabled")];
            }
            if (!identityPoolId) {
              logger.debug("No Cognito Identity pool provided for unauthenticated access");
              return [2, Promise.reject("No Cognito Identity pool provided for unauthenticated access")];
            }
            if (!region) {
              logger.debug("region is not configured for getting the credentials");
              return [2, Promise.reject("region is not configured for getting the credentials")];
            }
            _b = this;
            return [4, this._getGuestIdentityId()];
          case 1:
            identityId = _b._identityId = _c.sent();
            cognitoClient = new CognitoIdentityClient({
              region,
              customUserAgent: getAmplifyUserAgent()
            });
            credentials = void 0;
            if (identityId) {
              cognitoIdentityParams = {
                identityId,
                client: cognitoClient
              };
              credentials = fromCognitoIdentity(cognitoIdentityParams)();
            } else {
              credentialsProvider = function() {
                return __awaiter(_this, void 0, void 0, function() {
                  var IdentityId, cognitoIdentityParams2, credentialsFromCognitoIdentity;
                  return __generator(this, function(_a2) {
                    switch (_a2.label) {
                      case 0:
                        return [4, cognitoClient.send(new GetIdCommand({
                          IdentityPoolId: identityPoolId
                        }))];
                      case 1:
                        IdentityId = _a2.sent().IdentityId;
                        this._identityId = IdentityId;
                        cognitoIdentityParams2 = {
                          client: cognitoClient,
                          identityId: IdentityId
                        };
                        credentialsFromCognitoIdentity = fromCognitoIdentity(cognitoIdentityParams2);
                        return [2, credentialsFromCognitoIdentity()];
                    }
                  });
                });
              };
              credentials = credentialsProvider().catch(function(err) {
                return __awaiter(_this, void 0, void 0, function() {
                  return __generator(this, function(_a2) {
                    throw err;
                  });
                });
              });
            }
            return [2, this._loadCredentials(credentials, "guest", false, null).then(function(res) {
              return res;
            }).catch(function(e) {
              return __awaiter(_this, void 0, void 0, function() {
                var credentialsProvider2;
                var _this2 = this;
                return __generator(this, function(_a2) {
                  switch (_a2.label) {
                    case 0:
                      if (!(e.name === "ResourceNotFoundException" && e.message === "Identity '" + identityId + "' not found."))
                        return [3, 2];
                      logger.debug("Failed to load guest credentials");
                      return [4, this._removeGuestIdentityId()];
                    case 1:
                      _a2.sent();
                      credentialsProvider2 = function() {
                        return __awaiter(_this2, void 0, void 0, function() {
                          var IdentityId, cognitoIdentityParams2, credentialsFromCognitoIdentity;
                          return __generator(this, function(_a3) {
                            switch (_a3.label) {
                              case 0:
                                return [4, cognitoClient.send(new GetIdCommand({
                                  IdentityPoolId: identityPoolId
                                }))];
                              case 1:
                                IdentityId = _a3.sent().IdentityId;
                                this._identityId = IdentityId;
                                cognitoIdentityParams2 = {
                                  client: cognitoClient,
                                  identityId: IdentityId
                                };
                                credentialsFromCognitoIdentity = fromCognitoIdentity(cognitoIdentityParams2);
                                return [2, credentialsFromCognitoIdentity()];
                            }
                          });
                        });
                      };
                      credentials = credentialsProvider2().catch(function(err) {
                        return __awaiter(_this2, void 0, void 0, function() {
                          return __generator(this, function(_a3) {
                            throw err;
                          });
                        });
                      });
                      return [2, this._loadCredentials(credentials, "guest", false, null)];
                    case 2:
                      return [2, e];
                  }
                });
              });
            })];
        }
      });
    });
  };
  CredentialsClass2.prototype._setCredentialsFromFederation = function(params) {
    var provider = params.provider, token = params.token, identity_id = params.identity_id;
    var domains = {
      google: "accounts.google.com",
      facebook: "graph.facebook.com",
      amazon: "www.amazon.com",
      developer: "cognito-identity.amazonaws.com"
    };
    var domain = domains[provider] || provider;
    if (!domain) {
      return Promise.reject("You must specify a federated provider");
    }
    var logins = {};
    logins[domain] = token;
    var _a = this._config, identityPoolId = _a.identityPoolId, region = _a.region;
    if (!identityPoolId) {
      logger.debug("No Cognito Federated Identity pool provided");
      return Promise.reject("No Cognito Federated Identity pool provided");
    }
    if (!region) {
      logger.debug("region is not configured for getting the credentials");
      return Promise.reject("region is not configured for getting the credentials");
    }
    var cognitoClient = new CognitoIdentityClient({
      region,
      customUserAgent: getAmplifyUserAgent()
    });
    var credentials = void 0;
    if (identity_id) {
      var cognitoIdentityParams = {
        identityId: identity_id,
        logins,
        client: cognitoClient
      };
      credentials = fromCognitoIdentity(cognitoIdentityParams)();
    } else {
      var cognitoIdentityParams = {
        logins,
        identityPoolId,
        client: cognitoClient
      };
      credentials = fromCognitoIdentityPool(cognitoIdentityParams)();
    }
    return this._loadCredentials(credentials, "federated", true, params);
  };
  CredentialsClass2.prototype._setCredentialsFromSession = function(session) {
    var _this = this;
    logger.debug("set credentials from session");
    var idToken = session.getIdToken().getJwtToken();
    var _a = this._config, region = _a.region, userPoolId = _a.userPoolId, identityPoolId = _a.identityPoolId;
    if (!identityPoolId) {
      logger.debug("No Cognito Federated Identity pool provided");
      return Promise.reject("No Cognito Federated Identity pool provided");
    }
    if (!region) {
      logger.debug("region is not configured for getting the credentials");
      return Promise.reject("region is not configured for getting the credentials");
    }
    var key = "cognito-idp." + region + ".amazonaws.com/" + userPoolId;
    var logins = {};
    logins[key] = idToken;
    var cognitoClient = new CognitoIdentityClient({
      region,
      customUserAgent: getAmplifyUserAgent()
    });
    var credentialsProvider = function() {
      return __awaiter(_this, void 0, void 0, function() {
        var guestIdentityId, generatedOrRetrievedIdentityId, IdentityId, _a2, _b, AccessKeyId, Expiration, SecretKey, SessionToken, primaryIdentityId;
        return __generator(this, function(_c) {
          switch (_c.label) {
            case 0:
              return [4, this._getGuestIdentityId()];
            case 1:
              guestIdentityId = _c.sent();
              if (!!guestIdentityId)
                return [3, 3];
              return [4, cognitoClient.send(new GetIdCommand({
                IdentityPoolId: identityPoolId,
                Logins: logins
              }))];
            case 2:
              IdentityId = _c.sent().IdentityId;
              generatedOrRetrievedIdentityId = IdentityId;
              _c.label = 3;
            case 3:
              return [4, cognitoClient.send(new GetCredentialsForIdentityCommand({
                IdentityId: guestIdentityId || generatedOrRetrievedIdentityId,
                Logins: logins
              }))];
            case 4:
              _a2 = _c.sent(), _b = _a2.Credentials, AccessKeyId = _b.AccessKeyId, Expiration = _b.Expiration, SecretKey = _b.SecretKey, SessionToken = _b.SessionToken, primaryIdentityId = _a2.IdentityId;
              this._identityId = primaryIdentityId;
              if (!guestIdentityId)
                return [3, 6];
              logger.debug("The guest identity " + guestIdentityId + " has been successfully linked to the logins");
              if (guestIdentityId === primaryIdentityId) {
                logger.debug("The guest identity " + guestIdentityId + " has become the primary identity");
              }
              return [4, this._removeGuestIdentityId()];
            case 5:
              _c.sent();
              _c.label = 6;
            case 6:
              return [2, {
                accessKeyId: AccessKeyId,
                secretAccessKey: SecretKey,
                sessionToken: SessionToken,
                expiration: Expiration,
                identityId: primaryIdentityId
              }];
          }
        });
      });
    };
    var credentials = credentialsProvider().catch(function(err) {
      return __awaiter(_this, void 0, void 0, function() {
        return __generator(this, function(_a2) {
          throw err;
        });
      });
    });
    return this._loadCredentials(credentials, "userPool", true, null);
  };
  CredentialsClass2.prototype._loadCredentials = function(credentials, source, authenticated, info) {
    var _this = this;
    var that = this;
    return new Promise(function(res, rej) {
      credentials.then(function(credentials2) {
        return __awaiter(_this, void 0, void 0, function() {
          var user, provider, token, expires_at, identity_id;
          return __generator(this, function(_a) {
            switch (_a.label) {
              case 0:
                logger.debug("Load credentials successfully", credentials2);
                if (this._identityId && !credentials2.identityId) {
                  credentials2["identityId"] = this._identityId;
                }
                that._credentials = credentials2;
                that._credentials.authenticated = authenticated;
                that._credentials_source = source;
                that._nextCredentialsRefresh = new Date().getTime() + CREDENTIALS_TTL;
                if (source === "federated") {
                  user = Object.assign({ id: this._credentials.identityId }, info.user);
                  provider = info.provider, token = info.token, expires_at = info.expires_at, identity_id = info.identity_id;
                  try {
                    this._storage.setItem("aws-amplify-federatedInfo", JSON.stringify({
                      provider,
                      token,
                      user,
                      expires_at,
                      identity_id
                    }));
                  } catch (e) {
                    logger.debug("Failed to put federated info into auth storage", e);
                  }
                }
                if (!(source === "guest"))
                  return [3, 2];
                return [4, this._setGuestIdentityId(credentials2.identityId)];
              case 1:
                _a.sent();
                _a.label = 2;
              case 2:
                res(that._credentials);
                return [2];
            }
          });
        });
      }).catch(function(err) {
        if (err) {
          logger.debug("Failed to load credentials", credentials);
          logger.debug("Error loading credentials", err);
          rej(err);
          return;
        }
      });
    });
  };
  CredentialsClass2.prototype.set = function(params, source) {
    if (source === "session") {
      return this._setCredentialsFromSession(params);
    } else if (source === "federation") {
      return this._setCredentialsFromFederation(params);
    } else if (source === "guest") {
      return this._setCredentialsForGuest();
    } else {
      logger.debug("no source specified for setting credentials");
      return Promise.reject("invalid source");
    }
  };
  CredentialsClass2.prototype.clear = function() {
    return __awaiter(this, void 0, void 0, function() {
      return __generator(this, function(_a) {
        this._credentials = null;
        this._credentials_source = null;
        logger.debug("removing aws-amplify-federatedInfo from storage");
        this._storage.removeItem("aws-amplify-federatedInfo");
        return [2];
      });
    });
  };
  CredentialsClass2.prototype._getGuestIdentityId = function() {
    return __awaiter(this, void 0, void 0, function() {
      var identityPoolId, e_1;
      return __generator(this, function(_a) {
        switch (_a.label) {
          case 0:
            identityPoolId = this._config.identityPoolId;
            _a.label = 1;
          case 1:
            _a.trys.push([1, 3, , 4]);
            return [4, this._storageSync];
          case 2:
            _a.sent();
            return [2, this._storage.getItem(this._getCognitoIdentityIdStorageKey(identityPoolId))];
          case 3:
            e_1 = _a.sent();
            logger.debug("Failed to get the cached guest identityId", e_1);
            return [3, 4];
          case 4:
            return [2];
        }
      });
    });
  };
  CredentialsClass2.prototype._setGuestIdentityId = function(identityId) {
    return __awaiter(this, void 0, void 0, function() {
      var identityPoolId, e_2;
      return __generator(this, function(_a) {
        switch (_a.label) {
          case 0:
            identityPoolId = this._config.identityPoolId;
            _a.label = 1;
          case 1:
            _a.trys.push([1, 3, , 4]);
            return [4, this._storageSync];
          case 2:
            _a.sent();
            this._storage.setItem(this._getCognitoIdentityIdStorageKey(identityPoolId), identityId);
            return [3, 4];
          case 3:
            e_2 = _a.sent();
            logger.debug("Failed to cache guest identityId", e_2);
            return [3, 4];
          case 4:
            return [2];
        }
      });
    });
  };
  CredentialsClass2.prototype._removeGuestIdentityId = function() {
    return __awaiter(this, void 0, void 0, function() {
      var identityPoolId;
      return __generator(this, function(_a) {
        identityPoolId = this._config.identityPoolId;
        logger.debug("removing " + this._getCognitoIdentityIdStorageKey(identityPoolId) + " from storage");
        this._storage.removeItem(this._getCognitoIdentityIdStorageKey(identityPoolId));
        return [2];
      });
    });
  };
  CredentialsClass2.prototype.shear = function(credentials) {
    return {
      accessKeyId: credentials.accessKeyId,
      sessionToken: credentials.sessionToken,
      secretAccessKey: credentials.secretAccessKey,
      identityId: credentials.identityId,
      authenticated: credentials.authenticated
    };
  };
  return CredentialsClass2;
}();
var Credentials = new CredentialsClass(null);
Amplify.register(Credentials);
export { Amplify as A, getHostHeaderPlugin as B, ConsoleLogger as C, DEFAULT_MAX_ATTEMPTS as D, getLoggerPlugin as E, FetchHttpHandler as F, getUserAgentPlugin as G, Hub as H, resolveHostHeaderConfig as I, JS as J, getSerdePlugin as K, Command as L, buildQueryString as M, SignatureV4 as N, Platform as O, Parser$1 as P, getAmplifyUserAgent as Q, StorageHelper as S, Credentials as a, browserOrNode as b, HttpRequest as c, build$3 as d, toHex as e, fromHex as f, fromUtf8$1 as g, fromBase64 as h, toBase64 as i, calculateBodyLength as j, defaultUserAgent as k, invalidProvider as l, build$4 as m, toUtf8 as n, HttpResponse as o, parseUrl as p, Client as q, resolveRegionConfig as r, streamCollector as s, tslib as t, resolveEndpointsConfig as u, resolveAwsAuthConfig as v, resolveRetryConfig as w, resolveUserAgentConfig as x, getRetryPlugin as y, getContentLengthPlugin as z };
//# sourceMappingURL=Credentials.js.map
